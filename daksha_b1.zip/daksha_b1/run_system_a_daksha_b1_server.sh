#!/usr/bin/env bash
set -euo pipefail

cd ~/Desktop/I/grootn1.7/Isaac-GR00T
source .venv/bin/activate
# System A: the GR00T policy server for the Daksha B1 checkpoint.
#
# MODEL_PATH resolves to the HIGHEST-numbered checkpoint in RUN_DIR rather than a
# hardcoded step. This run trains with save_total_limit=2, so only the two most
# recent checkpoints exist at any moment: a pinned step number silently rots into
# a FileNotFoundError as soon as training rolls past it. Pin one explicitly by
# exporting MODEL_PATH if you want a specific step (and copy it out of the output
# directory first, or the trainer will delete it).
RUN_DIR="${RUN_DIR:-/home/physicalai/Desktop/I/grootn1.7/Isaac-GR00T/output/pick_place_blue/checkpoint-70000}"
if [ -z "${MODEL_PATH:-}" ]; then
  MODEL_PATH="$(find "$RUN_DIR" -maxdepth 1 -type d -name 'checkpoint-*' -print \
    | sort -t- -k2 -n | tail -1)"
  if [ -z "$MODEL_PATH" ]; then
    echo "No checkpoint-* directory under $RUN_DIR" >&2
    exit 1
  fi
  echo "Serving latest checkpoint: $MODEL_PATH"
fi

python gr00t/eval/run_gr00t_server.py \
  --model-path "$MODEL_PATH" \
  --embodiment-tag DAKSHA_B1 \
  --host "${HOST:-0.0.0.0}" \
  --port "${PORT:-5555}"
