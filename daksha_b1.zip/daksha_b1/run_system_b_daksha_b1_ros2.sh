#!/usr/bin/env bash
set -euo pipefail

cd ~/Desktop/I/grootn1.7/Isaac-GR00T
source .venv/bin/activate

# The robot's arm/camera nodes live on ROS_DOMAIN_ID=33. Pin it here instead of
# inheriting it: the VS Code server environment exports 35, so a bridge launched from
# a non-interactive shell (task, debug launch, nested shell) lands on an empty DDS
# graph and sits forever in "Waiting for inputs -> waiting on right=..., left=..." even
# though `ros2 topic echo` works fine in your own terminal. ~/.bashrc also no longer
# sources ROS, so source it here for the same reason.
export ROS_DOMAIN_ID=33
export RMW_IMPLEMENTATION="${RMW_IMPLEMENTATION:-rmw_cyclonedds_cpp}"
if [ -z "${AMENT_PREFIX_PATH:-}" ]; then
  set +u  # ROS setup.bash trips over unbound vars
  source /opt/ros/humble/setup.bash
  set -u
fi

# System B: ROS2 bridge (publishes JointState on /joint_cmd)
#
# ---------------------------------------------------------------------------
# THE ONE SOURCE OF TRUTH FOR EVERYTHING BELOW
#   dataset     /home/physicalai/Desktop/I/barani/pick_place_blue_old
#               288 episodes, 115 025 frames, 30 fps, one task
#   checkpoint  output/pick_place_blue_old/checkpoint-40000  (served by System A)
#   embodiment  DAKSHA_B1, 16 DoF, RIGHT-FIRST key order:
#               right_arm x7, right_gripper x1, left_arm x7, left_gripper x1
#
# Verified against the checkpoint's own processor_config.json (action delta_indices
# = 16 steps; video keys zed_right/zed_left/wrist_right/wrist_left) and its
# experiment_cfg/dataset_statistics.json, both read from the checkpoint ROOT for this
# run rather than the processor/ subdirectory. If you retrain, re-derive the envelope
# below from the NEW checkpoint's statistics (recipes in eval_daksha_b1_ros2.py).
# ---------------------------------------------------------------------------

# Safety envelope, right-first, derived from checkpoint-40000's own action+state
# statistics (experiment_cfg/dataset_statistics.json -> daksha_b1), which are the
# recorded ranges of pick_place_blue_old. Padding: arms +/- max(10 % of range,
# 0.05 rad); grippers +/- 0.01 rad.
#
#   WHY THIS MATTERS: the model min-max-denormalizes into precisely those statistics
#   ranges, so a clamp NARROWER than them silently truncates real predictions. The
#   previous envelope here came from the pick_place_blue / checkpoint-70000 run and
#   was tighter than this checkpoint's trained range on ALL 16 channels -- worst on
#   right_joint_4 (floor 0.208 vs a trained -0.116), right_joint_5 (floor 1.057 vs
#   0.803) and left_joint_6 (range covered 62 %), which reads at the robot as a policy
#   that refuses to reach.
#
#   RETRAINED? Re-derive from the new checkpoint before running. Limits from another
#   dataset can be disjoint from this one's poses.
JOINT_MIN_CSV="${JOINT_MIN_CSV:--1.34166,-0.64882,-0.7681,-0.11601,0.80276,-0.57938,-1.78157,-0.01023,-1.74494,-0.41417,-0.65831,-1.90996,-2.19146,-1.18535,-1.73892,-0.05402}"
JOINT_MAX_CSV="${JOINT_MAX_CSV:-1.68663,0.35518,0.54112,2.03373,2.30639,0.59319,1.74168,0.05407,1.39399,0.35895,0.65183,0.06151,-0.74441,0.44797,2.08253,0.01}"
# Per control STEP at --control-hz 30 (the dataset fps). 1.5x the per-joint p99.9 of the
# recorded frame-to-frame action delta over pick_place_blue_old's 288 episodes
# (114 737 steps), floored at 0.02. Scale by (30/control_hz) if you change the rate.
# Grippers keep 0.06 -- above their full 0.044 rad travel -- so a grasp is never
# throttled.
#
# Re-measured against THIS dataset. The values carried over from pick_place_blue were
# under the demonstrated speed on four channels, worst on right_joint_6 (0.020 vs the
# 0.048 needed) and left_joint_6 (0.028 vs 0.053) -- a joint capped at half its
# demonstrated rate does not fail, it just lags the chunk and the motion looks damped.
MAX_STEP_DELTA_CSV="${MAX_STEP_DELTA_CSV:-0.108,0.054,0.058,0.092,0.058,0.048,0.163,0.06,0.097,0.037,0.058,0.09,0.06,0.053,0.152,0.06}"

# Must match meta/tasks.jsonl verbatim. pick_place_blue_old has exactly one task
# (task_index 0); feeding a different sentence is an unnecessary distribution shift on
# the language input.
# NOTE: capital P and a TRAILING PERIOD are part of this string -- do not drop them, and
# do not pass the old pick_place_brown sentence from your shell; an override wins here.
LANG_INSTRUCTION="${LANG_INSTRUCTION:-Pick the blue box from the table.}"

# Replanning is DISABLED (no --replan-at flag, bridge default 0): each 16-step chunk
# is executed to completion, then the next one is predicted. This is plain open-loop
# chunk playback -- the "normal prediction" behaviour.
#
# What that costs, so the trade-off is on the record: the arm publishes hold for the
# duration of every policy round trip, because the queue is empty while inference runs.
# At ~172 ms inference and 30 Hz that is ~5 ticks of stationary arm between chunks, so
# motion arrives in bursts of 16 steps separated by a short pause. Chunk boundaries are
# clean, though: each chunk is re-anchored to the pose measured at its own plan time.
#
# If the pauses ever become a problem, add --replan-at N to overlap inference with the
# tail of the current chunk, sized as ceil(measured_inference_s * CONTROL_HZ) -- read
# the measurement off the "inference N ms" log line. Note that replanning discards the
# unexecuted tail of the chunk, and because this checkpoint predicts the arms as
# RELATIVE actions the displacement accumulates toward the END of the chunk, so an
# oversized N throws away most of the motion.

# CAMERA TRANSPORT IS PER CAMERA, hence --image-transport auto: each topic below is
# used verbatim and its message type comes from the "/compressed" suffix.
#   ZED   -> compressed. Its raw 1280x720 bgra8 stream only lands at ~0.6 Hz here
#            (3.7 MB/msg); the JPEG topic manages ~3.5 Hz.
#   WRIST -> RAW, deliberately. The two RealSense nodes DO publish
#            /{left,right}/camera/color/image_raw/compressed at 23 Hz, but every
#            message has an empty `data` field (only `format` is filled in), because
#            image_transport publishes the message even when its JPEG encode step
#            fails. Subscribing there is what produced the endless
#            "Waiting for inputs -> waiting on camera topics: wrist_right, wrist_left".
#            image_raw itself is healthy: 640x480 rgb8 at 23 Hz.
#   If the RealSense compressed publisher is ever fixed, add the "/compressed" suffix
#   back to the two wrist topics -- nothing else needs to change.

# The three CSV flags use --flag=value, not --flag value: JOINT_MIN_CSV starts with a
# minus sign and argparse would otherwise read it as an option name, not a value.
python gr00t/eval/real_robot/daksha_b1/eval_daksha_b1_ros2.py \
  --joint-min-csv="${JOINT_MIN_CSV}" \
  --joint-max-csv="${JOINT_MAX_CSV}" \
  --max-step-delta-csv="${MAX_STEP_DELTA_CSV}" \
  --policy-host "${POLICY_HOST:-127.0.0.1}" \
  --policy-port "${POLICY_PORT:-5555}" \
  --control-hz "${CONTROL_HZ:-30}" \
  --action-horizon "${ACTION_HORIZON:-16}" \
  --image-max-edge "${IMAGE_MAX_EDGE:-256}" \
  --joint-state-topic "${JOINT_STATE_TOPIC:-/joint_states}" \
  --right-joint-state-topic "${RIGHT_JOINT_STATE_TOPIC:-/RightArmSystem_ordered_joint_states}" \
  --left-joint-state-topic "${LEFT_JOINT_STATE_TOPIC:-/LeftArmSystem_ordered_joint_states}" \
  --cmd-topic "${CMD_TOPIC:-/joint_cmd_pri}" \
  --zed-right-topic "${ZED_RIGHT_TOPIC:-/zed/zed_node/right/color/rect/image/compressed}" \
  --zed-left-topic "${ZED_LEFT_TOPIC:-/zed/zed_node/left/color/rect/image/compressed}" \
  --right-wrist-topic "${RIGHT_WRIST_TOPIC:-/right/camera/color/image_raw}" \
  --left-wrist-topic "${LEFT_WRIST_TOPIC:-/left/camera/color/image_raw}" \
  --right-wrist-camera-key "wrist_right" \
  --left-wrist-camera-key "wrist_left" \
  --image-transport "${IMAGE_TRANSPORT:-auto}" \
  --state-obs-keys-csv "${STATE_OBS_KEYS_CSV:-right_joint_1,right_joint_2,right_joint_3,right_joint_4,right_joint_5,right_joint_6,right_joint_7,right_gripper_right_joint,left_joint_1,left_joint_2,left_joint_3,left_joint_4,left_joint_5,left_joint_6,left_joint_7,left_gripper_left_joint}" \
  --action-keys-csv "${ACTION_KEYS_CSV:-right_joint_1,right_joint_2,right_joint_3,right_joint_4,right_joint_5,right_joint_6,right_joint_7,right_gripper_right_joint,left_joint_1,left_joint_2,left_joint_3,left_joint_4,left_joint_5,left_joint_6,left_joint_7,left_gripper_left_joint}" \
  --lang-instruction "${LANG_INSTRUCTION}"