#!/usr/bin/env python3
"""Preflight for the OpenArm B1 bridge: is the robot parked where the policy can act?

Derives every bound from the DATASET and the CHECKPOINT at runtime, so it can never
disagree with what the runner script passes, then reads the live joint states and says
which joints are wrong, by how much, and what the bridge would do about each one.

  cd /home/physicalai/Desktop/I/groot && source .venv/bin/activate
  ROS_DOMAIN_ID=55 RMW_IMPLEMENTATION=rmw_cyclonedds_cpp \
    python examples/openarm_b1/check_start_pose.py

Reads only. Nothing is published, so this cannot move the arm.
"""
from __future__ import annotations

import argparse
import glob
import time

import numpy as np
import pandas as pd

NAMES = ("left_joint_1 left_joint_2 left_joint_3 left_joint_4 left_joint_5 left_joint_6 "
         "left_joint_7 left_gripper_left_joint right_joint_1 right_joint_2 right_joint_3 "
         "right_joint_4 right_joint_5 right_joint_6 right_joint_7 "
         "right_gripper_right_joint").split()
GRIP = np.zeros(16, bool)
GRIP[7] = GRIP[15] = True


def derive(dataset: str) -> dict[str, np.ndarray]:
    """Recompute the runner script's six CSVs from the dataset's own parquet files."""
    files = sorted(glob.glob(f"{dataset}/data/chunk-*/episode_*.parquet"))
    if not files:
        raise SystemExit(f"no episodes under {dataset}/data/chunk-*/")
    states, actions, deltas, first = [], [], [], []
    for f in files:
        df = pd.read_parquet(f, columns=["observation.state", "action"])
        s = np.stack(df["observation.state"].values).astype(np.float64)
        a = np.stack(df["action"].values).astype(np.float64)
        states.append(s)
        actions.append(a)
        deltas.append(np.abs(np.diff(a, axis=0)))
        first.append(s[0])
    s = np.concatenate(states)
    a = np.concatenate(actions)
    d = np.concatenate(deltas)
    f0 = np.stack(first)

    lo = np.minimum(s.min(0), a.min(0))
    hi = np.maximum(s.max(0), a.max(0))
    pad = np.maximum(0.1 * (hi - lo), np.where(GRIP, 0.01, 0.05))
    jmin, jmax = lo - pad, hi + pad
    # A negative right-gripper command over-closes the jaw against its stop.
    jmin[15] = max(jmin[15], 0.0)

    msd = np.maximum(np.round(1.5 * np.percentile(d, 99.9, axis=0), 3), 0.02)
    msd[GRIP] = 0.06  # never throttle a grasp

    p01, p99 = np.percentile(f0, 1, axis=0), np.percentile(f0, 99, axis=0)
    spad = np.maximum(0.1 * (p99 - p01), 0.05)
    return {
        "joint_min": jmin, "joint_max": jmax, "max_step_delta": msd,
        "start_min": p01 - spad, "start_max": p99 + spad,
        "home": np.median(f0, axis=0), "episodes": len(files), "frames": len(s),
    }


def read_live(timeout_s: float) -> np.ndarray:
    import rclpy
    from rclpy.node import Node
    from rclpy.qos import qos_profile_sensor_data
    from sensor_msgs.msg import JointState

    class Reader(Node):
        def __init__(self) -> None:
            super().__init__("openarm_b1_start_pose_check")
            self.seen: dict[str, float] = {}
            for topic in ("/LeftArmSystem_ordered_joint_states",
                          "/RightArmSystem_ordered_joint_states"):
                self.create_subscription(JointState, topic, self._cb, qos_profile_sensor_data)

        def _cb(self, msg: JointState) -> None:
            for name, pos in zip(msg.name, msg.position):
                self.seen[name.split("/")[-1]] = float(pos)

    rclpy.init()
    node = Reader()
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline and not all(n in node.seen for n in NAMES):
        rclpy.spin_once(node, timeout_sec=0.1)
    seen = dict(node.seen)
    node.destroy_node()
    rclpy.shutdown()

    missing = [n for n in NAMES if n not in seen]
    if missing:
        raise SystemExit(
            f"never received {len(missing)} of 16 joints (e.g. {', '.join(missing[:4])}).\n"
            "  The arm drivers are down, or ROS_DOMAIN_ID/RMW_IMPLEMENTATION point at the\n"
            "  wrong DDS graph. Check: ros2 topic list | grep ordered_joint_states"
        )
    return np.array([seen[n] for n in NAMES], dtype=np.float64)


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--dataset", default="/home/physicalai/Desktop/I/barani/pick_box_2")
    p.add_argument("--timeout-s", type=float, default=15.0)
    p.add_argument("--print-csvs", action="store_true",
                   help="also print the six export lines for the runner script")
    args = p.parse_args()

    b = derive(args.dataset)
    print(f"dataset: {args.dataset}  ({b['episodes']} episodes, {b['frames']} frames)\n")

    if args.print_csvs:
        csv = lambda v, n=5: ",".join(f"{x:.{n}f}" for x in v)
        for name, key, nd in (("JOINT_MIN_CSV", "joint_min", 5),
                              ("JOINT_MAX_CSV", "joint_max", 5),
                              ("MAX_STEP_DELTA_CSV", "max_step_delta", 3),
                              ("START_POSE_MIN_CSV", "start_min", 5),
                              ("START_POSE_MAX_CSV", "start_max", 5),
                              ("START_POSE_HOME_CSV", "home", 5)):
            print(f'export {name}="{csv(b[key], nd)}"')
        print()

    live = read_live(args.timeout_s)
    forced, off_start = [], []
    print(f"{'joint':<26}{'live':>9}{'target':>9}{'error':>9}   verdict")
    for i, name in enumerate(NAMES):
        v, home = live[i], b["home"][i]
        if v < b["joint_min"][i] or v > b["joint_max"][i]:
            bound = b["joint_min"][i] if v < b["joint_min"][i] else b["joint_max"][i]
            steps = int(np.ceil(abs(bound - v) / b["max_step_delta"][i]))
            verdict = (f"OUTSIDE LIMIT BOX -> bridge force-walks it to {bound:+.3f} "
                       f"over {steps} ticks, whatever the policy asks")
            forced.append(name)
        elif v < b["start_min"][i] or v > b["start_max"][i]:
            verdict = (f"outside episode-start range "
                       f"[{b['start_min'][i]:+.3f}, {b['start_max'][i]:+.3f}] -- policy "
                       "was never conditioned here")
            off_start.append(name)
        else:
            verdict = "ok"
        print(f"{name:<26}{v:>9.3f}{home:>9.3f}{v - home:>+9.3f}   {verdict}")

    print()
    if forced:
        print(f"BLOCKING: {len(forced)} joint(s) outside the limit box: {', '.join(forced)}")
        print("  The safety clamp drives these to the nearest bound on its own. That motion")
        print("  is not the policy reaching -- it is the arm crawling to the corner of the")
        print("  box, which is what 'the arm goes backwards' looks like.")
    if off_start:
        print(f"WARNING: {len(off_start)} joint(s) outside the episode-start range: "
              f"{', '.join(off_start)}")
        print("  The arms are RELATIVE actions, so the policy predicts a delta FROM this")
        print("  pose. It never saw this one, so it under-commands and the arm wanders.")
    if not forced and not off_start:
        print("READY: all 16 joints are inside the trained range and the episode-start range.")
        return 0

    print("\nPark the arms here first:")
    print("  left  " + ", ".join(f"{b['home'][i]:+.3f}" for i in range(7))
          + f"   gripper {b['home'][7]:+.3f}")
    print("  right " + ", ".join(f"{b['home'][i]:+.3f}" for i in range(8, 15))
          + f"   gripper {b['home'][15]:+.3f}")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
