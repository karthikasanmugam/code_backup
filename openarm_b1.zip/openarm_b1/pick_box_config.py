"""Modality config for the `pick_box` dataset on GR00T N1.6.

Dataset: /home/physicalai/Desktop/I/barani/pick_box
  - 16-DoF bimanual state/action, LEFT arm first:
        left_arm 0:7, left_gripper 7:8, right_arm 8:15, right_gripper 15:16
  - 3 cameras: observation.images.world / wrist_right / wrist_left

This differs from `openarm_b1_config.py`, which targets the older 4-camera
(zed_right/zed_left/right_wrist/left_wrist) right-arm-first datasets. That file is
left untouched; load this one instead via --modality_config_path.

The `video` modality_keys below must match the keys in the dataset's
meta/modality.json["video"] exactly, or LeRobotEpisodeLoader raises a ValueError.
"""

from copy import deepcopy

from gr00t.configs.data.embodiment_configs import MODALITY_CONFIGS, register_modality_config
from gr00t.data.embodiment_tags import EmbodimentTag
from gr00t.data.types import (
    ActionConfig,
    ActionFormat,
    ActionRepresentation,
    ActionType,
    ModalityConfig,
)


pick_box_config = {
    "video": ModalityConfig(
        delta_indices=[0],
        modality_keys=["world", "wrist_right", "wrist_left"],
    ),
    "state": ModalityConfig(
        delta_indices=[0],
        modality_keys=[
            "left_arm",
            "left_gripper",
            "right_arm",
            "right_gripper",
        ],
    ),
    "action": ModalityConfig(
        delta_indices=list(range(0, 8)),
        modality_keys=[
            "left_arm",
            "left_gripper",
            "right_arm",
            "right_gripper",
        ],
        # One ActionConfig per modality_key, in the same order.
        # Arms are RELATIVE, grippers ABSOLUTE -- this must stay in sync with
        # meta/relative_stats.json, which holds relative stats for exactly
        # `left_arm` and `right_arm`.
        action_configs=[
            ActionConfig(
                rep=ActionRepresentation.RELATIVE,
                type=ActionType.NON_EEF,
                format=ActionFormat.DEFAULT,
            ),
            ActionConfig(
                rep=ActionRepresentation.ABSOLUTE,
                type=ActionType.NON_EEF,
                format=ActionFormat.DEFAULT,
            ),
            ActionConfig(
                rep=ActionRepresentation.RELATIVE,
                type=ActionType.NON_EEF,
                format=ActionFormat.DEFAULT,
            ),
            ActionConfig(
                rep=ActionRepresentation.ABSOLUTE,
                type=ActionType.NON_EEF,
                format=ActionFormat.DEFAULT,
            ),
        ],
    ),
    "language": ModalityConfig(
        delta_indices=[0],
        modality_keys=["annotation.human.task_description"],
    ),
}

# Register under the OPENARM_B1 tag (already present in gr00t/data/embodiment_tags.py).
if EmbodimentTag.OPENARM_B1.value not in MODALITY_CONFIGS:
    register_modality_config(deepcopy(pick_box_config), embodiment_tag=EmbodimentTag.OPENARM_B1)
else:
    MODALITY_CONFIGS[EmbodimentTag.OPENARM_B1.value] = deepcopy(pick_box_config)

# Alias, so --embodiment_tag NEW_EMBODIMENT also works with this dataset.
MODALITY_CONFIGS[EmbodimentTag.NEW_EMBODIMENT.value] = deepcopy(pick_box_config)
