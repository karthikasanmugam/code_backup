from copy import deepcopy

from gr00t.configs.data.embodiment_configs import MODALITY_CONFIGS, register_modality_config
from gr00t.data.embodiment_tags import EmbodimentTag
from gr00t.data.types import (
    ActionConfig,
    ActionFormat,
    ActionRepresentation,
    ActionType,
    ModalityConfig,
)


openarm_b1_config = {
    "video": ModalityConfig(
        delta_indices=[0],
        modality_keys=["zed_right", "zed_left", "right_wrist", "left_wrist"],
    ),
    "state": ModalityConfig(
        delta_indices=[0],
        modality_keys=[
            "right_arm",
            "right_gripper",
            "left_arm",
            "left_gripper",
        ],
    ),
    "action": ModalityConfig(
        delta_indices=list(range(0, 8)),
        modality_keys=[
            "right_arm",
            "right_gripper",
            "left_arm",
            "left_gripper",
        ],
        action_configs=[
            ActionConfig(
                rep=ActionRepresentation.RELATIVE,
                type=ActionType.NON_EEF,
                format=ActionFormat.DEFAULT,
            ),
            ActionConfig(
                rep=ActionRepresentation.ABSOLUTE,
                type=ActionType.NON_EEF,
                format=ActionFormat.DEFAULT,
            ),
            ActionConfig(
                rep=ActionRepresentation.RELATIVE,
                type=ActionType.NON_EEF,
                format=ActionFormat.DEFAULT,
            ),
            ActionConfig(
                rep=ActionRepresentation.ABSOLUTE,
                type=ActionType.NON_EEF,
                format=ActionFormat.DEFAULT,
            ),
        ],
    ),
    "language": ModalityConfig(
        delta_indices=[0],
        modality_keys=["annotation.human.task_description"],
    ),
}

# Register dedicated OpenArm B1 tag.
if EmbodimentTag.OPENARM_B1.value not in MODALITY_CONFIGS:
    register_modality_config(deepcopy(openarm_b1_config), embodiment_tag=EmbodimentTag.OPENARM_B1)
else:
    MODALITY_CONFIGS[EmbodimentTag.OPENARM_B1.value] = deepcopy(openarm_b1_config)

# Keep alias for compatibility with existing custom flows.
MODALITY_CONFIGS[EmbodimentTag.NEW_EMBODIMENT.value] = deepcopy(openarm_b1_config)
