#!/usr/bin/env bash
# System B (robot machine) for the two_box_pick_8chunk checkpoint.
#
#   bash examples/openarm_b1/run_system_b_two_box_pick_ros2.sh
#
# Start System A first, pointed at the MATCHING run:
#   RUN_DIR=/home/physicalai/Desktop/I/groot/outputs/two_box_pick_8chunk \
#     bash examples/openarm_b1/run_system_a_openarm_b1_server.sh
#
# This is a thin wrapper. Every setting in run_system_b_openarm_b1_ros2.sh is
# env-overridable, so this file supplies only what differs between two_box_pick and
# pick_box_2 and then hands off. Everything else is already right for this checkpoint:
#   CONTROL_HZ=30      two_box_pick meta/info.json fps = 30
#   ACTION_HORIZON=8   checkpoint action delta_indices = 8
#   IMAGE_SIZE=320x240 two_box_pick video shape = [240, 320, 3], same as pick_box_2
#   camera topics      identical in both datasets' ros2_topics.json
#   REPLAN_AT          whatever the base script carries; this is a LATENCY tuning knob,
#                      not a task one, and this checkpoint is the same 3-camera model
#                      at the same cost. Re-derive as ceil(measured_inference_s * 30)
#                      from the "inference N ms" log line if the serving box changes.
set -euo pipefail

REPO_ROOT="${REPO_ROOT:-/home/physicalai/Desktop/I/groot}"

# two_box_pick/meta/tasks.jsonl (task_index 0), verbatim. Feeding pick_box_2's sentence
# here is an unnecessary distribution shift on the language input -- and this task is a
# different one: TWO boxes, and a target ("the blue box") the other task never names.
export LANG_INSTRUCTION="${LANG_INSTRUCTION:-Pick up the brown box on the right-hand side and place it into the blue box. Then pick up the black box on the left-hand side and place it into the blue box.}"

# outputs/two_box_pick_8chunk/checkpoint-50000/experiment_cfg/dataset_statistics.json
# -> openarm_b1: union of the action and state ranges widened by max(10% of range,
# 0.05) for arms / 0.01 for grippers, right-gripper min floored at 0.0 (a negative
# command over-closes the jaw against its stop).
#
# THIS TASK IS GENUINELY BIMANUAL -- that is the headline difference from pick_box_2.
# The left arm executes the second pick, so its trained range is now full-scale
# (left_joint_1 spans 2.47 rad, left_joint_7 spans 3.01 rad) instead of the few
# hundredths of a radian it spanned in pick_box. pick_box_2's limits would pin every
# left-arm joint at a bound for the entire episode.
export JOINT_MIN_CSV="${JOINT_MIN_CSV:--1.42353,-0.54347,-0.53166,-1.98392,0.86102,-1.46480,-1.61298,-0.05567,-1.47589,-0.62254,-0.62811,-0.45344,0.64044,-0.70855,-1.70657,0.0}"
export JOINT_MAX_CSV="${JOINT_MAX_CSV:-1.54012,0.19818,1.03483,-0.45033,2.08885,0.57662,2.00415,0.01061,1.73949,0.19884,1.00032,2.02424,2.12222,1.51695,1.54409,0.05492}"

# 1.5x the per-joint p99.9 frame-to-frame action delta over all 91 episodes of
# two_box_pick (72 709 transitions), floored at 0.02; grippers pinned to 0.06 so a
# grasp is never throttled. Scale by (30 / CONTROL_HZ) if you change the rate.
#
# pick_box_2's values would throttle 13 of the 16 joints here -- the whole left arm by
# up to 7x (left_joint_7 demonstrates 0.147 rad/frame against a 0.02 cap), plus six
# right-arm joints. A throttled joint cannot track the trajectory the policy predicts,
# which reads as sluggish, laggy motion rather than an outright failure.
#
# To re-derive:
#   import glob, numpy as np, pandas as pd
#   D = np.concatenate([np.abs(np.diff(np.stack(
#           pd.read_parquet(f, columns=["action"])["action"].values), axis=0))
#       for f in sorted(glob.glob("<dataset>/data/chunk-*/episode_*.parquet"))])
#   print(np.maximum(np.round(1.5 * np.percentile(D, 99.9, axis=0), 3), 0.02))
export MAX_STEP_DELTA_CSV="${MAX_STEP_DELTA_CSV:-0.131,0.039,0.104,0.097,0.071,0.120,0.221,0.060,0.129,0.041,0.074,0.107,0.092,0.215,0.212,0.060}"

# Episode-START range: p01/p99 of frame 0 across all 91 episodes, widened by
# max(10% of that span, 0.05). Startup check only; clamps nothing.
#
# NEITHER arm starts at zero here. Because this task is bimanual the left arm is also
# posed up (left_joint_4 ~ -1.79, left_joint_5 ~ +1.47), on top of the same forward
# right-arm reach pick_box_2 uses. pick_box_2's start range would flag the entire left
# arm here, and this one would flag it there -- they are not interchangeable. Park at:
#
#   left   0.774, -0.071, -0.010, -1.792,  1.466, -0.063, -0.663   gripper -0.044 (closed)
#   right -0.798, -0.233, -0.022,  1.732,  1.337,  0.023,  0.790   gripper  0.044 (open)
export START_POSE_MIN_CSV="${START_POSE_MIN_CSV:-0.32163,-0.35720,-0.27278,-1.88711,1.12387,-0.32745,-1.22072,-0.09401,-1.23237,-0.43472,-0.31753,1.47113,1.11194,-0.26569,0.11382,-0.01562}"
export START_POSE_MAX_CSV="${START_POSE_MAX_CSV:-1.29567,0.17547,0.30864,-1.48410,1.82013,0.24997,-0.25208,0.01314,-0.28872,0.11260,0.19405,1.84389,1.58960,0.28854,1.28814,0.09402}"

# Median start pose over every episode -- the pose to park the arms at before
# starting. Reported by the start-pose warning; nothing publishes it.
export START_POSE_HOME_CSV="${START_POSE_HOME_CSV:-0.77420,-0.07076,-0.00973,-1.79236,1.46620,-0.06275,-0.66320,-0.04395,-0.79824,-0.23251,-0.02232,1.73171,1.33650,0.02308,0.78985,0.04401}"

exec bash "$REPO_ROOT/examples/openarm_b1/run_system_b_openarm_b1_ros2.sh"
