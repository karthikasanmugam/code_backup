#!/usr/bin/env bash
# Finetune GR00T N1.6 on the `pick_box` dataset (98 episodes, 3 cameras, 16-DoF bimanual).
#
# Prerequisite (one-time): the dataset's meta/modality.json must describe the 3 real
# cameras. Install the corrected file with:
#   cp examples/openarm_b1/modality_pick_box.json \
#      /home/physicalai/Desktop/I/barani/pick_box/meta/modality.json
set -x -euo pipefail

cd /home/physicalai/Desktop/I/groot
source .venv/bin/activate

export NUM_GPUS="${NUM_GPUS:-1}"
SAVE_STEPS="${SAVE_STEPS:-1000}"
MAX_STEPS="${MAX_STEPS:-50000}"
USE_WANDB="${USE_WANDB:-1}"
DATALOADER_NUM_WORKERS="${DATALOADER_NUM_WORKERS:-8}"
GLOBAL_BATCH_SIZE="${GLOBAL_BATCH_SIZE:-16}"
SHARD_SIZE="${SHARD_SIZE:-1024}"
NUM_SHARDS_PER_EPOCH="${NUM_SHARDS_PER_EPOCH:-100000}"
EPISODE_SAMPLING_RATE="${EPISODE_SAMPLING_RATE:-0.1}"

DATASET_PATH="${DATASET_PATH:-/home/physicalai/Desktop/I/barani/pick_box}"
OUTPUT_DIR="${OUTPUT_DIR:-/home/physicalai/Desktop/I/groot/outputs/openarm_b1_pick_box}"

WANDB_FLAG=()
if [ "$USE_WANDB" = "1" ]; then
    WANDB_FLAG+=(--use_wandb)
fi

CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}" python \
    gr00t/experiment/launch_finetune.py \
    --base_model_path nvidia/GR00T-N1.6-3B \
    --dataset_path "$DATASET_PATH" \
    --modality_config_path examples/openarm_b1/pick_box_config.py \
    --embodiment_tag OPENARM_B1 \
    --num_gpus "$NUM_GPUS" \
    --output_dir "$OUTPUT_DIR" \
    --save_steps "$SAVE_STEPS" \
    --save_total_limit 2 \
    --max_steps "$MAX_STEPS" \
    --warmup_ratio 0.05 \
    --weight_decay 1e-5 \
    --learning_rate 1e-4 \
    "${WANDB_FLAG[@]}" \
    --global_batch_size "$GLOBAL_BATCH_SIZE" \
    --dataloader_num_workers "$DATALOADER_NUM_WORKERS" \
    --shard_size "$SHARD_SIZE" \
    --num_shards_per_epoch "$NUM_SHARDS_PER_EPOCH" \
    --episode_sampling_rate "$EPISODE_SAMPLING_RATE"
