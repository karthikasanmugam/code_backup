#!/usr/bin/env bash
set -euo pipefail

# GR00T finetuning launcher for the pick_place_new dataset split.
# This lives inside the existing openarm_b1 example folder, but it does not
# modify any of the existing openarm_b1 files.

cd ~/Desktop/I/groot
source .venv/bin/activate

DATASET_ROOT="${DATASET_ROOT:-/home/physicalai/Documents/daksh_b2/pick_place_new}"
TASK_FOLDER="${TASK_FOLDER:-bluebox_place}"
DATASET_PATH="${DATASET_PATH:-${DATASET_ROOT}/${TASK_FOLDER}}"
OUTPUT_DIR="${OUTPUT_DIR:-./outputs/openarm_b1_pick_place_new_${TASK_FOLDER}_ft}"
BASE_MODEL_PATH="${BASE_MODEL_PATH:-nvidia/GR00T-N1.6-3B}"

CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}" python -m gr00t.experiment.launch_finetune \
  --base-model-path "$BASE_MODEL_PATH" \
  --dataset-path "$DATASET_PATH" \
  --modality-config-path examples/openarm_b1/openarm_b1_config.py \
  --embodiment-tag OPENARM_B1 \
  --num-gpus "${NUM_GPUS:-1}" \
  --output-dir "$OUTPUT_DIR" \
  --save-total-limit "${SAVE_TOTAL_LIMIT:-2}" \
  --save-steps "${SAVE_STEPS:-1000}" \
  --max-steps "${MAX_STEPS:-50000}" \
  --global-batch-size "${GLOBAL_BATCH_SIZE:-8}" \
  --dataloader-num-workers "${DATALOADER_NUM_WORKERS:-4}" \
  --no-tune-diffusion-model
