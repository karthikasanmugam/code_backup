#!/usr/bin/env bash
# System B (robot machine) for the pick_box_2_8chunk checkpoint.
#
#   bash examples/openarm_b1/run_system_b_pick_box_2_ros2.sh
#
# Start System A first, pointed at the MATCHING run:
#   RUN_DIR=/home/physicalai/Desktop/I/groot/outputs/pick_box_2_8chunk \
#     bash examples/openarm_b1/run_system_a_openarm_b1_server.sh
#
# Thin wrapper: supplies only the task-specific values and hands off to the shared
# run_system_b_openarm_b1_ros2.sh. Everything else there already fits this checkpoint
# (30 Hz, 8-step horizon, 320x240 frames, 3 cameras, same topics).
set -euo pipefail

REPO_ROOT="${REPO_ROOT:-/home/physicalai/Desktop/I/groot}"

# pick_box_2/meta/tasks.jsonl (task_index 0), verbatim. Feeding a different sentence is
# an unnecessary distribution shift on the language input.
export LANG_INSTRUCTION="${LANG_INSTRUCTION:-pick the brown box on the right hand side, place it in to the center of the box}"

# outputs/pick_box_2_8chunk/checkpoint-50000/experiment_cfg/dataset_statistics.json ->
# openarm_b1: union of the action and state ranges widened by max(10% of range, 0.05)
# for arms / 0.01 for grippers (right-gripper min floored at 0.0 -- a negative command
# over-closes the jaw against its stop).
#
# This is a ONE-BOX task: the left arm moves only slightly, so its bounds are genuinely
# narrow (a few tenths of a radian). Do NOT reuse them for two_box_pick, which is
# bimanual -- see run_system_b_two_box_pick_ros2.sh.
#
# RETRAINED? Re-derive from the checkpoint you are actually serving; limits from
# another run can be disjoint from this one's poses. Recipe is in the --joint-min-csv
# comment in eval_openarm_b1_ros2.py.
export JOINT_MIN_CSV="${JOINT_MIN_CSV:--0.06736,-0.27297,-0.12670,-0.06278,-0.16198,-0.28899,-0.12670,-0.05418,-1.27588,-0.36374,-0.70903,0.28232,0.71468,-0.94800,-1.70379,0.0}"
export JOINT_MAX_CSV="${JOINT_MAX_CSV:-0.19858,0.08071,0.05515,0.06074,0.34927,0.22027,0.17989,0.01021,1.15534,0.24057,1.24613,1.93225,1.96825,1.44501,1.45682,0.05503}"

# 1.5x the per-joint p99.9 frame-to-frame action delta over ALL 220 of pick_box_2's
# episodes (120 780 transitions), floored at 0.02. Scale by (30 / CONTROL_HZ) if you
# change the rate.
#
# GRIPPERS: 0.025, NOT the 0.06 that used to be here. 0.06 exceeds the gripper's whole
# 0.044 rad travel, so the two gripper slots had NO rate limit at all and any
# chunk-to-chunk jitter in the policy's gripper head reached the jaw in a single 33 ms
# tick -- the right jaw chattering open/closed. Measured over the same 220 episodes the
# right gripper's real frame-to-frame action delta is p99 0.0050, p99.9 0.0086, and its
# largest single step EVER is 0.0249; the left gripper's is 0.0 (it is constant within
# an episode in this one-box task). 0.025 therefore still clears the biggest real step
# and completes a full open->close in 2 ticks (67 ms) against the demos' median
# transition of 6 ticks (200 ms), so a grasp is provably never throttled.
#
# To re-derive:
#   import glob, numpy as np, pandas as pd
#   D = np.concatenate([np.abs(np.diff(np.stack(
#           pd.read_parquet(f, columns=["action"])["action"].values), axis=0))
#       for f in sorted(glob.glob("<dataset>/data/chunk-*/episode_*.parquet"))])
#   print(np.maximum(np.round(1.5 * np.percentile(D, 99.9, axis=0), 3), 0.02))
export MAX_STEP_DELTA_CSV="${MAX_STEP_DELTA_CSV:-0.02,0.02,0.02,0.02,0.02,0.02,0.02,0.025,0.106,0.039,0.097,0.094,0.067,0.175,0.196,0.025}"

# The range of poses episodes actually STARTED from: p01/p99 of frame 0 across all 220
# episodes, widened by max(10% of that span, 0.05). Checked once at startup; it clamps
# nothing. This is NOT the range above -- it is far tighter, and it is the one that
# catches a wrongly-homed arm.
#
# THE RIGHT ARM DOES NOT START AT ZERO IN THIS DATASET. Every episode begins with it
# reaching forward and rotated out:
#     right_joint_1 ~ -0.60   right_joint_4 ~ +1.68
#     right_joint_5 ~ +1.43   right_joint_7 ~ +0.70
# while the LEFT arm does start at ~0 (it barely moves in this one-box task). Homing
# both arms to zero therefore mis-poses the right arm only. Verified against the served
# checkpoint: fed a real recorded pose it reproduces the demo to 0.003-0.009 rad, but
# fed a zero-homed right arm it predicts <=0.025 rad of motion over an entire 8-step
# chunk -- so the policy effectively stops commanding, the rate limiter walks
# right_joint_4/5 to their joint_min (0.282 / 0.715) at 0.094 / 0.067 rad per step, and
# the arm drives itself backwards to the limit-box corner with nothing in the logs.
# That is the "right arm goes backside" failure. Park the arms here first:
#
#   left  0.000, -0.168, -0.054,  0.003,  0.003, -0.002,  0.076   gripper -0.044 (closed)
#   right -0.599, -0.022,  0.020,  1.683,  1.431, -0.036,  0.698   gripper  0.044 (open)
export START_POSE_MIN_CSV="${START_POSE_MIN_CSV:--0.06469,-0.24703,-0.12496,-0.06278,-0.06044,-0.28320,-0.12107,-0.09407,-1.02761,-0.24778,-0.21205,1.34733,1.20929,-0.28391,0.23467,-0.01401}"
export START_POSE_MAX_CSV="${START_POSE_MAX_CSV:-0.19858,0.05019,0.05424,0.05844,0.34126,0.21537,0.17417,0.05000,-0.27390,0.17448,0.30273,1.82643,1.64513,0.16761,1.23695,0.09401}"

# Median start pose over every episode -- the pose to park the arms at before
# starting. Reported by the start-pose warning; nothing publishes it.
export START_POSE_HOME_CSV="${START_POSE_HOME_CSV:--0.00019,-0.16785,-0.05436,0.00286,0.00324,-0.00153,0.07572,-0.04393,-0.59911,-0.02213,0.02041,1.68326,1.43053,-0.03586,0.69848,0.04376}"

exec bash "$REPO_ROOT/examples/openarm_b1/run_system_b_openarm_b1_ros2.sh"
