#!/usr/bin/env bash
set -euo pipefail

# Train one GR00T model on both bluebox tasks together.

cd ~/Desktop/I/groot
source .venv/bin/activate

DATASET_PATH="${DATASET_PATH:-/home/physicalai/Documents/daksh_b2/pick_place_new/both_tasks}"
OUTPUT_DIR="${OUTPUT_DIR:-./outputs/openarm_b1_pick_place_both_ft}"
BASE_MODEL_PATH="${BASE_MODEL_PATH:-nvidia/GR00T-N1.6-3B}"

CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}" python -m gr00t.experiment.launch_finetune \
  --base-model-path "$BASE_MODEL_PATH" \
  --dataset-path "$DATASET_PATH" \
  --modality-config-path examples/openarm_b1/openarm_b1_config.py \
  --embodiment-tag OPENARM_B1 \
  --num-gpus "${NUM_GPUS:-1}" \
  --output-dir "$OUTPUT_DIR" \
  --save-total-limit "${SAVE_TOTAL_LIMIT:-2}" \
  --save-steps "${SAVE_STEPS:-1000}" \
  --max-steps "${MAX_STEPS:-50000}" \
  --global-batch-size "${GLOBAL_BATCH_SIZE:-8}" \
  --dataloader-num-workers "${DATALOADER_NUM_WORKERS:-4}" \
  --no-tune-diffusion-model
