#!/usr/bin/env bash
# System B (robot machine) for the blackbox_pick_and_place checkpoint. Self-contained:
# runs eval_openarm_b1_ros2.py directly and passes every task-specific flag, because the
# bridge's own argparse defaults (language, limits, start pose) are pick_box_2's.
#
#   bash examples/openarm_b1/run_system_b_blackbox_pick_and_place_ros2.sh
#
# Starts on pick_blackbox. When the arm is back home HOLDING the box, press Enter in
# this terminal: the bridge switches to place_blackbox without restarting, so the grasp
# is never released. Do NOT Ctrl+C between pick and place.
#
# While running, type in this terminal:
#   stop / hold       freeze the arm where it is (no Ctrl+C, grasp kept)
#   resume            continue the current instruction
#   <instruction>     switch to it and continue (also un-pauses), e.g. pick_blackbox
# During place_blackbox the grasp guard pauses the arm by itself if the box leaves the
# right jaw (or was never in it); re-pick with `pick_blackbox`.
#
# Start System A first, pointed at the MATCHING run:
#   MODEL_PATH=/home/physicalai/Desktop/I/groot/outputs/blackbox_pick_and_place/checkpoint-50000 \
#     bash examples/openarm_b1/run_system_a_openarm_b1_server.sh
#
# Matched against the checkpoint and dataset:
#   CONTROL_HZ=30      blackbox_pick_and_place meta/info.json fps = 30
#   ACTION_HORIZON=8   checkpoint action delta_indices = 8; relative_action stats length = 8
#   IMAGE_SIZE=320x240 all three cameras recorded at [240, 320, 3]
#   camera keys        world, wrist_right, wrist_left (processor_config.json video keys)
#   joint order        LEFT-first, matching meta/modality.json and pick_box_config.py
set -euo pipefail

REPO_ROOT="${REPO_ROOT:-/home/physicalai/Desktop/I/groot}"
cd "$REPO_ROOT"
source .venv/bin/activate

# The robot lives on domain 55 over Fast DDS. Pinned rather than inherited: ~/.bashrc
# exports ROS_DOMAIN_ID=33, which carries no robot topics, and the bridge would then
# sit in "Waiting for inputs" forever. Override with ROBOT_ROS_DOMAIN_ID /
# ROBOT_RMW_IMPLEMENTATION, never ROS_DOMAIN_ID (that is what leaks in from a profile).
export ROS_DOMAIN_ID="${ROBOT_ROS_DOMAIN_ID:-55}"
export RMW_IMPLEMENTATION="${ROBOT_RMW_IMPLEMENTATION:-rmw_fastrtps_cpp}"
case "$RMW_IMPLEMENTATION" in
  *fastrtps*) : ;;
  *) unset FASTRTPS_DEFAULT_PROFILES_FILE ;;
esac
echo "[blackbox] ROS_DOMAIN_ID=$ROS_DOMAIN_ID RMW_IMPLEMENTATION=$RMW_IMPLEMENTATION" >&2
if [ -z "${AMENT_PREFIX_PATH:-}" ]; then
  set +u  # ROS setup.bash trips over unbound vars
  # shellcheck disable=SC1091
  source /opt/ros/humble/setup.bash
  set -u
fi

POLICY_HOST="${POLICY_HOST:-127.0.0.1}"
POLICY_PORT="${POLICY_PORT:-5555}"
CONTROL_HZ="${CONTROL_HZ:-30}"
ACTION_HORIZON="${ACTION_HORIZON:-8}"
# Must be in [0, ACTION_HORIZON). Re-derive as ceil(measured_inference_s * CONTROL_HZ)
# from the "inference N ms" log line. If it says OVER BUDGET, run with REPLAN_AT=7.
REPLAN_AT="${REPLAN_AT:-6}"
WATCHDOG_TIMEOUT_S="${WATCHDOG_TIMEOUT_S:-2.0}"
INPUT_TIMEOUT_S="${INPUT_TIMEOUT_S:-1.0}"
GRIPPER_DEADBAND="${GRIPPER_DEADBAND:-0.004}"
VALIDATION_MODE="${VALIDATION_MODE:-full}"
PHASE_SECONDS="${PHASE_SECONDS:-12.0}"

# The model was trained on the tasks.jsonl "task" field, NOT the "prompt" sentence:
# lerobot_episode_loader.py builds tasks_map = {task_index: task["task"]}. So the two
# strings it has ever seen are exactly:
#   task_index 0 -> "pick_blackbox"   (52 episodes)
#   task_index 1 -> "place_blackbox"  (78 episodes)
# "pick up the black box from tabel" is never fed to the model during training.
#
# Pick and place were recorded as SEPARATE 250-frame (~8.3 s) episodes that chain:
# every pick ends at home with the box squeezed (right gripper command ~0.042, jaw
# stopped by the box at ~0.031; larger = more closed) and every place starts from that
# same grasp. So switch stages INSIDE one run (Enter, see top) rather than restarting.
# Switch promptly once pick is home: pick demos never continue past that point, and a
# pick policy left running may start a new grasp cycle and open the jaw.
LANG_INSTRUCTION="${LANG_INSTRUCTION:-pick_blackbox}"
LANG_SEQUENCE="${LANG_SEQUENCE:-pick_blackbox,place_blackbox}"
case "$LANG_INSTRUCTION" in
  pick_blackbox|place_blackbox) : ;;
  *) echo "[blackbox] WARNING: LANG_INSTRUCTION='$LANG_INSTRUCTION' is not a trained task string (pick_blackbox / place_blackbox)" >&2 ;;
esac
echo "[blackbox] LANG_INSTRUCTION=$LANG_INSTRUCTION" >&2

# Joint state and command topics (same as every other OpenArm B1 task).
LEFT_JOINT_STATE_TOPIC="${LEFT_JOINT_STATE_TOPIC:-/LeftArmSystem_ordered_joint_states}"
RIGHT_JOINT_STATE_TOPIC="${RIGHT_JOINT_STATE_TOPIC:-/RightArmSystem_ordered_joint_states}"
JOINT_STATE_TOPIC="${JOINT_STATE_TOPIC:-/joint_states}"
CMD_TOPIC="${CMD_TOPIC:-/joint_cmd}"
PUBLISH_JOINT_ORDER="${PUBLISH_JOINT_ORDER:-left_first}"

# Camera topics, verbatim from this dataset's ros2_topics.json -> camera_topics.
# The world camera is /camera/world/..., NOT the /world/camera/... that pick_box_2 and
# two_box_pick were recorded on.
WORLD_TOPIC="${WORLD_TOPIC:-/camera/world/color/image_raw/compressed}"
RIGHT_WRIST_TOPIC="${RIGHT_WRIST_TOPIC:-/right/camera/color/image_raw/compressed}"
LEFT_WRIST_TOPIC="${LEFT_WRIST_TOPIC:-/left/camera/color/image_raw/compressed}"
IMAGE_TRANSPORT="${IMAGE_TRANSPORT:-compressed}"
# Live cameras publish 640x480 / 848x480; the recorder squashed every frame to 320x240
# with cv2.resize(INTER_AREA). Reproduce that so the policy sees training geometry.
IMAGE_SIZE="${IMAGE_SIZE:-320x240}"
IMAGE_MAX_EDGE="${IMAGE_MAX_EDGE:-0}"

WORLD_CAMERA_KEY="world"
RIGHT_WRIST_CAMERA_KEY="wrist_right"
LEFT_WRIST_CAMERA_KEY="wrist_left"

# LEFT-first, matching the checkpoint's modality_keys and meta/modality.json.
JOINT_KEYS="left_joint_1,left_joint_2,left_joint_3,left_joint_4,left_joint_5,left_joint_6,left_joint_7,left_gripper_left_joint,right_joint_1,right_joint_2,right_joint_3,right_joint_4,right_joint_5,right_joint_6,right_joint_7,right_gripper_right_joint"

# Union of action and observation.state min/max over all 130 episodes (32 500 frames),
# widened by max(10% of range, 0.05) for arms / 0.01 for grippers, right-gripper min
# floored at 0.0 (a negative command over-closes the jaw against its stop).
#
# RIGHT-ARM-ONLY task: every left joint spans < 0.18 rad in the data, so the left arm
# is boxed in tight around its parked pose -- intended, the policy never moves it.
#
# URDF JOINT LIMITS WERE ENFORCED WHILE THIS DATASET WAS RECORDED, and the robot's
# joint_command_limiter now runs with enforce_joint_limits:false. The leader commanded
# past the limits and the follower stopped at them:
#   right_joint_1  commanded down to -0.742, follower never below -0.358 (URDF lower -0.3491)
#   left_joint_4   commanded up to   +0.095, follower never above +0.000 (URDF upper  0.0)
# so the model learned "command = state - ~0.2" for right_joint_1 at home. Without the
# clamp the follower obeys, the next chunk subtracts again, and the right shoulder swings
# BACKWARDS every chunk (policy rollout: -0.35 -> -0.58 -> -0.80 -> ... -> -2.1 rad).
# These bounds re-apply the URDF limits the demos were recorded under:
#   right_joint_1 min -0.34910, right_joint_4 min 0.0, right_joint_6 max 0.78540,
#   left_joint_4 max 0.0.
JOINT_MIN_CSV="${JOINT_MIN_CSV:--0.09909,-0.04233,-0.05591,-0.06965,-0.04693,-0.22794,-0.06381,-0.01083,-0.34910,-0.38932,-0.79804,0.0,0.87705,-0.32260,-0.82924,0.0}"
JOINT_MAX_CSV="${JOINT_MAX_CSV:-0.07766,0.08068,0.05307,0.0,0.06049,0.04693,0.05095,0.01071,1.37690,0.16845,1.17598,1.84154,1.76529,0.78540,1.26854,0.05428}"

# 1.5x the per-joint p99.9 frame-to-frame action delta over all 130 episodes, floored
# at 0.02; grippers pinned to 0.06 so a grasp is never throttled. Scale by
# (30 / CONTROL_HZ) if you change the rate.
MAX_STEP_DELTA_CSV="${MAX_STEP_DELTA_CSV:-0.020,0.020,0.020,0.020,0.020,0.020,0.020,0.060,0.115,0.048,0.104,0.120,0.050,0.106,0.127,0.060}"

# Episode-START range: p01/p99 of frame 0 across all 130 episodes (pick AND place
# starts), widened by max(10% of that span, 0.05). Startup check only; clamps nothing.
START_POSE_MIN_CSV="${START_POSE_MIN_CSV:--0.09788,-0.04142,-0.05591,-0.06965,-0.04332,-0.22605,-0.06202,-0.05070,-0.40786,-0.32543,-0.18262,1.26697,1.09480,-0.13588,0.05237,-0.02414}"
START_POSE_MAX_CSV="${START_POSE_MAX_CSV:-0.07755,0.07613,0.05057,0.05019,0.06049,0.04027,0.05019,0.05039,0.29098,0.07290,0.20985,1.70442,1.55545,0.24691,0.87083,0.08319}"

# Median start pose of the 52 pick_blackbox episodes -- park here before a pick run.
# Reported by the start-pose warning; nothing publishes it.
START_POSE_HOME_CSV="${START_POSE_HOME_CSV:-0.01926,0.00896,-0.00134,-0.00095,0.00935,-0.17185,-0.01163,-0.00013,-0.34924,-0.11540,-0.04692,1.53487,1.34165,0.01869,0.58156,0.03214}"

# Starting directly on place_blackbox: check against the 78 PLACE starts only (same
# p01/p99 + padding recipe). Place begins with the right wrist turned to right_joint_7
# ~+0.47 (p5..p95 +0.15..+0.76) and right_joint_4 ~1.58. A pick that ends with the
# wrist at the -0.83 limit is ~1.3 rad from any place start, and place then barely moves.
if [ "$LANG_INSTRUCTION" = "place_blackbox" ]; then
  START_POSE_MIN_CSV="${PLACE_START_POSE_MIN_CSV:--0.09788,-0.04142,-0.05591,-0.06965,-0.04332,-0.22605,-0.06202,-0.05070,-0.40898,-0.33378,-0.15373,1.26745,1.09119,-0.13052,-0.05228,-0.02110}"
  START_POSE_MAX_CSV="${PLACE_START_POSE_MAX_CSV:-0.07766,0.07613,0.05057,0.05019,0.06049,0.04027,0.05019,0.05034,0.30331,0.07774,0.22452,1.70541,1.57408,0.25850,0.86949,0.08224}"
  START_POSE_HOME_CSV="${PLACE_START_POSE_HOME_CSV:-0.01926,0.00896,-0.00134,-0.00095,0.00935,-0.17185,-0.01163,-0.00007,-0.15164,-0.12779,-0.01659,1.58217,1.33803,0.03433,0.46578,0.02944}"
fi

# Grasp guard, right gripper (larger = more closed), from the 78 place_blackbox demos:
# jaw holding the box 0.0281..0.0333 (never higher before release); an empty jaw tracks
# its command within ~0.001; every release keeps the command < 0.025 for >= 6 frames.
# The floor (0.040) is inside the demonstrated held-command range (max 0.0415) and
# replaces the demos' light ~0.0034 rad squeeze, which the 0.004 deadband can erase.
# GRASP_GUARD_TASKS="" turns the guard off.
GRASP_GUARD_TASKS="${GRASP_GUARD_TASKS-place_blackbox}"
GRASP_SQUEEZE_FLOOR="${GRASP_SQUEEZE_FLOOR:-0.040}"
GRASP_HELD_MIN="${GRASP_HELD_MIN:-0.026}"
GRASP_DROP_ABOVE="${GRASP_DROP_ABOVE:-0.036}"
GRASP_DROP_TICKS="${GRASP_DROP_TICKS:-3}"
GRASP_RELEASE_BELOW="${GRASP_RELEASE_BELOW:-0.025}"
GRASP_RELEASE_STEPS="${GRASP_RELEASE_STEPS:-3}"

extra_flags=()
if [ "${RUN_VALIDATION_SUITE:-false}" = "true" ]; then
  extra_flags+=(--run-validation-suite)
fi

# --flag=value for the CSVs: several start with a minus sign, which argparse would
# otherwise read as an option name.
exec python gr00t/eval/real_robot/OPENARM_B1/eval_openarm_b1_ros2.py \
  --lang-instruction "$LANG_INSTRUCTION" \
  --lang-sequence "$LANG_SEQUENCE" \
  --policy-host "$POLICY_HOST" \
  --policy-port "$POLICY_PORT" \
  --control-hz "$CONTROL_HZ" \
  --action-horizon "$ACTION_HORIZON" \
  --replan-at "$REPLAN_AT" \
  --gripper-deadband "$GRIPPER_DEADBAND" \
  --grasp-guard-tasks "$GRASP_GUARD_TASKS" \
  --grasp-squeeze-floor "$GRASP_SQUEEZE_FLOOR" \
  --grasp-held-min "$GRASP_HELD_MIN" \
  --grasp-drop-above "$GRASP_DROP_ABOVE" \
  --grasp-drop-ticks "$GRASP_DROP_TICKS" \
  --grasp-release-below "$GRASP_RELEASE_BELOW" \
  --grasp-release-steps "$GRASP_RELEASE_STEPS" \
  --watchdog-timeout-s "$WATCHDOG_TIMEOUT_S" \
  --input-timeout-s "$INPUT_TIMEOUT_S" \
  --validation-mode "$VALIDATION_MODE" \
  --phase-seconds "$PHASE_SECONDS" \
  --joint-state-topic "$JOINT_STATE_TOPIC" \
  --left-joint-state-topic "$LEFT_JOINT_STATE_TOPIC" \
  --right-joint-state-topic "$RIGHT_JOINT_STATE_TOPIC" \
  --cmd-topic "$CMD_TOPIC" \
  --publish-joint-order "$PUBLISH_JOINT_ORDER" \
  --world-topic "$WORLD_TOPIC" \
  --right-wrist-topic "$RIGHT_WRIST_TOPIC" \
  --left-wrist-topic "$LEFT_WRIST_TOPIC" \
  --image-transport "$IMAGE_TRANSPORT" \
  --image-size "$IMAGE_SIZE" \
  --image-max-edge "$IMAGE_MAX_EDGE" \
  --world-camera-key "$WORLD_CAMERA_KEY" \
  --right-wrist-camera-key "$RIGHT_WRIST_CAMERA_KEY" \
  --left-wrist-camera-key "$LEFT_WRIST_CAMERA_KEY" \
  --state-obs-keys-csv "$JOINT_KEYS" \
  --action-keys-csv "$JOINT_KEYS" \
  --joint-min-csv="$JOINT_MIN_CSV" \
  --joint-max-csv="$JOINT_MAX_CSV" \
  --max-step-delta-csv="$MAX_STEP_DELTA_CSV" \
  --start-pose-min-csv="$START_POSE_MIN_CSV" \
  --start-pose-max-csv="$START_POSE_MAX_CSV" \
  --start-pose-home-csv="$START_POSE_HOME_CSV" \
  "${extra_flags[@]}"
