#!/usr/bin/env bash
# System A (GPU box): serve a GR00T N1.6 OpenArm B1 checkpoint for inference.
#
#   bash examples/openarm_b1/run_system_a_daksha_b1_server.sh
#   MODEL_PATH=/home/physicalai/Desktop/I/groot/outputs/pick_box_2_8chunk/checkpoint-50000 \
#     bash examples/openarm_b1/run_system_a_daksha_b1_server.sh
#   RUN_DIR=/home/physicalai/Desktop/I/groot/outputs/two_box_pick_8chunk \
#     bash examples/openarm_b1/run_system_a_daksha_b1_server.sh
#   PORT=5556 bash examples/openarm_b1/run_system_a_daksha_b1_server.sh
#
# Start this BEFORE System B (e.g. run_system_b_pick_box_2_ros2.sh).
#
# The embodiment tag must be the one the checkpoint was trained with. pick_box_2_8chunk
# and two_box_pick_8chunk were both fine-tuned with --embodiment_tag OPENARM_B1
# (experiment_cfg/config.yaml: embodiment_tag: openarm_b1). There is no DAKSHA tag in
# gr00t/data/embodiment_tags.py, so passing one fails before the model loads.
#
# No --modality-config-path is needed: Gr00tPolicy reads the modality config out of
# the checkpoint's processor_config.json, keyed by the embodiment tag. For these runs
# that is video=[world, wrist_right, wrist_left], state/action=[left_arm,
# left_gripper, right_arm, right_gripper], 8-step action chunks.
set -euo pipefail

REPO_ROOT="${REPO_ROOT:-/home/physicalai/Desktop/I/groot}"
cd "$REPO_ROOT"
source .venv/bin/activate

# Training keeps only the 2 newest checkpoints (save_total_limit=2), so a hardcoded
# checkpoint number goes stale. Default to the highest-numbered one under RUN_DIR;
# set MODEL_PATH to pin a specific one. RUN_DIR may also point straight at a checkpoint.
RUN_DIR="${RUN_DIR:-$REPO_ROOT/outputs/pick_box_2_8chunk}"
if [ -z "${MODEL_PATH:-}" ]; then
  if [ -f "$RUN_DIR/config.json" ]; then
    MODEL_PATH="$RUN_DIR"
  else
    _step="$(ls -d "$RUN_DIR"/checkpoint-* 2>/dev/null | sed 's/.*checkpoint-//' | sort -n | tail -1 || true)"
    [ -n "$_step" ] || { echo "no checkpoint-* under $RUN_DIR — set MODEL_PATH" >&2; exit 1; }
    MODEL_PATH="$RUN_DIR/checkpoint-$_step"
  fi
fi
MODEL_PATH="${MODEL_PATH%/}"
echo "[system_a] model: $MODEL_PATH"

# A checkpoint whose save was interrupted leaves 0-byte files behind, and the server
# dies mid-load with a confusing error. Catch it here instead.
for f in config.json processor_config.json embodiment_id.json model.safetensors.index.json; do
  if [ ! -s "$MODEL_PATH/$f" ]; then
    echo "ERROR: $MODEL_PATH/$f is missing or empty (truncated checkpoint?)." >&2
    echo "       Set MODEL_PATH to an older checkpoint." >&2
    exit 1
  fi
done

EMBODIMENT_TAG="${EMBODIMENT_TAG:-OPENARM_B1}"
HOST="${HOST:-0.0.0.0}"
PORT="${PORT:-5555}"
DEVICE="${DEVICE:-cuda}"

exec python gr00t/eval/run_gr00t_server.py \
  --model-path "$MODEL_PATH" \
  --embodiment-tag "$EMBODIMENT_TAG" \
  --device "$DEVICE" \
  --host "$HOST" \
  --port "$PORT"
