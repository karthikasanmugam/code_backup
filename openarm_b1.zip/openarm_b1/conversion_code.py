#!/usr/bin/env python3
"""
Convert an OpenArm B1 (Daksha) raw dataset into the GR00T/LeRobot layout expected by training.

This script assumes the raw data already exists as per-episode parquet files and MP4
videos, and it fills in the missing LeRobot metadata files:

  - meta/modality.json
  - meta/tasks.jsonl
  - meta/episodes.jsonl
  - meta/info.json (adds chunks_size if missing, and names the joints of action,
    observation.state and observation.leader_state like barani/pick_box_2:
    left_joint_1 ... left_joint_7, left_gripper_left_joint, right_joint_1 ...)

Unless --skip-stats is given, it then runs the GR00T statistics generator (embodiment
tag OPENARM_B1). Any existing stats are moved to *.bak.json first and regenerated, so
removed episodes or a new action chunk length are always picked up:

  - meta/stats.json
  - meta/relative_stats.json

The modality template sets the joint slices and camera files; the modality config must
ask for the same camera and joint key names:

  - 3 cameras (world, wrist_right, wrist_left), left arm first:
      modality_pick_box.json + pick_box_config.py (default)
  - 4 cameras (zed_right, zed_left, right_wrist, left_wrist), right arm first:
      modality.json + openarm_b1_config.py

Datasets recorded with the ZED instead of the world camera have no
observation.images.world; for those the ZED left image is used as the world view
(override with --world-camera).

Example:
  uv run python examples/openarm_b1/conversion_code.py \
    --dataset-root /home/physicalai/Desktop/I/barani/pick_box

  uv run python examples/openarm_b1/conversion_code.py \
    --dataset-root /home/physicalai/Desktop/I/open_arm_datasetv3/new_daksha_b1_pick_place \
    --modality-template examples/openarm_b1/modality.json \
    --modality-config examples/openarm_b1/openarm_b1_config.py
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd


REPO_ROOT = Path(__file__).resolve().parents[2]
EXAMPLE_DIR = REPO_ROOT / "examples" / "openarm_b1"
DEFAULT_MODALITY_TEMPLATE = EXAMPLE_DIR / "modality_pick_box.json"
DEFAULT_MODALITY_CONFIG = EXAMPLE_DIR / "pick_box_config.py"
EMBODIMENT_TAG = "OPENARM_B1"
DEFAULT_CHUNKS_SIZE = 1024
# Dataset cameras tried, in order, for the template's "world" view.
WORLD_CAMERA_CANDIDATES = ("world", "zed_left")
# Joint vectors whose names info.json records, and the template group each one follows.
JOINT_FEATURES = {"action": "action", "observation.state": "state", "observation.leader_state": "state"}


def resolve_dataset_root(dataset_root: str | Path) -> Path:
    root = Path(dataset_root).expanduser().resolve()
    if (root / "meta" / "info.json").exists():
        return root

    nested_roots = sorted(
        p for p in root.iterdir() if p.is_dir() and (p / "meta" / "info.json").exists()
    )
    if len(nested_roots) == 1:
        return nested_roots[0]
    if len(nested_roots) > 1:
        raise FileNotFoundError(
            f"Multiple LeRobot dataset roots found under {root}: "
            f"{', '.join(str(p) for p in nested_roots)}"
        )
    raise FileNotFoundError(
        f"Could not find meta/info.json under {root}. "
        "Pass the exact dataset root that contains the dataset."
    )


def read_tasks(meta_dir: Path) -> list[dict[str, object]]:
    task_json = meta_dir / "task.json"
    tasks_parquet = meta_dir / "tasks.parquet"

    if task_json.exists():
        raw_tasks = json.loads(task_json.read_text())
    elif tasks_parquet.exists():
        raw_tasks = pd.read_parquet(tasks_parquet).to_dict(orient="records")
    else:
        raise FileNotFoundError(
            f"Could not find task.json or tasks.parquet in {meta_dir}. "
            "One of those files is needed to generate tasks.jsonl."
        )

    tasks: list[dict[str, object]] = []
    for row in raw_tasks:
        if "task_index" not in row or "task" not in row:
            raise ValueError(
                "Each task record must contain at least 'task_index' and 'task'. "
                f"Got keys: {list(row.keys())}"
            )
        task_index = int(row["task_index"])
        task_text = str(row["task"])
        prompt = str(row.get("prompt", task_text))
        tasks.append({"task_index": task_index, "task": task_text, "prompt": prompt})

    tasks.sort(key=lambda item: int(item["task_index"]))
    return tasks


def write_tasks_jsonl(meta_dir: Path, tasks: list[dict[str, object]]) -> Path:
    path = meta_dir / "tasks.jsonl"
    with open(path, "w") as f:
        for task in tasks:
            f.write(json.dumps(task, ensure_ascii=False) + "\n")
    return path


def parse_episode_index(path: Path) -> int:
    stem = path.stem
    if stem.startswith("episode_"):
        return int(stem.split("_", 1)[1])
    raise ValueError(f"Could not parse episode index from filename: {path.name}")


def build_episodes(dataset_root: Path) -> list[dict[str, object]]:
    episode_paths = sorted(dataset_root.glob("data/chunk-*/episode_*.parquet"))
    if not episode_paths:
        raise FileNotFoundError(
            f"No episode parquet files found under {dataset_root / 'data'}. "
            "Expected files like data/chunk-000/episode_000000.parquet."
        )

    episodes: list[dict[str, object]] = []
    for parquet_path in episode_paths:
        df = pd.read_parquet(parquet_path)
        if len(df) == 0:
            raise ValueError(f"Empty episode parquet: {parquet_path}")

        episode_index = int(df["episode_index"].iloc[0]) if "episode_index" in df.columns else parse_episode_index(parquet_path)
        file_episode_index = parse_episode_index(parquet_path)
        if episode_index != file_episode_index:
            raise ValueError(
                f"Episode index mismatch for {parquet_path.name}: "
                f"file says {file_episode_index}, parquet says {episode_index}"
            )

        episode: dict[str, object] = {
            "episode_index": episode_index,
            "length": int(len(df)),
        }
        if "task_index" in df.columns:
            episode["task_index"] = int(df["task_index"].iloc[0])
        if "task" in df.columns:
            episode["task"] = str(df["task"].iloc[0])
        if "prompt" in df.columns:
            episode["prompt"] = str(df["prompt"].iloc[0])
        if "timestamp" in df.columns:
            episode["timestamp_start"] = float(df["timestamp"].iloc[0])
            episode["timestamp_end"] = float(df["timestamp"].iloc[-1])

        episodes.append(episode)

    episodes.sort(key=lambda item: int(item["episode_index"]))
    return episodes


def write_episodes_jsonl(meta_dir: Path, episodes: list[dict[str, object]]) -> Path:
    path = meta_dir / "episodes.jsonl"
    with open(path, "w") as f:
        for episode in episodes:
            f.write(json.dumps(episode, ensure_ascii=False) + "\n")
    return path


def joint_names(groups: dict) -> list[str]:
    """Per-index joint names in the style of barani/pick_box_2.

    left_arm 0:7 -> left_joint_1 ... left_joint_7, left_gripper 7:8 -> left_gripper_left_joint.
    """
    names = [f"joint_{i + 1}" for i in range(max(span["end"] for span in groups.values()))]
    for group, span in groups.items():
        side, _, part = group.partition("_")
        count = span["end"] - span["start"]
        for i in range(count):
            if part == "arm":
                name = f"{side}_joint_{i + 1}"
            elif part == "gripper":
                name = f"{side}_gripper_{side}_joint" + (f"_{i + 1}" if count > 1 else "")
            else:
                name = f"{group}_{i + 1}"
            names[span["start"] + i] = name
    return names


def side_of(name: object) -> str | None:
    return next((side for side in ("left", "right") if str(name).startswith(side)), None)


def mirror_groups(groups: dict) -> dict | None:
    """The same groups with the left and right halves swapped, or None if they do not pair up."""
    flip = {"left": "right", "right": "left"}
    mirrored = {}
    for group, span in groups.items():
        side, sep, part = group.partition("_")
        partner = groups.get(f"{flip[side]}{sep}{part}") if side in flip else None
        if partner is None or partner["end"] - partner["start"] != span["end"] - span["start"]:
            return None
        mirrored[group] = partner
    return mirrored


def leader_layout(dataset_root: Path, groups: dict, max_episodes: int = 50) -> tuple[dict | None, str]:
    """Where each state group sits in observation.leader_state, read from the data.

    The recorder has written the leader vector right arm first while observation.state is
    left arm first, so the order is taken from which follower joint each leader joint tracks.
    Returns (None, reason) when the data does not show it clearly.
    """
    mirrored = mirror_groups(groups)
    paths = sorted(dataset_root.glob("data/chunk-*/episode_*.parquet"))[:max_episodes]
    try:
        df = pd.concat(pd.read_parquet(p, columns=["observation.state", "observation.leader_state"]) for p in paths)
    except Exception as e:  # missing column, unreadable file: keep the names, do not fail the conversion
        return None, f"could not be read from data/ ({type(e).__name__}: {e})"
    state = np.vstack(df["observation.state"].to_numpy())
    leader = np.vstack(df["observation.leader_state"].to_numpy())

    def score(layout: dict) -> float:
        corrs = []
        for group, span in groups.items():
            for i in range(span["end"] - span["start"]):
                a, b = leader[:, layout[group]["start"] + i], state[:, span["start"] + i]
                if a.std() > 1e-4 and b.std() > 1e-4:  # joints that never move say nothing
                    corrs.append(abs(np.corrcoef(a, b)[0, 1]))
        return float(np.mean(corrs)) if corrs else 0.0

    same = score(groups)
    swapped = score(mirrored) if mirrored else 0.0
    if max(same, swapped) < 0.8 or abs(same - swapped) < 0.2:
        return None, f"unclear from data/ (joint correlation {same:.2f} in state order, {swapped:.2f} arms swapped)"
    if swapped > same:
        return mirrored, f"arms swapped relative to observation.state (joint correlation {swapped:.2f} vs {same:.2f})"
    return groups, f"same order as observation.state (joint correlation {same:.2f} vs {swapped:.2f})"


def plan_joint_names(dataset_root: Path, modality: dict, features: dict) -> dict[str, tuple[list[str] | None, str]]:
    """New info.json names for each joint vector, with how they were chosen; None keeps the current names."""
    plan: dict[str, tuple[list[str] | None, str]] = {}
    for key, group in JOINT_FEATURES.items():
        groups = modality.get(group)
        if key not in features or not groups:
            continue
        how = f"template {group} layout"
        if key == "observation.leader_state":
            groups, how = leader_layout(dataset_root, groups)
            if groups is None:
                plan[key] = (None, f"names kept: leader arm order {how}")
                continue
        names = joint_names(groups)
        if features[key].get("shape") != [len(names)]:
            raise ValueError(
                f"info.json {key} has shape {features[key].get('shape')}, but the template describes {len(names)} joints."
            )
        plan[key] = (names, how)
    return plan


def update_info_json(
    meta_dir: Path,
    chunks_size: int,
    tasks: list[dict[str, object]],
    episodes: list[dict[str, object]],
    names: dict[str, list[str]],
) -> tuple[Path, int]:
    path = meta_dir / "info.json"
    with open(path, "r") as f:
        info = json.load(f)

    info["chunks_size"] = int(info.get("chunks_size", chunks_size))
    info["total_episodes"] = len(episodes)
    info["total_frames"] = int(sum(int(ep["length"]) for ep in episodes))
    info["total_tasks"] = len(tasks)
    for key, joint_list in names.items():
        info["features"][key]["names"] = joint_list

    with open(path, "w") as f:
        json.dump(info, f, indent=2)
        f.write("\n")
    return path, info["chunks_size"]


def build_modality(template_path: Path, features: dict, world_camera: str | None) -> dict:
    # The 3-camera template's "world" view is observation.images.world, which only the
    # newer datasets have; point it at the first camera this dataset actually recorded.
    if not template_path.exists():
        raise FileNotFoundError(f"Modality template not found: {template_path}")
    modality = json.loads(template_path.read_text())
    world = modality.get("video", {}).get("world")
    if world_camera:
        if world is None:
            raise ValueError(f"--world-camera was given, but {template_path} has no 'world' camera.")
        world["original_key"] = f"observation.images.{world_camera}"
    elif world is not None:
        world["original_key"] = next(
            (
                f"observation.images.{name}"
                for name in WORLD_CAMERA_CANDIDATES
                if f"observation.images.{name}" in features
            ),
            world["original_key"],
        )
    return modality


def check_modality(modality: dict, template_path: Path, meta_dir: Path, features: dict, modality_config: dict) -> None:
    # Camera names differ between OpenArm B1 datasets (right_wrist vs wrist_right),
    # so refuse to overwrite meta/modality.json with a template that points at missing
    # videos or that lacks keys the modality config (and so training) will ask for.
    missing = [
        video["original_key"]
        for video in modality.get("video", {}).values()
        if video["original_key"] not in features
    ]
    if missing:
        dataset_videos = [key for key, feat in features.items() if feat.get("dtype") == "video"]
        raise ValueError(
            f"{template_path} maps cameras to {missing}, which are not in this dataset. "
            f"Dataset cameras: {dataset_videos}. "
            "Pass a --modality-template whose video original_key values match these cameras."
        )

    for group in ("state", "action", "video"):
        missing = [key for key in modality_config[group].modality_keys if key not in modality.get(group, {})]
        if missing:
            raise ValueError(
                f"The modality config expects {group} keys {missing}, but {template_path} only has "
                f"{list(modality.get(group, {}))}. Pass a matching --modality-template/--modality-config pair."
            )

    # Side-specific joint names already in info.json (left_joint_1, ...) record the arm
    # order too; refuse a template that contradicts them rather than rename the joints.
    for key in ("action", "observation.state"):
        group = JOINT_FEATURES[key]
        old = features.get(key, {}).get("names") or []
        new = joint_names(modality[group]) if modality.get(group) else []
        clash = next((i for i, (o, n) in enumerate(zip(old, new)) if side_of(o) and side_of(o) != side_of(n)), None)
        if clash is not None:
            raise ValueError(
                f"info.json names {key}[{clash}] {old[clash]}, but {template_path} puts {new[clash]} there. "
                "Pass a template with this dataset's arm order."
            )

    # Templates differ in arm order (left arm first vs right arm first), so refuse to
    # move the joint slices that the dataset's current meta/modality.json records.
    current_path = meta_dir / "modality.json"
    if not current_path.exists():
        return
    current = json.loads(current_path.read_text())
    for group in ("state", "action"):
        for key, new in modality.get(group, {}).items():
            old = current.get(group, {}).get(key)
            if old is not None and (old["start"], old["end"]) != (new["start"], new["end"]):
                raise ValueError(
                    f"{template_path} puts {group}.{key} at {new['start']}:{new['end']}, but "
                    f"{current_path} has it at {old['start']}:{old['end']}. Pass a template with this "
                    f"dataset's joint layout, or delete {current_path} if it is wrong."
                )


def write_modality(meta_dir: Path, modality: dict) -> Path:
    path = meta_dir / "modality.json"
    with open(path, "w") as f:
        json.dump(modality, f, indent=2)
        f.write("\n")
    return path


def load_modality_config(config_path: Path) -> dict:
    # Importing the config registers the OPENARM_B1 entry in MODALITY_CONFIGS.
    if not config_path.exists():
        raise FileNotFoundError(f"Modality config not found: {config_path}")
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    spec = importlib.util.spec_from_file_location(config_path.stem, config_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    from gr00t.configs.data.embodiment_configs import MODALITY_CONFIGS
    from gr00t.data.embodiment_tags import EmbodimentTag

    return MODALITY_CONFIGS[EmbodimentTag.resolve(EMBODIMENT_TAG).value]


def run_stats_generation(dataset_root: Path) -> None:
    from gr00t.data.embodiment_tags import EmbodimentTag
    from gr00t.data.stats import generate_rel_stats, generate_stats

    # generate_stats and generate_rel_stats reuse whatever they find on disk, even after
    # episodes were removed or the action chunk length changed, so always start clean.
    meta_dir = dataset_root / "meta"
    for name in ("stats.json", "relative_stats.json"):
        path = meta_dir / name
        if path.exists():
            backup_path = path.with_name(f"{path.stem}.bak.json")
            path.replace(backup_path)
            print(f"  moved old {name} to {backup_path.name}")
    generate_stats(dataset_root)
    generate_rel_stats(dataset_root, EmbodimentTag.resolve(EMBODIMENT_TAG))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Convert an OpenArm B1 (Daksha) dataset into the GR00T/LeRobot metadata layout."
    )
    parser.add_argument(
        "--dataset-root",
        required=True,
        help="Path to the dataset root that contains data/ and meta/.",
    )
    parser.add_argument(
        "--modality-template",
        default=str(DEFAULT_MODALITY_TEMPLATE),
        help="Path to the OpenArm B1 modality.json template copied into meta/.",
    )
    parser.add_argument(
        "--modality-config",
        default=str(DEFAULT_MODALITY_CONFIG),
        help="Path to the OpenArm B1 modality config .py used for stats generation.",
    )
    parser.add_argument(
        "--world-camera",
        help=(
            "Dataset camera to use as the template's 'world' view, e.g. zed_right. "
            f"Default: the first of {', '.join(WORLD_CAMERA_CANDIDATES)} the dataset has."
        ),
    )
    parser.add_argument(
        "--chunks-size",
        type=int,
        default=DEFAULT_CHUNKS_SIZE,
        help="Value to write into meta/info.json if chunks_size is missing.",
    )
    parser.add_argument(
        "--skip-stats",
        action="store_true",
        help="Skip running the GR00T stats generator after metadata conversion.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    dataset_root = resolve_dataset_root(args.dataset_root)
    meta_dir = dataset_root / "meta"
    meta_dir.mkdir(parents=True, exist_ok=True)
    template_path = Path(args.modality_template).expanduser().resolve()
    config_path = Path(args.modality_config).expanduser().resolve()

    modality_config = load_modality_config(config_path)
    tasks = read_tasks(meta_dir)
    episodes = build_episodes(dataset_root)
    features = json.loads((meta_dir / "info.json").read_text())["features"]
    modality = build_modality(template_path, features, args.world_camera)
    check_modality(modality, template_path, meta_dir, features, modality_config)
    names_plan = plan_joint_names(dataset_root, modality, features)

    info_path, chunks_size = update_info_json(
        meta_dir, args.chunks_size, tasks, episodes, {key: names for key, (names, _) in names_plan.items() if names}
    )
    modality_path = write_modality(meta_dir, modality)
    tasks_path = write_tasks_jsonl(meta_dir, tasks)
    episodes_path = write_episodes_jsonl(meta_dir, episodes)

    print("Converted dataset metadata:")
    print(f"  dataset_root: {dataset_root}")
    print(f"  info.json: {info_path}")
    print(f"  modality.json: {modality_path}")
    print(f"  tasks.jsonl: {tasks_path}")
    print(f"  episodes.jsonl: {episodes_path}")
    print(f"  total_episodes: {len(episodes)}")
    print(f"  total_frames: {sum(int(ep['length']) for ep in episodes)}")
    print(f"  chunks_size: {chunks_size}")
    cameras = {key: video["original_key"] for key, video in modality["video"].items()}
    print(f"  cameras: {cameras}")
    for key, (names, how) in names_plan.items():
        print(f"  {key} names: " + (f"{names[0]}, {names[1]}, ... {names[-1]} ({how})" if names else how))

    if not args.skip_stats:
        # No try/except: a dataset without fresh stats must not look converted.
        print(f"Running GR00T stats generation ({EMBODIMENT_TAG}, {config_path.name})...")
        run_stats_generation(dataset_root)
        print("Stats generation complete.")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
