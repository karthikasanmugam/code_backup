"""
Piper real-robot GR00T evaluation bridge with safety controls.

Implements:
- action adaptation: model action[7] -> arm(6) + gripper(1)
- optional 2-finger mirrored gripper output
- joint clamp and per-step rate limiting
- watchdog fallback to hold pose
- validation modes: hold, arm_only, gripper_only, full
- ordered validation suite: hold -> arm_only -> gripper_only -> full
"""

from dataclasses import asdict, dataclass
import logging
from pprint import pformat
import time
from typing import Any, Dict, List

import draccus
from gr00t.policy.server_client import PolicyClient
from lerobot.cameras.opencv.configuration_opencv import OpenCVCameraConfig  # noqa: F401
from lerobot.robots import (  # noqa: F401
    RobotConfig,
    koch_follower,
    make_robot_from_config,
    so100_follower,
    so101_follower,
)
from lerobot.utils.utils import init_logging, log_say
import numpy as np


def recursive_add_extra_dim(obs: Dict[str, Any]) -> Dict[str, Any]:
    for key, val in obs.items():
        if isinstance(val, np.ndarray):
            obs[key] = val[np.newaxis, ...]
        elif isinstance(val, dict):
            obs[key] = recursive_add_extra_dim(val)
        else:
            obs[key] = [val]
    return obs


def parse_csv_list(value: str) -> List[str]:
    return [x.strip() for x in value.split(",") if x.strip()]


def parse_csv_floats(value: str, expected_len: int, name: str) -> np.ndarray:
    vals = np.array([float(x.strip()) for x in value.split(",") if x.strip()], dtype=np.float32)
    if vals.shape[0] != expected_len:
        raise ValueError(f"{name} must have {expected_len} values, got {vals.shape[0]}: {value}")
    return vals


class PiperHardwareAdapter:
    def __init__(self, cfg: "EvalConfig", policy: PolicyClient):
        self.cfg = cfg
        self.policy = policy

        self.arm_obs_keys = parse_csv_list(cfg.arm_obs_keys_csv)
        self.arm_action_keys = parse_csv_list(cfg.arm_action_keys_csv)
        self.gripper_action_keys = parse_csv_list(cfg.gripper_action_keys_csv)

        if len(self.arm_obs_keys) != 6:
            raise ValueError("arm_obs_keys_csv must contain exactly 6 observation keys")
        if len(self.arm_action_keys) != 6:
            raise ValueError("arm_action_keys_csv must contain exactly 6 action keys")
        if len(self.gripper_action_keys) not in (1, 2):
            raise ValueError("gripper_action_keys_csv must contain 1 or 2 action keys")

        self.arm_min = parse_csv_floats(cfg.arm_min_csv, expected_len=6, name="arm_min_csv")
        self.arm_max = parse_csv_floats(cfg.arm_max_csv, expected_len=6, name="arm_max_csv")
        self.max_step_delta = parse_csv_floats(
            cfg.max_step_delta_csv, expected_len=6, name="max_step_delta_csv"
        )

        self.prev_arm_cmd: np.ndarray | None = None
        self.last_policy_ok_time = 0.0

    def _obs_to_policy_inputs(self, obs: Dict[str, Any], lang: str) -> Dict[str, Any]:
        model_obs: Dict[str, Any] = {
            "video": {
                "world": obs[self.cfg.world_camera_obs_key],
                "front_left": obs[self.cfg.front_left_camera_obs_key],
                "front_right": obs[self.cfg.front_right_camera_obs_key],
                "wrist": obs[self.cfg.wrist_camera_obs_key],
            },
            "state": {
                "single_arm": np.array([obs[k] for k in self.arm_obs_keys], dtype=np.float32),
                "gripper": np.array([obs[self.cfg.gripper_obs_key]], dtype=np.float32),
            },
            "language": {"annotation.human.task_description": lang},
        }
        model_obs = recursive_add_extra_dim(model_obs)
        model_obs = recursive_add_extra_dim(model_obs)
        return model_obs

    def _extract_action_vec7(self, action_chunk: Dict[str, Any], t: int) -> np.ndarray:
        # Preferred output format from Gr00tPolicy
        if "single_arm" in action_chunk and "gripper" in action_chunk:
            arm = np.asarray(action_chunk["single_arm"][0][t], dtype=np.float32).reshape(-1)
            grip = np.asarray(action_chunk["gripper"][0][t], dtype=np.float32).reshape(-1)
            if arm.shape[0] != 6 or grip.shape[0] != 1:
                raise ValueError(
                    f"Unexpected action dims from policy: single_arm={arm.shape}, gripper={grip.shape}"
                )
            return np.concatenate([arm, grip], axis=0)

        # Sim-wrapper style fallback
        if "action.single_arm" in action_chunk and "action.gripper" in action_chunk:
            arm = np.asarray(action_chunk["action.single_arm"][0][t], dtype=np.float32).reshape(-1)
            grip = np.asarray(action_chunk["action.gripper"][0][t], dtype=np.float32).reshape(-1)
            if arm.shape[0] != 6 or grip.shape[0] != 1:
                raise ValueError(
                    f"Unexpected sim-wrapper action dims: single_arm={arm.shape}, gripper={grip.shape}"
                )
            return np.concatenate([arm, grip], axis=0)

        # Flat vector fallback
        if "action" in action_chunk:
            vec = np.asarray(action_chunk["action"][0][t], dtype=np.float32).reshape(-1)
            if vec.shape[0] != 7:
                raise ValueError(f"Expected action[7], got action[{vec.shape[0]}]")
            return vec

        raise ValueError(f"Unsupported action chunk keys: {list(action_chunk.keys())}")

    def _read_hold_vec(self, obs: Dict[str, Any]) -> np.ndarray:
        arm_now = np.array([obs[k] for k in self.arm_obs_keys], dtype=np.float32)
        gripper_now = np.array([obs[self.cfg.gripper_obs_key]], dtype=np.float32)
        return np.concatenate([arm_now, gripper_now], axis=0)

    def _apply_safety(self, target_vec7: np.ndarray, hold_vec7: np.ndarray, mode: str) -> tuple[np.ndarray, float]:
        target_arm = np.clip(target_vec7[:6], self.arm_min, self.arm_max)

        if self.prev_arm_cmd is None:
            self.prev_arm_cmd = hold_vec7[:6].copy()

        arm_delta = target_arm - self.prev_arm_cmd
        arm_delta = np.clip(arm_delta, -self.max_step_delta, self.max_step_delta)
        arm_cmd = np.clip(self.prev_arm_cmd + arm_delta, self.arm_min, self.arm_max)

        grip = float(target_vec7[6] * self.cfg.gripper_scale + self.cfg.gripper_offset)
        grip = float(np.clip(grip, self.cfg.gripper_min, self.cfg.gripper_max))

        if mode == "hold":
            arm_cmd = hold_vec7[:6].copy()
            grip = float(hold_vec7[6])
        elif mode == "arm_only":
            grip = float(hold_vec7[6])
        elif mode == "gripper_only":
            arm_cmd = hold_vec7[:6].copy()
        elif mode == "full":
            pass
        else:
            raise ValueError(f"Unknown mode: {mode}")

        self.prev_arm_cmd = arm_cmd.copy()
        return arm_cmd, grip

    def _to_robot_action_dict(self, arm_cmd: np.ndarray, gripper_cmd: float) -> Dict[str, float]:
        action = {name: float(arm_cmd[i]) for i, name in enumerate(self.arm_action_keys)}

        if len(self.gripper_action_keys) == 1:
            action[self.gripper_action_keys[0]] = float(gripper_cmd)
        else:
            action[self.gripper_action_keys[0]] = float(gripper_cmd)
            mirrored = float(self.cfg.second_gripper_mirror_sign * gripper_cmd)
            action[self.gripper_action_keys[1]] = mirrored

        return action

    def hold_action(self, obs: Dict[str, Any]) -> Dict[str, float]:
        hold = self._read_hold_vec(obs)
        return self._to_robot_action_dict(hold[:6], float(hold[6]))

    def plan_actions(self, obs: Dict[str, Any], mode: str) -> List[Dict[str, float]]:
        hold_vec = self._read_hold_vec(obs)

        if mode == "hold":
            return [self._to_robot_action_dict(hold_vec[:6], float(hold_vec[6]))]

        model_input = self._obs_to_policy_inputs(obs, self.cfg.lang_instruction)
        action_chunk, _ = self.policy.get_action(model_input)
        self.last_policy_ok_time = time.monotonic()

        horizon_key = next(iter(action_chunk.keys()))
        horizon = int(np.asarray(action_chunk[horizon_key]).shape[1])

        out: List[Dict[str, float]] = []
        for t in range(min(horizon, self.cfg.action_horizon)):
            vec7 = self._extract_action_vec7(action_chunk, t)
            arm_cmd, grip_cmd = self._apply_safety(vec7, hold_vec, mode=mode)
            out.append(self._to_robot_action_dict(arm_cmd, grip_cmd))
        return out


@dataclass
class EvalConfig:
    robot: RobotConfig

    policy_host: str = "localhost"
    policy_port: int = 5555

    lang_instruction: str = "Pick up the orange and place it on the plate."

    action_horizon: int = 8
    control_hz: float = 30.0
    watchdog_timeout_s: float = 1.0

    # Validation
    validation_mode: str = "full"  # hold | arm_only | gripper_only | full
    run_validation_suite: bool = False
    phase_seconds: float = 12.0

    # Observation keys
    world_camera_obs_key: str = "world"
    front_left_camera_obs_key: str = "front_left"
    front_right_camera_obs_key: str = "front_right"
    wrist_camera_obs_key: str = "wrist"

    arm_obs_keys_csv: str = "joint_1,joint_2,joint_3,joint_4,joint_5,joint_6"
    gripper_obs_key: str = "joint_7"

    # Robot command keys
    arm_action_keys_csv: str = "joint_1,joint_2,joint_3,joint_4,joint_5,joint_6"
    gripper_action_keys_csv: str = "joint_7"
    second_gripper_mirror_sign: float = -1.0

    # Safety constraints
    arm_min_csv: str = "-0.7161285,-0.03820236,-1.5631742,-1.007391,-0.7551507,-0.8011157"
    arm_max_csv: str = "0.8281539,2.1425767,0.04277269,0.83614326,1.1717832,2.2785003"
    max_step_delta_csv: str = "0.03,0.03,0.03,0.03,0.03,0.03"

    gripper_min: float = -0.0037
    gripper_max: float = 0.1030
    gripper_scale: float = 1.0
    gripper_offset: float = 0.0

    play_sounds: bool = False


@draccus.wrap()
def eval(cfg: EvalConfig):
    init_logging()
    logging.info("Piper eval config:\n%s", pformat(asdict(cfg)))

    robot = make_robot_from_config(cfg.robot)
    robot.connect()

    policy_client = PolicyClient(host=cfg.policy_host, port=cfg.policy_port)
    adapter = PiperHardwareAdapter(cfg, policy_client)

    valid_modes = {"hold", "arm_only", "gripper_only", "full"}
    if cfg.validation_mode not in valid_modes:
        raise ValueError(f"validation_mode must be one of {sorted(valid_modes)}")

    if cfg.run_validation_suite:
        modes = ["hold", "arm_only", "gripper_only", "full"]
    else:
        modes = [cfg.validation_mode]

    log_say("Piper policy bridge ready", cfg.play_sounds, blocking=True)

    dt = 1.0 / cfg.control_hz

    for mode in modes:
        logging.info("Starting mode: %s", mode)
        if cfg.run_validation_suite:
            deadline = time.monotonic() + cfg.phase_seconds
        else:
            deadline = None

        planned: List[Dict[str, float]] = []

        while True:
            if deadline is not None and time.monotonic() >= deadline:
                logging.info("Completed mode: %s", mode)
                break

            tic = time.monotonic()
            obs = robot.get_observation()

            # Watchdog: if policy has been stale too long, hold pose
            stale = (
                adapter.last_policy_ok_time > 0
                and (time.monotonic() - adapter.last_policy_ok_time) > cfg.watchdog_timeout_s
            )

            if mode == "hold" or stale:
                action_dict = adapter.hold_action(obs)
                planned.clear()
            else:
                if not planned:
                    try:
                        planned = adapter.plan_actions(obs, mode)
                    except Exception as exc:
                        logging.exception("Policy planning failed (%s). Falling back to hold.", exc)
                        planned = []

                if planned:
                    action_dict = planned.pop(0)
                else:
                    action_dict = adapter.hold_action(obs)

            robot.send_action(action_dict)

            elapsed = time.monotonic() - tic
            if elapsed < dt:
                time.sleep(dt - elapsed)


if __name__ == "__main__":
    eval()
