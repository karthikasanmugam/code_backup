

#!/usr/bin/env python3
"""
ROS2 Piper bridge for GR00T policy server.

System A (GPU): run GR00T server (`run_gr00t_server.py`) on tcp://<A_IP>:5555
System B (Thunder): run this bridge to:
  - read ROS2 joint + camera observations
  - query GR00T PolicyClient
  - publish safe joint commands to robot command topic

This bridge is intended for Piper CAN/ROS stacks (not LeRobot serial drivers).
"""

from __future__ import annotations

import argparse
from collections import deque
import time
from typing import Any

import cv2
import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import CompressedImage, JointState

from gr00t.policy.server_client import PolicyClient


def parse_csv_list(value: str) -> list[str]:
    return [x.strip() for x in value.split(",") if x.strip()]


def parse_csv_floats(value: str, expected_len: int, name: str) -> np.ndarray:
    vals = np.array([float(x.strip()) for x in value.split(",") if x.strip()], dtype=np.float32)
    if vals.shape[0] != expected_len:
        raise ValueError(f"{name} must have {expected_len} values, got {vals.shape[0]}: {value}")
    return vals


def recursive_add_extra_dim(obs: dict[str, Any]) -> dict[str, Any]:
    """Mirror shaping logic used by existing GR00T real-robot bridge."""
    for key, val in obs.items():
        if isinstance(val, np.ndarray):
            obs[key] = val[np.newaxis, ...]
        elif isinstance(val, dict):
            obs[key] = recursive_add_extra_dim(val)
        else:
            obs[key] = [val]
    return obs


class Gr00TPiperRosBridge(Node):
    def __init__(self, args: argparse.Namespace):
        super().__init__("gr00t_piper_ros2_bridge")
        self.args = args

        # Policy connection
        self.policy = PolicyClient(host=args.policy_host, port=args.policy_port, strict=False)
        if not self.policy.ping():
            raise RuntimeError(
                f"Could not reach GR00T server at tcp://{args.policy_host}:{args.policy_port}"
            )

        # Key configuration
        self.arm_obs_keys = parse_csv_list(args.arm_obs_keys_csv)
        self.arm_cmd_keys = parse_csv_list(args.arm_cmd_keys_csv)
        self.gripper_cmd_keys = parse_csv_list(args.gripper_cmd_keys_csv)
        self.gripper_obs_key = args.gripper_obs_key

        if len(self.arm_obs_keys) != 6:
            raise ValueError("arm_obs_keys_csv must contain exactly 6 keys")
        if len(self.arm_cmd_keys) != 6:
            raise ValueError("arm_cmd_keys_csv must contain exactly 6 keys")
        if len(self.gripper_cmd_keys) not in (1, 2):
            raise ValueError("gripper_cmd_keys_csv must contain 1 or 2 keys")

        # Safety configuration
        self.arm_min = parse_csv_floats(args.arm_min_csv, 6, "arm_min_csv")
        self.arm_max = parse_csv_floats(args.arm_max_csv, 6, "arm_max_csv")
        self.max_step_delta = parse_csv_floats(args.max_step_delta_csv, 6, "max_step_delta_csv")
        self.prev_arm_cmd: np.ndarray | None = None
        self.last_policy_ok_time = 0.0

        # Observation caches
        self.latest_joint_map: dict[str, float] = {}
        self.latest_images: dict[str, np.ndarray] = {}

        # Action planning queue
        self.planned_actions: deque[JointState] = deque()

        # Validation phases
        self.valid_modes = ["hold", "arm_only", "gripper_only", "full"]
        if args.run_validation_suite:
            self.phase_modes = list(self.valid_modes)
        else:
            if args.validation_mode not in self.valid_modes:
                raise ValueError(f"validation_mode must be one of {self.valid_modes}")
            self.phase_modes = [args.validation_mode]
        self.phase_idx = 0
        self.phase_start_t = time.monotonic()
        self.finished = False
        self.get_logger().info(f"Validation phases: {self.phase_modes}")

        # ROS interfaces
        self.create_subscription(
            JointState, args.joint_state_topic, self._joint_cb, qos_profile_sensor_data
        )
        self.create_subscription(
            CompressedImage, args.world_topic, lambda m: self._image_cb("world", m), qos_profile_sensor_data
        )
        self.create_subscription(
            CompressedImage,
            args.front_left_topic,
            lambda m: self._image_cb("front_left", m),
            qos_profile_sensor_data,
        )
        self.create_subscription(
            CompressedImage,
            args.front_right_topic,
            lambda m: self._image_cb("front_right", m),
            qos_profile_sensor_data,
        )
        self.create_subscription(
            CompressedImage, args.wrist_topic, lambda m: self._image_cb("wrist", m), qos_profile_sensor_data
        )
        self.cmd_pub = self.create_publisher(JointState, args.cmd_topic, 10)

        self.timer = self.create_timer(1.0 / args.control_hz, self._control_step)
        self.get_logger().info(
            f"Bridge started. Server=tcp://{args.policy_host}:{args.policy_port}, cmd_topic={args.cmd_topic}"
        )

    def _joint_cb(self, msg: JointState) -> None:
        if msg.name and msg.position and len(msg.name) == len(msg.position):
            for n, p in zip(msg.name, msg.position):
                self.latest_joint_map[n] = float(p)
        elif msg.position:
            # fallback if names absent; assume arm_obs_keys order then gripper
            ordered = self.arm_obs_keys + [self.gripper_obs_key]
            for i, key in enumerate(ordered[: len(msg.position)]):
                self.latest_joint_map[key] = float(msg.position[i])

    def _image_cb(self, cam_key: str, msg: CompressedImage) -> None:
        np_arr = np.frombuffer(msg.data, dtype=np.uint8)
        bgr = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        if bgr is None:
            return
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        self.latest_images[cam_key] = rgb.astype(np.uint8)

    def _current_mode(self) -> str | None:
        if self.finished:
            return None
        mode = self.phase_modes[self.phase_idx]
        if self.args.run_validation_suite:
            elapsed = time.monotonic() - self.phase_start_t
            if elapsed >= self.args.phase_seconds:
                self.get_logger().info(f"Completed phase: {mode}")
                self.phase_idx += 1
                if self.phase_idx >= len(self.phase_modes):
                    self.get_logger().info("Validation suite complete.")
                    self.finished = True
                    return None
                self.phase_start_t = time.monotonic()
                mode = self.phase_modes[self.phase_idx]
                self.planned_actions.clear()
                self.get_logger().info(f"Starting phase: {mode}")
        return mode

    def _ready(self) -> bool:
        for k in self.arm_obs_keys + [self.gripper_obs_key]:
            if k not in self.latest_joint_map:
                return False
        for k in ("world", "front_left", "front_right", "wrist"):
            if k not in self.latest_images:
                return False
        return True

    def _hold_vec7(self) -> np.ndarray:
        arm = np.array([self.latest_joint_map[k] for k in self.arm_obs_keys], dtype=np.float32)
        grip = np.array([self.latest_joint_map[self.gripper_obs_key]], dtype=np.float32)
        return np.concatenate([arm, grip], axis=0)

    def _obs_for_policy(self) -> dict[str, Any]:
        obs = {
            "video": {
                self.args.world_camera_key: self.latest_images["world"],
                self.args.front_left_camera_key: self.latest_images["front_left"],
                self.args.front_right_camera_key: self.latest_images["front_right"],
                self.args.wrist_camera_key: self.latest_images["wrist"],
            },
            "state": {
                "single_arm": np.array(
                    [self.latest_joint_map[k] for k in self.arm_obs_keys], dtype=np.float32
                ),
                "gripper": np.array([self.latest_joint_map[self.gripper_obs_key]], dtype=np.float32),
            },
            "language": {"annotation.human.task_description": self.args.lang_instruction},
        }
        obs = recursive_add_extra_dim(obs)
        obs = recursive_add_extra_dim(obs)
        return obs

    @staticmethod
    def _extract_action_vec7(action_chunk: dict[str, Any], t: int) -> np.ndarray:
        if "single_arm" in action_chunk and "gripper" in action_chunk:
            arm = np.asarray(action_chunk["single_arm"][0][t], dtype=np.float32).reshape(-1)
            grip = np.asarray(action_chunk["gripper"][0][t], dtype=np.float32).reshape(-1)
            if arm.shape[0] != 6 or grip.shape[0] != 1:
                raise ValueError(f"Unexpected action dims: arm={arm.shape}, gripper={grip.shape}")
            return np.concatenate([arm, grip], axis=0)
        if "action.single_arm" in action_chunk and "action.gripper" in action_chunk:
            arm = np.asarray(action_chunk["action.single_arm"][0][t], dtype=np.float32).reshape(-1)
            grip = np.asarray(action_chunk["action.gripper"][0][t], dtype=np.float32).reshape(-1)
            if arm.shape[0] != 6 or grip.shape[0] != 1:
                raise ValueError(f"Unexpected action dims: arm={arm.shape}, gripper={grip.shape}")
            return np.concatenate([arm, grip], axis=0)
        if "action" in action_chunk:
            vec = np.asarray(action_chunk["action"][0][t], dtype=np.float32).reshape(-1)
            if vec.shape[0] != 7:
                raise ValueError(f"Expected action[7], got {vec.shape[0]}")
            return vec
        raise ValueError(f"Unsupported action chunk keys: {list(action_chunk.keys())}")

    def _apply_safety(self, target_vec7: np.ndarray, hold_vec7: np.ndarray, mode: str) -> tuple[np.ndarray, float]:
        target_arm = np.clip(target_vec7[:6], self.arm_min, self.arm_max)
        if self.prev_arm_cmd is None:
            self.prev_arm_cmd = hold_vec7[:6].copy()
        arm_delta = np.clip(target_arm - self.prev_arm_cmd, -self.max_step_delta, self.max_step_delta)
        arm_cmd = np.clip(self.prev_arm_cmd + arm_delta, self.arm_min, self.arm_max)

        grip = float(target_vec7[6] * self.args.gripper_scale + self.args.gripper_offset)
        grip = float(np.clip(grip, self.args.gripper_min, self.args.gripper_max))

        if mode == "hold":
            arm_cmd = hold_vec7[:6].copy()
            grip = float(hold_vec7[6])
        elif mode == "arm_only":
            grip = float(hold_vec7[6])
        elif mode == "gripper_only":
            arm_cmd = hold_vec7[:6].copy()

        self.prev_arm_cmd = arm_cmd.copy()
        return arm_cmd, grip

    def _to_joint_state_msg(self, arm_cmd: np.ndarray, grip_cmd: float) -> JointState:
        msg = JointState()
        msg.header.stamp = self.get_clock().now().to_msg()

        names = list(self.arm_cmd_keys)
        pos = [float(x) for x in arm_cmd]
        if len(self.gripper_cmd_keys) == 1:
            names.append(self.gripper_cmd_keys[0])
            pos.append(float(grip_cmd))
        else:
            names.append(self.gripper_cmd_keys[0])
            pos.append(float(grip_cmd))
            names.append(self.gripper_cmd_keys[1])
            pos.append(float(self.args.second_gripper_mirror_sign * grip_cmd))

        msg.name = names
        msg.position = pos
        return msg

    def _plan_from_policy(self, mode: str) -> None:
        hold_vec7 = self._hold_vec7()
        obs = self._obs_for_policy()
        action_chunk, _ = self.policy.get_action(obs)
        self.last_policy_ok_time = time.monotonic()

        any_key = next(iter(action_chunk.keys()))
        horizon = int(np.asarray(action_chunk[any_key]).shape[1])
        steps = min(horizon, self.args.action_horizon)

        for t in range(steps):
            vec7 = self._extract_action_vec7(action_chunk, t)
            arm_cmd, grip_cmd = self._apply_safety(vec7, hold_vec7, mode)
            self.planned_actions.append(self._to_joint_state_msg(arm_cmd, grip_cmd))

    def _publish_hold(self) -> None:
        hold_vec7 = self._hold_vec7()
        msg = self._to_joint_state_msg(hold_vec7[:6], float(hold_vec7[6]))
        self.cmd_pub.publish(msg)

    def _control_step(self) -> None:
        mode = self._current_mode()
        if mode is None:
            if self._ready():
                self._publish_hold()
            return
        if not self._ready():
            return

        stale = (
            self.last_policy_ok_time > 0
            and (time.monotonic() - self.last_policy_ok_time) > self.args.watchdog_timeout_s
        )
        if mode == "hold" or stale:
            self.planned_actions.clear()
            self._publish_hold()
            return

        if not self.planned_actions:
            try:
                self._plan_from_policy(mode)
            except Exception as exc:
                self.get_logger().error(f"Policy planning failed: {exc}")
                self.planned_actions.clear()
                self._publish_hold()
                return

        if self.planned_actions:
            self.cmd_pub.publish(self.planned_actions.popleft())
        else:
            self._publish_hold()


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser("Piper ROS2 bridge for GR00T policy server")

    # Policy
    p.add_argument("--policy-host", default="127.0.0.1")
    p.add_argument("--policy-port", type=int, default=5555)
    p.add_argument("--lang-instruction", default="Pick up the brown block and place it in the blue box.")
    p.add_argument("--action-horizon", type=int, default=8)
    p.add_argument("--control-hz", type=float, default=10.0)
    p.add_argument("--watchdog-timeout-s", type=float, default=1.0)

    # Validation
    p.add_argument("--validation-mode", choices=["hold", "arm_only", "gripper_only", "full"], default="full")
    p.add_argument("--run-validation-suite", action="store_true")
    p.add_argument("--phase-seconds", type=float, default=12.0)

    # ROS topics
    p.add_argument("--joint-state-topic", default="/joint_states_right")
    p.add_argument("--cmd-topic", default="/joint_ctrl_cmd_right")
    p.add_argument("--world-topic", default="/world/camera/image_raw/compressed")
    p.add_argument("--front-left-topic", default="/front/left/image_raw/compressed")
    p.add_argument("--front-right-topic", default="/front/right/image_raw/compressed")
    p.add_argument("--wrist-topic", default="/waveshare/cam1/image_raw/compressed")

    # Policy modality keys
    p.add_argument("--world-camera-key", default="world")
    p.add_argument("--front-left-camera-key", default="front_left")
    p.add_argument("--front-right-camera-key", default="front_right")
    p.add_argument("--wrist-camera-key", default="wrist")

    # Joint key mapping
    p.add_argument("--arm-obs-keys-csv", default="joint1,joint2,joint3,joint4,joint5,joint6")
    p.add_argument("--gripper-obs-key", default="gripper")
    p.add_argument("--arm-cmd-keys-csv", default="joint1,joint2,joint3,joint4,joint5,joint6")
    p.add_argument("--gripper-cmd-keys-csv", default="gripper")
    p.add_argument("--second-gripper-mirror-sign", type=float, default=-1.0)

    # Safety
    p.add_argument(
        "--arm-min-csv",
        default="-0.7161285,-0.03820236,-1.5631742,-1.007391,-0.7551507,-0.8011157",
    )
    p.add_argument(
        "--arm-max-csv",
        default="0.8281539,2.1425767,0.04277269,0.83614326,1.1717832,2.2785003",
    )
    p.add_argument("--max-step-delta-csv", default="0.03,0.03,0.03,0.03,0.03,0.03")
    p.add_argument("--gripper-min", type=float, default=-0.0037)
    p.add_argument("--gripper-max", type=float, default=0.1030)
    p.add_argument("--gripper-scale", type=float, default=1.0)
    p.add_argument("--gripper-offset", type=float, default=0.0)
    return p


def main() -> None:
    args = build_arg_parser().parse_args()
    rclpy.init()
    node = Gr00TPiperRosBridge(args)
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()



# #!/usr/bin/env python3
# """
# ROS2 Piper bridge for GR00T policy server.

# System A (GPU): run GR00T server (`run_gr00t_server.py`) on tcp://<A_IP>:5555
# System B (Thunder): run this bridge to:
#   - read ROS2 joint + camera observations
#   - query GR00T PolicyClient
#   - publish safe joint commands to robot command topic

# This bridge is intended for Piper CAN/ROS stacks (not LeRobot serial drivers).
# """

# from __future__ import annotations

# import argparse
# from collections import deque
# import time
# from typing import Any

# import cv2
# import numpy as np
# import rclpy
# from rclpy.node import Node
# from rclpy.qos import qos_profile_sensor_data
# from sensor_msgs.msg import CompressedImage, JointState

# from gr00t.policy.server_client import PolicyClient


# def parse_csv_list(value: str) -> list[str]:
#     return [x.strip() for x in value.split(",") if x.strip()]


# def parse_csv_floats(value: str, expected_len: int, name: str) -> np.ndarray:
#     vals = np.array([float(x.strip()) for x in value.split(",") if x.strip()], dtype=np.float32)
#     if vals.shape[0] != expected_len:
#         raise ValueError(f"{name} must have {expected_len} values, got {vals.shape[0]}: {value}")
#     return vals


# def recursive_add_extra_dim(obs: dict[str, Any]) -> dict[str, Any]:
#     """Mirror shaping logic used by existing GR00T real-robot bridge."""
#     for key, val in obs.items():
#         if isinstance(val, np.ndarray):
#             obs[key] = val[np.newaxis, ...]
#         elif isinstance(val, dict):
#             obs[key] = recursive_add_extra_dim(val)
#         else:
#             obs[key] = [val]
#     return obs


# class Gr00TPiperRosBridge(Node):
#     def __init__(self, args: argparse.Namespace):
#         super().__init__("gr00t_piper_ros2_bridge")
#         self.args = args

#         # Policy connection
#         self.policy = PolicyClient(host=args.policy_host, port=args.policy_port, strict=False)
#         if not self.policy.ping():
#             raise RuntimeError(
#                 f"Could not reach GR00T server at tcp://{args.policy_host}:{args.policy_port}"
#             )

#         # Key configuration
#         self.arm_obs_keys = parse_csv_list(args.arm_obs_keys_csv)
#         self.arm_cmd_keys = parse_csv_list(args.arm_cmd_keys_csv)
#         self.gripper_cmd_keys = parse_csv_list(args.gripper_cmd_keys_csv)
#         self.gripper_obs_key = args.gripper_obs_key

#         if len(self.arm_obs_keys) != 6:
#             raise ValueError("arm_obs_keys_csv must contain exactly 6 keys")
#         if len(self.arm_cmd_keys) != 6:
#             raise ValueError("arm_cmd_keys_csv must contain exactly 6 keys")
#         if len(self.gripper_cmd_keys) not in (1, 2):
#             raise ValueError("gripper_cmd_keys_csv must contain 1 or 2 keys")

#         # Safety configuration
#         self.arm_min = parse_csv_floats(args.arm_min_csv, 6, "arm_min_csv")
#         self.arm_max = parse_csv_floats(args.arm_max_csv, 6, "arm_max_csv")
#         self.max_step_delta = parse_csv_floats(args.max_step_delta_csv, 6, "max_step_delta_csv")
#         self.prev_arm_cmd: np.ndarray | None = None
#         self.last_policy_ok_time = 0.0

#         # Observation caches
#         self.latest_joint_map: dict[str, float] = {}
#         self.latest_images: dict[str, np.ndarray] = {}

#         # Action planning queue
#         self.planned_actions: deque[JointState] = deque()

#         # Validation phases
#         self.valid_modes = ["hold", "arm_only", "gripper_only", "full"]
#         if args.run_validation_suite:
#             self.phase_modes = list(self.valid_modes)
#         else:
#             if args.validation_mode not in self.valid_modes:
#                 raise ValueError(f"validation_mode must be one of {self.valid_modes}")
#             self.phase_modes = [args.validation_mode]
#         self.phase_idx = 0
#         self.phase_start_t = time.monotonic()
#         self.finished = False
#         self.get_logger().info(f"Validation phases: {self.phase_modes}")

#         # ROS interfaces
#         self.create_subscription(
#             JointState, args.joint_state_topic, self._joint_cb, qos_profile_sensor_data
#         )
#         self.create_subscription(
#             CompressedImage, args.world_topic, lambda m: self._image_cb("world", m), qos_profile_sensor_data
#         )
#         self.create_subscription(
#             CompressedImage, args.wrist_topic, lambda m: self._image_cb("wrist", m), qos_profile_sensor_data
#         )
#         self.cmd_pub = self.create_publisher(JointState, args.cmd_topic, 10)

#         self.timer = self.create_timer(1.0 / args.control_hz, self._control_step)
#         self.get_logger().info(
#             f"Bridge started. Server=tcp://{args.policy_host}:{args.policy_port}, cmd_topic={args.cmd_topic}"
#         )

#     def _joint_cb(self, msg: JointState) -> None:
#         if msg.name and msg.position and len(msg.name) == len(msg.position):
#             for n, p in zip(msg.name, msg.position):
#                 self.latest_joint_map[n] = float(p)
#         elif msg.position:
#             # fallback if names absent; assume arm_obs_keys order then gripper
#             ordered = self.arm_obs_keys + [self.gripper_obs_key]
#             for i, key in enumerate(ordered[: len(msg.position)]):
#                 self.latest_joint_map[key] = float(msg.position[i])

#     def _image_cb(self, cam_key: str, msg: CompressedImage) -> None:
#         np_arr = np.frombuffer(msg.data, dtype=np.uint8)
#         bgr = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
#         if bgr is None:
#             return
#         rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
#         self.latest_images[cam_key] = rgb.astype(np.uint8)

#     def _current_mode(self) -> str | None:
#         if self.finished:
#             return None
#         mode = self.phase_modes[self.phase_idx]
#         if self.args.run_validation_suite:
#             elapsed = time.monotonic() - self.phase_start_t
#             if elapsed >= self.args.phase_seconds:
#                 self.get_logger().info(f"Completed phase: {mode}")
#                 self.phase_idx += 1
#                 if self.phase_idx >= len(self.phase_modes):
#                     self.get_logger().info("Validation suite complete.")
#                     self.finished = True
#                     return None
#                 self.phase_start_t = time.monotonic()
#                 mode = self.phase_modes[self.phase_idx]
#                 self.planned_actions.clear()
#                 self.get_logger().info(f"Starting phase: {mode}")
#         return mode

#     def _ready(self) -> bool:
#         for k in self.arm_obs_keys + [self.gripper_obs_key]:
#             if k not in self.latest_joint_map:
#                 return False
#         for k in ("world", "wrist"):
#             if k not in self.latest_images:
#                 return False
#         return True

#     def _hold_vec7(self) -> np.ndarray:
#         arm = np.array([self.latest_joint_map[k] for k in self.arm_obs_keys], dtype=np.float32)
#         grip = np.array([self.latest_joint_map[self.gripper_obs_key]], dtype=np.float32)
#         return np.concatenate([arm, grip], axis=0)

#     def _obs_for_policy(self) -> dict[str, Any]:
#         obs = {
#             "video": {
#                 self.args.world_camera_key: self.latest_images["world"],
#                 self.args.wrist_camera_key: self.latest_images["wrist"],
#             },
#             "state": {
#                 "single_arm": np.array(
#                     [self.latest_joint_map[k] for k in self.arm_obs_keys], dtype=np.float32
#                 ),
#                 "gripper": np.array([self.latest_joint_map[self.gripper_obs_key]], dtype=np.float32),
#             },
#             "language": {"annotation.human.task_description": self.args.lang_instruction},
#         }
#         obs = recursive_add_extra_dim(obs)
#         obs = recursive_add_extra_dim(obs)
#         return obs

#     @staticmethod
#     def _extract_action_vec7(action_chunk: dict[str, Any], t: int) -> np.ndarray:
#         if "single_arm" in action_chunk and "gripper" in action_chunk:
#             arm = np.asarray(action_chunk["single_arm"][0][t], dtype=np.float32).reshape(-1)
#             grip = np.asarray(action_chunk["gripper"][0][t], dtype=np.float32).reshape(-1)
#             if arm.shape[0] != 6 or grip.shape[0] != 1:
#                 raise ValueError(f"Unexpected action dims: arm={arm.shape}, gripper={grip.shape}")
#             return np.concatenate([arm, grip], axis=0)
#         if "action.single_arm" in action_chunk and "action.gripper" in action_chunk:
#             arm = np.asarray(action_chunk["action.single_arm"][0][t], dtype=np.float32).reshape(-1)
#             grip = np.asarray(action_chunk["action.gripper"][0][t], dtype=np.float32).reshape(-1)
#             if arm.shape[0] != 6 or grip.shape[0] != 1:
#                 raise ValueError(f"Unexpected action dims: arm={arm.shape}, gripper={grip.shape}")
#             return np.concatenate([arm, grip], axis=0)
#         if "action" in action_chunk:
#             vec = np.asarray(action_chunk["action"][0][t], dtype=np.float32).reshape(-1)
#             if vec.shape[0] != 7:
#                 raise ValueError(f"Expected action[7], got {vec.shape[0]}")
#             return vec
#         raise ValueError(f"Unsupported action chunk keys: {list(action_chunk.keys())}")

#     def _apply_safety(self, target_vec7: np.ndarray, hold_vec7: np.ndarray, mode: str) -> tuple[np.ndarray, float]:
#         target_arm = np.clip(target_vec7[:6], self.arm_min, self.arm_max)
#         if self.prev_arm_cmd is None:
#             self.prev_arm_cmd = hold_vec7[:6].copy()
#         arm_delta = np.clip(target_arm - self.prev_arm_cmd, -self.max_step_delta, self.max_step_delta)
#         arm_cmd = np.clip(self.prev_arm_cmd + arm_delta, self.arm_min, self.arm_max)

#         grip = float(target_vec7[6] * self.args.gripper_scale + self.args.gripper_offset)
#         grip = float(np.clip(grip, self.args.gripper_min, self.args.gripper_max))

#         if mode == "hold":
#             arm_cmd = hold_vec7[:6].copy()
#             grip = float(hold_vec7[6])
#         elif mode == "arm_only":
#             grip = float(hold_vec7[6])
#         elif mode == "gripper_only":
#             arm_cmd = hold_vec7[:6].copy()

#         self.prev_arm_cmd = arm_cmd.copy()
#         return arm_cmd, grip

#     def _to_joint_state_msg(self, arm_cmd: np.ndarray, grip_cmd: float) -> JointState:
#         msg = JointState()
#         msg.header.stamp = self.get_clock().now().to_msg()

#         names = list(self.arm_cmd_keys)
#         pos = [float(x) for x in arm_cmd]
#         if len(self.gripper_cmd_keys) == 1:
#             names.append(self.gripper_cmd_keys[0])
#             pos.append(float(grip_cmd))
#         else:
#             names.append(self.gripper_cmd_keys[0])
#             pos.append(float(grip_cmd))
#             names.append(self.gripper_cmd_keys[1])
#             pos.append(float(self.args.second_gripper_mirror_sign * grip_cmd))

#         msg.name = names
#         msg.position = pos
#         return msg

#     def _plan_from_policy(self, mode: str) -> None:
#         hold_vec7 = self._hold_vec7()
#         obs = self._obs_for_policy()
#         action_chunk, _ = self.policy.get_action(obs)
#         self.last_policy_ok_time = time.monotonic()

#         any_key = next(iter(action_chunk.keys()))
#         horizon = int(np.asarray(action_chunk[any_key]).shape[1])
#         steps = min(horizon, self.args.action_horizon)

#         for t in range(steps):
#             vec7 = self._extract_action_vec7(action_chunk, t)
#             arm_cmd, grip_cmd = self._apply_safety(vec7, hold_vec7, mode)
#             self.planned_actions.append(self._to_joint_state_msg(arm_cmd, grip_cmd))

#     def _publish_hold(self) -> None:
#         hold_vec7 = self._hold_vec7()
#         msg = self._to_joint_state_msg(hold_vec7[:6], float(hold_vec7[6]))
#         self.cmd_pub.publish(msg)

#     def _control_step(self) -> None:
#         mode = self._current_mode()
#         if mode is None:
#             if self._ready():
#                 self._publish_hold()
#             return
#         if not self._ready():
#             return

#         stale = (
#             self.last_policy_ok_time > 0
#             and (time.monotonic() - self.last_policy_ok_time) > self.args.watchdog_timeout_s
#         )
#         if mode == "hold" or stale:
#             self.planned_actions.clear()
#             self._publish_hold()
#             return

#         if not self.planned_actions:
#             try:
#                 self._plan_from_policy(mode)
#             except Exception as exc:
#                 self.get_logger().error(f"Policy planning failed: {exc}")
#                 self.planned_actions.clear()
#                 self._publish_hold()
#                 return

#         if self.planned_actions:
#             self.cmd_pub.publish(self.planned_actions.popleft())
#         else:
#             self._publish_hold()


# def build_arg_parser() -> argparse.ArgumentParser:
#     p = argparse.ArgumentParser("Piper ROS2 bridge for GR00T policy server")

#     # Policy
#     p.add_argument("--policy-host", default="127.0.0.1")
#     p.add_argument("--policy-port", type=int, default=5555)
#     p.add_argument("--lang-instruction", default="Pick up the brown block and place it in the blue box.")
#     p.add_argument("--action-horizon", type=int, default=8)
#     p.add_argument("--control-hz", type=float, default=10.0)
#     p.add_argument("--watchdog-timeout-s", type=float, default=1.0)

#     # Validation
#     p.add_argument("--validation-mode", choices=["hold", "arm_only", "gripper_only", "full"], default="full")
#     p.add_argument("--run-validation-suite", action="store_true")
#     p.add_argument("--phase-seconds", type=float, default=12.0)

#     # ROS topics
#     p.add_argument("--joint-state-topic", default="/joint_states_right")
#     p.add_argument("--cmd-topic", default="/joint_ctrl_cmd_right")
#     p.add_argument("--world-topic", default="/world/camera/image_raw/compressed")
#     p.add_argument("--wrist-topic", default="/waveshare/cam1/image_raw/compressed")

#     # Policy modality keys
#     p.add_argument("--world-camera-key", default="world")
#     p.add_argument("--wrist-camera-key", default="wrist")

#     # Joint key mapping
#     p.add_argument("--arm-obs-keys-csv", default="joint1,joint2,joint3,joint4,joint5,joint6")
#     p.add_argument("--gripper-obs-key", default="gripper")
#     p.add_argument("--arm-cmd-keys-csv", default="joint1,joint2,joint3,joint4,joint5,joint6")
#     p.add_argument("--gripper-cmd-keys-csv", default="gripper")
#     p.add_argument("--second-gripper-mirror-sign", type=float, default=-1.0)

#     # Safety
#     p.add_argument(
#         "--arm-min-csv",
#         default="-0.7161285,-0.03820236,-1.5631742,-1.007391,-0.7551507,-0.8011157",
#     )
#     p.add_argument(
#         "--arm-max-csv",
#         default="0.8281539,2.1425767,0.04277269,0.83614326,1.1717832,2.2785003",
#     )
#     p.add_argument("--max-step-delta-csv", default="0.03,0.03,0.03,0.03,0.03,0.03")
#     p.add_argument("--gripper-min", type=float, default=-0.0037)
#     p.add_argument("--gripper-max", type=float, default=0.1030)
#     p.add_argument("--gripper-scale", type=float, default=1.0)
#     p.add_argument("--gripper-offset", type=float, default=0.0)
#     return p


# def main() -> None:
#     args = build_arg_parser().parse_args()
#     rclpy.init()
#     node = Gr00TPiperRosBridge(args)
#     try:
#         rclpy.spin(node)
#     except KeyboardInterrupt:
#         pass
#     finally:
#         node.destroy_node()
#         rclpy.shutdown()


# if __name__ == "__main__":
#     main()

