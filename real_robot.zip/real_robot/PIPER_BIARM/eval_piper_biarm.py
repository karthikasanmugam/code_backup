"""
Piper bimanual real-robot GR00T evaluation bridge.

This is a bimanual version of the Piper bridge, shaped for the custom
`PIPER_BIARM` embodiment:

- 3 camera inputs: world, left_wrist, right_wrist
- 14 DoF state/action split as:
  left_arm(6) + left_gripper(1) + right_arm(6) + right_gripper(1)

The bridge is intentionally configurable so you can adapt the joint and
camera names to your robot hardware without changing the model interface.
"""

from dataclasses import asdict, dataclass
import logging
from pprint import pformat
import time
from typing import Any, Dict, List

import draccus
from gr00t.policy.server_client import PolicyClient
from lerobot.cameras.opencv.configuration_opencv import OpenCVCameraConfig  # noqa: F401
from lerobot.robots import (  # noqa: F401
    RobotConfig,
    koch_follower,
    make_robot_from_config,
    so100_follower,
    so101_follower,
)
from lerobot.utils.utils import init_logging, log_say
import numpy as np


EXPECTED_EMBODIMENT_TAG = "PIPER_BIARM"


def recursive_add_extra_dim(obs: Dict[str, Any]) -> Dict[str, Any]:
    for key, val in obs.items():
        if isinstance(val, np.ndarray):
            obs[key] = val[np.newaxis, ...]
        elif isinstance(val, dict):
            obs[key] = recursive_add_extra_dim(val)
        else:
            obs[key] = [val]
    return obs


def parse_csv_list(value: str) -> List[str]:
    return [x.strip() for x in value.split(",") if x.strip()]


def parse_csv_floats(value: str, expected_len: int, name: str) -> np.ndarray:
    vals = np.array([float(x.strip()) for x in value.split(",") if x.strip()], dtype=np.float32)
    if vals.shape[0] != expected_len:
        raise ValueError(f"{name} must have {expected_len} values, got {vals.shape[0]}: {value}")
    return vals


class PiperBiarmHardwareAdapter:
    def __init__(self, cfg: "EvalConfig", policy: PolicyClient):
        self.cfg = cfg
        self.policy = policy

        self.left_arm_obs_keys = parse_csv_list(cfg.left_arm_obs_keys_csv)
        self.left_gripper_obs_key = cfg.left_gripper_obs_key
        self.right_arm_obs_keys = parse_csv_list(cfg.right_arm_obs_keys_csv)
        self.right_gripper_obs_key = cfg.right_gripper_obs_key

        self.left_arm_action_keys = parse_csv_list(cfg.left_arm_action_keys_csv)
        self.left_gripper_action_keys = parse_csv_list(cfg.left_gripper_action_keys_csv)
        self.right_arm_action_keys = parse_csv_list(cfg.right_arm_action_keys_csv)
        self.right_gripper_action_keys = parse_csv_list(cfg.right_gripper_action_keys_csv)

        if len(self.left_arm_obs_keys) != 6 or len(self.right_arm_obs_keys) != 6:
            raise ValueError("left/right arm obs key CSVs must contain exactly 6 keys each")
        if len(self.left_arm_action_keys) != 6 or len(self.right_arm_action_keys) != 6:
            raise ValueError("left/right arm action key CSVs must contain exactly 6 keys each")
        if len(self.left_gripper_action_keys) not in (1, 2):
            raise ValueError("left_gripper_action_keys_csv must contain 1 or 2 keys")
        if len(self.right_gripper_action_keys) not in (1, 2):
            raise ValueError("right_gripper_action_keys_csv must contain 1 or 2 keys")

        self.left_arm_min = parse_csv_floats(cfg.left_arm_min_csv, expected_len=6, name="left_arm_min_csv")
        self.left_arm_max = parse_csv_floats(cfg.left_arm_max_csv, expected_len=6, name="left_arm_max_csv")
        self.left_arm_max_step_delta = parse_csv_floats(
            cfg.left_arm_max_step_delta_csv, expected_len=6, name="left_arm_max_step_delta_csv"
        )
        self.right_arm_min = parse_csv_floats(cfg.right_arm_min_csv, expected_len=6, name="right_arm_min_csv")
        self.right_arm_max = parse_csv_floats(cfg.right_arm_max_csv, expected_len=6, name="right_arm_max_csv")
        self.right_arm_max_step_delta = parse_csv_floats(
            cfg.right_arm_max_step_delta_csv, expected_len=6, name="right_arm_max_step_delta_csv"
        )

        self.prev_left_arm_cmd: np.ndarray | None = None
        self.prev_right_arm_cmd: np.ndarray | None = None
        self.last_policy_ok_time = 0.0

    def _obs_to_policy_inputs(self, obs: Dict[str, Any], lang: str) -> Dict[str, Any]:
        model_obs: Dict[str, Any] = {
            "video": {
                "world": obs[self.cfg.world_camera_obs_key],
                "left_wrist": obs[self.cfg.left_wrist_camera_obs_key],
                "right_wrist": obs[self.cfg.right_wrist_camera_obs_key],
            },
            "state": {
                "left_arm": np.array([obs[k] for k in self.left_arm_obs_keys], dtype=np.float32),
                "left_gripper": np.array([obs[self.left_gripper_obs_key]], dtype=np.float32),
                "right_arm": np.array([obs[k] for k in self.right_arm_obs_keys], dtype=np.float32),
                "right_gripper": np.array([obs[self.right_gripper_obs_key]], dtype=np.float32),
            },
            "language": {"annotation.human.task_description": lang},
        }
        model_obs = recursive_add_extra_dim(model_obs)
        model_obs = recursive_add_extra_dim(model_obs)
        return model_obs

    @staticmethod
    def _extract_action_group(action_chunk: Dict[str, Any], key: str, t: int) -> np.ndarray:
        if key in action_chunk:
            return np.asarray(action_chunk[key][0][t], dtype=np.float32).reshape(-1)
        prefixed_key = f"action.{key}"
        if prefixed_key in action_chunk:
            return np.asarray(action_chunk[prefixed_key][0][t], dtype=np.float32).reshape(-1)
        raise ValueError(f"Unsupported action chunk keys: {list(action_chunk.keys())}")

    def _read_hold_state(self, obs: Dict[str, Any]) -> tuple[np.ndarray, np.ndarray]:
        left = np.concatenate(
            [np.array([obs[k] for k in self.left_arm_obs_keys], dtype=np.float32), np.array([obs[self.left_gripper_obs_key]], dtype=np.float32)],
            axis=0,
        )
        right = np.concatenate(
            [np.array([obs[k] for k in self.right_arm_obs_keys], dtype=np.float32), np.array([obs[self.right_gripper_obs_key]], dtype=np.float32)],
            axis=0,
        )
        return left, right

    def _apply_safety(
        self, target_left: np.ndarray, target_right: np.ndarray, hold_left: np.ndarray, hold_right: np.ndarray, mode: str
    ) -> tuple[np.ndarray, np.ndarray]:
        left_arm_target = np.clip(target_left[:6], self.left_arm_min, self.left_arm_max)
        right_arm_target = np.clip(target_right[:6], self.right_arm_min, self.right_arm_max)

        if self.prev_left_arm_cmd is None:
            self.prev_left_arm_cmd = hold_left[:6].copy()
        if self.prev_right_arm_cmd is None:
            self.prev_right_arm_cmd = hold_right[:6].copy()

        left_arm_delta = np.clip(
            left_arm_target - self.prev_left_arm_cmd,
            -self.left_arm_max_step_delta,
            self.left_arm_max_step_delta,
        )
        right_arm_delta = np.clip(
            right_arm_target - self.prev_right_arm_cmd,
            -self.right_arm_max_step_delta,
            self.right_arm_max_step_delta,
        )
        left_arm_cmd = np.clip(self.prev_left_arm_cmd + left_arm_delta, self.left_arm_min, self.left_arm_max)
        right_arm_cmd = np.clip(self.prev_right_arm_cmd + right_arm_delta, self.right_arm_min, self.right_arm_max)

        left_grip = float(np.clip(target_left[6], self.cfg.left_gripper_min, self.cfg.left_gripper_max))
        right_grip = float(np.clip(target_right[6], self.cfg.right_gripper_min, self.cfg.right_gripper_max))

        if mode == "hold":
            left_arm_cmd = hold_left[:6].copy()
            left_grip = float(hold_left[6])
            right_arm_cmd = hold_right[:6].copy()
            right_grip = float(hold_right[6])
        elif mode == "left_only":
            right_arm_cmd = hold_right[:6].copy()
            right_grip = float(hold_right[6])
        elif mode == "right_only":
            left_arm_cmd = hold_left[:6].copy()
            left_grip = float(hold_left[6])
        elif mode == "full":
            pass
        else:
            raise ValueError(f"Unknown mode: {mode}")

        self.prev_left_arm_cmd = left_arm_cmd.copy()
        self.prev_right_arm_cmd = right_arm_cmd.copy()
        return (
            np.concatenate([left_arm_cmd, np.array([left_grip], dtype=np.float32)], axis=0),
            np.concatenate([right_arm_cmd, np.array([right_grip], dtype=np.float32)], axis=0),
        )

    def _to_robot_action_dict(self, left_cmd: np.ndarray, right_cmd: np.ndarray) -> Dict[str, float]:
        action: Dict[str, float] = {}
        for i, name in enumerate(self.left_arm_action_keys):
            action[name] = float(left_cmd[i])
        if len(self.left_gripper_action_keys) == 1:
            action[self.left_gripper_action_keys[0]] = float(left_cmd[6])
        else:
            action[self.left_gripper_action_keys[0]] = float(left_cmd[6])
            action[self.left_gripper_action_keys[1]] = float(self.cfg.left_second_gripper_mirror_sign * left_cmd[6])

        for i, name in enumerate(self.right_arm_action_keys):
            action[name] = float(right_cmd[i])
        if len(self.right_gripper_action_keys) == 1:
            action[self.right_gripper_action_keys[0]] = float(right_cmd[6])
        else:
            action[self.right_gripper_action_keys[0]] = float(right_cmd[6])
            action[self.right_gripper_action_keys[1]] = float(self.cfg.right_second_gripper_mirror_sign * right_cmd[6])

        return action

    def hold_action(self, obs: Dict[str, Any]) -> Dict[str, float]:
        left, right = self._read_hold_state(obs)
        return self._to_robot_action_dict(left, right)

    def plan_actions(self, obs: Dict[str, Any], mode: str) -> List[Dict[str, float]]:
        hold_left, hold_right = self._read_hold_state(obs)

        if mode == "hold":
            return [self._to_robot_action_dict(hold_left, hold_right)]

        model_input = self._obs_to_policy_inputs(obs, self.cfg.lang_instruction)
        action_chunk, _ = self.policy.get_action(model_input)
        self.last_policy_ok_time = time.monotonic()

        horizon_key = next(iter(action_chunk.keys()))
        horizon = int(np.asarray(action_chunk[horizon_key]).shape[1])
        out: List[Dict[str, float]] = []

        for t in range(min(horizon, self.cfg.action_horizon)):
            left_arm = self._extract_action_group(action_chunk, "left_arm", t)
            left_gripper = self._extract_action_group(action_chunk, "left_gripper", t)
            right_arm = self._extract_action_group(action_chunk, "right_arm", t)
            right_gripper = self._extract_action_group(action_chunk, "right_gripper", t)
            left_cmd, right_cmd = self._apply_safety(
                np.concatenate([left_arm, left_gripper], axis=0),
                np.concatenate([right_arm, right_gripper], axis=0),
                hold_left,
                hold_right,
                mode=mode,
            )
            out.append(self._to_robot_action_dict(left_cmd, right_cmd))

        return out


@dataclass
class EvalConfig:
    robot: RobotConfig

    embodiment_tag: str = EXPECTED_EMBODIMENT_TAG

    policy_host: str = "localhost"
    policy_port: int = 5555

    lang_instruction: str = "Use both arms to coordinate the task."

    action_horizon: int = 8
    control_hz: float = 30.0
    watchdog_timeout_s: float = 1.0

    validation_mode: str = "full"  # hold | left_only | right_only | full
    run_validation_suite: bool = False
    phase_seconds: float = 12.0

    world_camera_obs_key: str = "world"
    left_wrist_camera_obs_key: str = "left_wrist"
    right_wrist_camera_obs_key: str = "right_wrist"

    left_arm_obs_keys_csv: str = "left_joint_1,left_joint_2,left_joint_3,left_joint_4,left_joint_5,left_joint_6"
    left_gripper_obs_key: str = "left_gripper"
    right_arm_obs_keys_csv: str = "right_joint_1,right_joint_2,right_joint_3,right_joint_4,right_joint_5,right_joint_6"
    right_gripper_obs_key: str = "right_gripper"

    left_arm_action_keys_csv: str = "left_joint_1,left_joint_2,left_joint_3,left_joint_4,left_joint_5,left_joint_6"
    left_gripper_action_keys_csv: str = "left_gripper"
    right_arm_action_keys_csv: str = "right_joint_1,right_joint_2,right_joint_3,right_joint_4,right_joint_5,right_joint_6"
    right_gripper_action_keys_csv: str = "right_gripper"

    left_second_gripper_mirror_sign: float = -1.0
    right_second_gripper_mirror_sign: float = -1.0

    left_arm_min_csv: str = "-3.14,-3.14,-3.14,-3.14,-3.14,-3.14"
    left_arm_max_csv: str = "3.14,3.14,3.14,3.14,3.14,3.14"
    left_arm_max_step_delta_csv: str = "0.03,0.03,0.03,0.03,0.03,0.03"
    right_arm_min_csv: str = "-3.14,-3.14,-3.14,-3.14,-3.14,-3.14"
    right_arm_max_csv: str = "3.14,3.14,3.14,3.14,3.14,3.14"
    right_arm_max_step_delta_csv: str = "0.03,0.03,0.03,0.03,0.03,0.03"

    left_gripper_min: float = -0.0037
    left_gripper_max: float = 0.1030
    right_gripper_min: float = -0.0037
    right_gripper_max: float = 0.1030

    play_sounds: bool = False


@draccus.wrap()
def eval(cfg: EvalConfig):
    init_logging()
    if cfg.embodiment_tag != EXPECTED_EMBODIMENT_TAG:
        raise ValueError(
            f"This bridge is configured for {EXPECTED_EMBODIMENT_TAG}, got {cfg.embodiment_tag}"
        )
    logging.info("Piper biarm eval config:\n%s", pformat(asdict(cfg)))

    robot = make_robot_from_config(cfg.robot)
    robot.connect()

    policy_client = PolicyClient(host=cfg.policy_host, port=cfg.policy_port)
    adapter = PiperBiarmHardwareAdapter(cfg, policy_client)

    valid_modes = {"hold", "left_only", "right_only", "full"}
    if cfg.validation_mode not in valid_modes:
        raise ValueError(f"validation_mode must be one of {sorted(valid_modes)}")

    if cfg.run_validation_suite:
        modes = ["hold", "left_only", "right_only", "full"]
    else:
        modes = [cfg.validation_mode]

    log_say("Piper biarm policy bridge ready", cfg.play_sounds, blocking=True)
    dt = 1.0 / cfg.control_hz

    for mode in modes:
        logging.info("Starting mode: %s", mode)
        if cfg.run_validation_suite:
            deadline = time.monotonic() + cfg.phase_seconds
        else:
            deadline = None

        planned: List[Dict[str, float]] = []

        while True:
            if deadline is not None and time.monotonic() >= deadline:
                logging.info("Completed mode: %s", mode)
                break

            tic = time.monotonic()
            obs = robot.get_observation()

            stale = (
                adapter.last_policy_ok_time > 0
                and (time.monotonic() - adapter.last_policy_ok_time) > cfg.watchdog_timeout_s
            )

            if mode == "hold" or stale:
                action_dict = adapter.hold_action(obs)
                planned.clear()
            else:
                if not planned:
                    try:
                        planned = adapter.plan_actions(obs, mode)
                    except Exception as exc:
                        logging.exception("Policy planning failed (%s). Falling back to hold.", exc)
                        planned = []

                if planned:
                    action_dict = planned.pop(0)
                else:
                    action_dict = adapter.hold_action(obs)

            robot.send_action(action_dict)

            elapsed = time.monotonic() - tic
            if elapsed < dt:
                time.sleep(dt - elapsed)


if __name__ == "__main__":
    eval()
