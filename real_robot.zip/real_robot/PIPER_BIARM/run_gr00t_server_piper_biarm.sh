#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="/home/physicalai/Desktop/I/groot"
MODEL_PATH="${MODEL_PATH:-}"
EMBODIMENT_TAG="${EMBODIMENT_TAG:-PIPER_BIARM}"
HOST="${HOST:-0.0.0.0}"
PORT="${PORT:-5555}"

if [ -z "$MODEL_PATH" ]; then
  echo "MODEL_PATH must point to your checkpoint directory, for example:"
  echo "  MODEL_PATH=/home/physicalai/Desktop/I/groot/outputs/<run_name>/checkpoint-10000"
  exit 1
fi

cd "$REPO_ROOT"
source .venv/bin/activate

python gr00t/eval/run_gr00t_server.py \
  --model_path "$MODEL_PATH" \
  --embodiment-tag "$EMBODIMENT_TAG" \
  --host "$HOST" \
  --port "$PORT"
