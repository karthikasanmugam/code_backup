"""
ROS2 bridge for the Piper bimanual GR00T policy server.

This bridge mirrors the `PIPER_BIARM` training/evaluation modality:

- policy inputs:
  video.world, video.left_wrist, video.right_wrist
  state.left_arm, state.left_gripper, state.right_arm, state.right_gripper
- policy outputs:
  action.left_arm, action.left_gripper, action.right_arm, action.right_gripper

It is intentionally configurable so you can match your robot's ROS joint
names and camera topics without changing the model-facing interface.
"""

from __future__ import annotations

import argparse
import json
from collections import deque
from pathlib import Path
import time
from typing import Any

import cv2
import numpy as np
import rclpy
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import CompressedImage, Image, JointState

from gr00t.policy.server_client import PolicyClient


EXPECTED_EMBODIMENT_TAG = "PIPER_BIARM"


def parse_csv_list(value: str) -> list[str]:
    return [x.strip() for x in value.split(",") if x.strip()]


def parse_csv_floats(value: str, expected_len: int, name: str) -> np.ndarray:
    vals = np.array([float(x.strip()) for x in value.split(",") if x.strip()], dtype=np.float32)
    if vals.shape[0] != expected_len:
        raise ValueError(f"{name} must have {expected_len} values, got {vals.shape[0]}: {value}")
    return vals


def recursive_add_extra_dim(obs: dict[str, Any]) -> dict[str, Any]:
    for key, val in obs.items():
        if isinstance(val, np.ndarray):
            obs[key] = val[np.newaxis, ...]
        elif isinstance(val, dict):
            obs[key] = recursive_add_extra_dim(val)
        else:
            obs[key] = [val]
    return obs


def load_task_prompt(tasks_jsonl: str, task_index: int) -> str:
    path = Path(tasks_jsonl).expanduser()
    if not path.is_file():
        raise FileNotFoundError(f"tasks_jsonl not found: {path}")

    with path.open("r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, start=1):
            stripped = line.strip()
            if not stripped:
                continue
            try:
                record = json.loads(stripped)
            except json.JSONDecodeError as exc:
                raise ValueError(f"Invalid JSON on line {line_no} of {path}: {exc}") from exc
            if int(record.get("task_index", -1)) == task_index:
                prompt = record.get("prompt") or record.get("task")
                if not prompt:
                    raise ValueError(f"Task {task_index} in {path} is missing both 'prompt' and 'task'")
                return str(prompt)

    raise ValueError(f"Task index {task_index} not found in {path}")


class Gr00TPiperBiarmRosBridge(Node):
    def __init__(self, args: argparse.Namespace):
        super().__init__("gr00t_piper_biarm_ros2_bridge")
        self.args = args
        if args.embodiment_tag != EXPECTED_EMBODIMENT_TAG:
            raise ValueError(
                f"This bridge is configured for {EXPECTED_EMBODIMENT_TAG}, got {args.embodiment_tag}"
            )

        self.policy = PolicyClient(host=args.policy_host, port=args.policy_port, strict=False)
        if not self.policy.ping():
            raise RuntimeError(
                f"Could not reach GR00T server at tcp://{args.policy_host}:{args.policy_port}"
            )

        self.left_arm_obs_keys = parse_csv_list(args.left_arm_obs_keys_csv)
        self.left_gripper_obs_key = args.left_gripper_obs_key
        self.right_arm_obs_keys = parse_csv_list(args.right_arm_obs_keys_csv)
        self.right_gripper_obs_key = args.right_gripper_obs_key

        self.left_arm_cmd_keys = parse_csv_list(args.left_arm_cmd_keys_csv)
        self.left_gripper_cmd_keys = parse_csv_list(args.left_gripper_cmd_keys_csv)
        self.right_arm_cmd_keys = parse_csv_list(args.right_arm_cmd_keys_csv)
        self.right_gripper_cmd_keys = parse_csv_list(args.right_gripper_cmd_keys_csv)
        self.left_gripper_command_scale = args.left_gripper_command_scale
        self.left_gripper_command_offset = args.left_gripper_command_offset
        self.left_gripper_command_sign = args.left_gripper_command_sign
        self.right_gripper_command_scale = args.right_gripper_command_scale
        self.right_gripper_command_offset = args.right_gripper_command_offset
        self.right_gripper_command_sign = args.right_gripper_command_sign

        self.lang_instruction = args.lang_instruction
        if args.tasks_jsonl:
            self.lang_instruction = load_task_prompt(args.tasks_jsonl, args.task_index)
            self.get_logger().info(
                f"Loaded language prompt from {args.tasks_jsonl} for task_index={args.task_index}: "
                f"{self.lang_instruction}"
            )

        if len(self.left_arm_obs_keys) != 6 or len(self.right_arm_obs_keys) != 6:
            raise ValueError("left/right arm obs key CSVs must contain exactly 6 keys each")
        if len(self.left_arm_cmd_keys) != 6 or len(self.right_arm_cmd_keys) != 6:
            raise ValueError("left/right arm cmd key CSVs must contain exactly 6 keys each")
        if len(self.left_gripper_cmd_keys) not in (1, 2):
            raise ValueError("left_gripper_cmd_keys_csv must contain 1 or 2 keys")
        if len(self.right_gripper_cmd_keys) not in (1, 2):
            raise ValueError("right_gripper_cmd_keys_csv must contain 1 or 2 keys")

        self.left_arm_min = parse_csv_floats(args.left_arm_min_csv, 6, "left_arm_min_csv")
        self.left_arm_max = parse_csv_floats(args.left_arm_max_csv, 6, "left_arm_max_csv")
        self.left_arm_max_step_delta = parse_csv_floats(
            args.left_arm_max_step_delta_csv, 6, "left_arm_max_step_delta_csv"
        )
        self.right_arm_min = parse_csv_floats(args.right_arm_min_csv, 6, "right_arm_min_csv")
        self.right_arm_max = parse_csv_floats(args.right_arm_max_csv, 6, "right_arm_max_csv")
        self.right_arm_max_step_delta = parse_csv_floats(
            args.right_arm_max_step_delta_csv, 6, "right_arm_max_step_delta_csv"
        )

        self.prev_left_arm_cmd: np.ndarray | None = None
        self.prev_right_arm_cmd: np.ndarray | None = None
        self.last_policy_ok_time = 0.0

        self.latest_joint_map: dict[str, float] = {}
        self.latest_left_joint_map: dict[str, float] = {}
        self.latest_right_joint_map: dict[str, float] = {}
        self.latest_images: dict[str, np.ndarray] = {}
        self.planned_left_actions: deque[JointState] = deque()
        self.planned_right_actions: deque[JointState] = deque()
        self.last_wait_log_time = 0.0
        self.last_ready_state: str | None = None
        self.seen_left_joint_msg = False
        self.seen_right_joint_msg = False
        self.seen_world_image = False
        self.seen_left_wrist_image = False
        self.seen_right_wrist_image = False

        self.valid_modes = ["hold", "left_only", "right_only", "full"]
        if args.run_validation_suite:
            self.phase_modes = list(self.valid_modes)
        else:
            if args.validation_mode not in self.valid_modes:
                raise ValueError(f"validation_mode must be one of {self.valid_modes}")
            self.phase_modes = [args.validation_mode]
        self.phase_idx = 0
        self.phase_start_t = time.monotonic()
        self.finished = False
        self.get_logger().info(f"Validation phases: {self.phase_modes}")

        self.create_subscription(
            JointState,
            args.left_joint_state_topic,
            lambda m: self._joint_cb("left", m),
            qos_profile_sensor_data,
        )
        self.create_subscription(
            JointState,
            args.right_joint_state_topic,
            lambda m: self._joint_cb("right", m),
            qos_profile_sensor_data,
        )
        self.create_subscription(
            CompressedImage,
            args.world_topic,
            lambda m: self._image_cb("world", m),
            qos_profile_sensor_data,
        )
        self.create_subscription(
            CompressedImage,
            args.left_wrist_topic,
            lambda m: self._image_cb("left_wrist", m),
            qos_profile_sensor_data,
        )
        self.create_subscription(
            CompressedImage,
            args.right_wrist_topic,
            lambda m: self._image_cb("right_wrist", m),
            qos_profile_sensor_data,
        )
        self.left_cmd_pub = self.create_publisher(JointState, args.left_cmd_topic, 10)
        self.right_cmd_pub = self.create_publisher(JointState, args.right_cmd_topic, 10)
        self.timer = self.create_timer(1.0 / args.control_hz, self._control_step)
        self.get_logger().info(
            "Bridge started. Server=tcp://%s:%s, left_cmd_topic=%s, right_cmd_topic=%s"
            % (args.policy_host, args.policy_port, args.left_cmd_topic, args.right_cmd_topic)
        )
        self.get_logger().info(
            "Gripper command mapping: left(sign=%s, scale=%s, offset=%s, keys=%s) right(sign=%s, scale=%s, offset=%s, keys=%s)"
            % (
                self.left_gripper_command_sign,
                self.left_gripper_command_scale,
                self.left_gripper_command_offset,
                self.left_gripper_cmd_keys,
                self.right_gripper_command_sign,
                self.right_gripper_command_scale,
                self.right_gripper_command_offset,
                self.right_gripper_cmd_keys,
            )
        )
        self.get_logger().info(
            "Waiting for inputs on left=%s right=%s world=%s left_wrist=%s right_wrist=%s"
            % (
                args.left_joint_state_topic,
                args.right_joint_state_topic,
                args.world_topic,
                args.left_wrist_topic,
                args.right_wrist_topic,
            )
        )

    def _joint_cb(self, side: str, msg: JointState) -> None:
        target_map = self.latest_left_joint_map if side == "left" else self.latest_right_joint_map
        seen_attr = "seen_left_joint_msg" if side == "left" else "seen_right_joint_msg"
        topic_name = self.args.left_joint_state_topic if side == "left" else self.args.right_joint_state_topic
        if not getattr(self, seen_attr):
            self.get_logger().info(
                "Received first %s joint message on %s: names=%s positions=%d"
                % (side, topic_name, list(msg.name) if msg.name else [], len(msg.position) if msg.position else 0)
            )
            setattr(self, seen_attr, True)
        expected_keys = (
            self.left_arm_obs_keys + [self.left_gripper_obs_key]
            if side == "left"
            else self.right_arm_obs_keys + [self.right_gripper_obs_key]
        )
        if msg.name and msg.position and len(msg.name) == len(msg.position):
            if set(msg.name) == set(expected_keys):
                for n, p in zip(msg.name, msg.position):
                    target_map[n] = float(p)
            else:
                for i, key in enumerate(expected_keys[: len(msg.position)]):
                    target_map[key] = float(msg.position[i])
        elif msg.position:
            for i, key in enumerate(expected_keys[: len(msg.position)]):
                target_map[key] = float(msg.position[i])

        self.latest_joint_map.update(target_map)

    def _image_cb(self, cam_key: str, msg: Image | CompressedImage) -> None:
        if isinstance(msg, CompressedImage):
            seen_attr = {
                "world": "seen_world_image",
                "left_wrist": "seen_left_wrist_image",
                "right_wrist": "seen_right_wrist_image",
            }.get(cam_key)
            if seen_attr is not None and not getattr(self, seen_attr):
                self.get_logger().info(
                    "Received first %s compressed image on %s: format=%s size=%d bytes"
                    % (
                        cam_key,
                        getattr(self.args, f"{cam_key}_topic"),
                        msg.format,
                        len(msg.data),
                    )
                )
                setattr(self, seen_attr, True)

            np_arr = np.frombuffer(msg.data, dtype=np.uint8)
            bgr = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
            if bgr is None:
                return
            rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
            self.latest_images[cam_key] = rgb.astype(np.uint8)
            return

        if msg.height <= 0 or msg.width <= 0 or not msg.data:
            return

        seen_attr = {
            "world": "seen_world_image",
            "left_wrist": "seen_left_wrist_image",
            "right_wrist": "seen_right_wrist_image",
        }.get(cam_key)
        if seen_attr is not None and not getattr(self, seen_attr):
            self.get_logger().info(
                "Received first %s image on %s: encoding=%s size=%dx%d step=%d"
                % (cam_key, getattr(self.args, f"{cam_key}_topic"), msg.encoding, msg.width, msg.height, msg.step)
            )
            setattr(self, seen_attr, True)

        encoding = (msg.encoding or "").lower()
        if encoding in {"rgb8", "bgr8"}:
            np_arr = np.frombuffer(msg.data, dtype=np.uint8)
            try:
                row_width = int(msg.step)
                row_bytes = np_arr.reshape((msg.height, row_width))
                image = row_bytes[:, : msg.width * 3].reshape((msg.height, msg.width, 3))
            except ValueError:
                return
            if encoding == "bgr8":
                image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            self.latest_images[cam_key] = image.astype(np.uint8)
            return

        if encoding in {"mono8", "8uc1"}:
            np_arr = np.frombuffer(msg.data, dtype=np.uint8)
            try:
                row_bytes = np_arr.reshape((msg.height, int(msg.step)))
                image = row_bytes[:, : msg.width]
            except ValueError:
                return
            self.latest_images[cam_key] = image.astype(np.uint8)
            return

        self.get_logger().warning(
            f"Unsupported camera encoding for {cam_key}: {msg.encoding!r}; "
            "expected rgb8, bgr8, mono8, or CompressedImage"
        )

    def _current_mode(self) -> str | None:
        if self.finished:
            return None
        mode = self.phase_modes[self.phase_idx]
        if self.args.run_validation_suite:
            elapsed = time.monotonic() - self.phase_start_t
            if elapsed >= self.args.phase_seconds:
                self.get_logger().info(f"Completed phase: {mode}")
                self.phase_idx += 1
                if self.phase_idx >= len(self.phase_modes):
                    self.get_logger().info("Validation suite complete.")
                    self.finished = True
                    return None
                self.phase_start_t = time.monotonic()
                mode = self.phase_modes[self.phase_idx]
                self.planned_left_actions.clear()
                self.planned_right_actions.clear()
                self.get_logger().info(f"Starting phase: {mode}")
        return mode

    def _ready(self) -> bool:
        for k in self.left_arm_obs_keys + [self.left_gripper_obs_key]:
            if k not in self.latest_left_joint_map:
                return False
        for k in self.right_arm_obs_keys + [self.right_gripper_obs_key]:
            if k not in self.latest_right_joint_map:
                return False
        for k in ("world", "left_wrist", "right_wrist"):
            if k not in self.latest_images:
                return False
        return True

    def _missing_inputs(self) -> list[str]:
        missing: list[str] = []
        left_missing = [k for k in self.left_arm_obs_keys + [self.left_gripper_obs_key] if k not in self.latest_left_joint_map]
        right_missing = [k for k in self.right_arm_obs_keys + [self.right_gripper_obs_key] if k not in self.latest_right_joint_map]
        image_missing = [k for k in ("world", "left_wrist", "right_wrist") if k not in self.latest_images]

        if left_missing:
            missing.append(f"waiting left joint state keys: {left_missing}")
        if right_missing:
            missing.append(f"waiting right joint state keys: {right_missing}")
        if image_missing:
            missing.append(f"waiting camera topics: {image_missing}")
        return missing

    def _log_waiting(self, mode: str | None, reason: str) -> None:
        now = time.monotonic()
        state = f"mode={mode} {reason}"
        if state == self.last_ready_state and (now - self.last_wait_log_time) < 2.0:
            return
        self.last_ready_state = state
        self.last_wait_log_time = now
        self.get_logger().info(state)

    def _hold_left_right(self) -> tuple[np.ndarray, np.ndarray]:
        left = np.array(
            [self.latest_left_joint_map[k] for k in self.left_arm_obs_keys]
            + [self.latest_left_joint_map[self.left_gripper_obs_key]],
            dtype=np.float32,
        )
        right = np.array(
            [self.latest_right_joint_map[k] for k in self.right_arm_obs_keys]
            + [self.latest_right_joint_map[self.right_gripper_obs_key]],
            dtype=np.float32,
        )
        return left, right

    def _obs_for_policy(self) -> dict[str, Any]:
        obs = {
            "video": {
                self.args.world_camera_key: self.latest_images["world"],
                self.args.left_wrist_camera_key: self.latest_images["left_wrist"],
                self.args.right_wrist_camera_key: self.latest_images["right_wrist"],
            },
            "state": {
                "left_arm": np.array([self.latest_left_joint_map[k] for k in self.left_arm_obs_keys], dtype=np.float32),
                "left_gripper": np.array([self.latest_left_joint_map[self.left_gripper_obs_key]], dtype=np.float32),
                "right_arm": np.array([self.latest_right_joint_map[k] for k in self.right_arm_obs_keys], dtype=np.float32),
                "right_gripper": np.array([self.latest_right_joint_map[self.right_gripper_obs_key]], dtype=np.float32),
            },
            "language": {"annotation.human.task_description": self.lang_instruction},
        }
        obs = recursive_add_extra_dim(obs)
        obs = recursive_add_extra_dim(obs)
        return obs

    @staticmethod
    def _extract_action_group(action_chunk: dict[str, Any], key: str, t: int) -> np.ndarray:
        if key in action_chunk:
            return np.asarray(action_chunk[key][0][t], dtype=np.float32).reshape(-1)
        prefixed = f"action.{key}"
        if prefixed in action_chunk:
            return np.asarray(action_chunk[prefixed][0][t], dtype=np.float32).reshape(-1)
        raise ValueError(f"Unsupported action chunk keys: {list(action_chunk.keys())}")

    def _apply_safety(
        self,
        target_left: np.ndarray,
        target_right: np.ndarray,
        hold_left: np.ndarray,
        hold_right: np.ndarray,
        mode: str,
    ) -> tuple[np.ndarray, np.ndarray]:
        target_left_arm = np.clip(target_left[:6], self.left_arm_min, self.left_arm_max)
        target_right_arm = np.clip(target_right[:6], self.right_arm_min, self.right_arm_max)

        if self.prev_left_arm_cmd is None:
            self.prev_left_arm_cmd = hold_left[:6].copy()
        if self.prev_right_arm_cmd is None:
            self.prev_right_arm_cmd = hold_right[:6].copy()

        left_arm_delta = np.clip(
            target_left_arm - self.prev_left_arm_cmd,
            -self.left_arm_max_step_delta,
            self.left_arm_max_step_delta,
        )
        right_arm_delta = np.clip(
            target_right_arm - self.prev_right_arm_cmd,
            -self.right_arm_max_step_delta,
            self.right_arm_max_step_delta,
        )
        left_arm_cmd = np.clip(self.prev_left_arm_cmd + left_arm_delta, self.left_arm_min, self.left_arm_max)
        right_arm_cmd = np.clip(self.prev_right_arm_cmd + right_arm_delta, self.right_arm_min, self.right_arm_max)

        left_grip = float(
            np.clip(
                self.left_gripper_command_sign
                * (target_left[6] * self.left_gripper_command_scale + self.left_gripper_command_offset),
                self.args.left_gripper_min,
                self.args.left_gripper_max,
            )
        )
        right_grip = float(
            np.clip(
                self.right_gripper_command_sign
                * (target_right[6] * self.right_gripper_command_scale + self.right_gripper_command_offset),
                self.args.right_gripper_min,
                self.args.right_gripper_max,
            )
        )

        if mode == "hold":
            left_arm_cmd = hold_left[:6].copy()
            left_grip = float(hold_left[6])
            right_arm_cmd = hold_right[:6].copy()
            right_grip = float(hold_right[6])
        elif mode == "left_only":
            right_arm_cmd = hold_right[:6].copy()
            right_grip = float(hold_right[6])
        elif mode == "right_only":
            left_arm_cmd = hold_left[:6].copy()
            left_grip = float(hold_left[6])
        elif mode == "full":
            pass
        else:
            raise ValueError(f"Unknown mode: {mode}")

        self.prev_left_arm_cmd = left_arm_cmd.copy()
        self.prev_right_arm_cmd = right_arm_cmd.copy()
        return (
            np.concatenate([left_arm_cmd, np.array([left_grip], dtype=np.float32)], axis=0),
            np.concatenate([right_arm_cmd, np.array([right_grip], dtype=np.float32)], axis=0),
        )

    def _plan_from_policy(self, mode: str) -> None:
        hold_left, hold_right = self._hold_left_right()
        obs = self._obs_for_policy()
        action_chunk, _ = self.policy.get_action(obs)
        self.last_policy_ok_time = time.monotonic()

        any_key = next(iter(action_chunk.keys()))
        horizon = int(np.asarray(action_chunk[any_key]).shape[1])
        steps = min(horizon, self.args.action_horizon)

        for t in range(steps):
            left_arm = self._extract_action_group(action_chunk, "left_arm", t)
            left_gripper = self._extract_action_group(action_chunk, "left_gripper", t)
            right_arm = self._extract_action_group(action_chunk, "right_arm", t)
            right_gripper = self._extract_action_group(action_chunk, "right_gripper", t)
            left_cmd, right_cmd = self._apply_safety(
                np.concatenate([left_arm, left_gripper], axis=0),
                np.concatenate([right_arm, right_gripper], axis=0),
                hold_left,
                hold_right,
                mode,
            )
            self.planned_left_actions.append(self._to_joint_state_msg(left_cmd, "left"))
            self.planned_right_actions.append(self._to_joint_state_msg(right_cmd, "right"))

    def _publish_hold(self) -> None:
        left, right = self._hold_left_right()
        self.left_cmd_pub.publish(self._to_joint_state_msg(left, "left"))
        self.right_cmd_pub.publish(self._to_joint_state_msg(right, "right"))

    def _to_joint_state_msg(self, cmd7: np.ndarray, side: str) -> JointState:
        msg = JointState()
        msg.header.stamp = self.get_clock().now().to_msg()
        if side == "left":
            names = list(self.left_arm_cmd_keys)
            positions = [float(x) for x in cmd7[:6]]
            names.append(self.left_gripper_cmd_keys[0])
            positions.append(float(cmd7[6]))
            if len(self.left_gripper_cmd_keys) == 2:
                names.append(self.left_gripper_cmd_keys[1])
                positions.append(float(self.args.left_second_gripper_mirror_sign * cmd7[6]))
        else:
            names = list(self.right_arm_cmd_keys)
            positions = [float(x) for x in cmd7[:6]]
            names.append(self.right_gripper_cmd_keys[0])
            positions.append(float(cmd7[6]))
            if len(self.right_gripper_cmd_keys) == 2:
                names.append(self.right_gripper_cmd_keys[1])
                positions.append(float(self.args.right_second_gripper_mirror_sign * cmd7[6]))
        msg.name = names
        msg.position = positions
        return msg

    def _control_step(self) -> None:
        mode = self._current_mode()
        if mode is None:
            if self._ready():
                self._publish_hold()
            return
        if not self._ready():
            missing = self._missing_inputs()
            self._log_waiting(mode, "; ".join(missing) if missing else "waiting for inputs")
            return

        stale = (
            self.last_policy_ok_time > 0
            and (time.monotonic() - self.last_policy_ok_time) > self.args.watchdog_timeout_s
        )
        if mode == "hold" or stale:
            if mode == "hold":
                self._log_waiting(mode, "hold mode active; publishing hold commands")
            else:
                self._log_waiting(mode, "policy stale; publishing hold commands")
            self.planned_left_actions.clear()
            self.planned_right_actions.clear()
            self._publish_hold()
            return

        if not self.planned_left_actions or not self.planned_right_actions:
            try:
                self._plan_from_policy(mode)
            except Exception as exc:
                self.get_logger().error(f"Policy planning failed: {exc}")
                self.planned_left_actions.clear()
                self.planned_right_actions.clear()
                self._publish_hold()
                return

        if self.planned_left_actions and self.planned_right_actions:
            self.left_cmd_pub.publish(self.planned_left_actions.popleft())
            self.right_cmd_pub.publish(self.planned_right_actions.popleft())
        else:
            self._publish_hold()


def main() -> None:
    parser = argparse.ArgumentParser(description="Piper bimanual GR00T ROS2 bridge")
    parser.add_argument("--policy-host", default="localhost")
    parser.add_argument("--policy-port", type=int, default=5555)
    parser.add_argument("--embodiment-tag", default=EXPECTED_EMBODIMENT_TAG)
    parser.add_argument("--control-hz", type=float, default=10.0)
    parser.add_argument("--action-horizon", type=int, default=8)
    parser.add_argument("--lang-instruction", default="Use both arms to coordinate the task.")
    parser.add_argument(
        "--tasks-jsonl",
        default="/home/physicalai/Desktop/I/Dataset/pick_place_biarm/meta/tasks.jsonl",
        help="Optional tasks.jsonl file with task_index/prompt records",
    )
    parser.add_argument("--task-index", type=int, default=0)
    parser.add_argument("--validation-mode", default="full", choices=["hold", "left_only", "right_only", "full"])
    parser.add_argument("--run-validation-suite", action="store_true")
    parser.add_argument("--phase-seconds", type=float, default=12.0)
    parser.add_argument("--watchdog-timeout-s", type=float, default=1.0)

    parser.add_argument("--left-joint-state-topic", default="/left_follower/joint_states")
    parser.add_argument("--right-joint-state-topic", default="/right_follower/joint_states")
    parser.add_argument("--left-cmd-topic", default="/left_follower/joint_ctrl_cmd_left")
    parser.add_argument("--right-cmd-topic", default="/right_follower/joint_ctrl_cmd_right")
    parser.add_argument("--world-topic", default="/camera/world/color/image_raw/compressed")
    parser.add_argument("--left-wrist-topic", default="/left_arm_cam/image_raw/compressed")
    parser.add_argument("--right-wrist-topic", default="/right_arm_cam/image_raw/compressed")

    parser.add_argument("--world-camera-key", default="world")
    parser.add_argument("--left-wrist-camera-key", default="left_wrist")
    parser.add_argument("--right-wrist-camera-key", default="right_wrist")

    parser.add_argument("--left-arm-obs-keys-csv", default="joint1,joint2,joint3,joint4,joint5,joint6")
    parser.add_argument("--left-gripper-obs-key", default="gripper")
    parser.add_argument("--right-arm-obs-keys-csv", default="joint1,joint2,joint3,joint4,joint5,joint6")
    parser.add_argument("--right-gripper-obs-key", default="gripper")

    parser.add_argument("--left-arm-cmd-keys-csv", default="joint1,joint2,joint3,joint4,joint5,joint6")
    parser.add_argument("--left-gripper-cmd-keys-csv", default="gripper")
    parser.add_argument("--right-arm-cmd-keys-csv", default="joint1,joint2,joint3,joint4,joint5,joint6")
    parser.add_argument("--right-gripper-cmd-keys-csv", default="gripper")

    parser.add_argument("--left-second-gripper-mirror-sign", type=float, default=-1.0)
    parser.add_argument("--right-second-gripper-mirror-sign", type=float, default=-1.0)

    parser.add_argument("--left-arm-min-csv", default="-3.14,-3.14,-3.14,-3.14,-3.14,-3.14")
    parser.add_argument("--left-arm-max-csv", default="3.14,3.14,3.14,3.14,3.14,3.14")
    parser.add_argument("--left-arm-max-step-delta-csv", default="0.03,0.03,0.03,0.03,0.03,0.03")
    parser.add_argument("--right-arm-min-csv", default="-3.14,-3.14,-3.14,-3.14,-3.14,-3.14")
    parser.add_argument("--right-arm-max-csv", default="3.14,3.14,3.14,3.14,3.14,3.14")
    parser.add_argument("--right-arm-max-step-delta-csv", default="0.03,0.03,0.03,0.03,0.03,0.03")

    parser.add_argument("--left-gripper-min", type=float, default=-0.0037)
    parser.add_argument("--left-gripper-max", type=float, default=0.1030)
    parser.add_argument("--right-gripper-min", type=float, default=-0.0037)
    parser.add_argument("--right-gripper-max", type=float, default=0.1030)
    parser.add_argument("--left-gripper-command-scale", type=float, default=1.0)
    parser.add_argument("--left-gripper-command-offset", type=float, default=0.0)
    parser.add_argument("--left-gripper-command-sign", type=float, default=1.0)
    parser.add_argument("--right-gripper-command-scale", type=float, default=1.0)
    parser.add_argument("--right-gripper-command-offset", type=float, default=0.0)
    parser.add_argument("--right-gripper-command-sign", type=float, default=1.0)

    parser.add_argument("--robot", type=str, default="", help="Unused compatibility flag")
    args = parser.parse_args()

    # Keep compatibility with draccus-style config files by converting the robot
    # string later via LeRobot helpers. We expect the user to pass a valid RobotConfig.
    cfg = args
    rclpy.init()
    node = Gr00TPiperBiarmRosBridge(cfg)
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
