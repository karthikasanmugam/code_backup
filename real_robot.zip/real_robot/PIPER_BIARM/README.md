# PIPER_BIARM Real-Robot Evaluation

This folder provides bimanual Piper inference/evaluation bridges for GR00T.

- `eval_piper_biarm.py`: LeRobot hardware bridge
- `eval_piper_biarm_ros2.py`: ROS2 hardware bridge
- `run_gr00t_server_piper_biarm.sh`: Start the checkpoint-backed GR00T server
- `run_ros2_piper_biarm_eval.sh`: Start the ROS2 hardware bridge

The model-facing embodiment is the dedicated `PIPER_BIARM` tag, and the bridge now validates that tag so it stays aligned with training, with:

- `video.world`
- `video.left_wrist`
- `video.right_wrist`
- `state.left_arm`
- `state.left_gripper`
- `state.right_arm`
- `state.right_gripper`
- matching action outputs for the same four groups

## 1) Start GR00T server

```bash
cd ~/Desktop/I/groot
MODEL_PATH=/home/physicalai/Desktop/I/groot/outputs/<your_run>/checkpoint-10000 \
  ./gr00t/eval/real_robot/PIPER_BIARM/run_gr00t_server_piper_biarm.sh
```

Use the same embodiment tag you used for training.

## 2) Run the LeRobot bridge

```bash
python gr00t/eval/real_robot/PIPER_BIARM/eval_piper_biarm.py \
  --robot <YOUR_ROBOT_CONFIG> \
  --policy-host <SYSTEM_A_IP> \
  --policy-port 5555 \
  --lang-instruction "Use both arms to coordinate the task."
```

## 3) Run the ROS2 bridge

```bash
POLICY_HOST=<SYSTEM_A_IP> \
  ./gr00t/eval/real_robot/PIPER_BIARM/run_ros2_piper_biarm_eval.sh
```

## Notes

- This is a configurable bridge skeleton, so you can map your exact joint names and topics.
- It does not reuse `NEW_EMBODIMENT`; it uses the dedicated `PIPER_BIARM` tag.




test 1


system B

cd /home/physicalai/Desktop/I/groot
POLICY_HOST=192.168.200.208 POLICY_PORT=5555 CONTROL_HZ=10 \
LANG_INSTRUCTION="The left arm takes the bowl from the left side and places it in the center. Then, both the left and right arms pick multiple objects from the table and place them into the bowl. Finally, the right arm moves the bowl to the right side." \
  ./gr00t/eval/real_robot/PIPER_BIARM/run_ros2_piper_biarm_eval.sh



test 2 piper



system a



cd /home/physicalai/Desktop/I/groot
source .venv/bin/activate

MODEL_PATH=/home/physicalai/Desktop/I/groot/outputs/biarm_pick_test2/checkpoint-50000 \
./gr00t/eval/real_robot/PIPER_BIARM/run_gr00t_server_piper_biarm.sh



system B


cd /home/physicalai/Desktop/I/groot
source .venv/bin/activate

POLICY_HOST=192.168.200.208 \
LANG_INSTRUCTION="both arm place the blue box on to the table" \
./gr00t/eval/real_robot/PIPER_BIARM/run_ros2_piper_biarm_eval.sh


or 

LANG_INSTRUCTION="both arm place the blue box on to the table"





test 3 daksha


cd /home/physicalai/Desktop/I/groot
source .venv/bin/activate
python gr00t/eval/run_gr00t_server.py \
  --model_path /home/physicalai/Desktop/I/groot/output/openarm_b1_test1/checkpoint-50000 \
  --embodiment-tag OPENARM_B1 \
  --host 0.0.0.0 \
  --port 5555



cd /home/physicalai/Desktop/I/groot
source .venv/bin/activate
POLICY_HOST=192.168.200.208 \
LANG_INSTRUCTION=LANG_INSTRUCTION="Both arms grasp the blue box from the table, close both grippers on the box, and hold it securely." \
bash gr00t/eval/real_robot/OPENARM_B1/run_ros2_openarm_b1_eval.sh
