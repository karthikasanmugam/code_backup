#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="/home/physicalai/Desktop/I/groot"
POLICY_HOST="${POLICY_HOST:-localhost}"
POLICY_PORT="${POLICY_PORT:-5555}"
CONTROL_HZ="${CONTROL_HZ:-10}"
LANG_INSTRUCTION="${LANG_INSTRUCTION:-Use both arms to coordinate the task.}"
TASKS_JSONL="${TASKS_JSONL:-/home/physicalai/Desktop/I/Dataset/pick_place_biarm/meta/tasks.jsonl}"
TASK_INDEX="${TASK_INDEX:-0}"
LEFT_STATE_TOPIC="${LEFT_STATE_TOPIC:-/left_follower/joint_states}"
RIGHT_STATE_TOPIC="${RIGHT_STATE_TOPIC:-/right_follower/joint_states}"
LEFT_CMD_TOPIC="${LEFT_CMD_TOPIC:-/left_follower/joint_ctrl_cmd_left}"
RIGHT_CMD_TOPIC="${RIGHT_CMD_TOPIC:-/right_follower/joint_ctrl_cmd_right}"
WORLD_TOPIC="${WORLD_TOPIC:-/camera/world/color/image_raw/compressed}"
LEFT_WRIST_TOPIC="${LEFT_WRIST_TOPIC:-/left_arm_cam/image_raw/compressed}"
RIGHT_WRIST_TOPIC="${RIGHT_WRIST_TOPIC:-/right_arm_cam/image_raw/compressed}"
LEFT_OBS_KEYS="${LEFT_OBS_KEYS:-joint1,joint2,joint3,joint4,joint5,joint6}"
RIGHT_OBS_KEYS="${RIGHT_OBS_KEYS:-joint1,joint2,joint3,joint4,joint5,joint6}"
LEFT_GRIPPER_OBS_KEY="${LEFT_GRIPPER_OBS_KEY:-gripper}"
RIGHT_GRIPPER_OBS_KEY="${RIGHT_GRIPPER_OBS_KEY:-gripper}"
LEFT_CMD_KEYS="${LEFT_CMD_KEYS:-joint1,joint2,joint3,joint4,joint5,joint6}"
RIGHT_CMD_KEYS="${RIGHT_CMD_KEYS:-joint1,joint2,joint3,joint4,joint5,joint6}"
LEFT_GRIPPER_CMD_KEYS="${LEFT_GRIPPER_CMD_KEYS:-gripper}"
RIGHT_GRIPPER_CMD_KEYS="${RIGHT_GRIPPER_CMD_KEYS:-gripper}"
LEFT_GRIPPER_COMMAND_SCALE="${LEFT_GRIPPER_COMMAND_SCALE:-1.0}"
LEFT_GRIPPER_COMMAND_OFFSET="${LEFT_GRIPPER_COMMAND_OFFSET:-0.0}"
LEFT_GRIPPER_COMMAND_SIGN="${LEFT_GRIPPER_COMMAND_SIGN:-1.0}"
RIGHT_GRIPPER_COMMAND_SCALE="${RIGHT_GRIPPER_COMMAND_SCALE:-1.0}"
RIGHT_GRIPPER_COMMAND_OFFSET="${RIGHT_GRIPPER_COMMAND_OFFSET:-0.0}"
RIGHT_GRIPPER_COMMAND_SIGN="${RIGHT_GRIPPER_COMMAND_SIGN:-1.0}"

cd "$REPO_ROOT"
source .venv/bin/activate

python gr00t/eval/real_robot/PIPER_BIARM/eval_piper_biarm_ros2.py \
  --embodiment-tag PIPER_BIARM \
  --policy-host "$POLICY_HOST" \
  --policy-port "$POLICY_PORT" \
  --control-hz "$CONTROL_HZ" \
  --left-joint-state-topic "$LEFT_STATE_TOPIC" \
  --right-joint-state-topic "$RIGHT_STATE_TOPIC" \
  --left-cmd-topic "$LEFT_CMD_TOPIC" \
  --right-cmd-topic "$RIGHT_CMD_TOPIC" \
  --tasks-jsonl "$TASKS_JSONL" \
  --task-index "$TASK_INDEX" \
  --left-arm-obs-keys-csv "$LEFT_OBS_KEYS" \
  --right-arm-obs-keys-csv "$RIGHT_OBS_KEYS" \
  --left-gripper-obs-key "$LEFT_GRIPPER_OBS_KEY" \
  --right-gripper-obs-key "$RIGHT_GRIPPER_OBS_KEY" \
  --left-arm-cmd-keys-csv "$LEFT_CMD_KEYS" \
  --right-arm-cmd-keys-csv "$RIGHT_CMD_KEYS" \
  --left-gripper-cmd-keys-csv "$LEFT_GRIPPER_CMD_KEYS" \
  --right-gripper-cmd-keys-csv "$RIGHT_GRIPPER_CMD_KEYS" \
  --left-gripper-command-scale "$LEFT_GRIPPER_COMMAND_SCALE" \
  --left-gripper-command-offset "$LEFT_GRIPPER_COMMAND_OFFSET" \
  --left-gripper-command-sign "$LEFT_GRIPPER_COMMAND_SIGN" \
  --right-gripper-command-scale "$RIGHT_GRIPPER_COMMAND_SCALE" \
  --right-gripper-command-offset "$RIGHT_GRIPPER_COMMAND_OFFSET" \
  --right-gripper-command-sign "$RIGHT_GRIPPER_COMMAND_SIGN" \
  --world-topic "$WORLD_TOPIC" \
  --left-wrist-topic "$LEFT_WRIST_TOPIC" \
  --right-wrist-topic "$RIGHT_WRIST_TOPIC" \
  --lang-instruction "$LANG_INSTRUCTION"
