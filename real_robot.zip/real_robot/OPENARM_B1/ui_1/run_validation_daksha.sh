#!/usr/bin/env bash
# Offline validation: does outputs/pick_box_2_8chunk/checkpoint-50000 reproduce the
# recorded pick_box_2 actions?
# Produces a per-joint graph + an HTML report. No robot involved.
#
# Two ways to run:
#
#  A) ONE STEP (simplest) — this script loads the model itself and validates:
#        bash gr00t/eval/real_robot/Daksha/ui/run_validation_daksha.sh
#
#  B) TWO STEPS — reuse an already-running policy server:
#        # terminal 1: launch the model server
#        bash gr00t/eval/real_robot/Daksha/ui/run_gr00t_server_daksha.sh
#        # terminal 2: validate against it
#        USE_SERVER=1 bash gr00t/eval/real_robot/Daksha/ui/run_validation_daksha.sh
#
# Override anything via env vars, e.g.  EPISODES="0 5 10 20"  STEPS=200
#
# Reading the result: pick_box_2 has since grown to 220 episodes, and in this
# checkpoint's statistics the left side does move -- left_joint_6 spans 0.41 rad
# (-0.239..0.170) and the left gripper actuates over -0.044..0.0. The right arm and
# right gripper still carry most of the task, but a flat left-side curve is now a
# finding, not the expected result.
set -euo pipefail

REPO_ROOT="${REPO_ROOT:-/home/physicalai/Desktop/I/groot}"
cd "$REPO_ROOT"
source .venv/bin/activate

# The run keeps only the 2 newest checkpoints (save_total_limit=2) and writes a new
# one every 1000 steps, so a hardcoded checkpoint number goes stale within minutes.
# Default to the highest-numbered one that currently exists; override MODEL_PATH to
# pin a specific checkpoint.
RUN_DIR="${RUN_DIR:-/home/physicalai/Desktop/I/groot/outputs/pick_box_2_8chunk}"
latest_checkpoint() {
  ls -d "$RUN_DIR"/checkpoint-* 2>/dev/null | sed 's/.*checkpoint-//' | sort -n | tail -1
}
if [ -z "${MODEL_PATH:-}" ]; then
  _step="$(latest_checkpoint)"
  [ -n "$_step" ] || { echo "no checkpoint-* under $RUN_DIR — set MODEL_PATH" >&2; exit 1; }
  MODEL_PATH="$RUN_DIR/checkpoint-$_step"
  echo "[daksha] using newest checkpoint: $MODEL_PATH"
fi
DATASET_PATH="${DATASET_PATH:-/home/physicalai/Desktop/I/barani/pick_box_2}"
EMBODIMENT_TAG="${EMBODIMENT_TAG:-daksha}"
EPISODES="${EPISODES:-0 1 2 3}"
STEPS="${STEPS:-200}"
# Must equal the checkpoint's action delta_indices count: 8 for pick_box_2_8chunk
# (its experiment_cfg/conf.yaml lists delta_indices [0..7]), 16 for the older
# outputs/pick_box_2 run.
ACTION_HORIZON="${ACTION_HORIZON:-8}"
HOST="${HOST:-127.0.0.1}"
PORT="${PORT:-5555}"

SCRIPT="gr00t/eval/real_robot/Daksha/ui/validate_prediction_vs_dataset.py"

if [[ "${USE_SERVER:-0}" == "1" ]]; then
  echo "[validation] Using running policy server tcp://${HOST}:${PORT}"
  MODEL_ARG=(--host "${HOST}" --port "${PORT}")
else
  echo "[validation] Loading model directly from ${MODEL_PATH}"
  MODEL_ARG=(--model-path "${MODEL_PATH}")
fi

python "${SCRIPT}" \
  "${MODEL_ARG[@]}" \
  --dataset-path "${DATASET_PATH}" \
  --embodiment-tag "${EMBODIMENT_TAG}" \
  --episodes ${EPISODES} \
  --steps "${STEPS}" \
  --action-horizon "${ACTION_HORIZON}"

REPORT="$(dirname "${DATASET_PATH}")/validation_$(basename "${DATASET_PATH}")/validation_report.html"
echo
echo "[validation] Dashboard UI: ${REPORT}"
# Try to open the UI in a browser (ignore failure on headless machines).
( xdg-open "${REPORT}" >/dev/null 2>&1 & ) || true
