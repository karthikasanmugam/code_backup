# DAKSHA validation UI

Offline, **no-robot** validation for the `daksha` / `pick_box` checkpoint.
Runs the model open-loop over the RECORDED dataset and overlays, per joint:

- `state` — the recorded joint position at each frame
- `gt` — the recorded ACTION the human demonstrated
- `pred` — what the model predicts from the recorded observation

What this validates and what it does **not**: it validates the MODEL (given a
correct observation, does it reproduce the recorded actions?). It does **not**
validate the ROS2 deployment mapping — topic order, left/right routing, clamp
limits. Those live in `../eval_daksha_ros2.py`. A model that looks perfect
here can still move wrongly on the robot, so check both.

## Three ways in

```bash
# 1. Browser studio: pick dataset + checkpoint + episodes, press Run, read charts.
bash gr00t/eval/real_robot/Daksha/ui/run_validation_ui.sh
#    Binds 0.0.0.0:8123. Anyone who reaches the port can start a GPU job, so on a
#    shared network:  TOKEN=mysecret bash .../run_validation_ui.sh

# 2. CLI: writes episode_<id>.png + validation_report.html next to the dataset.
bash gr00t/eval/real_robot/Daksha/ui/run_validation_daksha.sh
EPISODES="0 5 10 20" STEPS=600 bash .../run_validation_daksha.sh

# 3. Serve a directory of dumps produced earlier by the CLI (no model loading).
STATIC=1 DATA_DIR=/home/physicalai/Desktop/I/barani/validation_pick_box \
  bash .../run_validation_ui.sh
```

## Training Studio

For an end-to-end Daksha browser UI (dataset selection, hyperparameters, action
chunk, live logs, stop/resume, checkpoint discovery, System A, offline evaluation,
and the guarded System B ROS2 bridge), run:

```bash
cd /home/s1/.ihub/vla/groot/Isaac-GR00T-n1.6.1
bash gr00t/eval/real_robot/Daksha/ui/run_training_studio.sh
```

Open `http://127.0.0.1:8130`. It scans `/home/s1/Desktop/datasets` by default.
Training uses `examples/Daksha/daksha_config.py` and `EmbodimentTag.DAKSHA`.
The action-chunk input is wired directly to `--action-chunk-size`; use the same
value for offline evaluation and the policy bridge. A re-run using the same output
folder resumes the latest checkpoint automatically. System B requires typing
`START ROBOT` and invokes the existing `examples/Daksha/run_system_b_daksha_ros2.sh`.

`run_gr00t_server_daksha.sh` (System A policy server) also lives here; both
validation entry points can reuse a running server instead of loading the model
themselves — pass `USE_SERVER=1` to the CLI one.

## Files

| file | what it is |
|---|---|
| `validation_app.py` + `validation_app.html` | the browser studio (scan, run, chart) |
| `validate_prediction_vs_dataset.py` | the CLI validator; also supplies the studio's metrics |
| `serve_validation_ui.py` | static server for already-computed dumps |
| `run_*.sh` | launchers, every default overridable by env var |
| `daksha_b1/` | A standalone Daksha B1 finetuning/eval setup with its own launchers. Uses `EmbodimentTag.DAKSHA` and paths rooted at `gr00t/eval/real_robot/Daksha/ui/daksha_b1/` (both fixed — they used to reference an undefined `DAKSHA_B1` tag and a nonexistent `grootn1.7/Isaac-GR00T` tree). Independent of the `run_*.sh` files above, which target the Daksha setup one level up. |

## Reading the report

`pred` should track `gt`. Flat / offset / noisy `pred` on a joint means that joint
was not learned well.

One caveat specific to `pick_box`: the **left arm barely moves** — under 0.05 rad
of total range per joint, and the left gripper spans 5e-5 rad. Its `MAE/range`
column is therefore a ratio of two near-zero numbers and means nothing (it prints
`n/a` when the range is zero). Judge the model on the right-arm channels, which
carry the task. For the same reason, use a realistic `STEPS` (episodes are 600
frames): a 32-step window catches only the initial pause, where nothing moves and
every ratio explodes.

## Defaults

Checkpoint `/home/physicalai/Desktop/I/groot/outputs/pick_box_2_8chunk/checkpoint-50000`,
dataset `/home/physicalai/Desktop/I/barani/pick_box_2`, embodiment tag `daksha`,
action horizon **8** (must equal the checkpoint's action `delta_indices` count --
8 for `pick_box_2_8chunk`, 16 for the older `outputs/pick_box_2` run).
