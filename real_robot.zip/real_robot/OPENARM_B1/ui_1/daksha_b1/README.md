# Daksha B1 Finetuning

This folder is a standalone embodiment setup for your 16-DoF, 4-camera dataset.
It mirrors the Daksha-style structure but uses a dedicated `DAKSHA` tag so
the example stays isolated from the reference folders.

## Tag flow

- `EmbodimentTag.DAKSHA` is defined in `gr00t/data/embodiment_tags.py`
  (value `"daksha"`)
- `daksha_b1_config.py` registers the modality config under that tag
- `modality.json` maps the dataset metadata to GR00T's `state`, `action`,
  `video`, and language fields

## Dataset layout

Expected dataset keys from your metadata:

- `action`: 16 values
- `observation.state`: 16 values
- `observation.leader_state`: 16 values
- split as:
  - `right_arm`: 7 values
  - `right_gripper`: 1 value
  - `left_arm`: 7 values
  - `left_gripper`: 1 value
- cameras:
  - `observation.images.zed_right`
  - `observation.images.zed_left`
  - `observation.images.right_wrist`
  - `observation.images.left_wrist`
- language: `task_index` in `meta/modality.json`

If your dataset root does not yet contain the modality file, copy it in:

```bash
cp gr00t/eval/real_robot/Daksha/ui/daksha_b1/modality.json /path/to/local/bluebox_pick_place/meta/modality.json
```

## Finetuning

Run this directly in a terminal:

```bash
cd ~/.ihub/vla/groot/Isaac-GR00T-n1.6.1
source .venv/bin/activate

CUDA_VISIBLE_DEVICES=0 python -m gr00t.experiment.launch_finetune \
  --base-model-path nvidia/GR00T-N1.7-3B \
  --dataset-path /path/to/local/bluebox_pick_place \
  --modality-config-path gr00t/eval/real_robot/Daksha/ui/daksha_b1/daksha_b1_config.py \
  --embodiment-tag DAKSHA \
  --num-gpus 1 \
  --output-dir ./outputs/daksha_b1_pick_place_ft \
  --save-total-limit 2 \
  --save-steps 1000 \
  --max-steps 50000 \
  --global-batch-size 32 \
  --dataloader-num-workers 8
```

Or call the shared launcher directly:

```bash
CUDA_VISIBLE_DEVICES=0 NUM_GPUS=1 uv run bash examples/finetune.sh \
  --base-model-path nvidia/GR00T-N1.7-3B \
  --dataset-path /path/to/local/bluebox_pick_place \
  --modality-config-path gr00t/eval/real_robot/Daksha/ui/daksha_b1/daksha_b1_config.py \
  --embodiment-tag DAKSHA \
  --output-dir /tmp/daksha_b1_finetune
```

## Resume Training

Resuming is automatic from the last checkpoint in the same `output_dir`:

```bash
cd ~/.ihub/vla/groot/Isaac-GR00T-n1.6.1
source .venv/bin/activate

CUDA_VISIBLE_DEVICES=0 python -m gr00t.experiment.launch_finetune \
  --base-model-path nvidia/GR00T-N1.7-3B \
  --dataset-path /path/to/local/bluebox_pick_place \
  --modality-config-path gr00t/eval/real_robot/Daksha/ui/daksha_b1/daksha_b1_config.py \
  --embodiment-tag DAKSHA \
  --num-gpus 1 \
  --output-dir ./outputs/daksha_b1_pick_place_ft \
  --save-total-limit 2 \
  --save-steps 1000 \
  --max-steps 100000 \
  --global-batch-size 32 \
  --dataloader-num-workers 8
```

## SOP

1. Copy [modality.json](modality.json) (`gr00t/eval/real_robot/Daksha/ui/daksha_b1/modality.json`) into your dataset `meta/` folder.
2. Run the training command above.
3. If training stops in the middle, run the resume command above.
4. Start System A with:

```bash
cd ~/.ihub/vla/groot/Isaac-GR00T-n1.6.1
source .venv/bin/activate

python gr00t/eval/run_gr00t_server.py \
  --model_path /home/physicalai/Desktop/I/grootn1.7/Isaac-GR00T/outputs/daksha_b1_pick_place_ft/checkpoint-50000 \
  --embodiment-tag DAKSHA \
  --host 0.0.0.0 \
  --port 5555
```

5. Start System B with:

> **No dedicated `eval_daksha_b1_ros2.py` exists in this repo.** The only ROS2
> bridge that actually ships here is `gr00t/eval/real_robot/Daksha/eval_daksha_ros2.py`,
> but it is wired for the 3-camera Daksha layout (`--world-topic`,
> `--right-wrist-topic`, `--left-wrist-topic`) and has no `--zed-right-topic`,
> `--zed-left-topic`, or `--lang-instruction` flags. This folder's 4-camera
> (`zed_right`/`zed_left`/`right_wrist`/`left_wrist`) dataset layout does not map
> onto it directly, so a dedicated Daksha B1 ROS2 bridge with its own topic
> wiring still needs to be written — the command below is the closest existing
> starting point, not a verified drop-in replacement:

```bash
cd ~/.ihub/vla/groot/Isaac-GR00T-n1.6.1
source .venv/bin/activate

python gr00t/eval/real_robot/Daksha/eval_daksha_ros2.py \
  --policy-host <SYSTEM_A_IP> \
  --policy-port 5555 \
  --control-hz 10 \
  --joint-state-topic /joint_states_ordered \
  --cmd-topic /leader_joint_states_ordered
  # NOTE: --zed-right-topic / --zed-left-topic / --lang-instruction do not exist
  # on this script; see the caveat above.
```

## Open-loop evaluation

```bash
uv run python gr00t/eval/open_loop_eval.py \
  --dataset-path /path/to/local/bluebox_pick_place \
  --embodiment-tag DAKSHA \
  --model-path /tmp/daksha_b1_finetune/checkpoint-10000 \
  --traj-ids 0 \
  --action-horizon 16 \
  --steps 400
```

## Closed-loop evaluation

Use the real-robot scaffold in `gr00t/eval/real_robot/Daksha/` (see the caveat
under "Start System B" above — there is no dedicated 4-camera Daksha B1 ROS2
bridge yet) and run the policy server with the same tag:

```bash
python gr00t/eval/run_gr00t_server.py \
  --model_path /tmp/daksha_b1_finetune/checkpoint-10000 \
  --embodiment-tag DAKSHA \
  --host 0.0.0.0 \
  --port 5555
```
