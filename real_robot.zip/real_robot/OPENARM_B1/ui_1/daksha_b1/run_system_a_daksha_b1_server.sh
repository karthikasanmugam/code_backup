#!/usr/bin/env bash
set -euo pipefail

cd ~/.ihub/vla/groot/Isaac-GR00T-n1.6.1
source .venv/bin/activate

python gr00t/eval/run_gr00t_server.py \
  --model_path "${MODEL_PATH:-/home/physicalai/Desktop/I/grootn1.7/Isaac-GR00T/output/pick_place_blue/checkpoint-70000}" \
  --embodiment-tag DAKSHA \
  --host "${HOST:-0.0.0.0}" \
  --port "${PORT:-5555}"