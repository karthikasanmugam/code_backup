#!/usr/bin/env python3
"""Smoothing filter node that sits between the policy and the arm controller.

    eval_daksha_b1_ros2.py  --cmd-topic /joint_cmd_pri  -->  [this node]  -->  /joint_cmd

No inference code is touched: point the policy at /joint_cmd_pri and this node publishes
the smoothed stream on /joint_cmd, so the controller subscription stays exactly as it is.

WHY THIS EXISTS
---------------
Measured on the validation dump
    barani/validation_pick_place_brown_300/pick_place_brown_300-checkpoint-70000__h16_s500
(4 episodes x 500 frames @ 30 fps, checkpoint-70000), comparing predicted actions against
ground truth on the 7 moving right-arm joints:

    action-velocity energy    ground truth      prediction
      0 - 1 Hz  (real motion)     70 %            11 - 27 %
      3 - 6 Hz                     3 %              ~17 %
     10 - 15 Hz (near Nyquist)    ~10 %            ~30 %     <-- the jerk

    jerk RMS                      1.00x (ref)      3.44x
    worst single 30 Hz step       0.087 rad        0.391 rad  (= 11.7 rad/s)

Real motion in this task lives below 1 Hz. A third of the predicted energy sits at
10-15 Hz, which is sampling noise from the flow-matching action head, not motion the
task needs. The prediction ERROR, meanwhile, is 65-77 % below 1 Hz -- slow tracking
offset that lives in a different band from the noise. That separation is what makes a
low-pass nearly free here: with lag compensated out, filtering at 3 Hz actually scores
BETTER than raw (MAE 0.01920 vs 0.01969), i.e. it removes noise and no signal.

Causal filters benchmarked over all 4 episodes (jerk relative to ground-truth jerk):

    raw / no filter                3.44x   max step 0.379   MAE   --
    slew limit 0.02 rad/tick       1.08x   max step 0.020   +42 %   <- clips peaks,
    moving average n=5             0.56x   max step 0.091   + 8.5 %    leaves the noise
    EMA alpha=0.35                 0.83x   max step 0.137   + 5.4 %
    Butterworth-2 fc=3 Hz          0.25x   max step 0.112   +11 %    <-- default
    Butterworth-2 fc=2 Hz          0.12x   max step 0.082   +19 %
    One-Euro fc0=1.0 beta=0.02     0.39x   max step 0.075   +21 %

Butterworth-2 @ 3 Hz wins: 13x less jerk than raw, and its entire "+11 % MAE" is phase
lag (167 ms), not distortion. One-Euro loses here because the noise amplitude does not
scale with motion speed, which is the only regime its adaptive cutoff wins in.

WHERE THE PER-JOINT CUTOFFS COME FROM
-------------------------------------
Measured on the full training set the checkpoint was fit to (barani/pick_place_brown_300,
236 episodes / 118 000 frames @ 30 fps). The recorded actions carry encoder quantization
at exactly 2*pi/4096 = 0.001534 rad, which puts a FLAT white noise floor across the whole
spectrum -- so raw "99 % of energy" bandwidth reads ~15 Hz for every joint and is
meaningless. Subtracting that floor (median PSD above 10 Hz) leaves the real signal:

    joint                f95 Hz   f99 Hz     dq p99.9    dataset range
    right_joint_1         1.35     2.70       0.0552        2.143
    right_joint_2         3.11     4.39       0.0307        0.652   <- fastest
    right_joint_3         2.11     2.93       0.0614        1.362
    right_joint_4         1.93     2.75       0.0614        1.549
    right_joint_5         2.64     3.81       0.0491        1.233
    right_joint_6         1.70     2.40       0.0982        1.796
    right_joint_7         1.70     2.29       0.1058        2.668
    right_gripper         2.34     3.11       0.0107        0.044
    left_joint_*         12.4-14.1  ~15       <=0.0031     0.17-0.76  <- no signal, noise only

--cutoff-map defaults are each joint's f99, so every filter passes 99 % of the motion that
joint actually performs in training and rejects the rest. The left arm never moves in this
task (dq p99.9 <= 0.003 rad, i.e. ~2 quantization counts), so its entire measured "band-
width" is quantization noise; it is pinned to 1.0 Hz to stop the model buzzing it. Left-arm
peak step: 0.00163 rad raw -> 0.00015 rad filtered.

    config                       jerk vs GT    MAE      lag-comp MAE
    raw                             3.44x     0.02106     0.01969
    single global fc=3 Hz           0.25x     0.02342     0.01920
    per-joint map (default)         0.22x     0.02362     0.01912   <-- best on both

FILTER CHAIN (per joint, in order)
----------------------------------
  1. Butterworth-2 low-pass, --cutoff-map / --cutoff-hz (default 3.0), transposed
     direct-form II.
     State is seeded to the first sample, so the output starts exactly on the incoming
     command with no startup kick, and is NEVER reset between policy chunks -- one
     continuous state across the whole run is what removes the discontinuity at every
     16-step chunk boundary.
  2. Slew limit, --max-step-rad, as a pure safety backstop after the low-pass. Keep it
     generous. As a smoother it is the worst option in the table above (1.08x jerk for
     +42 % MAE) because clipping peaks leaves the high-frequency content intact.

Grippers are excluded from both stages by default (--gripper-cutoff-hz 0) so a grasp
still snaps: their noise is +/-0.04 rad on a 0.044 rad range, and smoothing it would
blunt the open/close edge for no real gain.

USAGE
-----
    # terminal A -- policy, publishing to the PRE-filter topic (env var only)
    CMD_TOPIC=/joint_cmd_pri ./run_system_b_daksha_b1_ros2.sh

    # terminal B -- this node
    python gr00t/eval/real_robot/Daksha/ui/daksha_b1/joint_cmd_filter.py

    # A/B the filter live, without restarting the policy
    python gr00t/eval/real_robot/Daksha/ui/daksha_b1/joint_cmd_filter.py --mode none     # raw passthrough
    python gr00t/eval/real_robot/Daksha/ui/daksha_b1/joint_cmd_filter.py --cutoff-hz 4   # less lag, more jerk

--rate MUST match the policy's --control-hz (30 in run_system_b_daksha_b1_ros2.sh);
the filter is designed for that sample rate. The node warns if the measured input rate
drifts from it.
"""

import argparse
import math
import re
import sys
import time

import rclpy
from rclpy.node import Node
from rclpy.utilities import remove_ros_args
from sensor_msgs.msg import JointState


class Butter2LowPass:
    """Causal 2nd-order Butterworth low-pass, one scalar channel.

    Coefficients are the bilinear transform of the analog prototype and match
    scipy.signal.butter(2, fc / (fs / 2), "low") to ~1e-15, so scipy is not a
    dependency of this node (it may run outside the GR00T venv).
    """

    def __init__(self, cutoff_hz: float, rate_hz: float):
        k = math.tan(math.pi * cutoff_hz / rate_hz)
        norm = 1.0 / (1.0 + math.sqrt(2.0) * k + k * k)
        self.b0 = k * k * norm
        self.b1 = 2.0 * self.b0
        self.b2 = self.b0
        self.a1 = 2.0 * (k * k - 1.0) * norm
        self.a2 = (1.0 - math.sqrt(2.0) * k + k * k) * norm
        self.z1 = 0.0
        self.z2 = 0.0
        self.primed = False

    def seed(self, x: float) -> None:
        """Set state to the steady-state response for a constant input x.

        Equivalent to scipy's lfilter_zi * x. Guarantees the first output equals the
        first input, so inserting this node never produces a step on the command.
        """
        self.z1 = (self.b1 - self.a1 + self.b2 - self.a2) * x
        self.z2 = (self.b2 - self.a2) * x
        self.primed = True

    def step(self, x: float) -> float:
        if not self.primed:
            self.seed(x)
        y = self.b0 * x + self.z1
        self.z1 = self.b1 * x - self.a1 * y + self.z2
        self.z2 = self.b2 * x - self.a2 * y
        return y


class EmaLowPass:
    """First-order exponential moving average. Kept for A/B against the Butterworth."""

    def __init__(self, alpha: float):
        self.alpha = alpha
        self.y = None

    def seed(self, x: float) -> None:
        self.y = x

    def step(self, x: float) -> float:
        if self.y is None:
            self.y = x
        self.y = self.alpha * x + (1.0 - self.alpha) * self.y
        return self.y


def parse_cutoff_map(spec: str):
    """Parse "regex=hz,regex=hz" into an ordered [(compiled_regex, hz)] list, first match wins."""
    out = []
    for item in (s.strip() for s in spec.split(",")):
        if not item:
            continue
        if "=" not in item:
            raise SystemExit(f"--cutoff-map entry '{item}' is not of the form REGEX=HZ")
        pattern, _, hz = item.rpartition("=")
        try:
            out.append((re.compile(pattern, re.IGNORECASE), float(hz)))
        except (re.error, ValueError) as exc:
            raise SystemExit(f"--cutoff-map entry '{item}' is invalid: {exc}") from exc
    return out


class JointCmdFilter(Node):
    def __init__(self, args):
        super().__init__("joint_cmd_filter")
        self.args = args
        self.gripper_re = re.compile(args.gripper_regex, re.IGNORECASE) if args.gripper_regex else None
        self.zero_re = re.compile(args.zero_regex, re.IGNORECASE) if args.zero_regex else None
        self.cutoff_map = parse_cutoff_map(args.cutoff_map)

        # Per-joint-NAME state, so the node is immune to any reordering or subsetting of
        # the incoming JointState (unknown joints simply pass through unfiltered).
        self.filters: dict[str, object] = {}
        self.last_out: dict[str, float] = {}

        self.last_msg_time = 0.0
        self.n_msgs = 0
        self.first_msg_time = 0.0
        self.n_slew_clamped = 0
        # Rolling diagnostics: sum of squared 3rd differences in vs out (jerk energy).
        self.hist_in: dict[str, list[float]] = {}
        self.hist_out: dict[str, list[float]] = {}
        self.jerk_in_sq = 0.0
        self.jerk_out_sq = 0.0
        self.jerk_n = 0
        self.max_step_in = 0.0
        self.max_step_out = 0.0

        self.sub = self.create_subscription(
            JointState, args.in_topic, self.listener_callback, args.queue_depth
        )
        self.pub = self.create_publisher(JointState, args.out_topic, args.queue_depth)
        if args.report_s > 0:
            self.create_timer(args.report_s, self._report)

        if args.mode == "butter":
            desc = f"Butterworth-2 low-pass fc={args.cutoff_hz} Hz (default) @ {args.rate} Hz"
        elif args.mode == "ema":
            desc = f"EMA alpha={args.ema_alpha}"
        else:
            desc = "NONE (raw passthrough -- filter disabled)"
        self.get_logger().info(
            f"joint_cmd_filter: {args.in_topic} -> {args.out_topic} | {desc} | "
            f"slew limit {args.max_step_rad} rad/tick | "
            f"grippers "
            + (
                f"filtered at {args.gripper_cutoff_hz} Hz"
                if args.gripper_cutoff_hz > 0
                else "BYPASSED (snap preserved)"
            )
        )
        if args.zero_regex:
            self.get_logger().warn(f"zeroing joints matching /{args.zero_regex}/ -- these will be sent as 0.0")

    def _cutoff_for(self, name: str) -> float:
        """Per-joint cutoff: first regex in --cutoff-map that matches, else --cutoff-hz."""
        for pattern, hz in self.cutoff_map:
            if pattern.search(name):
                return hz
        return self.args.cutoff_hz

    def _make_filter(self, name: str):
        if self.args.mode == "none":
            return None
        is_gripper = bool(self.gripper_re and self.gripper_re.search(name))
        if is_gripper:
            if self.args.gripper_cutoff_hz <= 0:
                return None  # bypass: let the grasp snap
            return Butter2LowPass(self.args.gripper_cutoff_hz, self.args.rate)
        if self.args.mode == "ema":
            return EmaLowPass(self.args.ema_alpha)
        fc = self._cutoff_for(name)
        if fc <= 0:
            return None
        if fc >= self.args.rate / 2:
            raise SystemExit(f"cutoff {fc} Hz for '{name}' is at/above Nyquist ({self.args.rate / 2} Hz)")
        self.get_logger().info(f"  {name}: Butterworth-2 fc={fc} Hz")
        return Butter2LowPass(fc, self.args.rate)

    def _reseed_all(self, names, positions) -> None:
        """Re-seed every filter to the current command after a gap in the input stream.

        A stall (policy restart, paused run) breaks the uniform-sampling assumption the
        IIR design rests on. Re-seeding to the live value resumes from the current pose
        with no transient, instead of replaying stale state as a jump.
        """
        for name, pos in zip(names, positions):
            filt = self.filters.get(name)
            if filt is not None:
                filt.seed(float(pos))
            self.last_out[name] = float(pos)
        self.hist_in.clear()
        self.hist_out.clear()

    def listener_callback(self, msg: JointState) -> None:
        now = time.monotonic()
        has_pos = len(msg.position) == len(msg.name)
        if not has_pos:
            # Nothing to filter without positions -- forward untouched rather than drop.
            self.pub.publish(msg)
            return

        gap = now - self.last_msg_time if self.last_msg_time > 0 else 0.0
        if self.last_msg_time > 0 and gap > self.args.stale_reset_s:
            self.get_logger().warn(
                f"input gap {gap * 1000:.0f} ms > {self.args.stale_reset_s * 1000:.0f} ms "
                f"-- re-seeding filter state to current command"
            )
            self._reseed_all(msg.name, msg.position)
        self.last_msg_time = now
        if self.first_msg_time == 0.0:
            self.first_msg_time = now
        self.n_msgs += 1

        has_vel = len(msg.velocity) == len(msg.name)
        has_eff = len(msg.effort) == len(msg.name)

        out = JointState()
        out.header = msg.header
        if self.args.restamp:
            out.header.stamp = self.get_clock().now().to_msg()

        new_position, new_velocity, new_effort = [], [], []

        for i, name in enumerate(msg.name):
            out.name.append(name)
            raw = float(msg.position[i])

            if self.zero_re and self.zero_re.search(name):
                new_position.append(0.0)
                if has_vel:
                    new_velocity.append(0.0)
                if has_eff:
                    new_effort.append(0.0)
                continue

            if name not in self.filters:
                self.filters[name] = self._make_filter(name)
                self.last_out[name] = raw

            filt = self.filters[name]
            val = raw if filt is None else filt.step(raw)

            # Safety backstop only -- must not be doing the smoothing work.
            is_gripper = bool(self.gripper_re and self.gripper_re.search(name))
            if self.args.max_step_rad > 0 and not is_gripper:
                prev = self.last_out.get(name, val)
                delta = val - prev
                if delta > self.args.max_step_rad:
                    val = prev + self.args.max_step_rad
                    self.n_slew_clamped += 1
                elif delta < -self.args.max_step_rad:
                    val = prev - self.args.max_step_rad
                    self.n_slew_clamped += 1

            self._accumulate_stats(name, raw, val)
            self.last_out[name] = val
            new_position.append(val)
            if has_vel:
                new_velocity.append(float(msg.velocity[i]))
            if has_eff:
                new_effort.append(float(msg.effort[i]))

        out.position = new_position
        if has_vel:
            out.velocity = new_velocity
        if has_eff:
            out.effort = new_effort
        self.pub.publish(out)

    def _accumulate_stats(self, name: str, raw: float, val: float) -> None:
        """Track 3rd-difference (jerk) energy in vs out so the effect is measurable live."""
        hi = self.hist_in.setdefault(name, [])
        ho = self.hist_out.setdefault(name, [])
        hi.append(raw)
        ho.append(val)
        if len(hi) > 4:
            hi.pop(0)
            ho.pop(0)
        if len(hi) == 4:
            ji = hi[3] - 3 * hi[2] + 3 * hi[1] - hi[0]
            jo = ho[3] - 3 * ho[2] + 3 * ho[1] - ho[0]
            self.jerk_in_sq += ji * ji
            self.jerk_out_sq += jo * jo
            self.jerk_n += 1
            self.max_step_in = max(self.max_step_in, abs(hi[3] - hi[2]))
            self.max_step_out = max(self.max_step_out, abs(ho[3] - ho[2]))

    def _report(self) -> None:
        if self.n_msgs < 2:
            self.get_logger().warn(f"no commands seen on {self.args.in_topic} yet")
            return
        elapsed = max(time.monotonic() - self.first_msg_time, 1e-6)
        rate = (self.n_msgs - 1) / elapsed
        if abs(rate - self.args.rate) > 0.15 * self.args.rate:
            self.get_logger().warn(
                f"input rate {rate:.1f} Hz differs from --rate {self.args.rate:.1f} Hz -- "
                f"the {self.args.cutoff_hz} Hz cutoff is designed for --rate; "
                f"set --rate to the policy's --control-hz"
            )
        if self.jerk_n > 0:
            jin = math.sqrt(self.jerk_in_sq / self.jerk_n)
            jout = math.sqrt(self.jerk_out_sq / self.jerk_n)
            ratio = jout / jin if jin > 0 else float("nan")
            self.get_logger().info(
                f"{self.n_msgs} cmds @ {rate:.1f} Hz | jerk RMS in {jin:.5f} -> out {jout:.5f} "
                f"({ratio:.2f}x, {(1 - ratio) * 100:.0f}% removed) | "
                f"max step in {self.max_step_in:.4f} -> out {self.max_step_out:.4f} rad | "
                f"slew clamps {self.n_slew_clamped}"
            )
        self.jerk_in_sq = self.jerk_out_sq = 0.0
        self.jerk_n = 0
        self.max_step_in = self.max_step_out = 0.0
        self.n_slew_clamped = 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Low-pass smoothing filter for GR00T joint commands (topic in -> topic out).",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p.add_argument("--in-topic", default="/joint_cmd_pri", help="pre-filter topic the policy publishes")
    p.add_argument("--out-topic", default="/joint_cmd", help="post-filter topic the controller subscribes to")
    p.add_argument("--queue-depth", type=int, default=10)
    p.add_argument(
        "--mode",
        choices=["butter", "ema", "none"],
        default="butter",
        help="butter = 2nd-order Butterworth (recommended); none = raw passthrough for A/B",
    )
    p.add_argument(
        "--rate",
        type=float,
        default=30.0,
        help="sample rate the filter is designed for; MUST match the policy --control-hz",
    )
    p.add_argument(
        "--cutoff-hz",
        type=float,
        default=3.0,
        help="arm low-pass cutoff. 3.0 = 0.25x GT jerk @ 167 ms lag; 4.0 = 0.40x @ 133 ms; 2.0 = 0.12x @ 200 ms",
    )
    p.add_argument(
        "--cutoff-map",
        default="right_joint_2=4.5,right_joint_5=4.0,right_joint_6=2.5,right_joint_7=2.5,left_joint=1.0",
        help="per-joint overrides as REGEX=HZ,... (first match wins, else --cutoff-hz). Defaults are the "
        "f99 signal bandwidth measured per joint over all 236 training episodes, encoder-quantization "
        "noise floor subtracted. Left arm is idle in this task so it is pinned low to kill buzz. "
        "Empty string = one global cutoff for every arm joint",
    )
    p.add_argument("--ema-alpha", type=float, default=0.35, help="only used with --mode ema")
    p.add_argument(
        "--gripper-regex",
        default="gripper|finger",
        help="joints matching this are treated as grippers (empty string disables)",
    )
    p.add_argument(
        "--gripper-cutoff-hz",
        type=float,
        default=0.0,
        help="0 = bypass grippers entirely so a grasp snaps; >0 = low-pass them at this cutoff",
    )
    p.add_argument(
        "--max-step-rad",
        type=float,
        default=0.15,
        help="post-filter per-tick slew backstop for arm joints (0 disables). Keep generous: "
        "as a smoother this is the worst option measured. Scale by (30/rate) if rate changes",
    )
    p.add_argument(
        "--stale-reset-s",
        type=float,
        default=0.5,
        help="input gap above this re-seeds filter state to the live command",
    )
    p.add_argument("--restamp", action="store_true", help="stamp outgoing header with receive time")
    p.add_argument(
        "--zero-regex",
        default="",
        help="joints matching this are commanded to 0.0 (old right-arm-disable behaviour; off by default)",
    )
    p.add_argument("--report-s", type=float, default=5.0, help="diagnostics interval, 0 to disable")
    return p


def main(argv=None):
    argv = sys.argv if argv is None else argv
    # Strip ROS-injected args (--ros-args, __node:=, remappings) before our own parsing.
    args = build_parser().parse_args(remove_ros_args(argv)[1:])

    if args.cutoff_hz >= args.rate / 2:
        raise SystemExit(f"--cutoff-hz {args.cutoff_hz} must be below Nyquist ({args.rate / 2} Hz)")

    rclpy.init(args=argv)
    node = JointCmdFilter(args)
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
