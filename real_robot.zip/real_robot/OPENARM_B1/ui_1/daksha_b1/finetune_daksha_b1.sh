#!/usr/bin/env bash
set -euo pipefail

cd ~/.ihub/vla/groot/Isaac-GR00T-n1.6.1
source .venv/bin/activate

# Daksha B1 uses a 4-part split in modality.json:
# right_arm, right_gripper, left_arm, left_gripper.
CUDA_VISIBLE_DEVICES=0 python -m gr00t.experiment.launch_finetune \
  --base-model-path nvidia/GR00T-N1.7-3B \
  --dataset-path "${DATASET_PATH:-/home/physicalai/Desktop/I/Muliti_dataset_storage/custom_arm_task1}" \
  --modality-config-path gr00t/eval/real_robot/Daksha/ui/daksha_b1/daksha_b1_config.py \
  --embodiment-tag DAKSHA \
  --num-gpus 1 \
  --output-dir "${OUTPUT_DIR:-./outputs/daksha_b1_custom_arm_task1_ft}" \
  --save-total-limit 2 \
  --save-steps 1000 \
  --max-steps 50000 \
  --global-batch-size 32 \
  --dataloader-num-workers 8
