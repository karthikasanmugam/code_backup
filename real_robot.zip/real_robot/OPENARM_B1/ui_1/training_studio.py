#!/usr/bin/env python3
"""Daksha Training Studio: local browser UI for GR00T fine-tuning and deployment.

The server intentionally has no third-party web dependency.  It runs only commands
already provided by this repository and keeps a short live log for each process.
Use HOST=127.0.0.1 (the default) unless a TOKEN is configured.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import threading
import time
import urllib.parse
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any

HERE = Path(__file__).resolve().parent
REPO_ROOT = HERE.parents[4]
DEFAULT_DATASET_ROOT = Path("/home/s1/Desktop/datasets")
DAKSHA_CONFIG = REPO_ROOT / "examples/Daksha/daksha_config.py"
VALIDATION_APP = HERE / "validation_app.py"


def is_dataset(path: Path) -> bool:
    return (path / "meta/info.json").is_file()


def is_checkpoint(path: Path) -> bool:
    return (path / "config.json").is_file() and (
        (path / "model.safetensors.index.json").is_file() or any(path.glob("*.safetensors"))
    )


def scan(root: Path, predicate, depth: int = 4) -> list[Path]:
    found: list[Path] = []
    if not root.is_dir():
        return found
    for current, dirs, _ in os.walk(root):
        p = Path(current)
        level = len(p.relative_to(root).parts)
        dirs[:] = [d for d in dirs if not d.startswith(".") and d not in {"data", "videos", "wandb", "__pycache__"}]
        if level > depth:
            dirs[:] = []
            continue
        if predicate(p):
            found.append(p)
            if predicate is is_dataset:
                dirs[:] = []
    return sorted(found)


def dataset_info(path: Path) -> dict[str, Any]:
    info = json.loads((path / "meta/info.json").read_text())
    names = info.get("features", {}).get("action", {}).get("names", [])
    has_modality = (path / "meta/modality.json").is_file()
    return {"path": str(path), "name": path.name, "episodes": info.get("total_episodes", 0),
            "frames": info.get("total_frames", 0), "fps": info.get("fps", "?"),
            "action_dim": len(names), "modality": has_modality,
            "ready": has_modality and len(names) == 16,
            "reason": "Ready for the 16-DoF Daksha config" if has_modality and len(names) == 16 else
                      "Needs meta/modality.json and a 16-value action field for the supplied Daksha config"}


class Process:
    def __init__(self, name: str, command: list[str], env: dict[str, str] | None = None):
        self.name, self.command = name, command
        self.logs: deque[str] = deque(maxlen=800)
        self.started = time.time()
        child_env = os.environ.copy()
        child_env.update(env or {})
        self.proc = subprocess.Popen(command, cwd=REPO_ROOT, env=child_env, text=True,
                                     stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                     start_new_session=True, bufsize=1)
        threading.Thread(target=self._read, daemon=True).start()

    def _read(self):
        assert self.proc.stdout
        for line in self.proc.stdout:
            self.logs.append(line.rstrip())

    def public(self) -> dict[str, Any]:
        rc = self.proc.poll()
        return {"name": self.name, "running": rc is None, "returncode": rc,
                "started": self.started, "command": self.command, "logs": list(self.logs)}

    def stop(self) -> bool:
        if self.proc.poll() is not None:
            return False
        os.killpg(self.proc.pid, signal.SIGINT)
        self.logs.append("[studio] Stop requested (SIGINT). Existing checkpoints are preserved.")
        return True


class Studio:
    def __init__(self, args):
        self.args, self.jobs = args, {}
        self.lock = threading.Lock()

    def safe(self, raw: str) -> Path:
        p = Path(raw).expanduser().resolve()
        if not any(p == root or root in p.parents for root in self.args.allow_roots):
            raise PermissionError(f"{p} is outside allowed paths")
        return p

    def state(self) -> dict[str, Any]:
        datasets = []
        for root in self.args.dataset_roots:
            for p in scan(root, is_dataset):
                try: datasets.append(dataset_info(p))
                except Exception: pass
        checkpoints = []
        for p in scan(self.args.output_root, is_checkpoint, 5):
            m = re.search(r"checkpoint-(\\d+)$", p.name)
            checkpoints.append({"path": str(p), "name": str(p.relative_to(self.args.output_root)),
                                "step": int(m.group(1)) if m else None})
        return {"datasets": datasets, "checkpoints": checkpoints,
                "jobs": {key: job.public() for key, job in self.jobs.items()},
                "defaults": {"dataset_root": str(self.args.dataset_roots[0]), "output_root": str(self.args.output_root),
                             "base_model": "nvidia/GR00T-N1.6-3B", "modality_config": str(DAKSHA_CONFIG)}}

    def start_training(self, b: dict) -> Process:
        with self.lock:
            old = self.jobs.get("training")
            if old and old.proc.poll() is None: raise RuntimeError("A training job is already running")
            ds = self.safe(b["dataset"])
            if not is_dataset(ds): raise ValueError("Selected folder is not a LeRobot dataset (meta/info.json missing)")
            output = self.safe(b["output_dir"])
            if output == REPO_ROOT or output == self.args.output_root: raise ValueError("Choose a subfolder inside outputs")
            base = str(b.get("base_model") or "nvidia/GR00T-N1.6-3B")
            if base.startswith("/"):
                base_path = self.safe(base)
                if not is_checkpoint(base_path): raise ValueError("Local base model must be a valid GR00T checkpoint")
                base = str(base_path)
            def number(key, default, cast=float):
                try: return cast(b.get(key, default))
                except (TypeError, ValueError): raise ValueError(f"{key} must be a number")
            chunk, lr = number("chunk", 8, int), number("learning_rate", 1e-4)
            steps, batch = number("max_steps", 50000, int), number("batch_size", 8, int)
            save_steps, keep = number("save_steps", 1000, int), number("keep_checkpoints", 3, int)
            workers, gpus = number("workers", 4, int), number("gpus", 1, int)
            if not (1 <= chunk <= 40 and lr > 0 and steps > 0 and batch > 0 and save_steps > 0 and keep > 0 and workers >= 0 and gpus > 0):
                raise ValueError("Use positive values (chunk 1–40; workers may be 0)")
            cmd = [sys.executable, "-m", "gr00t.experiment.launch_finetune", "--base-model-path", base,
                   "--dataset-path", str(ds), "--modality-config-path", str(DAKSHA_CONFIG),
                   "--embodiment-tag", "DAKSHA", "--action-chunk-size", str(chunk), "--learning-rate", str(lr),
                   "--max-steps", str(steps), "--global-batch-size", str(batch), "--dataloader-num-workers", str(workers),
                   "--num-gpus", str(gpus), "--output-dir", str(output), "--save-steps", str(save_steps),
                   "--save-total-limit", str(keep)]
            if not b.get("tune_diffusion", True): cmd.append("--no-tune-diffusion-model")
            if b.get("tune_visual", False): cmd.append("--tune-visual")
            env = {"CUDA_VISIBLE_DEVICES": str(b.get("cuda_devices") or "0"), "PYTHONUNBUFFERED": "1"}
            self.jobs["training"] = Process("training", cmd, env)
            return self.jobs["training"]

    def start_server(self, b: dict) -> Process:
        with self.lock:
            old = self.jobs.get("inference")
            if old and old.proc.poll() is None: raise RuntimeError("Inference server is already running")
            model = self.safe(b["model"])
            if not is_checkpoint(model): raise ValueError("Select a complete checkpoint")
            port = int(b.get("port") or 5555)
            self.jobs["inference"] = Process("inference", [sys.executable, "gr00t/eval/run_gr00t_server.py", "--model_path", str(model),
                "--embodiment-tag", "DAKSHA", "--host", str(b.get("host") or "0.0.0.0"), "--port", str(port)], {"PYTHONUNBUFFERED":"1"})
            return self.jobs["inference"]

    def start_eval(self, b: dict) -> Process:
        with self.lock:
            old = self.jobs.get("evaluation")
            if old and old.proc.poll() is None: raise RuntimeError("Evaluation studio is already running")
            ds, model = self.safe(b["dataset"]), self.safe(b["model"])
            if not is_dataset(ds) or not is_checkpoint(model): raise ValueError("Choose a valid dataset and checkpoint")
            port = int(b.get("port") or 8123)
            self.jobs["evaluation"] = Process("evaluation", [sys.executable, str(VALIDATION_APP), "--host", "127.0.0.1", "--port", str(port),
                "--dataset-root", str(ds.parent), "--model-root", str(self.args.output_root), "--allow-root", str(self.args.allow_roots[0]),
                "--dataset-path", str(ds), "--model-path", str(model), "--embodiment-tag", "daksha", "--action-horizon", str(b.get("chunk") or 8)])
            return self.jobs["evaluation"]

    def start_bridge(self, b: dict) -> Process:
        if b.get("confirm") != "START ROBOT": raise ValueError("Type START ROBOT to enable the ROS2 bridge")
        with self.lock:
            old = self.jobs.get("bridge")
            if old and old.proc.poll() is None: raise RuntimeError("ROS2 bridge is already running")
            host, port = str(b.get("policy_host") or "127.0.0.1"), str(int(b.get("policy_port") or 5555))
            chunk = str(int(b.get("chunk") or 8))
            env = {"POLICY_HOST":host, "POLICY_PORT":port, "ACTION_HORIZON":chunk, "REPO_ROOT":str(REPO_ROOT), "PYTHONUNBUFFERED":"1"}
            self.jobs["bridge"] = Process("bridge", ["bash", "examples/Daksha/run_system_b_daksha_ros2.sh"], env)
            return self.jobs["bridge"]


HTML = r'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Daksha · GR00T Studio</title><style>
:root{--bg:#09111d;--panel:#101c2e;--line:#263b58;--txt:#eef4ff;--muted:#93a8c7;--blue:#66a9ff;--good:#66e3ad;--warn:#ffca6b;--red:#ff8491}*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 85% -10%,#1c416c,transparent 38%),var(--bg);color:var(--txt);font:14px system-ui,sans-serif}.wrap{max-width:1360px;margin:auto;padding:28px 18px 80px}h1{font-size:28px;margin:0}h2{font-size:16px;margin:0 0 14px}.sub{color:var(--muted);margin:8px 0 22px;line-height:1.5}.grid{display:grid;grid-template-columns:repeat(12,1fr);gap:16px}.card{grid-column:span 6;background:rgba(16,28,46,.92);border:1px solid var(--line);border-radius:14px;padding:18px}.full{grid-column:1/-1}.hint{font-size:12px;color:var(--muted);margin:-6px 0 14px;line-height:1.5}.row{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:11px}label{display:block;font-size:12px;color:var(--muted);margin:0 0 5px}input,select{width:100%;background:#091525;border:1px solid #304968;color:var(--txt);border-radius:7px;padding:9px}input:focus,select:focus{outline:2px solid var(--blue);border-color:transparent}button{background:var(--blue);color:#071323;border:0;border-radius:7px;padding:10px 14px;font-weight:750;cursor:pointer;margin:14px 8px 0 0}button.secondary{background:#20334d;color:var(--txt)}button.stop{background:var(--red)}.status{padding:10px;border-radius:7px;background:#0b1727;color:var(--muted);font-size:12px;white-space:pre-wrap;max-height:230px;overflow:auto}.pill{display:inline-block;border:1px solid var(--line);padding:3px 7px;border-radius:99px;font-size:11px;color:var(--muted);margin:0 5px 5px 0}.ready{color:var(--good)}.danger{border-color:#73404b;background:linear-gradient(135deg,#251722,#101c2e)}.danger h2{color:var(--warn)}.check{display:flex;gap:7px;align-items:center;color:var(--muted);font-size:12px;margin-top:10px}.check input{width:auto}@media(max-width:800px){.card{grid-column:1/-1}.row{grid-template-columns:1fr}}
</style></head><body><main class="wrap"><h1>Daksha / GR00T Training Studio</h1><div class="sub">A guided local control panel for 16-DoF Daksha training, checkpoint management, offline evaluation, and real-robot deployment. Dataset root: <code>/home/s1/Desktop/datasets</code>.</div><div class="grid">
<section class="card full"><h2>1. Dataset</h2><div class="hint">Select a LeRobot dataset. The green badge means it has <code>meta/info.json</code>, <code>meta/modality.json</code>, and a 16-value action vector compatible with the supplied Daksha configuration.</div><select id="dataset"></select><button class="secondary" onclick="loadState()">Rescan folders</button><div id="datasetInfo" class="hint"></div></section>
<section class="card"><h2>2. Train or resume</h2><div class="hint">Choose an output folder. Starting again with the same folder resumes from its newest checkpoint automatically. Checkpoints are saved at the selected interval.</div><div class="row"><div><label>Base model / checkpoint</label><input id="base" value="nvidia/GR00T-N1.6-3B"></div><div><label>Output folder</label><input id="output" value="/home/s1/.ihub/vla/groot/Isaac-GR00T-n1.6.1/outputs/daksha_run"></div><div><label>Learning rate</label><input id="lr" type="number" step="any" value="0.0001"></div><div><label>Action chunk (steps)</label><input id="chunk" type="number" min="1" max="40" value="8"></div><div><label>Max training steps</label><input id="steps" type="number" value="50000"></div><div><label>Global batch size</label><input id="batch" type="number" value="8"></div><div><label>Save every steps</label><input id="save" type="number" value="1000"></div><div><label>Checkpoints to keep</label><input id="keep" type="number" value="3"></div><div><label>GPU ids</label><input id="cuda" value="0"></div><div><label>Data workers</label><input id="workers" type="number" value="4"></div></div><label class="check"><input id="diffusion" type="checkbox" checked> Fine-tune diffusion action decoder</label><label class="check"><input id="visual" type="checkbox"> Fine-tune visual encoder (uses more VRAM)</label><button onclick="train()">Start / resume training</button><button class="stop" onclick="stop('training')">Stop training</button></section>
<section class="card"><h2>Live training log</h2><div class="hint">Stopping sends SIGINT. Already written checkpoints remain; use the same output folder to resume.</div><div id="training" class="status">No training job.</div></section>
<section class="card"><h2>3. Checkpoint → inference server (System A)</h2><div class="hint">Loads the selected checkpoint and serves it to the ROS2 bridge. The Daksha embodiment tag is fixed to <code>DAKSHA</code>.</div><label>Checkpoint</label><select id="model"></select><div class="row"><div><label>Host</label><input id="host" value="0.0.0.0"></div><div><label>Port</label><input id="serverPort" value="5555"></div></div><button onclick="server()">Start System A</button><button class="stop" onclick="stop('inference')">Stop System A</button><div id="inference" class="status">No inference server.</div></section>
<section class="card"><h2>4. Offline evaluation</h2><div class="hint">Opens the existing Daksha validation studio on recorded episodes. It evaluates model predictions against dataset actions; it does not command the robot.</div><div class="row"><div><label>Validation port</label><input id="evalPort" value="8123"></div><div><label>Action horizon</label><input id="evalChunk" value="8"></div></div><button onclick="evaluate()">Start evaluation studio</button><button class="stop" onclick="stop('evaluation')">Stop evaluation</button><div id="evaluation" class="status">No evaluation studio.</div></section>
<section class="card full danger"><h2>5. Real robot bridge (System B)</h2><div class="hint">This starts the existing <code>examples/Daksha/run_system_b_daksha_ros2.sh</code>, which can publish joint commands. Verify your robot, topic wiring, action horizon, limits, and emergency stop first. The current bridge is the 3-camera Daksha-style bridge; it is not a drop-in bridge for a four-camera Daksha B1 dataset.</div><div class="row"><div><label>System A host</label><input id="policyHost" value="127.0.0.1"></div><div><label>System A port</label><input id="policyPort" value="5555"></div><div><label>Action horizon (must match checkpoint)</label><input id="bridgeChunk" value="8"></div><div><label>Confirmation</label><input id="confirm" placeholder="Type START ROBOT"></div></div><button onclick="bridge()">Start System B bridge</button><button class="stop" onclick="stop('bridge')">Stop bridge</button><div id="bridge" class="status">No bridge process.</div></section>
</div></main><script>
let state={};const $=id=>document.getElementById(id);const value=id=>$(id).value;async function api(path,body){let r=await fetch(path,{method:body?'POST':'GET',headers:{'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined});let d=await r.json();if(!r.ok)throw Error(d.error||'Request failed');return d}function options(select,items,placeholder){select.innerHTML='';if(!items.length){select.innerHTML='<option>No items found</option>';return}items.forEach(x=>{let o=document.createElement('option');o.value=x.path;o.textContent=x.name||x.path;select.append(o)})}function showJob(id,j){$(id).textContent=!j?'No process.':`${j.running?'● Running':'● Finished'} ${j.returncode??''}\n$ ${j.command.join(' ')}\n\n${j.logs.join('\n')}`}
async function loadState(){try{state=await api('/api/state');options($('dataset'),state.datasets,'No datasets');options($('model'),state.checkpoints,'No checkpoints');$('datasetInfo').textContent=state.datasets.map(d=>`${d.ready?'●':'!'} ${d.name}: ${d.episodes} episodes · ${d.frames} frames · ${d.action_dim} action values · ${d.reason}`).join('\n');for(let id of ['training','inference','evaluation','bridge'])showJob(id,state.jobs[id]);}catch(e){alert(e.message)}}async function train(){try{await api('/api/train',{dataset:value('dataset'),base_model:value('base'),output_dir:value('output'),learning_rate:value('lr'),chunk:value('chunk'),max_steps:value('steps'),batch_size:value('batch'),save_steps:value('save'),keep_checkpoints:value('keep'),cuda_devices:value('cuda'),workers:value('workers'),tune_diffusion:$('diffusion').checked,tune_visual:$('visual').checked});loadState()}catch(e){alert(e.message)}}async function server(){try{await api('/api/server',{model:value('model'),host:value('host'),port:value('serverPort')});loadState()}catch(e){alert(e.message)}}async function evaluate(){try{await api('/api/evaluate',{dataset:value('dataset'),model:value('model'),port:value('evalPort'),chunk:value('evalChunk')});window.open(`http://127.0.0.1:${value('evalPort')}`,'_blank');loadState()}catch(e){alert(e.message)}}async function bridge(){try{await api('/api/bridge',{policy_host:value('policyHost'),policy_port:value('policyPort'),chunk:value('bridgeChunk'),confirm:value('confirm')});loadState()}catch(e){alert(e.message)}}async function stop(name){try{await api('/api/stop',{name});loadState()}catch(e){alert(e.message)}}loadState();setInterval(loadState,2500);
</script></body></html>'''


def handler(studio: Studio):
    class H(BaseHTTPRequestHandler):
        def reply(self, code, payload, kind="application/json"):
            raw = json.dumps(payload).encode() if kind == "application/json" else payload
            self.send_response(code); self.send_header("Content-Type", kind+"; charset=utf-8"); self.send_header("Content-Length", str(len(raw))); self.end_headers(); self.wfile.write(raw)
        def do_GET(self):
            if urllib.parse.urlparse(self.path).path == "/": self.reply(200, HTML.encode(), "text/html")
            elif urllib.parse.urlparse(self.path).path == "/api/state": self.reply(200, studio.state())
            else: self.reply(404,{"error":"not found"})
        def do_POST(self):
            try:
                n=int(self.headers.get("Content-Length","0")); body=json.loads(self.rfile.read(n) or b"{}")
                route=urllib.parse.urlparse(self.path).path
                if route=="/api/train": result=studio.start_training(body).public()
                elif route=="/api/server": result=studio.start_server(body).public()
                elif route=="/api/evaluate": result=studio.start_eval(body).public()
                elif route=="/api/bridge": result=studio.start_bridge(body).public()
                elif route=="/api/stop": result={"stopped":studio.jobs.get(body.get("name")).stop() if studio.jobs.get(body.get("name")) else False}
                else: raise ValueError("not found")
                self.reply(200,result)
            except (ValueError, PermissionError, RuntimeError, KeyError) as e: self.reply(400,{"error":str(e)})
            except Exception as e: self.reply(500,{"error":f"{type(e).__name__}: {e}"})
        def log_message(self,*_): pass
    return H


def main():
    p=argparse.ArgumentParser(description="Daksha GR00T Training Studio")
    p.add_argument("--host",default=os.environ.get("HOST","127.0.0.1"));p.add_argument("--port",type=int,default=int(os.environ.get("PORT","8130")))
    p.add_argument("--dataset-root",action="append",default=None);p.add_argument("--output-root",default=str(REPO_ROOT/"outputs"));p.add_argument("--allow-root",action="append",default=None)
    a=p.parse_args();a.dataset_roots=[Path(x).expanduser().resolve() for x in (a.dataset_root or [str(DEFAULT_DATASET_ROOT)])];a.output_root=Path(a.output_root).expanduser().resolve();a.allow_roots=[Path(x).expanduser().resolve() for x in (a.allow_root or [str(Path.home()),str(REPO_ROOT)])]
    print(f"Daksha Training Studio: http://{a.host}:{a.port}",flush=True);ThreadingHTTPServer((a.host,a.port),handler(Studio(a))).serve_forever()
if __name__=="__main__": main()
