#!/usr/bin/env bash
# Local browser UI for Daksha GR00T training and checkpoint deployment.
set -euo pipefail

REPO_ROOT="${REPO_ROOT:-/home/s1/.ihub/vla/groot/Isaac-GR00T-n1.6.1}"
cd "$REPO_ROOT"
source .venv/bin/activate

HOST="${HOST:-127.0.0.1}"
PORT="${PORT:-8130}"
DATASET_ROOT="${DATASET_ROOT:-/home/s1/Desktop/datasets}"
OUTPUT_ROOT="${OUTPUT_ROOT:-$REPO_ROOT/outputs}"

exec python gr00t/eval/real_robot/Daksha/ui/training_studio.py \
  --host "$HOST" --port "$PORT" --dataset-root "$DATASET_ROOT" \
  --output-root "$OUTPUT_ROOT" --allow-root /home/s1 --allow-root "$REPO_ROOT"
