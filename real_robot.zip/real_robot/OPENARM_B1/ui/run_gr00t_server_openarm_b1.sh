#!/usr/bin/env bash
# System A (GPU box): serve the openarm_b1 / pick_box_2_8chunk checkpoint.
#
#   bash gr00t/eval/real_robot/OPENARM_B1/ui/run_gr00t_server_openarm_b1.sh
#   MODEL_PATH=.../checkpoint-50000 bash .../run_gr00t_server_openarm_b1.sh
#
# The embodiment tag must be the one the checkpoint was trained with. `openarm_b1`
# maps to projector id 10 (the new_embodiment slot) -- see the checkpoint's own
# embodiment_id.json, which the processor loads and honours.
#
# No --modality-config-path is needed: Gr00tPolicy reads the modality config out of
# the checkpoint's processor_config.json, keyed by the embodiment tag.
set -euo pipefail

REPO_ROOT="${REPO_ROOT:-/home/physicalai/Desktop/I/groot}"
cd "$REPO_ROOT"
source .venv/bin/activate

# The run keeps only the 2 newest checkpoints (save_total_limit=2) and writes a new
# one every 1000 steps, so a hardcoded checkpoint number goes stale within minutes.
# Default to the highest-numbered one that currently exists; override MODEL_PATH to
# pin a specific checkpoint.
RUN_DIR="${RUN_DIR:-/home/physicalai/Desktop/I/groot/outputs/pick_box_2_8chunk}"
latest_checkpoint() {
  ls -d "$RUN_DIR"/checkpoint-* 2>/dev/null | sed 's/.*checkpoint-//' | sort -n | tail -1
}
if [ -z "${MODEL_PATH:-}" ]; then
  _step="$(latest_checkpoint)"
  [ -n "$_step" ] || { echo "no checkpoint-* under $RUN_DIR — set MODEL_PATH" >&2; exit 1; }
  MODEL_PATH="$RUN_DIR/checkpoint-$_step"
  echo "[openarm_b1] using newest checkpoint: $MODEL_PATH"
fi
EMBODIMENT_TAG="${EMBODIMENT_TAG:-OPENARM_B1}"
HOST="${HOST:-0.0.0.0}"
PORT="${PORT:-5555}"

python gr00t/eval/run_gr00t_server.py \
  --model_path "$MODEL_PATH" \
  --embodiment-tag "$EMBODIMENT_TAG" \
  --host "$HOST" \
  --port "$PORT"
