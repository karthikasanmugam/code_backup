#!/usr/bin/env bash
set -euo pipefail

cd ~/Desktop/I/grootn1.7/Isaac-GR00T
source .venv/bin/activate

# Resuming is automatic: the trainer picks up the last checkpoint in the same
# output directory and restores optimizer/scheduler state.
CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}" python -m gr00t.experiment.launch_finetune \
  --base-model-path "${BASE_MODEL_PATH:-nvidia/GR00T-N1.7-3B}" \
  --dataset-path "${DATASET_PATH:-/home/physicalai/Desktop/I/Muliti_dataset_storage/custom_arm_task1}" \
  --modality-config-path "${MODALITY_CONFIG_PATH:-examples/daksha_b1/daksha_b1_config.py}" \
  --embodiment-tag "${EMBODIMENT_TAG:-DAKSHA_B1}" \
  --num-gpus "${NUM_GPUS:-1}" \
  --output-dir "${OUTPUT_DIR:-./outputs/daksha_b1_custom_arm_task1_ft}" \
  --save-total-limit "${SAVE_TOTAL_LIMIT:-2}" \
  --save-steps "${SAVE_STEPS:-1000}" \
  --max-steps "${MAX_STEPS:-100000}" \
  --global-batch-size "${GLOBAL_BATCH_SIZE:-32}" \
  --dataloader-num-workers "${DATALOADER_NUM_WORKERS:-8}"
