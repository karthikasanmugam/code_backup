# Daksha B1 Finetuning

This folder is a standalone embodiment setup for your 16-DoF, 4-camera dataset.
It mirrors the OpenArm-style structure but uses a dedicated `DAKSHA_B1` tag so
the example stays isolated from the reference folders.

## Tag flow

- `EmbodimentTag.DAKSHA_B1` is defined in `gr00t/data/embodiment_tags.py`
- `daksha_b1_config.py` registers the modality config under that tag
- `modality.json` maps the dataset metadata to GR00T's `state`, `action`,
  `video`, and language fields

## Dataset layout

Expected dataset keys from your metadata:

- `action`: 16 values
- `observation.state`: 16 values
- `observation.leader_state`: 16 values
- split as:
  - `right_arm`: 7 values
  - `right_gripper`: 1 value
  - `left_arm`: 7 values
  - `left_gripper`: 1 value
- cameras:
  - `observation.images.zed_right`
  - `observation.images.zed_left`
  - `observation.images.right_wrist`
  - `observation.images.left_wrist`
- language: `task_index` in `meta/modality.json`

If your dataset root does not yet contain the modality file, copy it in:

```bash
cp examples/daksha_b1/modality.json /path/to/local/bluebox_pick_place/meta/modality.json
```

## Finetuning

Run this directly in a terminal:

```bash
cd ~/Desktop/I/grootn1.7/Isaac-GR00T
source .venv/bin/activate

CUDA_VISIBLE_DEVICES=0 python -m gr00t.experiment.launch_finetune \
  --base-model-path nvidia/GR00T-N1.7-3B \
  --dataset-path /path/to/local/bluebox_pick_place \
  --modality-config-path examples/daksha_b1/daksha_b1_config.py \
  --embodiment-tag DAKSHA_B1 \
  --num-gpus 1 \
  --output-dir ./outputs/daksha_b1_pick_place_ft \
  --save-total-limit 2 \
  --save-steps 1000 \
  --max-steps 50000 \
  --global-batch-size 32 \
  --dataloader-num-workers 8
```

Or call the shared launcher directly:

```bash
CUDA_VISIBLE_DEVICES=0 NUM_GPUS=1 uv run bash examples/finetune.sh \
  --base-model-path nvidia/GR00T-N1.7-3B \
  --dataset-path /path/to/local/bluebox_pick_place \
  --modality-config-path examples/daksha_b1/daksha_b1_config.py \
  --embodiment-tag DAKSHA_B1 \
  --output-dir /tmp/daksha_b1_finetune
```

## Resume Training

Resuming is automatic from the last checkpoint in the same `output_dir`:

```bash
cd ~/Desktop/I/grootn1.7/Isaac-GR00T
source .venv/bin/activate

CUDA_VISIBLE_DEVICES=0 python -m gr00t.experiment.launch_finetune \
  --base-model-path nvidia/GR00T-N1.7-3B \
  --dataset-path /path/to/local/bluebox_pick_place \
  --modality-config-path examples/daksha_b1/daksha_b1_config.py \
  --embodiment-tag DAKSHA_B1 \
  --num-gpus 1 \
  --output-dir ./outputs/daksha_b1_pick_place_ft \
  --save-total-limit 2 \
  --save-steps 1000 \
  --max-steps 100000 \
  --global-batch-size 32 \
  --dataloader-num-workers 8
```

## SOP

1. Copy [examples/daksha_b1/modality.json](/home/physicalai/Desktop/I/grootn1.7/Isaac-GR00T/examples/daksha_b1/modality.json) into your dataset `meta/` folder.
2. Run the training command above.
3. If training stops in the middle, run the resume command above.
4. Start System A with:

```bash
cd ~/Desktop/I/grootn1.7/Isaac-GR00T
source .venv/bin/activate

python gr00t/eval/run_gr00t_server.py \
  --model_path /home/physicalai/Desktop/I/grootn1.7/Isaac-GR00T/outputs/daksha_b1_pick_place_ft/checkpoint-50000 \
  --embodiment-tag DAKSHA_B1 \
  --host 0.0.0.0 \
  --port 5555
```

5. Start System B with:

```bash
cd ~/Desktop/I/grootn1.7/Isaac-GR00T
source .venv/bin/activate

python gr00t/eval/real_robot/daksha_b1/eval_daksha_b1_ros2.py \
  --policy-host <SYSTEM_A_IP> \
  --policy-port 5555 \
  --control-hz 10 \
  --joint-state-topic /joint_states_ordered \
  --cmd-topic /leader_joint_states_ordered \
  --zed-right-topic /zed/zed_node/right/color/raw/image \
  --zed-left-topic /zed/zed_node/left/color/raw/image \
  --right-wrist-topic /right_arm/right/color/image_raw \
  --left-wrist-topic /left_arm/left/color/image_raw \
  --lang-instruction "Pick up the object and place it in the target."
```

## Open-loop evaluation

```bash
uv run python gr00t/eval/open_loop_eval.py \
  --dataset-path /path/to/local/bluebox_pick_place \
  --embodiment-tag DAKSHA_B1 \
  --model-path /tmp/daksha_b1_finetune/checkpoint-10000 \
  --traj-ids 0 \
  --action-horizon 16 \
  --steps 400
```

## Closed-loop evaluation

Use the real-robot scaffold in `gr00t/eval/real_robot/daksha_b1/` and run the
policy server with the same tag:

```bash
python gr00t/eval/run_gr00t_server.py \
  --model_path /tmp/daksha_b1_finetune/checkpoint-10000 \
  --embodiment-tag DAKSHA_B1 \
  --host 0.0.0.0 \
  --port 5555
```
