# # #!/usr/bin/env bash
# # set -euo pipefail

# # cd ~/Desktop/I/grootn1.7/Isaac-GR00T
# # source .venv/bin/activate

# # python gr00t/eval/real_robot/daksha_b1/eval_daksha_b1_ros2.py \
# #   --policy-host "${POLICY_HOST:-127.0.0.1}" \
# #   --policy-port "${POLICY_PORT:-5555}" \
# #   --control-hz "${CONTROL_HZ:-10}" \
# #   --joint-state-topic "${JOINT_STATE_TOPIC:-/joint_states_ordered}" \
# #   --cmd-topic "${CMD_TOPIC:-/leader_joint_states_ordered}" \
# #   --zed-right-topic "${ZED_RIGHT_TOPIC:-/zed/zed_node/right/color/raw/image}" \
# #   --zed-left-topic "${ZED_LEFT_TOPIC:-/zed/zed_node/left/color/raw/image}" \
# #   --right-wrist-topic "${RIGHT_WRIST_TOPIC:-/right_arm/right/color/image_raw}" \
# #   --left-wrist-topic "${LEFT_WRIST_TOPIC:-/left_arm/left/color/image_raw}" \
# #   --lang-instruction "${LANG_INSTRUCTION:-Pick up the object and place it in the target.}"







# #!/usr/bin/env bash
# set -euo pipefail

# SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
# cd "$REPO_ROOT"
# source .venv/bin/activate

# python gr00t/eval/real_robot/daksha_b1/eval_daksha_b1_ros2.py \
#   --policy-host "${POLICY_HOST:-192.168.200.208}" \
#   --policy-port "${POLICY_PORT:-5555}" \
#   --control-hz "${CONTROL_HZ:-40}" \
#   --joint-state-topic "${JOINT_STATE_TOPIC:-/joint_states}" \
#   --right-joint-state-topic "${RIGHT_JOINT_STATE_TOPIC:-/RightArmSystem_ordered_joint_states}" \
#   --left-joint-state-topic "${LEFT_JOINT_STATE_TOPIC:-/LeftArmSystem_ordered_joint_states}" \
#   --cmd-topic "${CMD_TOPIC:-/joint_cmd}" \
#   --zed-right-topic "${ZED_RIGHT_TOPIC:-/zed/zed_node/right/color/raw/image/compressed}" \
#   --zed-left-topic "${ZED_LEFT_TOPIC:-/zed/zed_node/left/color/raw/image/compressed}" \
#   --right-wrist-topic "${RIGHT_WRIST_TOPIC:-/right_arm/right/color/image_raw/compressed}" \
#   --left-wrist-topic "${LEFT_WRIST_TOPIC:-/left_arm/left/color/image_raw/compressed}" \
#   --image-transport "${IMAGE_TRANSPORT:-compressed}" \
#   --state-obs-keys-csv "${STATE_OBS_KEYS_CSV:-left_joint_1,left_joint_2,left_joint_3,left_joint_4,left_joint_5,left_joint_6,left_joint_7,left_gripper_left_joint,right_joint_1,right_joint_2,right_joint_3,right_joint_4,right_joint_5,right_joint_6,right_joint_7,right_gripper_right_joint}" \
#   --action-keys-csv "${ACTION_KEYS_CSV:-left_joint_1,left_joint_2,left_joint_3,left_joint_4,left_joint_5,left_joint_6,left_joint_7,left_gripper_left_joint,right_joint_1,right_joint_2,right_joint_3,right_joint_4,right_joint_5,right_joint_6,right_joint_7,right_gripper_right_joint}" \
#   --lang-instruction "${LANG_INSTRUCTION:-Pick up the object and place it in the target.}"


#!/usr/bin/env bash
set -euo pipefail

cd ~/Desktop/I/grootn1.7/Isaac-GR00T
source .venv/bin/activate

# The robot's arm/camera nodes live on ROS_DOMAIN_ID=33. Pin it here instead of
# inheriting it: the VS Code server environment exports 35, so a bridge launched from
# a non-interactive shell (task, debug launch, nested shell) lands on an empty DDS
# graph and sits forever in "Waiting for inputs -> waiting on right=..., left=..." even
# though `ros2 topic echo` works fine in your own terminal. ~/.bashrc also no longer
# sources ROS, so source it here for the same reason.
export ROS_DOMAIN_ID=33
export RMW_IMPLEMENTATION="${RMW_IMPLEMENTATION:-rmw_cyclonedds_cpp}"
if [ -z "${AMENT_PREFIX_PATH:-}" ]; then
  set +u  # ROS setup.bash trips over unbound vars
  source /opt/ros/humble/setup.bash
  set -u
fi

# System B: ROS2 bridge (publishes JointState on /joint_cmd)
#
# ---------------------------------------------------------------------------
# THE ONE SOURCE OF TRUTH FOR EVERYTHING BELOW
#   dataset     /home/physicalai/Desktop/I/barani/pick_place_blue
#               134 episodes, 53 600 frames, 30 fps, one task
#   checkpoint  output/pick_place_blue/checkpoint-70000  (served by System A)
#   embodiment  DAKSHA_B1, 16 DoF, RIGHT-FIRST key order:
#               right_arm x7, right_gripper x1, left_arm x7, left_gripper x1
#
# Verified against the checkpoint's own processor_config.json and statistics.json
# (both at the checkpoint ROOT for this run, not under processor/). The checkpoint's
# action min/max match the 134-episode dataset exactly on all 16 dims. If you retrain,
# re-derive from the NEW checkpoint's statistics.json (recipe at the bottom).
# ---------------------------------------------------------------------------

# Safety envelope, right-first, derived from the checkpoint's action statistics
# (statistics.json -> daksha_b1 -> action -> min/max), which are exactly the recorded
# action ranges of pick_place_blue. Padding: arms +/- max(10 % of range, 0.05 rad);
# grippers +/- 0.01 rad.
#
#   WHY THIS MATTERS: the model min-max-denormalizes into precisely those statistics
#   ranges, so a clamp NARROWER than them silently truncates real predictions. The
#   previous envelope here came from pick_place_brown_300, where the left arm only ever
#   held a pose. Against THIS checkpoint it covered just 18 % of left_joint_4's trained
#   range, 30 % of left_joint_7, 41 % of left_joint_1 and 43 % of the left gripper,
#   while every right-side channel was untouched -- which reads at the robot as "the
#   policy is not moving the left arm".
#
#   RETRAINED? Re-derive from the new checkpoint before running. Limits from another
#   dataset can be disjoint from this one's poses.
JOINT_MIN_CSV="${JOINT_MIN_CSV:--1.2658,-0.5203,-0.4329,0.2125,1.0601,-0.2356,-1.7039,-0.0100,-1.3913,-0.3625,-0.4585,-1.8175,-1.6708,-0.5165,-1.7161,-0.0540}"
JOINT_MAX_CSV="${JOINT_MAX_CSV:-1.4806,0.3117,0.5096,1.7863,1.8866,0.3184,1.7346,0.0540,1.3146,0.3241,0.4232,-0.2197,-0.9492,0.3247,1.8311,0.0100}"
# Per control STEP at --control-hz 30 (the dataset fps). 1.5x the per-joint p99.9 of the
# recorded frame-to-frame action delta over pick_place_blue's 134 episodes (53 466
# steps), floored at 0.02. Scale by (30/control_hz) if you change the rate. Grippers
# exceed their full travel so a grasp is never throttled.
#
# BOTH arms move in this task, so the left arm no longer keeps brown's flat 0.02:
# left_joint_1 demonstrates 0.065 rad/frame at p99.9 and left_joint_7 0.102, which 0.02
# would throttle to a third and a fifth of the speed the task needs.
MAX_STEP_DELTA_CSV="${MAX_STEP_DELTA_CSV:-0.113,0.058,0.069,0.087,0.050,0.020,0.159,0.060,0.098,0.025,0.055,0.060,0.048,0.028,0.153,0.060}"

# Must match meta/tasks.jsonl verbatim. pick_place_blue has exactly one task; feeding a
# different sentence is an unnecessary distribution shift on the language input.
# NOTE: capital P and a TRAILING PERIOD are part of this string -- do not drop them, and
# do not pass the old pick_place_brown sentence from your shell; an override wins here.
LANG_INSTRUCTION="${LANG_INSTRUCTION:-Pick the blue box from the table.}"

# Replanning is DISABLED (no --replan-at flag, bridge default 0): each 16-step chunk
# is executed to completion, then the next one is predicted. This is plain open-loop
# chunk playback -- the "normal prediction" behaviour.
#
# What that costs, so the trade-off is on the record: the arm publishes hold for the
# duration of every policy round trip, because the queue is empty while inference runs.
# At ~172 ms inference and 30 Hz that is ~5 ticks of stationary arm between chunks, so
# motion arrives in bursts of 16 steps separated by a short pause. Chunk boundaries are
# clean, though: each chunk is re-anchored to the pose measured at its own plan time.
#
# If the pauses ever become a problem, add --replan-at N to overlap inference with the
# tail of the current chunk, sized as ceil(measured_inference_s * CONTROL_HZ) -- read
# the measurement off the "inference N ms" log line. Note that replanning discards the
# unexecuted tail of the chunk, and because this checkpoint predicts the arms as
# RELATIVE actions the displacement accumulates toward the END of the chunk, so an
# oversized N throws away most of the motion.

# The three CSV flags use --flag=value, not --flag value: JOINT_MIN_CSV starts with a
# minus sign and argparse would otherwise read it as an option name, not a value.
python gr00t/eval/real_robot/daksha_b1/eval_daksha_b1_ros2.py \
  --joint-min-csv="${JOINT_MIN_CSV}" \
  --joint-max-csv="${JOINT_MAX_CSV}" \
  --max-step-delta-csv="${MAX_STEP_DELTA_CSV}" \
  --policy-host "${POLICY_HOST:-127.0.0.1}" \
  --policy-port "${POLICY_PORT:-5555}" \
  --control-hz "${CONTROL_HZ:-30}" \
  --action-horizon "${ACTION_HORIZON:-16}" \
  --image-max-edge "${IMAGE_MAX_EDGE:-256}" \
  --joint-state-topic "${JOINT_STATE_TOPIC:-/joint_states}" \
  --right-joint-state-topic "${RIGHT_JOINT_STATE_TOPIC:-/RightArmSystem_ordered_joint_states}" \
  --left-joint-state-topic "${LEFT_JOINT_STATE_TOPIC:-/LeftArmSystem_ordered_joint_states}" \
  --cmd-topic "${CMD_TOPIC:-/joint_cmd_pri}" \
  --zed-right-topic "${ZED_RIGHT_TOPIC:-/zed/zed_node/right/color/rect/image/compressed}" \
  --zed-left-topic "${ZED_LEFT_TOPIC:-/zed/zed_node/left/color/rect/image/compressed}" \
  --right-wrist-topic "${RIGHT_WRIST_TOPIC:-/right/camera/color/image_raw/compressed}" \
  --left-wrist-topic "${LEFT_WRIST_TOPIC:-/left/camera/color/image_raw/compressed}" \
  --right-wrist-camera-key "wrist_right" \
  --left-wrist-camera-key "wrist_left" \
  --image-transport "${IMAGE_TRANSPORT:-compressed}" \
  --state-obs-keys-csv "${STATE_OBS_KEYS_CSV:-right_joint_1,right_joint_2,right_joint_3,right_joint_4,right_joint_5,right_joint_6,right_joint_7,right_gripper_right_joint,left_joint_1,left_joint_2,left_joint_3,left_joint_4,left_joint_5,left_joint_6,left_joint_7,left_gripper_left_joint}" \
  --action-keys-csv "${ACTION_KEYS_CSV:-right_joint_1,right_joint_2,right_joint_3,right_joint_4,right_joint_5,right_joint_6,right_joint_7,right_gripper_right_joint,left_joint_1,left_joint_2,left_joint_3,left_joint_4,left_joint_5,left_joint_6,left_joint_7,left_gripper_left_joint}" \
  --lang-instruction "${LANG_INSTRUCTION}"