#!/usr/bin/env bash
# Offline validation: does the model (new_3 checkpoint) reproduce the recorded
# task_5 dataset actions? Produces a per-joint graph + an HTML UI. No robot.
#
# Two ways to run:
#
#  A) ONE STEP (simplest) — this script loads the model itself and validates:
#        bash examples/daksha_b1/run_validation_daksha_b1.sh
#
#  B) TWO STEPS — reuse an already-running policy server:
#        # step 1 (terminal 1): launch the model server
#        bash examples/daksha_b1/run_system_a_daksha_b1_server.sh
#        # step 2 (terminal 2): validate against it (set USE_SERVER=1)
#        USE_SERVER=1 bash examples/daksha_b1/run_validation_daksha_b1.sh
#
# Override anything via env vars, e.g.  EPISODES="0 5 10 20"  STEPS=200
set -euo pipefail

cd ~/Desktop/I/grootn1.7/Isaac-GR00T
source .venv/bin/activate

MODEL_PATH="${MODEL_PATH:-output/new_3/checkpoint-50000}"
DATASET_PATH="${DATASET_PATH:-/home/physicalai/Desktop/I/barani/task_5}"
EMBODIMENT_TAG="${EMBODIMENT_TAG:-DAKSHA_B1}"
EPISODES="${EPISODES:-0 1 2 3}"
STEPS="${STEPS:-200}"
ACTION_HORIZON="${ACTION_HORIZON:-16}"
HOST="${HOST:-127.0.0.1}"
PORT="${PORT:-5555}"

SCRIPT="gr00t/eval/real_robot/daksha_b1/validate_prediction_vs_dataset.py"

if [[ "${USE_SERVER:-0}" == "1" ]]; then
  echo "[validation] Using running policy server tcp://${HOST}:${PORT}"
  MODEL_ARG=(--host "${HOST}" --port "${PORT}")
else
  echo "[validation] Loading model directly from ${MODEL_PATH}"
  MODEL_ARG=(--model-path "${MODEL_PATH}")
fi

python "${SCRIPT}" \
  "${MODEL_ARG[@]}" \
  --dataset-path "${DATASET_PATH}" \
  --embodiment-tag "${EMBODIMENT_TAG}" \
  --episodes ${EPISODES} \
  --steps "${STEPS}" \
  --action-horizon "${ACTION_HORIZON}"

REPORT="$(dirname "${DATASET_PATH}")/validation_$(basename "${DATASET_PATH}")/validation_report.html"
echo
echo "[validation] Dashboard UI: ${REPORT}"
# Try to open the UI in a browser (ignore failure on headless machines).
( xdg-open "${REPORT}" >/dev/null 2>&1 & ) || true
