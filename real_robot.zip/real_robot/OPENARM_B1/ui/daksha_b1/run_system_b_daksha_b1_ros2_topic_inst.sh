#!/usr/bin/env bash
set -euo pipefail

cd ~/Desktop/I/grootn1.7/Isaac-GR00T
source .venv/bin/activate

python gr00t/eval/real_robot/daksha_b1/eval_daksha_b1_ros2_topic_inst.py \
  --policy-host "${POLICY_HOST:-127.0.0.1}" \
  --policy-port "${POLICY_PORT:-5555}" \
  --control-hz "${CONTROL_HZ:-10}" \
  --joint-state-topic "${JOINT_STATE_TOPIC:-/joint_states}" \
  --right-joint-state-topic "${RIGHT_JOINT_STATE_TOPIC:-/RightArmSystem_ordered_joint_states}" \
  --left-joint-state-topic "${LEFT_JOINT_STATE_TOPIC:-/LeftArmSystem_ordered_joint_states}" \
  --cmd-topic "${CMD_TOPIC:-/joint_cmd}" \
  --zed-right-topic "${ZED_RIGHT_TOPIC:-/zed/zed_node/right/color/raw/image/compressed}" \
  --zed-left-topic "${ZED_LEFT_TOPIC:-/zed/zed_node/left/color/raw/image/compressed}" \
  --right-wrist-topic "${RIGHT_WRIST_TOPIC:-/right_arm/right/color/image_raw/compressed}" \
  --left-wrist-topic "${LEFT_WRIST_TOPIC:-/left_arm/left/color/image_raw/compressed}" \
  --image-transport "${IMAGE_TRANSPORT:-compressed}" \
  --state-obs-keys-csv "${STATE_OBS_KEYS_CSV:-daksha_right_joint1,daksha_right_joint2,daksha_right_joint3,daksha_right_joint4,daksha_right_joint5,daksha_right_joint6,daksha_right_joint7,daksha_right_finger_joint1,daksha_left_joint1,daksha_left_joint2,daksha_left_joint3,daksha_left_joint4,daksha_left_joint5,daksha_left_joint6,daksha_left_joint7,daksha_left_finger_joint1}" \
  --action-keys-csv "${ACTION_KEYS_CSV:-daksha_right_joint1,daksha_right_joint2,daksha_right_joint3,daksha_right_joint4,daksha_right_joint5,daksha_right_joint6,daksha_right_joint7,daksha_right_finger_joint1,daksha_left_joint1,daksha_left_joint2,daksha_left_joint3,daksha_left_joint4,daksha_left_joint5,daksha_left_joint6,daksha_left_joint7,daksha_left_finger_joint1}" \
  --lang-instruction "${LANG_INSTRUCTION:-Pick up the object and place it in the target.}"