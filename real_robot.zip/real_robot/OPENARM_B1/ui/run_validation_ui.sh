#!/usr/bin/env bash
# OpenArm B1 validation studio — one web app that does the whole loop: pick the
# dataset, pick the checkpoint, pick the episodes, press Run, and read the per-joint
# charts (recorded action vs model prediction) + tables.
#
# It binds every interface by default, so you can open it from another machine:
#   http://<this machine's IP>:8123      (the script prints the exact URLs)
#
#   bash gr00t/eval/real_robot/OPENARM_B1/ui/run_validation_ui.sh
#   PORT=9000 bash .../run_validation_ui.sh
#   TOKEN=mysecret bash .../run_validation_ui.sh     # require ?token=mysecret
#   HOST=127.0.0.1 bash .../run_validation_ui.sh     # this machine only
#   DATASET_ROOT=/data/robot MODEL_ROOT=/data/ckpts bash .../run_validation_ui.sh
#
# Anyone who can reach the port can start a GPU job and read any dataset under
# ALLOW_ROOT, so set TOKEN on a shared network.
#
# Old behaviour (serve a directory of dumps produced earlier by
# validate_prediction_vs_dataset.py, no model loading) is still one flag away:
#   STATIC=1 DATA_DIR=/path/to/validation_dir bash .../run_validation_ui.sh
set -euo pipefail

REPO_ROOT="${REPO_ROOT:-/home/physicalai/Desktop/I/groot}"
cd "$REPO_ROOT"
source .venv/bin/activate

UI_DIR="gr00t/eval/real_robot/OPENARM_B1/ui"

PORT="${PORT:-8123}"
HOST="${HOST:-0.0.0.0}"          # 0.0.0.0 = reachable from the LAN; 127.0.0.1 = local only
TOKEN="${TOKEN:-}"
DATASET_ROOT="${DATASET_ROOT:-$HOME/Desktop}"
MODEL_ROOT="${MODEL_ROOT:-$PWD/outputs}"
ALLOW_ROOT="${ALLOW_ROOT:-$HOME}"
DATASET_PATH="${DATASET_PATH:-/home/physicalai/Desktop/I/barani/pick_box_2}"
# Leave MODEL_PATH empty to just pick the checkpoint in the browser: the studio
# scans MODEL_ROOT and lists every checkpoint it finds, newest last. Set it only
# to preselect one.
MODEL_PATH="${MODEL_PATH:-}"
EMBODIMENT_TAG="${EMBODIMENT_TAG:-openarm_b1}"
STEPS="${STEPS:-200}"
ACTION_HORIZON="${ACTION_HORIZON:-8}"

# Free the port if a previous UI server is still holding it.
fuser -k "${PORT}/tcp" 2>/dev/null || true
sleep 1

if [[ "${STATIC:-0}" == "1" ]]; then
  DATA_DIR="${DATA_DIR:-/home/physicalai/Desktop/I/barani/validation_pick_box}"
  echo "[ui] static mode: serving ${DATA_DIR} at http://localhost:${PORT}"
  ( xdg-open "http://localhost:${PORT}" >/dev/null 2>&1 & ) || true
  exec python "${UI_DIR}/serve_validation_ui.py" \
    --data-dir "${DATA_DIR}" --port "${PORT}" --host "${HOST}"
fi

( sleep 2; xdg-open "http://localhost:${PORT}/${TOKEN:+?token=$TOKEN}" >/dev/null 2>&1 & ) || true

exec python "${UI_DIR}/validation_app.py" \
  --host "${HOST}" --port "${PORT}" \
  ${TOKEN:+--token "${TOKEN}"} \
  --dataset-root "${DATASET_ROOT}" \
  --model-root "${MODEL_ROOT}" \
  --allow-root "${ALLOW_ROOT}" \
  --dataset-path "${DATASET_PATH}" \
  ${MODEL_PATH:+--model-path "${MODEL_PATH}"} \
  --embodiment-tag "${EMBODIMENT_TAG}" \
  --steps "${STEPS}" \
  --action-horizon "${ACTION_HORIZON}"
