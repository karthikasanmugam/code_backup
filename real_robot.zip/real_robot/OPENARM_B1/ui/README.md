# OPENARM_B1 validation UI

Offline, **no-robot** validation for the `openarm_b1` / `pick_box` checkpoint.
Runs the model open-loop over the RECORDED dataset and overlays, per joint:

- `state` — the recorded joint position at each frame
- `gt` — the recorded ACTION the human demonstrated
- `pred` — what the model predicts from the recorded observation

What this validates and what it does **not**: it validates the MODEL (given a
correct observation, does it reproduce the recorded actions?). It does **not**
validate the ROS2 deployment mapping — topic order, left/right routing, clamp
limits. Those live in `../eval_openarm_b1_ros2.py`. A model that looks perfect
here can still move wrongly on the robot, so check both.

## Three ways in

```bash
# 1. Browser studio: pick dataset + checkpoint + episodes, press Run, read charts.
bash gr00t/eval/real_robot/OPENARM_B1/ui/run_validation_ui.sh
#    Binds 0.0.0.0:8123. Anyone who reaches the port can start a GPU job, so on a
#    shared network:  TOKEN=mysecret bash .../run_validation_ui.sh

# 2. CLI: writes episode_<id>.png + validation_report.html next to the dataset.
bash gr00t/eval/real_robot/OPENARM_B1/ui/run_validation_openarm_b1.sh
EPISODES="0 5 10 20" STEPS=600 bash .../run_validation_openarm_b1.sh

# 3. Serve a directory of dumps produced earlier by the CLI (no model loading).
STATIC=1 DATA_DIR=/home/physicalai/Desktop/I/barani/validation_pick_box \
  bash .../run_validation_ui.sh
```

`run_gr00t_server_openarm_b1.sh` (System A policy server) also lives here; both
validation entry points can reuse a running server instead of loading the model
themselves — pass `USE_SERVER=1` to the CLI one.

## Files

| file | what it is |
|---|---|
| `validation_app.py` + `validation_app.html` | the browser studio (scan, run, chart) |
| `validate_prediction_vs_dataset.py` | the CLI validator; also supplies the studio's metrics |
| `serve_validation_ui.py` | static server for already-computed dumps |
| `run_*.sh` | launchers, every default overridable by env var |
| `daksha_b1/` | **stale.** A copied Daksha B1 setup — a different robot, a tag this repo does not define (`DAKSHA_B1`), and paths into a `grootn1.7/Isaac-GR00T` tree that does not exist here. Nothing in this folder uses it; the `run_*.sh` files above replace its launchers. |

## Reading the report

`pred` should track `gt`. Flat / offset / noisy `pred` on a joint means that joint
was not learned well.

One caveat specific to `pick_box`: the **left arm barely moves** — under 0.05 rad
of total range per joint, and the left gripper spans 5e-5 rad. Its `MAE/range`
column is therefore a ratio of two near-zero numbers and means nothing (it prints
`n/a` when the range is zero). Judge the model on the right-arm channels, which
carry the task. For the same reason, use a realistic `STEPS` (episodes are 600
frames): a 32-step window catches only the initial pause, where nothing moves and
every ratio explodes.

## Defaults

Checkpoint `/home/physicalai/Desktop/I/groot/outputs/pick_box_2_8chunk/checkpoint-50000`,
dataset `/home/physicalai/Desktop/I/barani/pick_box_2`, embodiment tag `openarm_b1`,
action horizon **8** (must equal the checkpoint's action `delta_indices` count --
8 for `pick_box_2_8chunk`, 16 for the older `outputs/pick_box_2` run).
