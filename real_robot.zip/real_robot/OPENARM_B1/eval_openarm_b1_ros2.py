#!/usr/bin/env python3
"""
ROS2 OpenArm B1 bridge for the GR00T N1.6 policy server.

This bridge is TASK-AGNOSTIC; the runner scripts in examples/openarm_b1/ supply the
per-checkpoint values. Two checkpoints currently use it, both 8-step / 30 Hz / 320x240
with the same 3 cameras and the same 16-DoF layout:

  outputs/pick_box_2_8chunk/checkpoint-50000
      barani/pick_box_2   (220 eps, 121 000 frames)  run_system_b_openarm_b1_ros2.sh
      One-box task. The left arm moves only slightly.
  outputs/two_box_pick_8chunk/checkpoint-50000
      barani/two_box_pick (91 eps, 72 800 frames)    run_system_b_two_box_pick_ros2.sh
      Two-box task, GENUINELY BIMANUAL -- the left arm executes the second pick and
      spans up to 3.0 rad, so it needs its own limits and rate caps.
Embodiment: openarm_b1   (projector id 10, i.e. the new_embodiment slot --
            see gr00t/model/gr00t_n1d6/processing_gr00t_n1d6.py and the
            checkpoint's own embodiment_id.json, which agree)

DEFAULTS IN THIS FILE ARE NOT SAFE FOR EVERY CHECKPOINT. The structural ones (16-DoF
left-first layout, 3 camera keys, topics, 30 Hz, 8-step horizon, 320x240 frames) hold
for both runs above. The three TASK-SPECIFIC ones -- --lang-instruction,
--joint-min/max-csv and --max-step-delta-csv -- still carry pick_box-era values and
match NEITHER checkpoint above: against two_box_pick they clamp 11 of 16 joints inside
the range the model was trained to emit and throttle 13 of 16. Always launch through
the runner script for the checkpoint you are serving, which passes all three
explicitly; a bare `python eval_openarm_b1_ros2.py` will pin the arms without
complaining. Re-derive per checkpoint from its own baked configs
(processor_config.json, experiment_cfg/dataset_statistics.json) and its dataset meta
(meta/tasks.jsonl, meta/info.json, meta/modality.json, ros2_topics.json).

Policy state/action layout (16 DoF), LEFT-first -- this is the ordering in the
checkpoint's processor_config.json -> modality_configs -> openarm_b1, and it
matches meta/modality.json (left_arm 0:7, left_gripper 7:8, right_arm 8:15,
right_gripper 15:16):
  left_arm(7) + left_gripper(1) + right_arm(7) + right_gripper(1)

Video modality keys (must match processor_config.json -> modality_configs ->
openarm_b1 -> video -> modality_keys):
  world, wrist_right, wrist_left        (3 cameras, not 4)

Action horizon: 8 -- both checkpoints above bake action delta_indices [0..7]
(pick_box_config.py's range(0, 8)). Pass --action-horizon 16 only when serving the
older 16-step run outputs/pick_box_2/checkpoint-50000.
Control rate: 30 Hz (dataset meta/info.json fps).

Note on action representation: the checkpoint trains the two arms as RELATIVE
actions and the two grippers as ABSOLUTE (processor use_relative_action=True).
The policy server already converts relative -> absolute using the state we send,
so the actions returned here are ABSOLUTE joint positions and are clamped as such
below.

Note on pick_box_2 specifically: it was EXTENDED after the first 16-step run was
trained (101 -> 220 episodes), and the extra episodes move the left side too. In
this checkpoint's baked statistics the left arm spans up to 0.41 rad
(left_joint_6: -0.239..0.170) and the LEFT gripper actuates over -0.044..0.0 --
it is no longer the degenerate constant it was in the 101-episode snapshot. Any
clamp derived from that older snapshot pins the left arm and gripper and drives
them the wrong way; see the --joint-min-csv note below.

The RIGHT gripper actuates over 0.0..0.044 rad: 0.044 = OPEN (its resting value
for most of every episode) and ~0.000-0.010 rad = CLOSED/grasping. Both grippers
are ABSOLUTE actions, so the value the policy returns is the commanded position
directly, already bounded by min-max unnormalization.

Grasp guard (--grasp-guard-tasks, off by default): during a "carry" instruction such
as place_blackbox the right gripper is held to a squeeze floor until the policy
deliberately releases, and if the jaw closes past the object (it was dropped, or never
grasped) the bridge stops following the policy and freezes the arm in place. The
policy itself cannot recover: no demo ever drops the object, so it keeps executing the
place with an empty hand. Typing `stop` / `resume` / an instruction on stdin pauses and
continues by hand.

Start the server first:
  python gr00t/eval/run_gr00t_server.py \
      --model_path /home/physicalai/Desktop/I/groot/outputs/pick_box_2_8chunk/checkpoint-50000 \
      --embodiment-tag openarm_b1

Commands are published as sensor_msgs/JointState on --cmd-topic (/joint_cmd).
"""

from __future__ import annotations

import argparse
from collections import deque
import concurrent.futures
import math
import sys
import threading
import time
from typing import Any

import cv2
from gr00t.policy.server_client import PolicyClient
import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import CompressedImage, Image, JointState


def parse_csv_list(value: str) -> list[str]:
    return [x.strip() for x in value.split(",") if x.strip()]


def parse_csv_floats(value: str, expected_len: int, name: str) -> np.ndarray:
    vals = np.array([float(x.strip()) for x in value.split(",") if x.strip()], dtype=np.float32)
    if vals.shape[0] != expected_len:
        raise ValueError(f"{name} must have {expected_len} values, got {vals.shape[0]}: {value}")
    return vals


def parse_image_size(value: str) -> tuple[int, int] | None:
    """Parse "WxH" into (width, height); "", "0" or "none" disables the exact resize."""
    v = value.strip().lower()
    if v in ("", "0", "none", "off"):
        return None
    if "x" not in v:
        raise ValueError(f"--image-size must look like WxH (e.g. 320x240), got {value!r}")
    w_s, h_s = v.split("x", 1)
    w, h = int(w_s), int(h_s)
    if w <= 0 or h <= 0:
        raise ValueError(f"--image-size must be positive, got {value!r}")
    return w, h


def joint_name_aliases(name: str) -> set[str]:
    """Accept both the bare dataset joint name and a side-namespaced variant.

    The dataset records bare names (meta/info.json: left_joint_1, ...), but the
    per-arm drivers publish some of them under a `left/` or `right/` namespace.
    """
    aliases = {name}
    if "/" in name:
        aliases.add(name.split("/", 1)[1])
    elif name.startswith("left_"):
        aliases.add(f"left/{name}")
    elif name.startswith("right_"):
        aliases.add(f"right/{name}")
    return aliases


def recursive_add_extra_dim(obs: dict[str, Any]) -> dict[str, Any]:
    for key, val in obs.items():
        if isinstance(val, np.ndarray):
            obs[key] = val[np.newaxis, ...]
        elif isinstance(val, dict):
            obs[key] = recursive_add_extra_dim(val)
        else:
            obs[key] = [val]
    return obs


class Gr00TOpenArmB1RosBridge(Node):
    def __init__(self, args: argparse.Namespace):
        super().__init__("gr00t_openarm_b1_ros2_bridge")
        self.args = args

        self.policy = PolicyClient(host=args.policy_host, port=args.policy_port, strict=False)
        if not self.policy.ping():
            raise RuntimeError(
                f"Could not reach GR00T server at tcp://{args.policy_host}:{args.policy_port}"
            )

        if args.verify_server:
            self._verify_server_matches()

        self.state_obs_keys = parse_csv_list(args.state_obs_keys_csv)
        self.action_keys = parse_csv_list(args.action_keys_csv)

        if len(self.state_obs_keys) != 16:
            raise ValueError("state_obs_keys_csv must contain exactly 16 keys")
        if len(self.action_keys) != 16:
            raise ValueError("action_keys_csv must contain exactly 16 keys")

        # Guard against the left/right swap regression: the slice indices below and the
        # action concatenation assume LEFT-first ordering, because that is the order of
        # the checkpoint's modality_keys (left_arm, left_gripper, right_arm,
        # right_gripper) and of the dataset's flat 16-DoF vector. If the key CSVs are
        # ever reordered (e.g. to the right-first convention some older bridges use)
        # without also updating the indices, the arms and grippers get silently swapped
        # and the gripper never actuates. Fail loudly instead.
        for name, keys in (
            ("state_obs_keys", self.state_obs_keys),
            ("action_keys", self.action_keys),
        ):
            expected_side = ["left"] * 8 + ["right"] * 8
            for i, (key, side) in enumerate(zip(keys, expected_side)):
                if side not in key.lower():
                    raise ValueError(
                        f"{name}[{i}]={key!r} must be a '{side}' joint. Keys must be "
                        f"left-first: left_arm(0..6), left_gripper(7), right_arm(8..14), "
                        f"right_gripper(15). Reordering breaks the state/action mapping."
                    )
            for i in (7, 15):
                if "gripper" not in keys[i].lower():
                    raise ValueError(f"{name}[{i}]={keys[i]!r} must be a gripper joint.")

        if not 0 <= args.replan_at < args.action_horizon:
            raise ValueError(
                f"--replan-at must be in [0, action_horizon), got {args.replan_at} "
                f"with --action-horizon {args.action_horizon}"
            )
        # Wall-clock the policy has to answer before the queue runs dry and the arm
        # falls back to hold. Reported next to the measured latency each replan.
        self.replan_budget_s = args.replan_at / args.control_hz

        self.joint_min = parse_csv_floats(args.joint_min_csv, 16, "joint_min_csv")
        self.joint_max = parse_csv_floats(args.joint_max_csv, 16, "joint_max_csv")
        self.max_step_delta = parse_csv_floats(args.max_step_delta_csv, 16, "max_step_delta_csv")
        # Optional, and checked only at startup: the range of poses the dataset's
        # episodes actually BEGAN from. Far tighter than [joint_min, joint_max] and the
        # only thing that catches a wrongly-homed arm -- see _check_start_pose. Pass an
        # empty string to skip the check.
        if args.start_pose_min_csv and args.start_pose_max_csv:
            self.start_pose_min = parse_csv_floats(args.start_pose_min_csv, 16, "start_pose_min_csv")
            self.start_pose_max = parse_csv_floats(args.start_pose_max_csv, 16, "start_pose_max_csv")
            # The pose the warning tells the operator to park at. It is not a command --
            # nothing publishes it -- just the number to drive the arms to by hand or
            # with the teleop leader. Prefer the dataset's MEDIAN start pose; the
            # midpoint of the range is only a fallback, and it is wrong on the
            # asymmetric joints (pick_box_2's left_joint_5 starts at 0.003 but its start
            # range midpoint is 0.140, because one tail of the distribution is long).
            if args.start_pose_home_csv:
                self.start_pose_home = parse_csv_floats(
                    args.start_pose_home_csv, 16, "start_pose_home_csv"
                )
            else:
                self.start_pose_home = (self.start_pose_min + self.start_pose_max) / 2.0
        else:
            self.start_pose_min = None
            self.start_pose_max = None
            self.start_pose_home = None
        self.prev_cmd: np.ndarray | None = None
        # Currently latched gripper target; see the deadband in _apply_safety.
        self.gripper_hold: np.ndarray | None = None
        self.last_policy_ok_time = 0.0

        # Grasp guard, RIGHT gripper only; see _update_grasp_guard. Off unless
        # --grasp-guard-tasks names at least one instruction.
        self.grasp_guard_tasks = set(parse_csv_list(args.grasp_guard_tasks))
        self.grasp_armed = False
        # Instruction the guard last armed/disarmed for. Reset to None to force a
        # re-check of the jaw (on resume), since retyping the same task changes nothing.
        self.guard_lang: str | None = None
        self.drop_ticks = 0
        # The queued command at which the policy's release begins; the guard disarms
        # when it is PUBLISHED, not when it is planned, because the chunk may be replaced
        # before it gets there.
        self.release_msg: JointState | None = None
        if self.grasp_guard_tasks:
            order = (
                args.grasp_release_below,
                args.grasp_held_min,
                args.grasp_drop_above,
                args.grasp_squeeze_floor,
            )
            if not all(a < b for a, b in zip(order, order[1:])):
                raise ValueError(
                    "Grasp guard thresholds must satisfy release_below < held_min < "
                    f"drop_above < squeeze_floor (larger = more closed), got {order}"
                )
            if args.grasp_squeeze_floor > self.joint_max[15]:
                raise ValueError(
                    f"--grasp-squeeze-floor {args.grasp_squeeze_floor} is above the right "
                    f"gripper's joint_max {self.joint_max[15]:.5f}; the clamp would undo it"
                )
        # Paused = streaming a latched pose instead of the policy. Set by a dropped
        # object or the operator's "stop"; cleared by "resume" or a new instruction.
        self.paused_reason: str | None = None
        self.frozen_cmd: np.ndarray | None = None
        # One-shot requests from the stdin thread, consumed on the timer thread so all
        # queue/prev_cmd mutation stays single-threaded. A bool rebind is atomic.
        self._stop_requested = False
        self._resume_requested = False

        # Policy state/action layout is LEFT-first (matches the checkpoint's modality
        # groups; the key CSVs above are validated to follow this order):
        # left arm(0..6), left gripper(7), right arm(8..14), right gripper(15).
        self.policy_left_arm_indices = np.array([0, 1, 2, 3, 4, 5, 6], dtype=np.int64)
        self.policy_left_gripper_index = np.array([7], dtype=np.int64)
        self.policy_right_arm_indices = np.array([8, 9, 10, 11, 12, 13, 14], dtype=np.int64)
        self.policy_right_gripper_index = np.array([15], dtype=np.int64)
        self.policy_control_indices = np.arange(16, dtype=np.int64)
        # The two ABSOLUTE action slots. _build_plan must never offset these.
        self.policy_gripper_indices = np.array([7, 15], dtype=np.int64)

        # Outgoing /joint_cmd ordering. The internal layout is already left-first, which
        # is also what every other publisher on this robot's /joint_cmd sends and what
        # the dataset's flat layout uses (meta/info.json names), so `left_first` is the
        # identity permutation and is the default. sensor_msgs/JointState carries `name`
        # alongside `position`, so a name-driven consumer accepts either order; an
        # index-driven one accepts only the convention already on the wire. `right_first`
        # is kept for controllers that were wired to the older right-first bridges.
        # Names and positions are permuted together by the same index array, so the
        # pairing can never come apart.
        if args.publish_joint_order == "right_first":
            self.publish_indices = np.array(list(range(8, 16)) + list(range(0, 8)), dtype=np.int64)
        else:
            self.publish_indices = np.arange(16, dtype=np.int64)

        # Internal camera keys, in the same order as the checkpoint's video
        # modality_keys: world, wrist_right, wrist_left.
        self.camera_keys = ("world", "wrist_right", "wrist_left")

        # Receipt timestamps, so a publisher that dies is detected instead of the
        # bridge silently re-sending the last frame it ever saw. Without this the
        # policy keeps scoring a frozen image, predicts "no motion" every chunk, and
        # the arm sits still with no error anywhere -- indistinguishable from a bad
        # checkpoint. Cameras dropping out is exactly the observed failure.
        self.image_stamps: dict[str, float] = {}
        self.joint_stamps: dict[str, float] = {}

        # Resolved once: the image callbacks run at camera rate and must not re-parse.
        self.image_size = parse_image_size(args.image_size)

        self.latest_joint_map: dict[str, float] = {}
        self.latest_joint_names: list[str] = []
        self.latest_images: dict[str, np.ndarray] = {}
        self.planned_actions: deque[JointState] = deque()
        self.pending_plan_future: (
            concurrent.futures.Future[tuple[np.ndarray, list[np.ndarray]]] | None
        ) = None
        self.pending_plan_mode: str | None = None
        self.shape_log_done = False
        self.start_pose_checked = False
        self.plan_executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)

        self.valid_modes = ["hold", "full"]
        if args.run_validation_suite:
            self.phase_modes = list(self.valid_modes)
        else:
            if args.validation_mode not in self.valid_modes:
                raise ValueError(f"validation_mode must be one of {self.valid_modes}")
            self.phase_modes = [args.validation_mode]
        self.phase_idx = 0
        self.phase_start_t = time.monotonic()
        self.finished = False
        self.get_logger().info(f"Validation phases: {self.phase_modes}")

        if args.right_joint_state_topic or args.left_joint_state_topic:
            if args.right_joint_state_topic:
                self.create_subscription(
                    JointState,
                    args.right_joint_state_topic,
                    lambda m: self._joint_cb(m, side="right"),
                    qos_profile_sensor_data,
                )
            if args.left_joint_state_topic:
                self.create_subscription(
                    JointState,
                    args.left_joint_state_topic,
                    lambda m: self._joint_cb(m, side="left"),
                    qos_profile_sensor_data,
                )
        else:
            self.create_subscription(
                JointState, args.joint_state_topic, self._joint_cb, qos_profile_sensor_data
            )
        # The dataset was recorded from the "<topic>/compressed" variants
        # (ros2_topics.json -> camera_topics). Keep the raw base topics as the
        # defaults and append the "/compressed" suffix automatically when compressed
        # transport is selected, so both modes subscribe to the topics the data came
        # from. Compressed is the default here because that is what was recorded.
        if args.image_transport == "compressed":
            for attr in ("world_topic", "right_wrist_topic", "left_wrist_topic"):
                topic = getattr(args, attr)
                if not topic.endswith("/compressed"):
                    setattr(args, attr, f"{topic}/compressed")

        image_msg_type = CompressedImage if args.image_transport == "compressed" else Image
        self.create_subscription(
            image_msg_type,
            args.world_topic,
            lambda m: self._image_cb("world", m),
            10,
        )
        self.create_subscription(
            image_msg_type,
            args.right_wrist_topic,
            lambda m: self._image_cb("wrist_right", m),
            10,
        )
        self.create_subscription(
            image_msg_type,
            args.left_wrist_topic,
            lambda m: self._image_cb("wrist_left", m),
            10,
        )
        # Inference publishes a single JointState command topic even if the
        # dataset was originally recorded from separate arm controller topics.
        self.cmd_pub = self.create_publisher(JointState, args.cmd_topic, 10)

        # Instruction the next chunk is planned with. Switched at runtime from stdin so a
        # multi-stage task (pick -> place) runs in ONE bridge process. Restarting the
        # bridge between stages drops a grasped object: see the startup note in
        # _control_step. Read by the planning thread, rebound by the stdin thread; a str
        # rebind is atomic, so no lock.
        self.lang_instruction = args.lang_instruction
        self.lang_sequence = parse_csv_list(args.lang_sequence)
        self.lang_idx = (
            self.lang_sequence.index(self.lang_instruction)
            if self.lang_instruction in self.lang_sequence
            else -1
        )
        self.get_logger().info(f"Language instruction: '{self.lang_instruction}'")
        if self.grasp_guard_tasks:
            self.get_logger().info(
                f"Grasp guard ON for {sorted(self.grasp_guard_tasks)}: right-gripper squeeze "
                f"floor {args.grasp_squeeze_floor:.4f}, holding range "
                f"{args.grasp_held_min:.4f}..{args.grasp_drop_above:.4f}, release below "
                f"{args.grasp_release_below:.4f} for {args.grasp_release_steps} steps"
            )
        if sys.stdin.isatty():
            threading.Thread(target=self._read_lang_from_stdin, daemon=True).start()
            nxt = self._next_lang()
            self.get_logger().info(
                "Type an instruction + Enter to switch task"
                + (f"; Enter alone switches to '{nxt}'" if nxt else "")
                + "; 'stop' freezes the arm, 'resume' continues"
            )

        self.timer = self.create_timer(1.0 / args.control_hz, self._control_step)
        self.get_logger().info(
            f"Bridge started. Server=tcp://{args.policy_host}:{args.policy_port}, "
            f"cmd_topic={args.cmd_topic}, image_transport={args.image_transport}"
        )

    def _next_lang(self) -> str | None:
        if self.lang_idx + 1 < len(self.lang_sequence):
            return self.lang_sequence[self.lang_idx + 1]
        return None

    def _read_lang_from_stdin(self) -> None:
        for line in sys.stdin:
            raw = line.strip()
            if raw.lower() in ("stop", "hold"):
                self._stop_requested = True
                continue
            if raw.lower() == "resume":
                self._resume_requested = True
                continue
            text = raw or self._next_lang()
            if not text:
                hint = (
                    f"Paused ({self.paused_reason}). " if self.paused_reason is not None else ""
                )
                self.get_logger().info(
                    f"{hint}No next task after '{self.lang_instruction}'; type an instruction "
                    "to switch" + (" or 'resume'" if self.paused_reason is not None else "")
                )
                continue
            # With a sequence configured, the known task strings are the only ones the
            # checkpoint was trained on. Anything else -- typically shell commands pasted
            # into the wrong terminal -- would become the instruction verbatim and the
            # policy would stop doing the task, so refuse it.
            known = set(self.lang_sequence) | self.grasp_guard_tasks
            if known and text not in known:
                self.get_logger().warn(
                    f"Ignored '{text}': not a trained instruction. Known: {sorted(known)} "
                    "(or 'stop' / 'resume')"
                )
                continue
            if text in self.lang_sequence:
                self.lang_idx = self.lang_sequence.index(text)
            self.lang_instruction = text
            # Giving an instruction also un-pauses: it says what the arm should do now.
            self._resume_requested = True
            # The chunk already queued (at most ACTION_HORIZON steps) finishes first.
            self.get_logger().info(f"Language instruction -> '{text}' (from the next chunk)")

    def _verify_server_matches(self) -> None:
        """Fail fast when System A is serving a different checkpoint than configured.

        Serving the wrong run is otherwise a SILENT failure. A 16-step checkpoint under
        --action-horizon 8 executes only the first half of every chunk, and since the
        arms are relative the displacement accumulates toward the chunk's end, so the
        arm just moves feebly. Mismatched video keys instead explode deep inside the
        server's processor with a KeyError that names nothing useful. The server knows
        its own modality config, so ask it.
        """
        try:
            served = self.policy.get_modality_config()
        except Exception as exc:
            self.get_logger().warn(
                f"Could not read the server's modality config ({exc}); "
                "skipping the checkpoint match check"
            )
            return

        problems: list[str] = []
        action = served.get("action")
        if action is not None:
            horizon = len(action.delta_indices)
            if horizon != self.args.action_horizon:
                problems.append(
                    f"the served checkpoint emits {horizon}-step action chunks, but "
                    f"--action-horizon is {self.args.action_horizon}"
                )
        video = served.get("video")
        if video is not None:
            want = [
                self.args.world_camera_key,
                self.args.right_wrist_camera_key,
                self.args.left_wrist_camera_key,
            ]
            if sorted(video.modality_keys) != sorted(want):
                problems.append(
                    f"the served checkpoint expects video keys {sorted(video.modality_keys)}, "
                    f"but this bridge sends {sorted(want)}"
                )
        if problems:
            raise RuntimeError(
                "The policy server is serving a checkpoint that does not match this "
                "bridge's configuration:\n  - "
                + "\n  - ".join(problems)
                + "\nStart System A with the matching RUN_DIR, or pass "
                "--no-verify-server to run anyway."
            )
        self.get_logger().info(
            "Server checkpoint matches: "
            f"{len(served['action'].delta_indices) if 'action' in served else '?'}-step chunks, "
            f"video keys {sorted(served['video'].modality_keys) if 'video' in served else '?'}"
        )

    def _joint_cb(self, msg: JointState, side: str | None = None) -> None:
        if msg.name and msg.position and len(msg.name) == len(msg.position):
            if not self.latest_joint_names:
                self.latest_joint_names = list(msg.name)
                if self.latest_joint_names != self.action_keys:
                    self.get_logger().info(
                        "Incoming joint names differ from action_keys. The bridge will match aliases "
                        "like left_joint_1 and left/left_joint_1."
                    )
            now = time.monotonic()
            for n, p in zip(msg.name, msg.position):
                for alias in joint_name_aliases(n):
                    self.latest_joint_map[alias] = float(p)
                    self.joint_stamps[alias] = now
        elif msg.position:
            # Nameless JointState: fall back to positional mapping. The key CSVs are
            # left-first, so the left arm owns slots 0..7 and the right arm 8..15.
            if side == "left":
                keys = self.state_obs_keys[:8]
            elif side == "right":
                keys = self.state_obs_keys[8:16]
            else:
                keys = self.state_obs_keys
            now = time.monotonic()
            for i, key in enumerate(keys[: len(msg.position)]):
                self.latest_joint_map[key] = float(msg.position[i])
                self.joint_stamps[key] = now

    def _preprocess_image(self, img: np.ndarray) -> np.ndarray:
        """Reproduce the recorder's frame geometry, then optionally cap the long edge.

        pick_box_2 was written by custom_v3format_dataset/recorder.py, whose
        _resize_if_needed is a plain `cv2.resize(img, (W, H), INTER_AREA)` to the
        camera's configured size -- no aspect preservation, no crop. Every camera in
        that dataset is 320x240 (meta/info.json), while the live cameras publish
        640x480 (world) and 848x480 (wrists), so the two wrist views were SQUASHED from
        16:9 into 4:3 when the data was recorded. Feeding the raw 848x480 frame at
        inference therefore hands the backbone a geometry it never trained on, and
        costs ~33% more vision tokens on two of the three cameras (the server resizes
        the SHORTEST edge to 256, so 848x480 -> 256x452 against training's 256x341).
        Doing the identical resize here fixes the mismatch and the latency together.
        """
        target = self.image_size
        if target is not None:
            w, h = target
            if img.shape[1] != w or img.shape[0] != h:
                img = cv2.resize(img, (w, h), interpolation=cv2.INTER_AREA)
            return img

        limit = self.args.image_max_edge
        if limit <= 0:
            return img
        h, w = img.shape[:2]
        longest = max(h, w)
        if longest <= limit:
            return img
        scale = limit / float(longest)
        # INTER_AREA is the correct kernel for downsampling; anything else aliases.
        return cv2.resize(
            img,
            (max(1, int(round(w * scale))), max(1, int(round(h * scale)))),
            interpolation=cv2.INTER_AREA,
        )

    def _image_cb(self, cam_key: str, msg: Image | CompressedImage) -> None:
        if isinstance(msg, CompressedImage):
            try:
                compressed = np.frombuffer(msg.data, dtype=np.uint8)
                if len(compressed) == 0:
                    self.get_logger().warn(f"Received empty compressed image data from {cam_key}")
                    return
                img = cv2.imdecode(compressed, cv2.IMREAD_COLOR)
                if img is None:
                    self.get_logger().warn(f"Failed to decode compressed image from {cam_key}")
                    return
                img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
                self.latest_images[cam_key] = self._preprocess_image(img)
                self.image_stamps[cam_key] = time.monotonic()
            except Exception as e:
                self.get_logger().warn(f"Error processing compressed image from {cam_key}: {e}")
            return

        if msg.encoding not in ("rgb8", "bgr8", "bgra8", "rgba8"):
            self.get_logger().warn(f"Unsupported raw image encoding for {cam_key}: {msg.encoding}")
            return
        channels = 4 if msg.encoding in ("bgra8", "rgba8") else 3
        img = np.frombuffer(msg.data, dtype=np.uint8).reshape((msg.height, msg.width, channels))
        if msg.encoding == "bgr8":
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        elif msg.encoding == "bgra8":
            img = cv2.cvtColor(img, cv2.COLOR_BGRA2RGB)
        elif msg.encoding == "rgba8":
            img = cv2.cvtColor(img, cv2.COLOR_RGBA2RGB)
        self.latest_images[cam_key] = self._preprocess_image(img)
        self.image_stamps[cam_key] = time.monotonic()

    def _current_mode(self) -> str | None:
        if self.finished:
            return None
        mode = self.phase_modes[self.phase_idx]
        if self.args.run_validation_suite:
            elapsed = time.monotonic() - self.phase_start_t
            if elapsed >= self.args.phase_seconds:
                self.get_logger().info(f"Completed phase: {mode}")
                self.phase_idx += 1
                if self.phase_idx >= len(self.phase_modes):
                    self.get_logger().info("Validation suite complete.")
                    self.finished = True
                    return None
                self.phase_start_t = time.monotonic()
                mode = self.phase_modes[self.phase_idx]
                self.planned_actions.clear()
                self.get_logger().info(f"Starting phase: {mode}")
        return mode

    def _ready(self) -> bool:
        missing_joints, missing_cameras = self._missing_inputs()
        return not missing_joints and not missing_cameras

    def _missing_inputs(self) -> tuple[list[tuple[str, str]], list[tuple[str, str]]]:
        """Inputs that never arrived, or whose last message is older than the timeout.

        Each entry is (key, description). A key that went stale is described as
        "<key> (stale Ns)" so a publisher that died mid-run is called out by name
        rather than silently reused forever; the bare key is kept alongside it
        because callers look topics up by it.
        """
        now = time.monotonic()
        timeout = self.args.input_timeout_s

        def stale(key: str, stamps: dict[str, float]) -> tuple[str, str] | None:
            if key not in stamps:
                return key, key
            age = now - stamps[key]
            if timeout > 0 and age > timeout:
                return key, f"{key} (stale {age:.1f}s)"
            return None

        missing_joints = [
            s for s in (stale(k, self.joint_stamps) for k in self.state_obs_keys) if s
        ]
        missing_cameras = [s for s in (stale(k, self.image_stamps) for k in self.camera_keys) if s]
        return missing_joints, missing_cameras

    def _log_waiting_inputs(self) -> None:
        missing_joints, missing_cameras = self._missing_inputs()
        parts: list[str] = []
        if missing_joints:
            if self.args.right_joint_state_topic or self.args.left_joint_state_topic:
                topic_desc = (
                    f"left={self.args.left_joint_state_topic or 'disabled'}, "
                    f"right={self.args.right_joint_state_topic or 'disabled'}"
                )
            else:
                topic_desc = self.args.joint_state_topic
            joint_desc = ", ".join(desc for _, desc in missing_joints)
            parts.append(f"waiting on {topic_desc} for joint keys: {joint_desc}")
        if missing_cameras:
            camera_topics = {
                "world": self.args.world_topic,
                "wrist_right": self.args.right_wrist_topic,
                "wrist_left": self.args.left_wrist_topic,
            }
            missing_cam_desc = ", ".join(
                f"{desc} ({camera_topics.get(key, 'unknown topic')})"
                for key, desc in missing_cameras
            )
            parts.append(f"waiting on camera topics: {missing_cam_desc}")
        if not parts:
            parts.append("all required ROS2 inputs received, but policy is not ready yet")
        self.get_logger().info("Waiting for inputs -> " + " | ".join(parts))

    def _check_start_pose(self) -> None:
        """Warn once if the arms are parked outside the region the policy was trained in.

        The arms are RELATIVE actions, so the policy predicts a delta FROM the state we
        send. Send it a pose it never saw in training and the output is undefined --
        the arm moves in ways that look random rather than wrong-but-purposeful, with
        nothing in the logs. That is easy to hit on this robot: two_box_pick keeps
        left_joint_4 in [-1.85, -0.58] and left_joint_5 in [0.97, 1.99], so a left arm
        homed anywhere near zero is nowhere near the distribution, even though the
        right arm may be posed correctly and behave perfectly.

        Two separate yardsticks are applied, because the loose one alone misses the
        failure that actually bites:

        [joint_min, joint_max] is the trained action/state range over WHOLE episodes,
        widened slightly. A joint outside it is unquestionably broken -- the rate
        limiter will walk it to the nearest bound at max_step_delta per step no matter
        what the policy asks for, so the arm drives itself to the limit box.

        [start_pose_min, start_pose_max] is the much tighter range of poses episodes
        actually BEGAN from. This is the one that catches a wrongly-homed arm. On
        pick_box_2 every episode starts with the right arm reaching forward
        (right_joint_4 ~ 1.68, right_joint_5 ~ 1.43, right_joint_1 ~ -0.60,
        right_joint_7 ~ 0.70) while the left arm sits at zero, so an operator who homes
        BOTH arms to zero leaves right_joint_1/4/5/7 far outside the start
        distribution. The whole-episode box misses two of those four, because the right
        arm does pass through 0 rad on joints 1 and 7 later in the episode -- just
        never at the start. The policy then sees a pose it was never conditioned on,
        predicts ~0 motion for the right arm (measured: <=0.02 rad over a whole 8-step
        chunk), and the clamp drags joints 4 and 5 to the limit-box corner instead.
        That is the "right arm goes backwards / behind itself" failure.
        """
        state16 = self._hold_vec16()
        outside = []
        off_start = []
        for i, key in enumerate(self.state_obs_keys):
            v = float(state16[i])
            lo, hi = float(self.joint_min[i]), float(self.joint_max[i])
            if v < lo or v > hi:
                off = lo - v if v < lo else v - hi
                outside.append(f"{key}={v:+.3f} outside [{lo:+.3f}, {hi:+.3f}] by {off:.3f} rad")
            if self.start_pose_min is not None:
                slo, shi = float(self.start_pose_min[i]), float(self.start_pose_max[i])
                if v < slo or v > shi:
                    off = slo - v if v < slo else v - shi
                    off_start.append(
                        f"{key}={v:+.3f} outside start range [{slo:+.3f}, {shi:+.3f}] "
                        f"by {off:.3f} rad"
                    )
        if outside:
            self.get_logger().warn(
                "START POSE IS OUTSIDE THE TRAINED RANGE on "
                f"{len(outside)} of {len(self.state_obs_keys)} joints. The policy "
                "predicts RELATIVE motion from the state you send it, so its output "
                "for these joints is undefined and the arm will look erratic:\n  - "
                + "\n  - ".join(outside)
                + "\nMove the arms into a pose from the dataset before starting."
            )
        if off_start:
            self.get_logger().warn(
                f"START POSE IS NOT A POSE ANY EPISODE BEGAN FROM on {len(off_start)} "
                f"of {len(self.state_obs_keys)} joints. The policy has never been "
                "conditioned on this pose, so it predicts almost no motion for these "
                "joints while the safety clamp keeps driving them -- the arm wanders "
                "instead of reaching:\n  - "
                + "\n  - ".join(off_start)
                + "\nPark the arms at the dataset home pose first:\n    "
                + ", ".join(
                    f"{k}={float(h):+.3f}"
                    for k, h in zip(self.state_obs_keys, self.start_pose_home)
                )
            )
        if not outside and not off_start:
            self.get_logger().info(
                "Start pose is inside the trained range AND the episode-start range "
                "on all 16 joints."
            )

    def _hold_vec16(self) -> np.ndarray:
        return np.array([self.latest_joint_map[k] for k in self.state_obs_keys], dtype=np.float32)

    def _log_obs_shapes(self, obs: dict[str, Any]) -> None:
        video_shapes = {k: tuple(v.shape) for k, v in obs["video"].items()}
        state_shapes = {k: tuple(v.shape) for k, v in obs["state"].items()}
        language_shapes = {k: (len(v), len(v[0]) if v else 0) for k, v in obs["language"].items()}
        self.get_logger().info(
            f"Policy obs shapes: video={video_shapes}, state={state_shapes}, language={language_shapes}"
        )

    def _obs_for_policy(self, state16: np.ndarray | None = None) -> dict[str, Any]:
        # Accept a precomputed state so the caller can guarantee the rate limiter is
        # anchored to the exact same vector the policy conditions on.
        if state16 is None:
            state16 = self._hold_vec16()
        obs = {
            "video": {
                self.args.world_camera_key: self.latest_images["world"],
                self.args.right_wrist_camera_key: self.latest_images["wrist_right"],
                self.args.left_wrist_camera_key: self.latest_images["wrist_left"],
            },
            "state": {
                "left_arm": state16[self.policy_left_arm_indices],
                "left_gripper": state16[self.policy_left_gripper_index],
                "right_arm": state16[self.policy_right_arm_indices],
                "right_gripper": state16[self.policy_right_gripper_index],
            },
            "language": {"annotation.human.task_description": self.lang_instruction},
        }
        obs = recursive_add_extra_dim(obs)
        obs = recursive_add_extra_dim(obs)
        if not self.shape_log_done:
            self._log_obs_shapes(obs)
            self.shape_log_done = True
        return obs

    @staticmethod
    def _extract_action_vec16(action_chunk: dict[str, Any], t: int) -> np.ndarray:
        # Concatenation order must be LEFT-first, matching the checkpoint's
        # modality_keys and the slice indices in __init__.
        for prefix in ("", "action."):
            groups = [f"{prefix}{g}" for g in
                      ("left_arm", "left_gripper", "right_arm", "right_gripper")]
            if not all(g in action_chunk for g in groups):
                continue
            vecs = [
                np.asarray(action_chunk[g][0][t], dtype=np.float32).reshape(-1) for g in groups
            ]
            expected = (7, 1, 7, 1)
            if tuple(v.shape[0] for v in vecs) != expected:
                raise ValueError(
                    "Unexpected action dims: "
                    + ", ".join(f"{g}={v.shape}" for g, v in zip(groups, vecs))
                )
            return np.concatenate(vecs, axis=0)
        if "action" in action_chunk:
            vec = np.asarray(action_chunk["action"][0][t], dtype=np.float32).reshape(-1)
            if vec.shape[0] != 16:
                raise ValueError(f"Expected action[16], got {vec.shape[0]}")
            return vec
        raise ValueError(f"Unsupported action chunk keys: {list(action_chunk.keys())}")

    def _apply_safety(
        self,
        action_vec16: np.ndarray,
        hold_vec16: np.ndarray,
        mode: str,
        grip_floor: bool = False,
    ) -> np.ndarray:
        # `prev_cmd` chains within a chunk (step t rate-limits against step t-1) and is
        # re-anchored to the measured state at the start of each chunk by `_build_plan`.
        # Both happen on the main (timer) thread, so no locking.
        if self.prev_cmd is None:
            self.prev_cmd = hold_vec16.copy()

        prev_control = self.prev_cmd[self.policy_control_indices]
        target = np.clip(action_vec16, self.joint_min, self.joint_max)

        # GRIPPER DEADBAND. The bridge replaces the whole chunk every replan, so the
        # commanded value at each chunk boundary is a FRESH, independent sample from the
        # diffusion head. For the arms that discontinuity is absorbed by the anchor
        # compensation in _build_plan; the grippers are deliberately excluded from it
        # (they are ABSOLUTE), so nothing smooths them and the head's sample noise --
        # measured at 0.003-0.010 rad, against a jaw whose entire travel is 0.044 --
        # reaches the hardware raw. That is the jaw buzzing open/closed at the replan
        # rate even while the policy is "right" on average.
        #
        # The demonstrations say what the gripper signal actually looks like: over all
        # 220 episodes the right-gripper action is EXACTLY unchanged on 83.3% of frames
        # and NEVER moves more than 0.012 rad in one 30 Hz step. It is piecewise
        # constant, so latching it and ignoring sub-deadband wobble loses nothing.
        #
        # Replaying every recorded grasp through this filter at 0.004: worst-case error
        # 0.0040 rad, mean 0.0012, not one frame off by more than 0.005, and a
        # transition lag of 0.8 ticks (25 ms). It makes the command 95.8% static --
        # smoother than the demos. Raising it buys little and costs real accuracy
        # (0.008 puts 23.9% of frames off by >0.005 and lags 72 ms). 0 disables.
        if self.args.gripper_deadband > 0.0:
            gi = self.policy_gripper_indices
            if self.gripper_hold is None:
                self.gripper_hold = target[gi].copy()
            moved = np.abs(target[gi] - self.gripper_hold) > self.args.gripper_deadband
            self.gripper_hold = np.where(moved, target[gi], self.gripper_hold)
            target[gi] = self.gripper_hold

        # SQUEEZE FLOOR while the grasp guard is armed, applied after the deadband so it
        # always wins. blackbox_pick_and_place demos carry the box on a very light
        # squeeze -- median command only 0.0034 rad past where the box stops the jaw
        # (~0.0295), less than the 0.004 deadband -- so one low diffusion sample can
        # latch a command with no grip at all and the box slides out mid-carry. The
        # floor is inside the demonstrated range (held command max 0.0415) and also
        # makes a drop visible: an empty jaw closes to ~the floor, far above the box.
        if grip_floor:
            g = int(self.policy_right_gripper_index[0])
            target[g] = max(float(target[g]), self.args.grasp_squeeze_floor)

        delta = np.clip(target - prev_control, -self.max_step_delta, self.max_step_delta)
        cmd_control = np.clip(prev_control + delta, self.joint_min, self.joint_max)
        # The [joint_min, joint_max] clip above can move the command FURTHER than
        # max_step_delta when the arm is currently OUTSIDE the limit box -- it snaps
        # straight to the nearest bound, defeating the rate limit in exactly the
        # situation where it matters most. That is reachable in normal use: two_box_pick
        # keeps left_joint_4 in [-1.98, -0.45] and left_joint_5 in [0.86, 2.09], so an
        # arm parked near zero at startup is outside the box on both, and the first
        # command would jump ~0.45 rad in one 33 ms tick. Re-impose the rate limit last
        # so the arm always WALKS into the legal range at max_step_delta per step.
        cmd_control = np.clip(
            cmd_control, prev_control - self.max_step_delta, prev_control + self.max_step_delta
        )

        cmd = hold_vec16.copy()
        cmd[self.policy_control_indices] = cmd_control
        if mode == "hold":
            cmd = hold_vec16.copy()
        self.prev_cmd = cmd.copy()
        return cmd

    def _to_joint_state_msg(self, cmd16: np.ndarray) -> JointState:
        msg = JointState()
        msg.header.stamp = self.get_clock().now().to_msg()
        # Permute names and positions together so each value keeps its own name.
        msg.name = [self.action_keys[i] for i in self.publish_indices]
        msg.position = [float(cmd16[i]) for i in self.publish_indices]
        # Many hardware controllers require velocity / effort fields to be
        # present (even if zero) to accept the JointState as a valid command.
        msg.velocity = [0.0] * len(cmd16)
        msg.effort = [0.0] * len(cmd16)
        return msg

    def _plan_from_policy(self, mode: str) -> tuple[np.ndarray, list[np.ndarray]]:
        hold_vec16 = self._hold_vec16()
        obs = self._obs_for_policy(hold_vec16)
        t_start = time.monotonic()
        action_chunk, _ = self.policy.get_action(obs)
        inference_s = time.monotonic() - t_start
        self.last_policy_ok_time = time.monotonic()

        # Tuning signal for --replan-at: the round trip must fit in the budget, else
        # the queue drains before the next chunk lands and the arm hold-stutters.
        # With replanning disabled (--replan-at 0) there is no budget -- the arm simply
        # holds for the whole round trip by design, so report the cost of that pause.
        if self.args.replan_at > 0:
            budget_s = self.replan_budget_s
            note = ""
            if inference_s > budget_s:
                note = (
                    f"  OVER BUDGET -- raise --replan-at to "
                    f"{math.ceil(inference_s * self.args.control_hz)}"
                )
            self.get_logger().info(
                f"inference {inference_s * 1000:.0f} ms vs budget {budget_s * 1000:.0f} ms{note}"
            )
        else:
            self.get_logger().info(
                f"inference {inference_s * 1000:.0f} ms "
                f"(~{inference_s * self.args.control_hz:.1f} ticks held between chunks; "
                f"replanning disabled)"
            )

        any_key = next(iter(action_chunk.keys()))
        horizon = int(np.asarray(action_chunk[any_key]).shape[1])
        steps = min(horizon, self.args.action_horizon)
        action_shapes = {k: tuple(np.asarray(v).shape) for k, v in action_chunk.items()}
        self.get_logger().info(
            f"Policy action keys/shapes: {action_shapes}, horizon={horizon}, steps={steps}, mode={mode}"
        )

        # Return the raw absolute targets together with the state they were anchored
        # to. Safety clamping and the stale-anchor correction both need the arm's
        # position at LANDING time, not at plan time, so they run on the main thread in
        # _build_plan. Extracting the vectors here keeps that numpy work off the timer.
        return hold_vec16, [self._extract_action_vec16(action_chunk, t) for t in range(steps)]

    def _build_plan(
        self, anchor16: np.ndarray, action_vecs: list[np.ndarray], mode: str
    ) -> list[JointState]:
        """Turn the policy's absolute targets into commands, corrected for the motion
        that happened while the policy was thinking.

        The arms are RELATIVE actions: the server produced these absolute targets by
        adding the state we sent at plan time (`anchor16`). With --replan-at > 0 the
        chunk is requested BEFORE the previous one has finished, so by the time it
        lands the arm has executed up to --replan-at more steps and `anchor16` is that
        far behind. Publishing the targets verbatim commands the arm back to where it
        was when the request went out -- a backward tug at every chunk boundary, which
        is precisely the stutter overlapped replanning exists to remove.

        Shifting the whole chunk by (measured state - anchor) re-anchors it to where
        the arm actually is while preserving the shape of the predicted trajectory.
        The correction is applied to the ARMS ONLY: the grippers are ABSOLUTE actions
        (processor_config.json -> action_configs), so their targets are already in the
        right frame and offsetting them would inject an error equal to the gripper's
        own drift -- enough to open a closed grasp.
        """
        current16 = self._hold_vec16()
        if self.args.replan_anchor_compensation and self.args.replan_at > 0:
            offset = current16 - anchor16
            offset[self.policy_gripper_indices] = 0.0
            action_vecs = [vec + offset for vec in action_vecs]

        # Re-anchor the rate limiter to the arm's real position, so step 0 is limited
        # against where the arm is now rather than a reference it has already left.
        # `_publish_hold` streams the measured state between chunks without touching
        # `prev_cmd`, so without this the two drift apart and the +/-max_step_delta
        # clamp eats the leading steps of every chunk.
        # ...but only for the ARMS. Re-anchoring a gripper to its measured position
        # re-introduces the tracking gap described in _publish_hold: the limiter would
        # restart each chunk 0.02 rad away from what we actually commanded and spend
        # the chunk climbing back. Grippers stay anchored to the last COMMAND.
        prev_cmd = self.prev_cmd
        self.prev_cmd = current16.copy()
        if prev_cmd is not None:
            self.prev_cmd[self.policy_gripper_indices] = prev_cmd[self.policy_gripper_indices]

        # While the grasp guard is armed, floor the squeeze on every step up to the
        # policy's release (if this chunk contains one); see _release_step.
        release_at = self._release_step(action_vecs) if self.grasp_armed else None
        floor_steps = (
            (len(action_vecs) if release_at is None else release_at) if self.grasp_armed else 0
        )
        msgs = [
            self._to_joint_state_msg(
                self._apply_safety(vec, current16, mode, grip_floor=i < floor_steps)
            )
            for i, vec in enumerate(action_vecs)
        ]
        self.release_msg = msgs[release_at] if release_at is not None else None
        return msgs

    def _release_step(self, action_vecs: list[np.ndarray]) -> int | None:
        """First step of a deliberate right-gripper release in this chunk, else None.

        Deliberate = at least --grasp-release-steps consecutive targets below
        --grasp-release-below. Every place demo's release holds the command below 0.025
        for >= 6 frames (median 28), so a short run is diffusion noise, not an intent to
        let go, and must not switch the squeeze floor off mid-carry.
        """
        g = int(self.policy_right_gripper_index[0])
        need = self.args.grasp_release_steps
        run = 0
        for i, vec in enumerate(action_vecs):
            run = run + 1 if float(vec[g]) < self.args.grasp_release_below else 0
            if run >= need:
                return i - need + 1
        return None

    def _right_jaw(self) -> float:
        return float(self.latest_joint_map[self.state_obs_keys[15]])

    def _update_grasp_guard(self) -> None:
        """Arm on a carrying task, and pause the moment the object leaves the jaw.

        The policy has never seen a dropped object -- no place demo loses the box -- so
        after a drop it keeps playing the place motion with an empty gripper. The jaw
        is the one sensor that knows: while the box is in it the jaw is stopped at
        0.028-0.033 rad (max 0.0333 over every pre-release frame of all 78 place
        demos), and with the squeeze floor commanded an empty jaw closes to ~0.039.
        Crossing --grasp-drop-above for --grasp-drop-ticks ticks therefore means the
        object is gone, and the arm is frozen where it is instead of "placing" nothing.

        Arming also checks that there IS an object: switching to place after a failed
        pick (jaw open, or closed on nothing) pauses instead of carrying out the place.
        """
        lang = self.lang_instruction
        if lang != self.guard_lang:
            self.guard_lang = lang
            self.grasp_armed = lang in self.grasp_guard_tasks
            self.release_msg = None
            self.drop_ticks = 0
            if not self.grasp_armed:
                return
            jaw = self._right_jaw()
            if not self.args.grasp_held_min <= jaw <= self.args.grasp_drop_above:
                self.grasp_armed = False
                self._pause(
                    f"NO OBJECT IN THE RIGHT GRIPPER for '{lang}': jaw reads {jaw:.4f}, "
                    f"holding range is {self.args.grasp_held_min:.4f}.."
                    f"{self.args.grasp_drop_above:.4f}"
                )
                return
            self.get_logger().info(f"Grasp guard armed for '{lang}' (jaw {jaw:.4f})")
            return
        if not self.grasp_armed:
            return
        jaw = self._right_jaw()
        if jaw > self.args.grasp_drop_above:
            self.drop_ticks += 1
            if self.drop_ticks >= self.args.grasp_drop_ticks:
                self.grasp_armed = False
                self._pause(
                    f"OBJECT DROPPED during '{lang}': right jaw closed to {jaw:.4f} "
                    f"(> {self.args.grasp_drop_above:.4f}) without a release command"
                )
        else:
            self.drop_ticks = 0

    def _pause(self, reason: str) -> None:
        """Stop following the policy and hold the arm exactly where it is now."""
        self.paused_reason = reason
        self.planned_actions.clear()
        # Any in-flight chunk is simply never consumed.
        self.pending_plan_future = None
        self.pending_plan_mode = None
        self.release_msg = None
        # Latch ONE pose rather than re-sampling the measured state every tick, which
        # lets the arm sag a little further each tick under gravity. Grippers keep the
        # last COMMAND (see _publish_hold). Before the policy has ever spoken there is
        # no command to keep, so nothing is published -- same rule as _control_step.
        if self.prev_cmd is not None:
            self.frozen_cmd = self._hold_vec16()
            self.frozen_cmd[self.policy_gripper_indices] = self.prev_cmd[
                self.policy_gripper_indices
            ]
        else:
            self.frozen_cmd = None
        self.get_logger().warn(
            f"PAUSED -- {reason}. Arm is holding position. Type an instruction "
            f"(e.g. '{self.lang_sequence[0] if self.lang_sequence else self.lang_instruction}') "
            "or 'resume' + Enter to continue."
        )

    def _handle_operator_requests(self) -> None:
        if self._stop_requested:
            self._stop_requested = False
            if self.paused_reason is None:
                self._pause("operator stop")
        if self._resume_requested:
            self._resume_requested = False
            if self.paused_reason is not None:
                self.get_logger().info(
                    f"Resuming with '{self.lang_instruction}' (was paused: {self.paused_reason})"
                )
                self.paused_reason = None
                self.frozen_cmd = None
                # Re-check the jaw even if the instruction did not change.
                self.guard_lang = None
                # Nothing was requested while paused; do not let the watchdog read that
                # silence as a dead server and pin the arm in hold forever.
                self.last_policy_ok_time = time.monotonic()

    def _publish_hold(self) -> None:
        """Republish the measured pose as a command -- except for the two grippers.

        The arms track their command closely, so commanding the measured position is a
        real "stay where you are". The GRIPPERS do not track: a gripper command is a
        squeeze target, not a pose the jaw reaches. On this robot the right jaw settles
        0.015-0.020 rad short of a 0.044 OPEN command -- a standing gap in 142 of
        pick_box_2's 220 episodes (p05 of state-action over open frames: -0.0185).

        Feeding that measured position back as the command therefore CANCELS the
        squeeze for as long as the queue is dry, and the next chunk re-applies it: the
        jaw buzzes open/closed at the replan rate with nothing in the logs. Both
        grippers are ABSOLUTE actions (processor_config.json -> action_configs), so the
        only correct hold for them is the last value we COMMANDED.
        """
        hold_vec16 = self._hold_vec16()
        if self.prev_cmd is not None:
            hold_vec16[self.policy_gripper_indices] = self.prev_cmd[self.policy_gripper_indices]
        self.cmd_pub.publish(self._to_joint_state_msg(hold_vec16))

    def _control_step(self) -> None:
        mode = self._current_mode()
        if mode is None:
            self.pending_plan_future = None
            self.pending_plan_mode = None
            if self._ready():
                self._publish_hold()
            return
        if not self._ready():
            self._log_waiting_inputs()
            return

        if not self.start_pose_checked:
            self.start_pose_checked = True
            self._check_start_pose()

        self._handle_operator_requests()
        if self.paused_reason is None:
            self._update_grasp_guard()
        if self.paused_reason is not None:
            if self.frozen_cmd is not None:
                self.prev_cmd = self.frozen_cmd.copy()
                self.cmd_pub.publish(self._to_joint_state_msg(self.frozen_cmd))
            return

        stale = (
            self.last_policy_ok_time > 0
            and (time.monotonic() - self.last_policy_ok_time) > self.args.watchdog_timeout_s
        )
        if mode == "hold" or stale:
            self.pending_plan_future = None
            self.pending_plan_mode = None
            self.planned_actions.clear()
            self._publish_hold()
            return

        if self.pending_plan_future is not None and self.pending_plan_future.done():
            try:
                anchor16, action_vecs = self.pending_plan_future.result()
                # REPLACE, don't append. The fresh chunk is anchored to the state
                # sampled at its own plan time, so any steps still queued from the
                # previous chunk are stale targets relative to it.
                self.planned_actions.clear()
                self.planned_actions.extend(self._build_plan(anchor16, action_vecs, mode))
            except Exception as exc:
                # Keep whatever is still queued: those steps are only slightly stale
                # and finishing them beats stuttering to hold. A persistent failure is
                # caught by the watchdog above once last_policy_ok_time goes stale.
                self.get_logger().error(f"Policy planning failed: {exc}")
            finally:
                self.pending_plan_future = None
                self.pending_plan_mode = None

        # Kick off the next chunk once the queue is down to --replan-at steps, so the
        # round trip overlaps with executing the tail of the current chunk instead of
        # stalling the arm. replan_at=0 means "drain fully, then replan".
        if self.pending_plan_future is None and len(self.planned_actions) <= self.args.replan_at:
            try:
                self.pending_plan_mode = mode
                self.pending_plan_future = self.plan_executor.submit(self._plan_from_policy, mode)
            except Exception as exc:
                self.get_logger().error(f"Could not start policy planning: {exc}")
                self.pending_plan_future = None
                self.pending_plan_mode = None

        # Keep executing the queue while inference is in flight; only hold if it is dry.
        # Before the FIRST chunk there is no commanded gripper value to hold, so
        # _publish_hold would command the MEASURED gripper position -- zero squeeze. With
        # an object already in the jaw (bridge restarted between pick and place) that
        # opens the grasp and the object falls. Publish nothing until the policy has
        # spoken: the controller is still holding whatever it was last commanded, exactly
        # as it was before the bridge started.
        if self.planned_actions:
            msg = self.planned_actions.popleft()
            if msg is self.release_msg:
                self.release_msg = None
                self.grasp_armed = False
                self.get_logger().info("Policy released the grasp; grasp guard off")
            self.cmd_pub.publish(msg)
        elif self.prev_cmd is not None:
            self._publish_hold()

    def destroy_node(self) -> bool:
        self.plan_executor.shutdown(wait=False, cancel_futures=True)
        return super().destroy_node()


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser("OpenArm B1 ROS2 bridge for GR00T N1.6 policy server")

    p.add_argument("--policy-host", default="127.0.0.1")
    p.add_argument("--policy-port", type=int, default=5555)
    # Must match the training task string exactly. Verbatim from the dataset's
    # meta/tasks.jsonl (task_index 0), which is the only task in `pick_box_2`.
    p.add_argument(
        "--lang-instruction",
        default="pick the brown box on the right hand side, place it in to the center of the box",
    )
    # Action horizon must match the number of delta_indices in the checkpoint
    # (processor_config.json -> modality_configs -> openarm_b1 -> action -> delta_indices).
    # pick_box_config.py declares delta_indices=list(range(0, 8)), so checkpoints trained
    # with it are 8 -- and meta/relative_stats.json in pick_box_1/pick_box_2 is shaped
    # (8, 7) to match. Older checkpoints (e.g. checkpoint-50000) were trained at 16; pass
    # --action-horizon 16 when serving one of those. Note the model's own config.json says
    # action_horizon: 50 -- that is max_action_horizon, the padded width the diffusion head
    # emits; the processor truncates to the embodiment's delta_indices before returning,
    # so the server already hands back exactly this many steps.
    p.add_argument("--action-horizon", type=int, default=8)
    # Comma-separated task stages. While running, Enter alone in the terminal advances
    # --lang-instruction to the next stage (typing any text + Enter switches to that
    # text instead). Empty = no Enter-to-advance; typed switching still works.
    p.add_argument("--lang-sequence", default="")
    # Must match the dataset recording rate (pick_box_2 meta/info.json -> fps = 30),
    # otherwise the chunk is played back at the wrong speed.
    p.add_argument("--control-hz", type=float, default=30.0)
    # Start the next chunk once only this many planned steps remain, so the policy
    # round trip overlaps with executing the current chunk's tail rather than stalling
    # the arm at hold. This checkpoint predicts the arms as RELATIVE actions, so a
    # chunk's displacement accumulates toward its END -- replanning too early throws
    # away the part of the chunk that carries the motion, and the arm looks sluggish.
    # Set it to ceil(measured_inference_s * control_hz); read the measurement off the
    # "inference N ms vs budget M ms" log line. 0 = drain the chunk fully, then replan
    # (the arm holds during every round trip).
    p.add_argument("--replan-at", type=int, default=0)
    # Shift a landing chunk by (measured state - the state it was planned from), so
    # overlapped replanning does not command the arm back to where it was when the
    # request went out. Only meaningful with --replan-at > 0. See _build_plan.
    p.add_argument(
        "--replan-anchor-compensation",
        action=argparse.BooleanOptionalAction,
        default=True,
    )
    # Ask the policy server what checkpoint it is serving and refuse to start if its
    # action horizon or video keys disagree with this bridge. See _verify_server_matches.
    p.add_argument(
        "--verify-server", action=argparse.BooleanOptionalAction, default=True
    )
    # Ignore gripper target changes smaller than this (rad); see _apply_safety. The
    # default is derived from pick_box_2's own action traces -- at 0.004 no recorded
    # grasp frame is reproduced more than 0.005 rad off. 0 disables the filter.
    p.add_argument("--gripper-deadband", type=float, default=0.004)
    # Grasp guard (RIGHT gripper, larger = more closed); see _update_grasp_guard.
    # Comma-separated instructions during which the right jaw must hold an object --
    # the "carry" stage, e.g. place_blackbox. Empty (default) = guard off.
    # Threshold defaults are from blackbox_pick_and_place (right jaw over 78 place demos:
    # held 0.0281..0.0333, empty jaw tracks its command within ~0.001, release command
    # < 0.025 for >= 6 frames). Re-derive them for any other object or gripper.
    p.add_argument("--grasp-guard-tasks", default="")
    # Minimum right-gripper command while armed. Well past the box stop (~0.0295) so the
    # grip is firm, and above --grasp-drop-above so an empty jaw is detectable.
    p.add_argument("--grasp-squeeze-floor", type=float, default=0.040)
    # Jaw position band that means "object in the jaw" when the guard arms.
    p.add_argument("--grasp-held-min", type=float, default=0.026)
    # Jaw closed past this while armed = the object is gone.
    p.add_argument("--grasp-drop-above", type=float, default=0.036)
    p.add_argument("--grasp-drop-ticks", type=int, default=3)
    # A policy target below this for --grasp-release-steps consecutive steps is a
    # deliberate release: the floor lets go and the guard disarms.
    p.add_argument("--grasp-release-below", type=float, default=0.025)
    p.add_argument("--grasp-release-steps", type=int, default=3)
    p.add_argument("--watchdog-timeout-s", type=float, default=2.0)
    # Treat a camera/joint input as unusable once its last message is this old. Guards
    # against a dead publisher: without it the bridge keeps feeding the policy the last
    # frame forever and the arm sits still with nothing logged. 0 disables the check.
    p.add_argument("--input-timeout-s", type=float, default=1.0)

    p.add_argument("--validation-mode", choices=["hold", "full"], default="full")
    p.add_argument("--run-validation-suite", action="store_true")
    p.add_argument("--phase-seconds", type=float, default=12.0)

    # Follower state topics, verbatim from the dataset's ros2_topics.json ->
    # follower_state_topic. These are the joints the policy conditions on.
    p.add_argument("--joint-state-topic", default="/joint_states")
    p.add_argument("--left-joint-state-topic", default="/LeftArmSystem_ordered_joint_states")
    p.add_argument("--right-joint-state-topic", default="/RightArmSystem_ordered_joint_states")
    # /joint_cmd is the real command entry point on this robot: joint_command_limiter
    # subscribes to it (sensor_msgs/JointState) and fans out to the arm and gripper
    # *_mit_controller/joint_trajectory topics. The follower_cmd_topic entries in the
    # dataset's ros2_topics.json are those downstream controller topics, not the input.
    p.add_argument("--cmd-topic", default="/joint_cmd")
    # Order of `name`/`position` in the published JointState. See publish_indices.
    p.add_argument(
        "--publish-joint-order", choices=["left_first", "right_first"], default="left_first"
    )
    # Topic defaults are the base (raw) topics behind the dataset's recorded
    # camera_topics in ros2_topics.json; "/compressed" is appended automatically
    # when --image-transport compressed is used (the default, since the dataset was
    # recorded from the compressed variants).
    p.add_argument("--world-topic", default="/camera/world/color/image_raw")
    p.add_argument("--right-wrist-topic", default="/right/camera/color/image_raw")
    p.add_argument("--left-wrist-topic", default="/left/camera/color/image_raw")
    p.add_argument("--image-transport", choices=["compressed", "raw"], default="compressed")
    # Cap each frame's longest edge before sending it to the policy server; 0 disables.
    # Only ever downscales. NOTE for this checkpoint: the cameras publish 320x240
    # (meta/info.json video shapes) and the server's own preprocessing resizes the
    # SHORTEST edge to 256. A cap of 256 therefore shrinks 320x240 to 256x192, and the
    # server upsamples it back -- a resampling round trip the training data never went
    # through. 0 (or 320) feeds the server the same 320x240 frames the dataset holds.
    p.add_argument("--image-max-edge", type=int, default=0)
    # Resize every frame to exactly WxH before sending it, reproducing what
    # custom_v3format_dataset/recorder.py did when the dataset was written:
    # cv2.resize(frame, (W, H), INTER_AREA), with no aspect preservation and no crop.
    # pick_box_2 is 320x240 on all three cameras while the live wrists publish 848x480,
    # so leaving this off feeds the policy a 16:9 view of a scene it only ever saw
    # squashed to 4:3 -- and makes every inference slower. Set to "none" to disable and
    # fall back to --image-max-edge. RETRAINED ON A DIFFERENT RESOLUTION? Match the new
    # meta/info.json video shape here.
    p.add_argument("--image-size", default="320x240")

    # Video modality keys the checkpoint's processor expects, verbatim from
    # processor_config.json -> modality_configs -> openarm_b1 -> video.
    p.add_argument("--world-camera-key", default="world")
    p.add_argument("--right-wrist-camera-key", default="wrist_right")
    p.add_argument("--left-wrist-camera-key", default="wrist_left")

    # IMPORTANT: key order MUST be left-first to match the slice indices in
    # __init__ (policy_left_arm_indices=[0..6], left_gripper=7, right_arm=[8..14],
    # right_gripper=15) and the action concatenation order in _extract_action_vec16.
    # The checkpoint's `left_arm` group is the physical left arm: meta/modality.json
    # slices left_arm out of flat indices 0:7, and meta/info.json names those dims
    # left_joint_1..7. Joint names below are those recorded names verbatim.
    p.add_argument(
        "--state-obs-keys-csv",
        default=(
            "left_joint_1,left_joint_2,left_joint_3,left_joint_4,left_joint_5,left_joint_6,left_joint_7,left_gripper_left_joint,"
            "right_joint_1,right_joint_2,right_joint_3,right_joint_4,right_joint_5,right_joint_6,right_joint_7,right_gripper_right_joint"
        ),
    )
    p.add_argument(
        "--action-keys-csv",
        default=(
            "left_joint_1,left_joint_2,left_joint_3,left_joint_4,left_joint_5,left_joint_6,left_joint_7,left_gripper_left_joint,"
            "right_joint_1,right_joint_2,right_joint_3,right_joint_4,right_joint_5,right_joint_6,right_joint_7,right_gripper_right_joint"
        ),
    )

    # Safety clamp limits, left-first order to match the key CSVs above:
    #   left_arm(7) + left_gripper(1) + right_arm(7) + right_gripper(1)
    #
    # Derived DIRECTLY from THIS checkpoint's baked training statistics
    # (pick_box_2_8chunk/checkpoint-50000/experiment_cfg/dataset_statistics.json ->
    # openarm_b1, verified identical to the union over the dataset's 220 parquet
    # episodes / 121 000 frames as it stands today), so inference
    # is clamped to the same value range the model was trained on. Per joint the
    # bound is the union of the recorded action and state ranges, widened by
    # max(10% of range, 0.05 rad) for arms and by 0.01 rad for grippers -- except the
    # right gripper's lower bound, which is floored at 0.0 because its travel starts
    # there and a negative command is meaningless.
    #
    # Note the gripper signs, which are what a hand-written limit usually gets wrong
    # here: the LEFT gripper's recorded range is NEGATIVE (-0.044..0.0) and the RIGHT
    # gripper's is POSITIVE (0.0..0.044, 0.044 = open, ~0 = grasped). Clamping either
    # to the other's sign pins that gripper and it never actuates.
    #
    # RE-DERIVED FOR THE 220-EPISODE pick_box_2 THAT pick_box_2_8chunk WAS TRAINED ON.
    # The limits from the earlier 101-episode snapshot (the outputs/pick_box_2 16-step
    # run) are NOT usable here -- the added episodes widened almost every joint, and
    # those older bounds are on the WRONG SIDE of this checkpoint's own range:
    #   left_joint_6  was floored at +0.11041, this checkpoint reaches -0.28899
    #                 (the floor alone forces the joint 0.40 rad the wrong way),
    #   left_joint_2  was capped  at -0.12948, this checkpoint reaches +0.08071,
    #   left_joint_1  was capped  at +0.05767, this checkpoint reaches +0.19858,
    #   left_joint_5  was capped  at +0.13283, this checkpoint reaches +0.34927,
    #   left_gripper  was capped  at -0.03393, so it could never open past that,
    #   right_joint_5 was floored at +1.13821, this checkpoint reaches +0.71468,
    #   right_joint_4 was floored at +0.62330, this checkpoint reaches +0.28232.
    # A clamp that sits on the wrong side of the target does not merely freeze the
    # joint: the rate limiter walks it max_step_delta per step toward the clamp and
    # holds it there, so the arm drives steadily to a pose the policy never asked for
    # and every subsequent chunk conditions on that off-distribution state.
    #
    # To re-derive for another checkpoint:
    #   python - <<'EOF'
    #   import json
    #   d = json.load(open("<ckpt>/experiment_cfg/dataset_statistics.json"))["openarm_b1"]
    #   for g in ("left_arm", "left_gripper", "right_arm", "right_gripper"):
    #       lo = [min(a, s) for a, s in zip(d["action"][g]["min"], d["state"][g]["min"])]
    #       hi = [max(a, s) for a, s in zip(d["action"][g]["max"], d["state"][g]["max"])]
    #       m = [0.01 if "gripper" in g else max(0.1 * (h - l), 0.05) for l, h in zip(lo, hi)]
    #       print(g, [round(l - e, 5) for l, e in zip(lo, m)], [round(h + e, 5) for h, e in zip(hi, m)])
    #   EOF
    p.add_argument(
        "--joint-min-csv",
        default=(
            "-0.06736,-0.27297,-0.12670,-0.06278,-0.16198,-0.28899,-0.12670,-0.05418,"
            "-1.27588,-0.36374,-0.70903,0.28232,0.71468,-0.94800,-1.70379,0.0"
        ),
    )
    p.add_argument(
        "--joint-max-csv",
        default=(
            "0.19858,0.08071,0.05515,0.06074,0.34927,0.22027,0.17989,0.01021,"
            "1.15534,0.24057,1.24613,1.93225,1.96825,1.44501,1.45682,0.05503"
        ),
    )
    # Per-step rate limit, left-first, per control STEP at --control-hz 30 (the dataset
    # fps). Derived from the dataset itself: 1.5x the per-joint p99.9 of the recorded
    # frame-to-frame action delta over pick_box_2's 220 episodes (120 780 steps),
    # floored at 0.02. Scale by (30 / control_hz) if you change the rate. The gripper
    # entries (0.06) exceed the gripper's whole 0.044 rad travel on purpose, so a grasp
    # is never throttled (the right gripper's own p99.9 is only 0.0069, max 0.0194).
    #
    # A flat limit is wrong for this task: the right arm's fast joints demonstrate up to
    # 0.130 rad/frame at p99.9 (right_joint_7) and 0.117 (right_joint_6), so a uniform
    # 0.03 would throttle the pick to a quarter of the speed it was trained at, while
    # the left arm -- which now travels a real distance, just slowly -- never exceeds
    # 0.0031 per frame, so its 0.02 floor is pure headroom.
    #
    # To re-derive for another dataset:
    #   import glob, numpy as np, pandas as pd
    #   D = np.concatenate([np.abs(np.diff(np.stack(
    #           pd.read_parquet(f, columns=["action"])["action"].values), axis=0))
    #       for f in sorted(glob.glob("<dataset>/data/chunk-*/episode_*.parquet"))])
    #   print(np.maximum(np.round(1.5 * np.percentile(D, 99.9, axis=0), 3), 0.02))
    p.add_argument(
        "--max-step-delta-csv",
        default=(
            "0.02,0.02,0.02,0.02,0.02,0.02,0.02,0.06,"
            "0.106,0.039,0.097,0.094,0.067,0.175,0.196,0.06"
        ),
    )
    # Episode-START range, left-first -- NOT the whole-episode range above. Checked once
    # at startup and never used to clamp anything. Derived from pick_box_2 as the p01/p99
    # of each joint's value in frame 0 of all 220 episodes, widened by
    # max(10% of that span, 0.05) -- the same padding recipe as --joint-min-csv.
    #
    # The right arm starts REACHING FORWARD in every episode of this dataset
    # (right_joint_4 ~ 1.68, right_joint_5 ~ 1.43) while the left arm starts at zero.
    # Homing both arms to zero is therefore wrong for the right arm only, which is
    # exactly what "the right arm goes backwards" looks like on this robot.
    #
    # To re-derive for another dataset:
    #   import glob, numpy as np, pandas as pd
    #   S = np.array([np.stack(pd.read_parquet(f, columns=["observation.state"])
    #                          ["observation.state"].values)[0]
    #                 for f in sorted(glob.glob("<dataset>/data/chunk-*/episode_*.parquet"))])
    #   p01, p99 = np.percentile(S, 1, axis=0), np.percentile(S, 99, axis=0)
    #   pad = np.maximum(0.1 * (p99 - p01), 0.05)
    #   print(np.round(p01 - pad, 5)); print(np.round(p99 + pad, 5))
    p.add_argument(
        "--start-pose-min-csv",
        default=(
            "-0.06469,-0.24703,-0.12496,-0.06278,-0.06044,-0.28320,-0.12107,-0.09407,"
            "-1.02761,-0.24778,-0.21205,1.34733,1.20929,-0.28391,0.23467,-0.01401"
        ),
    )
    p.add_argument(
        "--start-pose-max-csv",
        default=(
            "0.19858,0.05019,0.05424,0.05844,0.34126,0.21537,0.17417,0.05000,"
            "-0.27390,0.17448,0.30273,1.82643,1.64513,0.16761,1.23695,0.09401"
        ),
    )
    # Median over frame 0 of all 220 pick_box_2 episodes -- the pose to park the arms at
    # before starting. Reported by the start-pose warning; never published.
    p.add_argument(
        "--start-pose-home-csv",
        default=(
            "-0.00019,-0.16785,-0.05436,0.00286,0.00324,-0.00153,0.07572,-0.04393,"
            "-0.59911,-0.02213,0.02041,1.68326,1.43053,-0.03586,0.69848,0.04376"
        ),
    )
    return p


def main() -> None:
    args = build_arg_parser().parse_args()
    rclpy.init()
    node = Gr00TOpenArmB1RosBridge(args)
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
