#!/usr/bin/env bash
# System B (robot machine): ROS2 bridge for the openarm_b1 / pick_box_2 checkpoint.
#
# Start System A (the GPU box) first:
#   bash gr00t/eval/real_robot/OPENARM_B1/ui/run_gr00t_server_openarm_b1.sh
#
# Then here:
#   bash gr00t/eval/real_robot/OPENARM_B1/run_ros2_openarm_b1_eval.sh
#   POLICY_HOST=192.168.x.x bash gr00t/eval/real_robot/OPENARM_B1/run_ros2_openarm_b1_eval.sh
#
# Every default below is the bridge's own default, which is derived from
# outputs/pick_box_2_8chunk/checkpoint-50000's baked configs and the pick_box_2 dataset
# meta. They are spelled out here so each one is overridable from the environment
# without editing Python.
set -euo pipefail

REPO_ROOT="${REPO_ROOT:-/home/physicalai/Desktop/I/groot}"
cd "$REPO_ROOT"
source .venv/bin/activate

# The robot's arm/camera nodes live on ROS_DOMAIN_ID=33. Pin it here instead of
# inheriting it: a VS Code / non-interactive shell can export a different domain, and
# the bridge then lands on an empty DDS graph and sits forever in "Waiting for inputs"
# even though `ros2 topic echo` works in your own terminal.
export ROS_DOMAIN_ID="${ROS_DOMAIN_ID:-33}"
export RMW_IMPLEMENTATION="${RMW_IMPLEMENTATION:-rmw_cyclonedds_cpp}"
if [ -z "${AMENT_PREFIX_PATH:-}" ]; then
  set +u  # ROS setup.bash trips over unbound vars
  # shellcheck disable=SC1091
  source /opt/ros/humble/setup.bash
  set -u
fi

POLICY_HOST="${POLICY_HOST:-127.0.0.1}"
POLICY_PORT="${POLICY_PORT:-5555}"
# 30 Hz = pick_box_2 meta/info.json fps. 8 = the action delta_indices of the
# checkpoint these defaults target, outputs/pick_box_2_8chunk/checkpoint-50000
# (its experiment_cfg/conf.yaml lists delta_indices [0..7]). The model's own
# config.json action_horizon: 50 is the padded max, truncated by the processor to
# the embodiment's 8 before the server replies.
# Serving the older 16-step run outputs/pick_box_2/checkpoint-50000 instead? Set
# ACTION_HORIZON=16 -- and re-derive the limits below from THAT checkpoint's
# dataset_statistics.json, because they are not interchangeable.
CONTROL_HZ="${CONTROL_HZ:-30}"
ACTION_HORIZON="${ACTION_HORIZON:-8}"
WATCHDOG_TIMEOUT_S="${WATCHDOG_TIMEOUT_S:-2.0}"
INPUT_TIMEOUT_S="${INPUT_TIMEOUT_S:-1.0}"
VALIDATION_MODE="${VALIDATION_MODE:-full}"
RUN_VALIDATION_SUITE="${RUN_VALIDATION_SUITE:-false}"
PHASE_SECONDS="${PHASE_SECONDS:-12.0}"

# Must match meta/tasks.jsonl verbatim -- pick_box_2 has exactly one task (task_index
# 0). Feeding a different sentence is an unnecessary distribution shift on the
# language input.
LANG_INSTRUCTION="${LANG_INSTRUCTION:-pick the brown box on the right hand side, place it in to the center of the box}"

# ros2_topics.json -> follower_state_topic
LEFT_JOINT_STATE_TOPIC="${LEFT_JOINT_STATE_TOPIC:-/LeftArmSystem_ordered_joint_states}"
RIGHT_JOINT_STATE_TOPIC="${RIGHT_JOINT_STATE_TOPIC:-/RightArmSystem_ordered_joint_states}"
JOINT_STATE_TOPIC="${JOINT_STATE_TOPIC:-/joint_states}"
# /joint_cmd is the command entry point; joint_command_limiter fans it out to the
# *_mit_controller/joint_trajectory topics listed as follower_cmd_topic.
CMD_TOPIC="${CMD_TOPIC:-/joint_cmd}"
PUBLISH_JOINT_ORDER="${PUBLISH_JOINT_ORDER:-left_first}"

# ros2_topics.json -> camera_topics, minus the "/compressed" suffix the bridge
# re-appends itself when IMAGE_TRANSPORT=compressed (which is how they were recorded).
WORLD_TOPIC="${WORLD_TOPIC:-/world/camera/color/image_raw}"
RIGHT_WRIST_TOPIC="${RIGHT_WRIST_TOPIC:-/right/camera/color/image_raw}"
LEFT_WRIST_TOPIC="${LEFT_WRIST_TOPIC:-/left/camera/color/image_raw}"
IMAGE_TRANSPORT="${IMAGE_TRANSPORT:-compressed}"
# pick_box_2 stores every camera at 320x240 because custom_v3format_dataset/recorder.py
# squashed each frame with cv2.resize(frame, (320, 240), INTER_AREA) -- no aspect
# preservation, no crop -- while the live cameras publish 640x480 (world) and 848x480
# (wrists). Reproducing that exact resize is what makes inference see the geometry it
# trained on; without it the two wrist views arrive as 16:9 of a scene the model only
# ever saw as 4:3. Set to "none" to disable and fall back to IMAGE_MAX_EDGE.
IMAGE_SIZE="${IMAGE_SIZE:-320x240}"
# Legacy aspect-preserving long-edge cap. Leave at 0; IMAGE_SIZE supersedes it.
IMAGE_MAX_EDGE="${IMAGE_MAX_EDGE:-0}"

# processor_config.json -> modality_configs -> openarm_b1 -> video -> modality_keys
WORLD_CAMERA_KEY="${WORLD_CAMERA_KEY:-world}"
RIGHT_WRIST_CAMERA_KEY="${RIGHT_WRIST_CAMERA_KEY:-wrist_right}"
LEFT_WRIST_CAMERA_KEY="${LEFT_WRIST_CAMERA_KEY:-wrist_left}"

# LEFT-first, matching the checkpoint's modality_keys and meta/modality.json.
# Reordering these without also reordering the CSVs below silently swaps the arms.
JOINT_KEYS="left_joint_1,left_joint_2,left_joint_3,left_joint_4,left_joint_5,left_joint_6,left_joint_7,left_gripper_left_joint,right_joint_1,right_joint_2,right_joint_3,right_joint_4,right_joint_5,right_joint_6,right_joint_7,right_gripper_right_joint"
STATE_OBS_KEYS_CSV="${STATE_OBS_KEYS_CSV:-$JOINT_KEYS}"
ACTION_KEYS_CSV="${ACTION_KEYS_CSV:-$JOINT_KEYS}"

# outputs/pick_box_2_8chunk/checkpoint-50000/experiment_cfg/dataset_statistics.json ->
# openarm_b1: union of the action and state ranges widened by max(10% of range, 0.05)
# for arms / 0.01 for grippers (right-gripper min floored at 0.0 -- a negative command
# over-closes the jaw against its stop).
#
# These MUST come from the checkpoint you are actually serving. The values that used
# to sit here were the earlier 101-episode pick_box_2 snapshot, and against this
# checkpoint they land on the WRONG SIDE of the trained range, so the rate limiter
# walks the joint to the clamp and pins it there:
#   left_joint_6  was floored at +0.11041, this checkpoint reaches -0.28899
#   left_joint_2  was capped  at -0.12948, this checkpoint reaches +0.08071
#   left_joint_1  was capped  at +0.05767, this checkpoint reaches +0.19858
#   left_gripper  was capped  at -0.03393, so it could never open
#   right_joint_5 was floored at +1.13821, this checkpoint reaches +0.71468
# Note the gripper signs -- LEFT is NEGATIVE (-0.044..0.0), RIGHT is POSITIVE
# (0.044 = open, ~0 = grasped). Swapping them pins that gripper for the whole run.
JOINT_MIN_CSV="${JOINT_MIN_CSV:--0.06736,-0.27297,-0.12670,-0.06278,-0.16198,-0.28899,-0.12670,-0.05418,-1.27588,-0.36374,-0.70903,0.28232,0.71468,-0.94800,-1.70379,0.0}"
JOINT_MAX_CSV="${JOINT_MAX_CSV:-0.19858,0.08071,0.05515,0.06074,0.34927,0.22027,0.17989,0.01021,1.15534,0.24057,1.24613,1.93225,1.96825,1.44501,1.45682,0.05503}"
# 1.5x the per-joint p99.9 recorded frame-to-frame action delta over pick_box_2's
# 220 episodes, floored at 0.02; grippers pinned to 0.06 so a grasp is never throttled.
# Scale by (30 / CONTROL_HZ) if you change the rate.
MAX_STEP_DELTA_CSV="${MAX_STEP_DELTA_CSV:-0.02,0.02,0.02,0.02,0.02,0.02,0.02,0.06,0.106,0.039,0.097,0.094,0.067,0.175,0.196,0.06}"

# Replanning is disabled by default (REPLAN_AT=0): each 8-step chunk runs to
# completion, then the next is predicted, so the arm holds for the duration of every
# round trip. Set REPLAN_AT=ceil(measured_inference_s * CONTROL_HZ) -- read the
# measurement off the "inference N ms" log line -- to overlap inference with the tail
# of the current chunk. Because the arms are RELATIVE actions the displacement
# accumulates toward the END of a chunk, so an oversized value throws away the motion.
REPLAN_AT="${REPLAN_AT:-0}"

extra_flags=()
if [ "$RUN_VALIDATION_SUITE" = "true" ]; then
  extra_flags+=(--run-validation-suite)
fi

# The three CSV limit flags use --flag=value, not --flag value: JOINT_MIN_CSV starts
# with a minus sign and argparse would otherwise read it as an option name.
python gr00t/eval/real_robot/OPENARM_B1/eval_openarm_b1_ros2.py \
  --joint-min-csv="$JOINT_MIN_CSV" \
  --joint-max-csv="$JOINT_MAX_CSV" \
  --max-step-delta-csv="$MAX_STEP_DELTA_CSV" \
  --policy-host "$POLICY_HOST" \
  --policy-port "$POLICY_PORT" \
  --control-hz "$CONTROL_HZ" \
  --action-horizon "$ACTION_HORIZON" \
  --replan-at "$REPLAN_AT" \
  --watchdog-timeout-s "$WATCHDOG_TIMEOUT_S" \
  --input-timeout-s "$INPUT_TIMEOUT_S" \
  --validation-mode "$VALIDATION_MODE" \
  --phase-seconds "$PHASE_SECONDS" \
  --lang-instruction "$LANG_INSTRUCTION" \
  --joint-state-topic "$JOINT_STATE_TOPIC" \
  --left-joint-state-topic "$LEFT_JOINT_STATE_TOPIC" \
  --right-joint-state-topic "$RIGHT_JOINT_STATE_TOPIC" \
  --cmd-topic "$CMD_TOPIC" \
  --publish-joint-order "$PUBLISH_JOINT_ORDER" \
  --world-topic "$WORLD_TOPIC" \
  --right-wrist-topic "$RIGHT_WRIST_TOPIC" \
  --left-wrist-topic "$LEFT_WRIST_TOPIC" \
  --image-transport "$IMAGE_TRANSPORT" \
  --image-max-edge "$IMAGE_MAX_EDGE" \
  --image-size "$IMAGE_SIZE" \
  --world-camera-key "$WORLD_CAMERA_KEY" \
  --right-wrist-camera-key "$RIGHT_WRIST_CAMERA_KEY" \
  --left-wrist-camera-key "$LEFT_WRIST_CAMERA_KEY" \
  --state-obs-keys-csv "$STATE_OBS_KEYS_CSV" \
  --action-keys-csv "$ACTION_KEYS_CSV" \
  "${extra_flags[@]}"
