"""
GR1 Real-Robot / Offline Evaluation Script

Adapted from gr00t/eval/real_robot/SO100/eval_so100.py to support GR1
Both realtime (PolicyClient) and offline dataset playback (LeRobotEpisodeLoader)
Default dataset path set to the path you provided.
"""

from dataclasses import asdict, dataclass
import logging
from pprint import pformat
import time
from typing import Any, Dict, List

import numpy as np
from gr00t.policy.server_client import PolicyClient
from gr00t.data.dataset.lerobot_episode_loader import LeRobotEpisodeLoader
from gr00t.data.embodiment_tags import EmbodimentTag
from lerobot.utils.utils import init_logging, log_say
import tyro


def recursive_add_extra_dim(obs: Dict) -> Dict:
    for key, val in obs.items():
        if isinstance(val, np.ndarray):
            obs[key] = val[np.newaxis, ...]
        elif isinstance(val, dict):
            obs[key] = recursive_add_extra_dim(val)
        else:
            obs[key] = [val]
    return obs


class Gr1Adapter:
    """Adapter to convert between dataset/robot observations and GR00T policy API."""

    def __init__(self, policy: PolicyClient | None = None, lang_instruction: str | None = None):
        self.policy = policy
        # GR1 modality keys (from examples/GR1/gr1_config.py)
        self.camera_keys = ["ego_view"]
        self.state_keys = ["left_arm", "right_arm", "left_hand", "right_hand"]
        self.lang_key = "annotation.human.action.task_description"
        self.lang_instruction = lang_instruction or "Perform the task"

    def obs_to_policy_inputs(self, obs: Dict[str, Any]) -> Dict:
        model_obs = {}
        # Cameras: expect obs to contain ego_view as an ndarray (T,H,W,C) or (H,W,C)
        model_obs["video"] = {k: obs.get(k, obs.get(f"video.{k}", np.zeros((1, 1, 256, 256, 3), dtype=np.uint8))))
                             for k in self.camera_keys}

        # States: expect each key to be an array (T, D) or (D,)
        model_obs["state"] = {k: obs.get(k, obs.get(f"state.{k}", np.zeros((1, 1), dtype=np.float32)))
                               for k in self.state_keys}

        # Language
        model_obs["language"] = {self.lang_key: obs.get("lang", [[self.lang_instruction]])}

        # Ensure batch/time dims: call twice so shapes become (1,1,...)
        model_obs = recursive_add_extra_dim(model_obs)
        model_obs = recursive_add_extra_dim(model_obs)
        return model_obs

    def decode_action_chunk(self, chunk: Dict, t: int) -> Dict[str, Any]:
        # For GR1 we expect action keys matching state_keys. We'll flatten per-key outputs.
        action_dict = {}
        for key in chunk:
            # chunk[key]: (B, T, D)
            arr = chunk[key][0][t]
            action_dict[f"action.{key}"] = arr
        return action_dict

    def get_action(self, obs: Dict) -> List[Dict[str, Any]]:
        model_input = self.obs_to_policy_inputs(obs)
        action_chunk, info = self.policy.get_action(model_input)
        any_key = next(iter(action_chunk.keys()))
        horizon = action_chunk[any_key].shape[1]
        return [self.decode_action_chunk(action_chunk, t) for t in range(horizon)]


@dataclass
class EvalConfig:
    """Configuration for GR1 evaluation."""

    # Mode: realtime (connect to Policy server) or offline (dataset playback)
    mode: str = "realtime"  # or 'offline'
    policy_host: str = "localhost"
    policy_port: int = 5555
    lang_instruction: str = "Perform the task"

    # Offline dataset path (default to user-provided path)
    dataset_path: str = "/home/physicalai/Desktop/I/gr1_microwave/lerobot"
    traj_ids: list[int] = (0,)
    steps: int = 200
    embodiment_tag: EmbodimentTag = EmbodimentTag.GR1


def run_offline_eval(cfg: EvalConfig):
    logging.info(f"Running offline eval on dataset: {cfg.dataset_path}")
    policy = PolicyClient(host=cfg.policy_host, port=cfg.policy_port)
    adapter = Gr1Adapter(policy, lang_instruction=cfg.lang_instruction)

    # Use LeRobotEpisodeLoader to read trajectories
    from gr00t.data.dataset.lerobot_episode_loader import LeRobotEpisodeLoader

    dataset = LeRobotEpisodeLoader(dataset_path=cfg.dataset_path, modality_configs=policy.get_modality_config())
    logging.info(f"Dataset length: {len(dataset)}")

    for traj_id in cfg.traj_ids:
        if traj_id >= len(dataset):
            logging.warning(f"Trajectory {traj_id} out of range, skipping")
            continue
        traj = dataset[traj_id]
        logging.info(f"Evaluating traj {traj_id}, len={len(traj)}")
        for step_idx in range(0, min(cfg.steps, len(traj))):
            # Build observation dictionary expected by adapter
            obs = {}
            # states in traj are stored as columns like 'state.left_arm'
            for key in adapter.state_keys:
                col = f"state.{key}"
                if col in traj.columns:
                    obs[key] = np.vstack(traj[col])[:1]
            # video
            video_key = "ego_view"
            if f"video.{video_key}" in traj.columns:
                obs[video_key] = np.array(traj[f"video.{video_key}"])[0]
            obs["lang"] = cfg.lang_instruction

            actions = adapter.get_action(obs)
            logging.info(f"Step {step_idx} actions (first timestep): {actions[0]}")


def run_realtime_eval(cfg: EvalConfig):
    logging.info("Starting realtime GR1 eval (PolicyClient)")
    policy_client = PolicyClient(host=cfg.policy_host, port=cfg.policy_port)
    adapter = Gr1Adapter(policy_client, lang_instruction=cfg.lang_instruction)

    log_say("Policy ready", play_sounds=False, blocking=False)

    while True:
        # For real robot mode the script expects a `lerobot` Robot instance to supply obs.
        # We keep this loop simple: user should replace the robot-observation acquisition.
        # Example placeholder observation (zeros) - replace with `robot.get_observation()` in deployment.
        obs = {"ego_view": np.zeros((1, 1, 256, 256, 3), dtype=np.uint8)}
        for k in adapter.state_keys:
            obs[k] = np.zeros((1, 1, 7), dtype=np.float32)
        obs["lang"] = cfg.lang_instruction

        actions = adapter.get_action(obs)
        for i, action in enumerate(actions):
            logging.info(f"Action[{i}]: {action}")
        time.sleep(0.05)


def main(cfg: EvalConfig):
    init_logging()
    logging.info(pformat(asdict(cfg)))

    if cfg.mode == "offline":
        run_offline_eval(cfg)
    else:
        run_realtime_eval(cfg)


if __name__ == "__main__":
    config = tyro.cli(EvalConfig)
    main(config)
