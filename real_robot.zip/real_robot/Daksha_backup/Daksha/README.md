# DAKSHA Real-Robot Evaluation

Inference / evaluation for the **daksha** embodiment on GR00T **N1.6**.

Everything in this folder is wired to one concrete run, and every default is read
off that run's own artifacts rather than typed by hand:

| | |
|---|---|
| Checkpoint | `/home/physicalai/Desktop/I/groot/outputs/pick_box_2_8chunk/checkpoint-50000` |
| Dataset | `/home/physicalai/Desktop/I/barani/pick_box_2` (220 eps, 121 000 frames, 30 fps, 320x240) |
| Embodiment tag | `daksha` (`DAKSHA`) |
| Modality config | `examples/Daksha/pick_box_config.py` |
| State / action | 16 DoF, **LEFT-first**: `left_arm(7) + left_gripper(1) + right_arm(7) + right_gripper(1)` |
| Cameras | **3**: `world`, `wrist_right`, `wrist_left` |
| Action horizon | **8** (`delta_indices` `[0..7]`) · Control rate 30 Hz |
| Action representation | arms RELATIVE, grippers ABSOLUTE (`use_relative_action=True`) |

The tag id needs no configuration: `daksha: 10` is already in
`gr00t/model/gr00t_n1d6/processing_gr00t_n1d6.py`, and the checkpoint ships its
own `embodiment_id.json` that agrees with it. The processor also bakes the
modality config in, so serving needs no `--modality-config-path`.

## Files

- `eval_daksha_ros2.py` — **the ROS2 hardware bridge** (this is the inference path)
- `run_ros2_daksha_eval.sh` — launcher for it, every default overridable by env var
- `ui/` — offline, no-robot validation tools (see `ui/README.md`)
- `eval_daksha.py` — older LeRobot (non-ROS2) bridge, still on the 4-camera
  `zed_right/zed_left/...` layout. It does **not** match the `pick_box_2_8chunk`
  checkpoint.

> The safety clamps, step limits and action horizon in this folder are derived from
> **`outputs/pick_box_2_8chunk/checkpoint-50000`**. They are not interchangeable with
> the older `outputs/pick_box_2` (16-step) run: that one was trained when the dataset
> held 101 episodes, and its narrower bounds sit on the wrong side of this
> checkpoint's trained range on several joints (notably `left_joint_6`, floored at
> +0.110 where this checkpoint reaches −0.289), which drives the arm steadily into
> the clamp. Serving a different run means re-deriving all three CSVs from *its*
> `experiment_cfg/dataset_statistics.json`.

## 1) System A (GPU box): start the policy server

```bash
bash gr00t/eval/real_robot/Daksha/ui/run_gr00t_server_daksha.sh
```

or by hand:

```bash
cd ~/Desktop/I/groot && source .venv/bin/activate

python gr00t/eval/run_gr00t_server.py \
  --model_path /home/physicalai/Desktop/I/groot/outputs/pick_box_2_8chunk/checkpoint-50000 \
  --embodiment-tag DAKSHA \
  --host 0.0.0.0 --port 5555
```

## 2) System B (robot machine): run the ROS2 bridge

```bash
POLICY_HOST=<SYSTEM_A_IP> bash gr00t/eval/real_robot/Daksha/run_ros2_daksha_eval.sh
```

The launcher pins `ROS_DOMAIN_ID=33` and sources ROS itself, because a
non-interactive shell can otherwise land on an empty DDS graph and sit forever in
`Waiting for inputs -> ...` while `ros2 topic echo` works fine in your terminal.

Topics come from the dataset's `ros2_topics.json`, so the bridge subscribes to
exactly what was recorded:

| role | topic |
|---|---|
| left follower state | `/LeftArmSystem_ordered_joint_states` |
| right follower state | `/RightArmSystem_ordered_joint_states` |
| `world` camera | `/world/camera/color/image_raw/compressed` |
| `wrist_right` camera | `/right/camera/color/image_raw/compressed` |
| `wrist_left` camera | `/left/camera/color/image_raw/compressed` |
| command out | `/joint_cmd` (`sensor_msgs/JointState`, left-first) |

Compressed transport is the default because that is how the data was recorded;
`--image-transport raw` drops the `/compressed` suffix automatically.

### Dry run without moving the robot

```bash
VALIDATION_MODE=hold bash gr00t/eval/real_robot/Daksha/run_ros2_daksha_eval.sh
# or alternate hold/full phases:
RUN_VALIDATION_SUITE=true PHASE_SECONDS=12 bash .../run_ros2_daksha_eval.sh
```

## 3) Offline validation (no robot)

```bash
bash gr00t/eval/real_robot/Daksha/ui/run_validation_daksha.sh      # CLI + HTML report
bash gr00t/eval/real_robot/Daksha/ui/run_validation_ui.sh              # browser studio
```

## Notes and gotchas

- **Ordering is LEFT-first.** `meta/modality.json` slices `left_arm` out of flat
  indices `0:7`, and the checkpoint's `modality_configs -> daksha` lists
  `left_arm, left_gripper, right_arm, right_gripper` in that order. The bridge
  refuses to start if the key CSVs are reordered, because a silent left/right swap
  looks like "the policy won't move the gripper" rather than like an error.
- **Gripper signs are opposite.** The left gripper is a negative **constant**
  (`-0.044`, action `min == max`, std `0.0`), the right gripper's range is positive
  (`0.0 … 0.044`, where `0.044` = open and `~0` = grasped). Clamping one to the
  other's sign pins it shut. Because the left gripper's range is degenerate, the
  processor floors its normalization range at `1e-8`, so the policy can only ever
  emit `-0.044` for it — the left gripper not actuating is the trained behaviour.
- **The left arm barely moves in `pick_box_2`.** Its whole recorded range is under
  0.16 rad per joint and the left gripper does not move at all; only the right arm
  performs the pick. A stationary left arm at inference is trained behaviour.
  It also means the left-side rows in the validation report have a meaningless
  MAE/range ratio — judge the model on the right-arm and right-gripper channels.
- **Clamp and rate limits are derived from this checkpoint**, not guessed:
  `joint_min/max` from `experiment_cfg/dataset_statistics.json`, and
  `max_step_delta` from 1.5× the per-joint p99.9 recorded frame-to-frame action
  delta over all 101 episodes. Both scripts carry the re-derivation snippet in a
  comment. **Retrained? Re-derive them** — limits from another dataset can be
  disjoint from this one's poses. `pick_box`'s old bounds, for instance, cut
  `pick_box_2`'s `left_joint_6` by 0.117 rad (its rest pose moved from ~0.0 to
  ~0.164), which walks the left arm off-distribution and corrupts the state the
  policy conditions on.
- **Replanning is off by default** (`REPLAN_AT=0`): each 16-step chunk runs to
  completion, so the arm holds during every inference round trip. Set
  `REPLAN_AT=ceil(inference_s * control_hz)` — read the value off the
  `inference N ms` log line — to overlap them. Because the arms are RELATIVE
  actions, displacement accumulates toward the END of a chunk, so an oversized
  value throws the motion away.
- Safety is always on: joint clamp, per-step delta limit, stale-input detection
  and a watchdog that falls back to hold.
