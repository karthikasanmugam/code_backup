"""
Daksha real-robot GR00T evaluation bridge (16 DoF + 4 cameras).

Implements:
- action adaptation: model action[16] -> robot 16 joint command dict
- joint clamp and per-step rate limiting
- watchdog fallback to hold pose
- validation modes: hold, full
"""

from dataclasses import asdict, dataclass
import logging
from pprint import pformat
import time
from typing import Any, Dict, List

import draccus
from gr00t.policy.server_client import PolicyClient
from lerobot.cameras.opencv.configuration_opencv import OpenCVCameraConfig  # noqa: F401
from lerobot.robots import (  # noqa: F401
    RobotConfig,
    make_robot_from_config,
)
from lerobot.utils.utils import init_logging, log_say
import numpy as np


def recursive_add_extra_dim(obs: Dict[str, Any]) -> Dict[str, Any]:
    for key, val in obs.items():
        if isinstance(val, np.ndarray):
            obs[key] = val[np.newaxis, ...]
        elif isinstance(val, dict):
            obs[key] = recursive_add_extra_dim(val)
        else:
            obs[key] = [val]
    return obs


def parse_csv_list(value: str) -> List[str]:
    return [x.strip() for x in value.split(",") if x.strip()]


def parse_csv_floats(value: str, expected_len: int, name: str) -> np.ndarray:
    vals = np.array([float(x.strip()) for x in value.split(",") if x.strip()], dtype=np.float32)
    if vals.shape[0] != expected_len:
        raise ValueError(f"{name} must have {expected_len} values, got {vals.shape[0]}: {value}")
    return vals


class DakshaHardwareAdapter:
    def __init__(self, cfg: "EvalConfig", policy: PolicyClient):
        self.cfg = cfg
        self.policy = policy

        self.state_obs_keys = parse_csv_list(cfg.state_obs_keys_csv)
        self.action_keys = parse_csv_list(cfg.action_keys_csv)

        if len(self.state_obs_keys) != 16:
            raise ValueError("state_obs_keys_csv must contain exactly 16 observation keys")
        if len(self.action_keys) != 16:
            raise ValueError("action_keys_csv must contain exactly 16 action keys")

        self.joint_min = parse_csv_floats(cfg.joint_min_csv, expected_len=16, name="joint_min_csv")
        self.joint_max = parse_csv_floats(cfg.joint_max_csv, expected_len=16, name="joint_max_csv")
        self.max_step_delta = parse_csv_floats(
            cfg.max_step_delta_csv, expected_len=16, name="max_step_delta_csv"
        )

        self.prev_cmd: np.ndarray | None = None
        self.last_policy_ok_time = 0.0

    def _obs_to_policy_inputs(self, obs: Dict[str, Any], lang: str) -> Dict[str, Any]:
        state16 = np.array([obs[k] for k in self.state_obs_keys], dtype=np.float32)

        model_obs: Dict[str, Any] = {
            "video": {
                "zed_right": obs[self.cfg.zed_right_camera_obs_key],
                "zed_left": obs[self.cfg.zed_left_camera_obs_key],
                "right_wrist": obs[self.cfg.right_wrist_camera_obs_key],
                "left_wrist": obs[self.cfg.left_wrist_camera_obs_key],
            },
            "state": {
                "right_arm": state16[:8],
                "left_arm": state16[8:16],
            },
            "language": {"annotation.human.task_description": lang},
        }
        model_obs = recursive_add_extra_dim(model_obs)
        model_obs = recursive_add_extra_dim(model_obs)
        return model_obs

    def _extract_action_vec16(self, action_chunk: Dict[str, Any], t: int) -> np.ndarray:
        if "right_arm" in action_chunk and "left_arm" in action_chunk:
            right = np.asarray(action_chunk["right_arm"][0][t], dtype=np.float32).reshape(-1)
            left = np.asarray(action_chunk["left_arm"][0][t], dtype=np.float32).reshape(-1)
            if right.shape[0] != 8 or left.shape[0] != 8:
                raise ValueError(
                    f"Unexpected action dims from policy: right_arm={right.shape}, left_arm={left.shape}"
                )
            return np.concatenate([right, left], axis=0)

        if "action.right_arm" in action_chunk and "action.left_arm" in action_chunk:
            right = np.asarray(action_chunk["action.right_arm"][0][t], dtype=np.float32).reshape(-1)
            left = np.asarray(action_chunk["action.left_arm"][0][t], dtype=np.float32).reshape(-1)
            if right.shape[0] != 8 or left.shape[0] != 8:
                raise ValueError(
                    f"Unexpected sim-wrapper dims: right_arm={right.shape}, left_arm={left.shape}"
                )
            return np.concatenate([right, left], axis=0)

        if "action" in action_chunk:
            vec = np.asarray(action_chunk["action"][0][t], dtype=np.float32).reshape(-1)
            if vec.shape[0] != 16:
                raise ValueError(f"Expected action[16], got action[{vec.shape[0]}]")
            return vec

        raise ValueError(f"Unsupported action chunk keys: {list(action_chunk.keys())}")

    def _read_hold_vec(self, obs: Dict[str, Any]) -> np.ndarray:
        return np.array([obs[k] for k in self.state_obs_keys], dtype=np.float32)

    def _apply_safety(self, target_vec16: np.ndarray, hold_vec16: np.ndarray, mode: str) -> np.ndarray:
        target = np.clip(target_vec16, self.joint_min, self.joint_max)

        if self.prev_cmd is None:
            self.prev_cmd = hold_vec16.copy()

        delta = np.clip(target - self.prev_cmd, -self.max_step_delta, self.max_step_delta)
        cmd = np.clip(self.prev_cmd + delta, self.joint_min, self.joint_max)

        if mode == "hold":
            cmd = hold_vec16.copy()
        elif mode == "full":
            pass
        else:
            raise ValueError(f"Unknown mode: {mode}")

        self.prev_cmd = cmd.copy()
        return cmd

    def _to_robot_action_dict(self, cmd_vec16: np.ndarray) -> Dict[str, float]:
        return {name: float(cmd_vec16[i]) for i, name in enumerate(self.action_keys)}

    def hold_action(self, obs: Dict[str, Any]) -> Dict[str, float]:
        hold = self._read_hold_vec(obs)
        return self._to_robot_action_dict(hold)

    def plan_actions(self, obs: Dict[str, Any], mode: str) -> List[Dict[str, float]]:
        hold_vec = self._read_hold_vec(obs)
        if mode == "hold":
            return [self._to_robot_action_dict(hold_vec)]

        model_input = self._obs_to_policy_inputs(obs, self.cfg.lang_instruction)
        action_chunk, _ = self.policy.get_action(model_input)
        self.last_policy_ok_time = time.monotonic()

        horizon_key = next(iter(action_chunk.keys()))
        horizon = int(np.asarray(action_chunk[horizon_key]).shape[1])

        out: List[Dict[str, float]] = []
        for t in range(min(horizon, self.cfg.action_horizon)):
            vec16 = self._extract_action_vec16(action_chunk, t)
            cmd16 = self._apply_safety(vec16, hold_vec, mode=mode)
            out.append(self._to_robot_action_dict(cmd16))
        return out


@dataclass
class EvalConfig:
    robot: RobotConfig

    policy_host: str = "localhost"
    policy_port: int = 5555

    lang_instruction: str = "Pick up the object and place it in the target."

    action_horizon: int = 8
    control_hz: float = 30.0
    watchdog_timeout_s: float = 1.0

    validation_mode: str = "full"  # hold | full
    run_validation_suite: bool = False
    phase_seconds: float = 12.0

    zed_right_camera_obs_key: str = "zed_right"
    zed_left_camera_obs_key: str = "zed_left"
    right_wrist_camera_obs_key: str = "right_wrist"
    left_wrist_camera_obs_key: str = "left_wrist"

    state_obs_keys_csv: str = (
        "openarm_right_joint1,openarm_right_joint2,openarm_right_joint3,openarm_right_joint4,"
        "openarm_right_joint5,openarm_right_joint6,openarm_right_joint7,openarm_right_finger_joint1,"
        "openarm_left_joint1,openarm_left_joint2,openarm_left_joint3,openarm_left_joint4,"
        "openarm_left_joint5,openarm_left_joint6,openarm_left_joint7,openarm_left_finger_joint1"
    )
    action_keys_csv: str = (
        "openarm_right_joint1,openarm_right_joint2,openarm_right_joint3,openarm_right_joint4,"
        "openarm_right_joint5,openarm_right_joint6,openarm_right_joint7,openarm_right_finger_joint1,"
        "openarm_left_joint1,openarm_left_joint2,openarm_left_joint3,openarm_left_joint4,"
        "openarm_left_joint5,openarm_left_joint6,openarm_left_joint7,openarm_left_finger_joint1"
    )

    joint_min_csv: str = (
        "-0.671391,-0.174533,-1.487048,0.509289,0.140947,-0.785398,-0.348441,-0.003000,"
        "-1.014957,-0.823207,1.519953,1.810898,-1.111847,0.184504,0.232751,0.000000"
    )
    joint_max_csv: str = (
        "0.803236,0.954900,-0.503700,1.937051,1.482775,-0.344266,1.113665,0.044000,"
        "-0.997953,-0.822754,1.541741,1.810903,-1.100820,0.189782,0.243485,0.044000"
    )
    max_step_delta_csv: str = (
        "0.03,0.03,0.03,0.03,0.03,0.03,0.03,0.03,0.03,0.03,0.03,0.03,0.03,0.03,0.03,0.03"
    )

    play_sounds: bool = False


@draccus.wrap()
def eval(cfg: EvalConfig):
    init_logging()
    logging.info("Daksha eval config:\n%s", pformat(asdict(cfg)))

    policy = PolicyClient(host=cfg.policy_host, port=cfg.policy_port, strict=False)
    if not policy.ping():
        raise RuntimeError(f"Could not reach GR00T server at tcp://{cfg.policy_host}:{cfg.policy_port}")

    robot = make_robot_from_config(cfg.robot)
    robot.connect()
    log_say("Daksha evaluation bridge initialized.", cfg.play_sounds, blocking=False)

    adapter = DakshaHardwareAdapter(cfg, policy)

    valid_modes = ["hold", "full"]
    if cfg.run_validation_suite:
        phase_modes = valid_modes
    else:
        if cfg.validation_mode not in valid_modes:
            raise ValueError(f"validation_mode must be one of {valid_modes}")
        phase_modes = [cfg.validation_mode]

    phase_idx = 0
    phase_start_t = time.monotonic()
    curr_actions: List[Dict[str, float]] = []

    while True:
        obs = robot.get_observation()

        if cfg.run_validation_suite and time.monotonic() - phase_start_t >= cfg.phase_seconds:
            logging.info("Completed phase: %s", phase_modes[phase_idx])
            phase_idx += 1
            if phase_idx >= len(phase_modes):
                logging.info("Validation suite complete.")
                break
            phase_start_t = time.monotonic()
            curr_actions = []
            logging.info("Starting phase: %s", phase_modes[phase_idx])

        mode = phase_modes[phase_idx]

        stale = (
            adapter.last_policy_ok_time > 0
            and (time.monotonic() - adapter.last_policy_ok_time) > cfg.watchdog_timeout_s
        )
        if mode == "hold" or stale:
            action = adapter.hold_action(obs)
            robot.send_action(action)
            time.sleep(max(0.0, 1.0 / cfg.control_hz))
            continue

        if not curr_actions:
            try:
                curr_actions = adapter.plan_actions(obs, mode=mode)
            except Exception as exc:
                logging.exception("Policy planning failed: %s", exc)
                action = adapter.hold_action(obs)
                robot.send_action(action)
                time.sleep(max(0.0, 1.0 / cfg.control_hz))
                continue

        action = curr_actions.pop(0)
        robot.send_action(action)
        time.sleep(max(0.0, 1.0 / cfg.control_hz))

    robot.disconnect()


if __name__ == "__main__":
    eval()
