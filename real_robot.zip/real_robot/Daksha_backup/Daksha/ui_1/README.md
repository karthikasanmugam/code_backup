# Daksha (OpenArm B1) validation and training UI

Offline, **no-robot** validation for the `openarm_b1` / `pick_box_2_8chunk` checkpoint.
Runs the model open-loop over the RECORDED dataset and overlays, per joint:

- `state` — the recorded joint position at each frame
- `gt` — the recorded ACTION the human demonstrated
- `pred` — what the model predicts from the recorded observation

What this validates and what it does **not**: it validates the MODEL (given a
correct observation, does it reproduce the recorded actions?). It does **not**
validate the ROS2 deployment mapping — topic order, left/right routing, clamp
limits. Those live in `../eval_daksha_ros2.py`. A model that looks perfect
here can still move wrongly on the robot, so check both.

## Three ways in

```bash
# 1. Browser studio: pick dataset + checkpoint + episodes, press Run, read charts.
bash gr00t/eval/real_robot/Daksha_backup/Daksha/ui_1/run_validation_ui.sh
#    Binds 0.0.0.0:8123. Anyone who reaches the port can start a GPU job, so on a
#    shared network:  TOKEN=mysecret bash .../run_validation_ui.sh

# 2. CLI: writes episode_<id>.png + validation_report.html next to the dataset.
bash gr00t/eval/real_robot/Daksha_backup/Daksha/ui_1/run_validation_daksha.sh
EPISODES="0 5 10 20" STEPS=600 bash .../run_validation_daksha.sh

# 3. Serve a directory of dumps produced earlier by the CLI (no model loading).
STATIC=1 DATA_DIR=/home/physicalai/Desktop/I/barani/validation_pick_box \
  bash .../run_validation_ui.sh
```

## Training Studio

For an end-to-end Daksha browser UI (dataset selection, hyperparameters, action
chunk, live logs, stop/resume, checkpoint discovery, System A, offline evaluation,
and the guarded System B ROS2 bridge), run:

```bash
cd /home/physicalai/Desktop/I/groot
bash gr00t/eval/real_robot/Daksha_backup/Daksha/ui_1/run_training_studio.sh
```

It listens on this machine's LAN address, so open `http://192.168.200.114:8130`
from any machine on 192.168.200.0/24, including this one. Anyone who reaches it
can start training and the robot bridge, so on a shared network start it with
`TOKEN=<secret>` and open `http://192.168.200.114:8130/?token=<secret>`; the
evaluation studio it launches uses the same address and token. Use `HOST=127.0.0.1`
to keep it local to this machine.

It scans these dataset roots by default (override with `DATASET_ROOTS=dir1:dir2`):

- `/home/physicalai/Desktop/I/barani`
- `/home/physicalai/Desktop/I/dinesh`
- `/home/physicalai/Desktop/I/open_arm_datasetv3`
- `/home/physicalai/Desktop/I/Muliti_dataset_storage`
- `/home/physicalai/Desktop/I/Dataset`

Everything follows `examples/openarm_b1`. Training uses the `OPENARM_B1` tag (this
repo has no `DAKSHA` tag) and picks the config whose camera keys match the
dataset's `meta/modality.json`:

| cameras in modality.json | config |
|---|---|
| `world`, `wrist_right`, `wrist_left` | `examples/openarm_b1/pick_box_config.py` |
| `zed_right`, `zed_left`, `right_wrist`, `left_wrist` | `examples/openarm_b1/openarm_b1_config.py` |

Both configs pin an 8-step action chunk. For any other chunk the studio writes a
small wrapper config into the output folder that overrides the action horizon.
Training reuses an existing `meta/relative_stats.json` as-is, so the chunk must
equal the length that file was computed for; the studio sets it when you pick a
dataset and refuses a mismatch. A re-run using the same output folder resumes the
latest checkpoint automatically. System B requires typing `START ROBOT` and runs
the task wrapper you pick from `examples/openarm_b1` (`run_system_b_pick_box_2_ros2.sh`
or `run_system_b_two_box_pick_ros2.sh`); pick the one matching the served checkpoint.

`run_gr00t_server_daksha.sh` (System A policy server) also lives here; both
validation entry points can reuse a running server instead of loading the model
themselves — pass `USE_SERVER=1` to the CLI one.

## Files

| file | what it is |
|---|---|
| `validation_app.py` + `validation_app.html` | the browser studio (scan, run, chart) |
| `validate_prediction_vs_dataset.py` | the CLI validator; also supplies the studio's metrics |
| `serve_validation_ui.py` | static server for already-computed dumps |
| `run_*.sh` | launchers, every default overridable by env var |
| `daksha_b1/` | A standalone Daksha B1 finetuning/eval setup with its own launchers. Uses the `OPENARM_B1` tag, the repo at `/home/physicalai/Desktop/I/groot`, and its own `daksha_b1_config.py` (4 cameras: `zed_right`, `zed_left`, `wrist_right`, `wrist_left`; 16-step chunk). Its validation launchers reuse the apps in this folder. |

## Reading the report

`pred` should track `gt`. Flat / offset / noisy `pred` on a joint means that joint
was not learned well.

One caveat specific to `pick_box`: the **left arm barely moves** — under 0.05 rad
of total range per joint, and the left gripper spans 5e-5 rad. Its `MAE/range`
column is therefore a ratio of two near-zero numbers and means nothing (it prints
`n/a` when the range is zero). Judge the model on the right-arm channels, which
carry the task. For the same reason, use a realistic `STEPS` (episodes are 600
frames): a 32-step window catches only the initial pause, where nothing moves and
every ratio explodes.

## Defaults

Checkpoint `/home/physicalai/Desktop/I/groot/outputs/pick_box_2_8chunk/checkpoint-50000`,
dataset `/home/physicalai/Desktop/I/barani/pick_box_2`, embodiment tag `openarm_b1`,
action horizon **8** (must equal the checkpoint's action `delta_indices` count --
8 for `pick_box_2_8chunk`, 16 for the older `outputs/pick_box_2` run).
