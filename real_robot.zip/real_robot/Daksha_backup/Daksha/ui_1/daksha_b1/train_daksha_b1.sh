#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="${REPO_ROOT:-/home/physicalai/Desktop/I/groot}"
cd "$REPO_ROOT"
source .venv/bin/activate

# Daksha B1 uses the 4-part modality split:
# right_arm, right_gripper, left_arm, left_gripper.
CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}" python -m gr00t.experiment.launch_finetune \
  --base-model-path "${BASE_MODEL_PATH:-nvidia/GR00T-N1.7-3B}" \
  --dataset-path "${DATASET_PATH:-/home/physicalai/Desktop/I/Muliti_dataset_storage/custom_arm_task1}" \
  --modality-config-path "${MODALITY_CONFIG_PATH:-gr00t/eval/real_robot/Daksha_backup/Daksha/ui_1/daksha_b1/daksha_b1_config.py}" \
  --embodiment-tag "${EMBODIMENT_TAG:-OPENARM_B1}" \
  --num-gpus "${NUM_GPUS:-1}" \
  --output-dir "${OUTPUT_DIR:-./outputs/daksha_b1_custom_arm_task1}" \
  --save-total-limit "${SAVE_TOTAL_LIMIT:-2}" \
  --save-steps "${SAVE_STEPS:-1000}" \
  --max-steps "${MAX_STEPS:-50000}" \
  --global-batch-size "${GLOBAL_BATCH_SIZE:-32}" \
  --dataloader-num-workers "${DATALOADER_NUM_WORKERS:-8}"
