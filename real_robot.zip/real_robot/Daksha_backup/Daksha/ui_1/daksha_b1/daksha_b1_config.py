from copy import deepcopy

from gr00t.configs.data.embodiment_configs import MODALITY_CONFIGS, register_modality_config
from gr00t.data.embodiment_tags import EmbodimentTag
from gr00t.data.types import (
    ActionConfig,
    ActionFormat,
    ActionRepresentation,
    ActionType,
    ModalityConfig,
)


daksha_b1_config = {
    "video": ModalityConfig(
        delta_indices=[0],
        modality_keys=["zed_right", "zed_left", "wrist_right", "wrist_left"],
    ),
    "state": ModalityConfig(
        delta_indices=[0],
        modality_keys=[
            "right_arm",
            "right_gripper",
            "left_arm",
            "left_gripper",
        ],
    ),
    "action": ModalityConfig(
        delta_indices=list(range(0, 16)),
        modality_keys=[
            "right_arm",
            "right_gripper",
            "left_arm",
            "left_gripper",
        ],
        action_configs=[
            ActionConfig(
                rep=ActionRepresentation.RELATIVE,
                type=ActionType.NON_EEF,
                format=ActionFormat.DEFAULT,
            ),
            ActionConfig(
                rep=ActionRepresentation.ABSOLUTE,
                type=ActionType.NON_EEF,
                format=ActionFormat.DEFAULT,
            ),
            ActionConfig(
                rep=ActionRepresentation.RELATIVE,
                type=ActionType.NON_EEF,
                format=ActionFormat.DEFAULT,
            ),
            ActionConfig(
                rep=ActionRepresentation.ABSOLUTE,
                type=ActionType.NON_EEF,
                format=ActionFormat.DEFAULT,
            ),
        ],
    ),
    "language": ModalityConfig(
        delta_indices=[0],
        modality_keys=["annotation.human.task_description"],
    ),
}

# Register under OPENARM_B1, the Daksha tag in gr00t/data/embodiment_tags.py
# (this repo has no DAKSHA tag). Same pattern as examples/openarm_b1/*_config.py.
if EmbodimentTag.OPENARM_B1.value not in MODALITY_CONFIGS:
    register_modality_config(deepcopy(daksha_b1_config), embodiment_tag=EmbodimentTag.OPENARM_B1)
else:
    MODALITY_CONFIGS[EmbodimentTag.OPENARM_B1.value] = deepcopy(daksha_b1_config)

# Alias, so --embodiment-tag NEW_EMBODIMENT also works with this config.
MODALITY_CONFIGS[EmbodimentTag.NEW_EMBODIMENT.value] = deepcopy(daksha_b1_config)
