#!/usr/bin/env python3
"""
Convert the Daksha B1 raw dataset into the GR00T/LeRobot layout expected by training.

This script assumes the raw data already exists as per-episode parquet files and MP4
videos, and it fills in the missing LeRobot metadata files:

  - meta/modality.json
  - meta/tasks.jsonl
  - meta/episodes.jsonl
  - meta/info.json (adds chunks_size if missing)

Optionally, it can also run the GR00T statistics generator to produce:

  - meta/stats.json
  - meta/relative_stats.json

Example:
  python gr00t/eval/real_robot/Daksha_backup/Daksha/ui_1/daksha_b1/convert_daksha_b1_dataset.py \
    --dataset-root /home/physicalai/Desktop/I/Muliti_dataset_storage/custom_arm_task1
"""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

import pandas as pd


HERE = Path(__file__).resolve().parent
# The repo that owns gr00t/; found by content because this folder has moved before.
REPO_ROOT = next(p for p in HERE.parents if (p / "gr00t" / "experiment" / "launch_finetune.py").is_file())
# The template and config are this folder's own files (there is no examples/daksha_b1 here).
DEFAULT_MODALITY_TEMPLATE = HERE / "modality.json"
MODALITY_CONFIG = HERE / "daksha_b1_config.py"
DEFAULT_CHUNKS_SIZE = 1024


def resolve_dataset_root(dataset_root: str | Path) -> Path:
    root = Path(dataset_root).expanduser().resolve()
    if (root / "meta" / "info.json").exists():
        return root

    nested_roots = sorted(
        p for p in root.iterdir() if p.is_dir() and (p / "meta" / "info.json").exists()
    )
    if len(nested_roots) == 1:
        return nested_roots[0]
    if len(nested_roots) > 1:
        raise FileNotFoundError(
            f"Multiple LeRobot dataset roots found under {root}: "
            f"{', '.join(str(p) for p in nested_roots)}"
        )
    raise FileNotFoundError(
        f"Could not find meta/info.json under {root}. "
        "Pass the exact dataset root that contains the dataset."
    )


def read_tasks(meta_dir: Path) -> list[dict[str, object]]:
    task_json = meta_dir / "task.json"
    tasks_parquet = meta_dir / "tasks.parquet"

    if task_json.exists():
        raw_tasks = json.loads(task_json.read_text())
    elif tasks_parquet.exists():
        raw_tasks = pd.read_parquet(tasks_parquet).to_dict(orient="records")
    else:
        raise FileNotFoundError(
            f"Could not find task.json or tasks.parquet in {meta_dir}. "
            "One of those files is needed to generate tasks.jsonl."
        )

    tasks: list[dict[str, object]] = []
    for row in raw_tasks:
        if "task_index" not in row or "task" not in row:
            raise ValueError(
                "Each task record must contain at least 'task_index' and 'task'. "
                f"Got keys: {list(row.keys())}"
            )
        task_index = int(row["task_index"])
        task_text = str(row["task"])
        prompt = str(row.get("prompt", task_text))
        tasks.append({"task_index": task_index, "task": task_text, "prompt": prompt})

    tasks.sort(key=lambda item: int(item["task_index"]))
    return tasks


def write_tasks_jsonl(meta_dir: Path, tasks: list[dict[str, object]]) -> Path:
    path = meta_dir / "tasks.jsonl"
    with open(path, "w") as f:
        for task in tasks:
            f.write(json.dumps(task, ensure_ascii=False) + "\n")
    return path


def parse_episode_index(path: Path) -> int:
    stem = path.stem
    if stem.startswith("episode_"):
        return int(stem.split("_", 1)[1])
    raise ValueError(f"Could not parse episode index from filename: {path.name}")


def build_episodes(dataset_root: Path) -> list[dict[str, object]]:
    episode_paths = sorted(dataset_root.glob("data/chunk-*/episode_*.parquet"))
    if not episode_paths:
        raise FileNotFoundError(
            f"No episode parquet files found under {dataset_root / 'data'}. "
            "Expected files like data/chunk-000/episode_000000.parquet."
        )

    episodes: list[dict[str, object]] = []
    for parquet_path in episode_paths:
        df = pd.read_parquet(parquet_path)
        if len(df) == 0:
            raise ValueError(f"Empty episode parquet: {parquet_path}")

        episode_index = int(df["episode_index"].iloc[0]) if "episode_index" in df.columns else parse_episode_index(parquet_path)
        file_episode_index = parse_episode_index(parquet_path)
        if episode_index != file_episode_index:
            raise ValueError(
                f"Episode index mismatch for {parquet_path.name}: "
                f"file says {file_episode_index}, parquet says {episode_index}"
            )

        episode: dict[str, object] = {
            "episode_index": episode_index,
            "length": int(len(df)),
        }
        if "task_index" in df.columns:
            episode["task_index"] = int(df["task_index"].iloc[0])
        if "task" in df.columns:
            episode["task"] = str(df["task"].iloc[0])
        if "prompt" in df.columns:
            episode["prompt"] = str(df["prompt"].iloc[0])
        if "timestamp" in df.columns:
            episode["timestamp_start"] = float(df["timestamp"].iloc[0])
            episode["timestamp_end"] = float(df["timestamp"].iloc[-1])

        episodes.append(episode)

    episodes.sort(key=lambda item: int(item["episode_index"]))
    return episodes


def write_episodes_jsonl(meta_dir: Path, episodes: list[dict[str, object]]) -> Path:
    path = meta_dir / "episodes.jsonl"
    with open(path, "w") as f:
        for episode in episodes:
            f.write(json.dumps(episode, ensure_ascii=False) + "\n")
    return path


def update_info_json(meta_dir: Path, chunks_size: int, tasks: list[dict[str, object]], episodes: list[dict[str, object]]) -> Path:
    path = meta_dir / "info.json"
    with open(path, "r") as f:
        info = json.load(f)

    info["chunks_size"] = int(info.get("chunks_size", chunks_size))
    info["total_episodes"] = len(episodes)
    info["total_frames"] = int(sum(int(ep["length"]) for ep in episodes))
    info["total_tasks"] = len(tasks)

    with open(path, "w") as f:
        json.dump(info, f, indent=2)
        f.write("\n")
    return path


def copy_modality_template(meta_dir: Path, template_path: Path) -> Path:
    if not template_path.exists():
        raise FileNotFoundError(f"Modality template not found: {template_path}")
    target_path = meta_dir / "modality.json"
    shutil.copy2(template_path, target_path)
    return target_path


def run_stats_generation(dataset_root: Path) -> None:
    # gr00t.data.stats has no --modality-config-path flag, so register the config
    # in the same process first, then call its main() under the OPENARM_B1 tag.
    code = (
        "import sys; sys.path.insert(0, sys.argv[1]); import daksha_b1_config; "
        "from gr00t.data.embodiment_tags import EmbodimentTag; from gr00t.data.stats import main; "
        "main(sys.argv[2], EmbodimentTag.OPENARM_B1)"
    )
    cmd = [sys.executable, "-c", code, str(MODALITY_CONFIG.parent), str(dataset_root)]
    subprocess.run(cmd, cwd=REPO_ROOT, check=True)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Convert the Daksha B1 dataset into the GR00T/LeRobot metadata layout."
    )
    parser.add_argument(
        "--dataset-root",
        required=True,
        help="Path to the dataset root that contains data/ and meta/.",
    )
    parser.add_argument(
        "--modality-template",
        default=str(DEFAULT_MODALITY_TEMPLATE),
        help="Path to the Daksha B1 modality.json template.",
    )
    parser.add_argument(
        "--chunks-size",
        type=int,
        default=DEFAULT_CHUNKS_SIZE,
        help="Value to write into meta/info.json if chunks_size is missing.",
    )
    parser.add_argument(
        "--skip-stats",
        action="store_true",
        help="Skip running the GR00T stats generator after metadata conversion.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    dataset_root = resolve_dataset_root(args.dataset_root)
    meta_dir = dataset_root / "meta"
    meta_dir.mkdir(parents=True, exist_ok=True)

    tasks = read_tasks(meta_dir)
    episodes = build_episodes(dataset_root)

    info_path = update_info_json(meta_dir, args.chunks_size, tasks, episodes)
    modality_path = copy_modality_template(meta_dir, Path(args.modality_template))
    tasks_path = write_tasks_jsonl(meta_dir, tasks)
    episodes_path = write_episodes_jsonl(meta_dir, episodes)

    print("Converted dataset metadata:")
    print(f"  dataset_root: {dataset_root}")
    print(f"  info.json: {info_path}")
    print(f"  modality.json: {modality_path}")
    print(f"  tasks.jsonl: {tasks_path}")
    print(f"  episodes.jsonl: {episodes_path}")
    print(f"  total_episodes: {len(episodes)}")
    print(f"  total_frames: {sum(int(ep['length']) for ep in episodes)}")
    print(f"  chunks_size: {args.chunks_size}")

    if not args.skip_stats:
        print("Running GR00T stats generation...")
        try:
            run_stats_generation(dataset_root)
            print("Stats generation complete.")
        except Exception as e:
            print(f"Warning: stats generation failed, continuing without stats: {e}")


    return 0


if __name__ == "__main__":
    raise SystemExit(main())
