#!/usr/bin/env bash
# Daksha B1 validation studio — one web app that does the whole loop:
# pick the dataset, pick the checkpoint, pick the episodes, press Run, and read
# the per-joint charts (recorded action vs model prediction) + tables.
#
# It binds every interface by default, so you can open it from another machine:
#   http://<this machine's IP>:8123      (the script prints the exact URLs)
#
#   bash gr00t/eval/real_robot/Daksha_backup/Daksha/ui_1/daksha_b1/run_validation_ui.sh
#   PORT=9000 bash gr00t/eval/real_robot/Daksha_backup/Daksha/ui_1/daksha_b1/run_validation_ui.sh
#   TOKEN=mysecret bash gr00t/eval/real_robot/Daksha_backup/Daksha/ui_1/daksha_b1/run_validation_ui.sh     # require ?token=mysecret
#   HOST=127.0.0.1 bash gr00t/eval/real_robot/Daksha_backup/Daksha/ui_1/daksha_b1/run_validation_ui.sh     # this machine only
#   DATASET_ROOT=/data/robot MODEL_ROOT=/data/ckpts bash gr00t/eval/real_robot/Daksha_backup/Daksha/ui_1/daksha_b1/run_validation_ui.sh
#
# Anyone who can reach the port can start a GPU job and read any dataset under
# ALLOW_ROOT, so set TOKEN on a shared network.
#
# Old behaviour (serve a directory of dumps produced earlier by
# validate_prediction_vs_dataset.py, no model loading) is still one flag away:
#   STATIC=1 DATA_DIR=/path/to/validation_dir bash gr00t/eval/real_robot/Daksha_backup/Daksha/ui_1/daksha_b1/run_validation_ui.sh
set -euo pipefail

# The validation apps live one level up, in ui_1/.
UI_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

REPO_ROOT="${REPO_ROOT:-/home/physicalai/Desktop/I/groot}"
cd "$REPO_ROOT"
source .venv/bin/activate

PORT="${PORT:-8123}"
HOST="${HOST:-0.0.0.0}"          # 0.0.0.0 = reachable from the LAN; 127.0.0.1 = local only
TOKEN="${TOKEN:-}"
DATASET_ROOT="${DATASET_ROOT:-$HOME/Desktop}"
MODEL_ROOT="${MODEL_ROOT:-$PWD/output}"
ALLOW_ROOT="${ALLOW_ROOT:-$HOME}"
DATASET_PATH="${DATASET_PATH:-/home/physicalai/Desktop/I/barani/task_5}"
MODEL_PATH="${MODEL_PATH:-$PWD/output/new_3/checkpoint-50000}"
EMBODIMENT_TAG="${EMBODIMENT_TAG:-OPENARM_B1}"
STEPS="${STEPS:-200}"
ACTION_HORIZON="${ACTION_HORIZON:-16}"

# Free the port if a previous UI server is still holding it.
fuser -k "${PORT}/tcp" 2>/dev/null || true
sleep 1

if [[ "${STATIC:-0}" == "1" ]]; then
  DATA_DIR="${DATA_DIR:-/home/physicalai/Desktop/I/barani/validation_pick_place_brown}"
  echo "[ui] static mode: serving ${DATA_DIR} at http://localhost:${PORT}"
  ( xdg-open "http://localhost:${PORT}" >/dev/null 2>&1 & ) || true
  exec python "$UI_DIR/serve_validation_ui.py" \
    --data-dir "${DATA_DIR}" --port "${PORT}" --host "${HOST}"
fi

( sleep 2; xdg-open "http://localhost:${PORT}/${TOKEN:+?token=$TOKEN}" >/dev/null 2>&1 & ) || true

exec python "$UI_DIR/validation_app.py" \
  --host "${HOST}" --port "${PORT}" \
  ${TOKEN:+--token "${TOKEN}"} \
  --dataset-root "${DATASET_ROOT}" \
  --model-root "${MODEL_ROOT}" \
  --allow-root "${ALLOW_ROOT}" \
  --dataset-path "${DATASET_PATH}" \
  --model-path "${MODEL_PATH}" \
  --embodiment-tag "${EMBODIMENT_TAG}" \
  --steps "${STEPS}" \
  --action-horizon "${ACTION_HORIZON}"
