#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="${REPO_ROOT:-/home/physicalai/Desktop/I/groot}"
cd "$REPO_ROOT"
source .venv/bin/activate

python gr00t/eval/run_gr00t_server.py \
  --model-path "${MODEL_PATH:-/home/physicalai/Desktop/I/grootn1.7/Isaac-GR00T/output/pick_place_blue/checkpoint-70000}" \
  --embodiment-tag "${EMBODIMENT_TAG:-OPENARM_B1}" \
  --host "${HOST:-0.0.0.0}" \
  --port "${PORT:-5555}"