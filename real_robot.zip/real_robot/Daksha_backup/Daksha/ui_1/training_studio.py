#!/usr/bin/env python3
"""Daksha Training Studio: local browser UI for GR00T fine-tuning and deployment.

The server intentionally has no third-party web dependency.  It runs only commands
already provided by this repository and keeps a short live log for each process.
It can start GPU jobs and the robot bridge, so when it listens on a LAN address
(run_training_studio.sh defaults to 192.168.200.114) set TOKEN=<secret> and open
the page as http://<host>:<port>/?token=<secret>.

Everything is wired to this machine's OpenArm B1 (Daksha) setup in
examples/openarm_b1: its modality configs, the OPENARM_B1 embodiment tag and its
System B wrappers. This repo has no DAKSHA tag and no examples/Daksha folder.
"""
from __future__ import annotations

import argparse
import ast
import hmac
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import threading
import time
import urllib.parse
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any

HERE = Path(__file__).resolve().parent


def find_repo_root(start: Path) -> Path:
    """Walk up to the repo that owns gr00t/experiment/launch_finetune.py.

    A fixed HERE.parents[N] broke as soon as this folder moved under Daksha_backup/,
    so the root is found by content. An exported REPO_ROOT wins.
    """
    if os.environ.get("REPO_ROOT"):
        return Path(os.environ["REPO_ROOT"]).expanduser().resolve()
    for p in start.parents:
        if (p / "gr00t/experiment/launch_finetune.py").is_file():
            return p
    raise SystemExit(f"Cannot find the GR00T repo above {start}; set REPO_ROOT")


REPO_ROOT = find_repo_root(HERE)
# The local Daksha setup: modality configs (*_config.py) and System B wrappers.
OPENARM_B1_DIR = REPO_ROOT / "examples/openarm_b1"
# The tag pick_box_2_8chunk and two_box_pick_8chunk were trained with.
EMBODIMENT_TAG = "OPENARM_B1"
# The folders on this machine that hold 16-DoF OpenArm B1 LeRobot datasets.
DATASETS_HOME = Path("/home/physicalai/Desktop/I")
DEFAULT_DATASET_ROOTS = [DATASETS_HOME / d for d in
                         ("barani", "dinesh", "open_arm_datasetv3", "Muliti_dataset_storage", "Dataset")]
VALIDATION_APP = HERE / "validation_app.py"
# System B wrappers carry checkpoint-specific joint limits; the base script is not one.
BRIDGE_BASE = "run_system_b_openarm_b1_ros2.sh"


def is_dataset(path: Path) -> bool:
    return (path / "meta/info.json").is_file()


def is_checkpoint(path: Path) -> bool:
    return (path / "config.json").is_file() and (
        (path / "model.safetensors.index.json").is_file() or any(path.glob("*.safetensors"))
    )


def scan(root: Path, predicate, depth: int = 4) -> list[Path]:
    found: list[Path] = []
    if not root.is_dir():
        return found
    for current, dirs, _ in os.walk(root):
        p = Path(current)
        level = len(p.relative_to(root).parts)
        dirs[:] = [d for d in dirs if not d.startswith(".") and d not in {"data", "videos", "wandb", "__pycache__"}]
        if level > depth:
            dirs[:] = []
            continue
        if predicate(p):
            found.append(p)
            if predicate is is_dataset:
                dirs[:] = []
    return sorted(found)


def _horizon(node: ast.AST | None) -> int | None:
    """len() of a delta_indices literal: [0, 1, ...] or list(range(a, b))."""
    if node is None:
        return None
    try:
        return len(ast.literal_eval(node))
    except (ValueError, TypeError, SyntaxError):
        pass
    if (isinstance(node, ast.Call) and getattr(node.func, "id", "") == "list" and node.args
            and isinstance(node.args[0], ast.Call) and getattr(node.args[0].func, "id", "") == "range"):
        try:
            return len(range(*[ast.literal_eval(a) for a in node.args[0].args]))
        except (ValueError, TypeError, SyntaxError):
            return None
    return None


def read_modality_config(path: Path) -> dict[str, Any] | None:
    """Read video/state/action keys and the action horizon from a config file.

    Parsed, not imported: importing registers the config globally and pulls in
    the whole gr00t stack, and the studio only needs the keys to match datasets.
    """
    try:
        tree = ast.parse(path.read_text())
    except (OSError, SyntaxError):
        return None
    for node in tree.body:
        if not (isinstance(node, ast.Assign) and isinstance(node.value, ast.Dict)):
            continue
        parts: dict[str, dict[str, Any]] = {}
        for key, value in zip(node.value.keys, node.value.values):
            if not (isinstance(key, ast.Constant) and isinstance(value, ast.Call)):
                continue
            kw = {k.arg: k.value for k in value.keywords}
            try:
                keys = ast.literal_eval(kw["modality_keys"])
            except (KeyError, ValueError, TypeError, SyntaxError):
                continue
            parts[key.value] = {"keys": list(keys), "horizon": _horizon(kw.get("delta_indices"))}
        if {"video", "state", "action"} <= parts.keys():
            return {"path": path, "name": path.name, "video": parts["video"]["keys"],
                    "state": parts["state"]["keys"], "action": parts["action"]["keys"],
                    "horizon": parts["action"]["horizon"]}
    return None


def modality_configs() -> list[dict[str, Any]]:
    """Every modality config in examples/openarm_b1 (pick_box_config.py, openarm_b1_config.py)."""
    found = (read_modality_config(p) for p in sorted(OPENARM_B1_DIR.glob("*_config.py")))
    return [c for c in found if c and c["horizon"]]


def relative_stats_horizon(path: Path) -> int | None:
    """Chunk length meta/relative_stats.json was computed for, None if it is absent.

    Training only generates this file when it is missing and otherwise reuses it
    as-is, so its length must equal the action chunk being trained. Returns 0 when
    the file is unreadable or its keys disagree.
    """
    f = path / "meta/relative_stats.json"
    if not f.is_file():
        return None
    try:
        lengths = {len(v["mean"]) for v in json.loads(f.read_text()).values()}
    except (OSError, ValueError, TypeError, KeyError):
        return 0
    return lengths.pop() if len(lengths) == 1 else 0


def dataset_info(path: Path, configs: list[dict[str, Any]]) -> dict[str, Any]:
    info = json.loads((path / "meta/info.json").read_text())
    action = info.get("features", {}).get("action", {})
    dim = len(action.get("names") or []) or (action.get("shape") or [0])[0]
    modality_file = path / "meta/modality.json"
    modality = json.loads(modality_file.read_text()) if modality_file.is_file() else None
    config = None
    if modality is None:
        reason = "Needs meta/modality.json"
    elif dim != 16:
        reason = f"Action has {dim} values; the OpenArm B1 configs need 16"
    else:
        video = set(modality.get("video", {}))
        state, act = set(modality.get("state", {})), set(modality.get("action", {}))
        same_cameras = [c for c in configs if set(c["video"]) == video]
        config = next((c for c in same_cameras if set(c["state"]) <= state and set(c["action"]) <= act), None)
        if config:
            reason = f"Ready: {config['name']}"
        elif same_cameras:
            c = same_cameras[0]
            missing = sorted((set(c["state"]) - state) | (set(c["action"]) - act))
            reason = f"Cameras match {c['name']}, but modality.json lacks {missing}"
        else:
            reason = f"Cameras {sorted(video)} match no config in examples/openarm_b1"
    stats = relative_stats_horizon(path)
    if config and stats:
        reason += f" · relative_stats.json is {stats}-step, so train with chunk {stats}"
    elif config and stats == 0:
        reason += " · meta/relative_stats.json is unreadable"
    return {"path": str(path), "name": path.name, "episodes": info.get("total_episodes", 0),
            "frames": info.get("total_frames", 0), "fps": info.get("fps", "?"),
            "action_dim": dim, "modality": modality is not None,
            "config": str(config["path"]) if config else None,
            "config_horizon": config["horizon"] if config else None,
            "stats_horizon": stats, "ready": config is not None, "reason": reason}


def write_chunk_config(output: Path, base: Path, chunk: int) -> Path:
    """Wrap `base` so it trains `chunk`-step actions.

    This repo's launch_finetune has no action-chunk flag and both openarm_b1 configs
    pin delta_indices, so the chunk is set by a tiny config that imports the chosen
    one and overrides its action horizon. launch_finetune imports it by file stem.
    """
    output.mkdir(parents=True, exist_ok=True)
    path = output / f"studio_{base.stem}_chunk{chunk}.py"
    path.write_text(
        f'"""Generated by training_studio.py: {base.name} with a {chunk}-step action chunk."""\n'
        "import sys\n\n"
        f"sys.path.insert(0, {str(base.parent)!r})\n"
        f"import {base.stem}  # noqa: E402,F401  registers the openarm_b1 modality config\n"
        "from gr00t.configs.data.embodiment_configs import MODALITY_CONFIGS  # noqa: E402\n\n"
        'for _tag in ("openarm_b1", "new_embodiment"):\n'
        "    if _tag in MODALITY_CONFIGS:\n"
        f'        MODALITY_CONFIGS[_tag]["action"].delta_indices = list(range(0, {chunk}))\n'
    )
    return path


def bridge_scripts() -> list[str]:
    """Per-task System B wrappers, e.g. run_system_b_pick_box_2_ros2.sh."""
    return sorted(p.name for p in OPENARM_B1_DIR.glob("run_system_b_*_ros2.sh") if p.name != BRIDGE_BASE)


class Process:
    def __init__(self, name: str, command: list[str], env: dict[str, str] | None = None):
        self.name, self.command = name, command
        self.logs: deque[str] = deque(maxlen=800)
        self.started = time.time()
        child_env = os.environ.copy()
        child_env.update(env or {})
        self.proc = subprocess.Popen(command, cwd=REPO_ROOT, env=child_env, text=True,
                                     stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                     start_new_session=True, bufsize=1)
        threading.Thread(target=self._read, daemon=True).start()

    def _read(self):
        assert self.proc.stdout
        for line in self.proc.stdout:
            self.logs.append(line.rstrip())

    def public(self) -> dict[str, Any]:
        rc = self.proc.poll()
        return {"name": self.name, "running": rc is None, "returncode": rc,
                "started": self.started, "command": self.command, "logs": list(self.logs)}

    def stop(self) -> bool:
        if self.proc.poll() is not None:
            return False
        os.killpg(self.proc.pid, signal.SIGINT)
        self.logs.append("[studio] Stop requested (SIGINT). Existing checkpoints are preserved.")
        return True


class Studio:
    def __init__(self, args):
        self.args, self.jobs = args, {}
        self.lock = threading.Lock()

    def safe(self, raw: str) -> Path:
        p = Path(raw).expanduser().resolve()
        if not any(p == root or root in p.parents for root in self.args.allow_roots):
            raise PermissionError(f"{p} is outside allowed paths")
        return p

    def state(self) -> dict[str, Any]:
        configs = modality_configs()
        datasets = []
        for root in self.args.dataset_roots:
            for p in scan(root, is_dataset):
                try: datasets.append(dataset_info(p, configs))
                except Exception: pass
        checkpoints = []
        for p in scan(self.args.output_root, is_checkpoint, 5):
            m = re.search(r"checkpoint-(\d+)$", p.name)
            checkpoints.append({"path": str(p), "name": str(p.relative_to(self.args.output_root)),
                                "step": int(m.group(1)) if m else None})
        return {"datasets": datasets, "checkpoints": checkpoints, "bridges": bridge_scripts(),
                "jobs": {key: job.public() for key, job in self.jobs.items()},
                "defaults": {"dataset_roots": [str(r) for r in self.args.dataset_roots],
                             "output_root": str(self.args.output_root), "base_model": "nvidia/GR00T-N1.6-3B",
                             "embodiment_tag": EMBODIMENT_TAG, "modality_configs": [c["name"] for c in configs]}}

    def start_training(self, b: dict) -> Process:
        with self.lock:
            old = self.jobs.get("training")
            if old and old.proc.poll() is None: raise RuntimeError("A training job is already running")
            ds = self.safe(b["dataset"])
            if not is_dataset(ds): raise ValueError("Selected folder is not a LeRobot dataset (meta/info.json missing)")
            info = dataset_info(ds, modality_configs())
            if not info["ready"]: raise ValueError(f"{ds.name}: {info['reason']}")
            output = self.safe(b["output_dir"])
            if output == REPO_ROOT or output == self.args.output_root: raise ValueError("Choose a subfolder inside outputs")
            base = str(b.get("base_model") or "nvidia/GR00T-N1.6-3B")
            if base.startswith("/"):
                base_path = self.safe(base)
                if not is_checkpoint(base_path): raise ValueError("Local base model must be a valid GR00T checkpoint")
                base = str(base_path)
            def number(key, default, cast=float):
                try: return cast(b.get(key, default))
                except (TypeError, ValueError): raise ValueError(f"{key} must be a number")
            chunk, lr = number("chunk", 8, int), number("learning_rate", 1e-4)
            steps, batch = number("max_steps", 50000, int), number("batch_size", 8, int)
            save_steps, keep = number("save_steps", 1000, int), number("keep_checkpoints", 3, int)
            workers, gpus = number("workers", 4, int), number("gpus", 1, int)
            if not (1 <= chunk <= 40 and lr > 0 and steps > 0 and batch > 0 and save_steps > 0 and keep > 0 and workers >= 0 and gpus > 0):
                raise ValueError("Use positive values (chunk 1–40; workers may be 0)")
            stats = info["stats_horizon"]
            if stats == 0:
                raise ValueError(f"{ds}/meta/relative_stats.json is unreadable. Rename it so training regenerates it.")
            if stats is not None and stats != chunk:
                raise ValueError(f"{ds}/meta/relative_stats.json holds {stats}-step statistics and training reuses "
                                 f"that file as-is. Set the action chunk to {stats}, or rename the file so "
                                 f"training regenerates it for {chunk} steps.")
            config = Path(info["config"])
            if chunk != info["config_horizon"]:
                config = write_chunk_config(output, config, chunk)
            cmd = [sys.executable, "-m", "gr00t.experiment.launch_finetune", "--base-model-path", base,
                   "--dataset-path", str(ds), "--modality-config-path", str(config),
                   "--embodiment-tag", EMBODIMENT_TAG, "--learning-rate", str(lr),
                   "--max-steps", str(steps), "--global-batch-size", str(batch), "--dataloader-num-workers", str(workers),
                   "--num-gpus", str(gpus), "--output-dir", str(output), "--save-steps", str(save_steps),
                   "--save-total-limit", str(keep)]
            if not b.get("tune_diffusion", True): cmd.append("--no-tune-diffusion-model")
            if b.get("tune_visual", False): cmd.append("--tune-visual")
            env = {"CUDA_VISIBLE_DEVICES": str(b.get("cuda_devices") or "0"), "PYTHONUNBUFFERED": "1"}
            self.jobs["training"] = Process("training", cmd, env)
            return self.jobs["training"]

    def start_server(self, b: dict) -> Process:
        with self.lock:
            old = self.jobs.get("inference")
            if old and old.proc.poll() is None: raise RuntimeError("Inference server is already running")
            model = self.safe(b["model"])
            if not is_checkpoint(model): raise ValueError("Select a complete checkpoint")
            port = int(b.get("port") or 5555)
            self.jobs["inference"] = Process("inference", [sys.executable, "gr00t/eval/run_gr00t_server.py", "--model-path", str(model),
                "--embodiment-tag", EMBODIMENT_TAG, "--host", str(b.get("host") or "0.0.0.0"), "--port", str(port)], {"PYTHONUNBUFFERED":"1"})
            return self.jobs["inference"]

    def start_eval(self, b: dict) -> Process:
        with self.lock:
            old = self.jobs.get("evaluation")
            if old and old.proc.poll() is None: raise RuntimeError("Evaluation studio is already running")
            ds, model = self.safe(b["dataset"]), self.safe(b["model"])
            if not is_dataset(ds) or not is_checkpoint(model): raise ValueError("Choose a valid dataset and checkpoint")
            port = int(b.get("port") or 8123)
            self.jobs["evaluation"] = Process("evaluation", [sys.executable, str(VALIDATION_APP), "--host", self.args.host, "--port", str(port),
                *(["--token", self.args.token] if self.args.token else []),
                "--dataset-root", str(ds.parent), "--model-root", str(self.args.output_root), "--allow-root", str(self.args.allow_roots[0]),
                "--dataset-path", str(ds), "--model-path", str(model), "--embodiment-tag", EMBODIMENT_TAG, "--action-horizon", str(b.get("chunk") or 8)],
                {"REPO_ROOT": str(REPO_ROOT)})
            return self.jobs["evaluation"]

    def start_bridge(self, b: dict) -> Process:
        if b.get("confirm") != "START ROBOT": raise ValueError("Type START ROBOT to enable the ROS2 bridge")
        with self.lock:
            old = self.jobs.get("bridge")
            if old and old.proc.poll() is None: raise RuntimeError("ROS2 bridge is already running")
            host, port = str(b.get("policy_host") or "127.0.0.1"), str(int(b.get("policy_port") or 5555))
            chunk = str(int(b.get("chunk") or 8))
            script = str(b.get("script") or "")
            if script not in bridge_scripts():
                raise ValueError(f"Choose a System B task wrapper from examples/openarm_b1: {', '.join(bridge_scripts())}")
            env = {"POLICY_HOST":host, "POLICY_PORT":port, "ACTION_HORIZON":chunk, "REPO_ROOT":str(REPO_ROOT), "PYTHONUNBUFFERED":"1"}
            self.jobs["bridge"] = Process("bridge", ["bash", str(OPENARM_B1_DIR / script)], env)
            return self.jobs["bridge"]


HTML = r'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Daksha · GR00T Studio</title><style>
:root{color-scheme:dark;--bg:#09111d;--panel:#101c2e;--line:#263b58;--txt:#eef4ff;--muted:#93a8c7;--blue:#66a9ff;--good:#66e3ad;--warn:#ffca6b;--red:#ff8491}*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 85% -10%,#1c416c,transparent 38%),var(--bg);color:var(--txt);font:14px system-ui,sans-serif}.wrap{max-width:1360px;margin:auto;padding:28px 18px 80px}h1{font-size:28px;margin:0}h2{font-size:16px;margin:0 0 14px}.sub{color:var(--muted);margin:8px 0 22px;line-height:1.5}.grid{display:grid;grid-template-columns:repeat(12,1fr);gap:16px}.card{grid-column:span 6;background:rgba(16,28,46,.92);border:1px solid var(--line);border-radius:14px;padding:18px}.full{grid-column:1/-1}.hint{font-size:12px;color:var(--muted);margin:-6px 0 14px;line-height:1.5}.info{margin-top:12px;padding:10px 12px;border-radius:7px;background:#0b1727;border-left:3px solid var(--line);font-size:12px;line-height:1.7;white-space:pre-line;overflow-wrap:anywhere}.info.ok{border-left-color:var(--good)}.info.bad{border-left-color:var(--warn)}details.all{margin-top:10px;font-size:12px;color:var(--muted)}details.all summary{cursor:pointer;padding:4px 0}.list{margin-top:6px;max-height:280px;overflow:auto;scrollbar-color:#304968 #0b1727;white-space:pre;font:12px/1.6 ui-monospace,SFMono-Regular,Menlo,monospace;background:#0b1727;border-radius:7px;padding:10px 12px}.row{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:11px}label{display:block;font-size:12px;color:var(--muted);margin:0 0 5px}input,select{width:100%;background:#091525;border:1px solid #304968;color:var(--txt);border-radius:7px;padding:9px}input:focus,select:focus{outline:2px solid var(--blue);border-color:transparent}button{background:var(--blue);color:#071323;border:0;border-radius:7px;padding:10px 14px;font-weight:750;cursor:pointer;margin:14px 8px 0 0}button.secondary{background:#20334d;color:var(--txt)}button.stop{background:var(--red)}.status{scrollbar-color:#304968 #0b1727;padding:10px;border-radius:7px;background:#0b1727;color:var(--muted);font-size:12px;white-space:pre-wrap;max-height:230px;overflow:auto}.pill{display:inline-block;border:1px solid var(--line);padding:3px 7px;border-radius:99px;font-size:11px;color:var(--muted);margin:0 5px 5px 0}.ready{color:var(--good)}.danger{border-color:#73404b;background:linear-gradient(135deg,#251722,#101c2e)}.danger h2{color:var(--warn)}.check{display:flex;gap:7px;align-items:center;color:var(--muted);font-size:12px;margin-top:10px}.check input{width:auto}@media(max-width:800px){.card{grid-column:1/-1}.row{grid-template-columns:1fr}}
</style></head><body><main class="wrap"><h1>Daksha / GR00T Training Studio</h1><div class="sub">A guided local control panel for 16-DoF Daksha (OpenArm B1) training, checkpoint management, offline evaluation, and real-robot deployment. Uses <code>examples/openarm_b1</code> and the <code>OPENARM_B1</code> tag. Dataset roots: <code id="roots">…</code></div><div class="grid">
<section class="card full"><h2>1. Dataset</h2><div class="hint">Select a LeRobot dataset. <code>●</code> means it has <code>meta/modality.json</code>, a 16-value action vector, and camera keys that match a config in <code>examples/openarm_b1</code>: 3 cameras use <code>pick_box_config.py</code>, 4 ZED/wrist cameras use <code>openarm_b1_config.py</code>. Selecting a dataset sets the action chunk to the length its <code>meta/relative_stats.json</code> was computed for.</div><select id="dataset" onchange="pickDataset()"></select><button class="secondary" onclick="loadState()">Rescan folders</button><div id="datasetInfo" class="info">Loading datasets…</div><details class="all"><summary id="allSummary">All datasets</summary><div id="datasetList" class="list"></div></details></section>
<section class="card"><h2>2. Train or resume</h2><div class="hint">Choose an output folder. Starting again with the same folder resumes from its newest checkpoint automatically. Checkpoints are saved at the selected interval.</div><div class="row"><div><label>Base model / checkpoint</label><input id="base" value="nvidia/GR00T-N1.6-3B"></div><div><label>Output folder</label><input id="output" value="/home/physicalai/Desktop/I/groot/outputs/openarm_b1_run"></div><div><label>Learning rate</label><input id="lr" type="number" step="any" value="0.0001"></div><div><label>Action chunk (steps)</label><input id="chunk" type="number" min="1" max="40" value="8"></div><div><label>Max training steps</label><input id="steps" type="number" value="50000"></div><div><label>Global batch size</label><input id="batch" type="number" value="8"></div><div><label>Save every steps</label><input id="save" type="number" value="1000"></div><div><label>Checkpoints to keep</label><input id="keep" type="number" value="3"></div><div><label>GPU ids</label><input id="cuda" value="0"></div><div><label>Data workers</label><input id="workers" type="number" value="4"></div></div><label class="check"><input id="diffusion" type="checkbox" checked> Fine-tune diffusion action decoder</label><label class="check"><input id="visual" type="checkbox"> Fine-tune visual encoder (uses more VRAM)</label><button onclick="train()">Start / resume training</button><button class="stop" onclick="stop('training')">Stop training</button></section>
<section class="card"><h2>Live training log</h2><div class="hint">Stopping sends SIGINT. Already written checkpoints remain; use the same output folder to resume.</div><div id="training" class="status">No training job.</div></section>
<section class="card"><h2>3. Checkpoint → inference server (System A)</h2><div class="hint">Loads the selected checkpoint and serves it to the ROS2 bridge. The embodiment tag is fixed to <code>OPENARM_B1</code>, the tag the local Daksha checkpoints were trained with.</div><label>Checkpoint</label><select id="model"></select><div class="row"><div><label>Host</label><input id="host" value="0.0.0.0"></div><div><label>Port</label><input id="serverPort" value="5555"></div></div><button onclick="server()">Start System A</button><button class="stop" onclick="stop('inference')">Stop System A</button><div id="inference" class="status">No inference server.</div></section>
<section class="card"><h2>4. Offline evaluation</h2><div class="hint">Opens the existing Daksha validation studio on recorded episodes. It evaluates model predictions against dataset actions; it does not command the robot.</div><div class="row"><div><label>Validation port</label><input id="evalPort" value="8123"></div><div><label>Action horizon</label><input id="evalChunk" value="8"></div></div><button onclick="evaluate()">Start evaluation studio</button><button class="stop" onclick="stop('evaluation')">Stop evaluation</button><div id="evaluation" class="status">No evaluation studio.</div></section>
<section class="card full danger"><h2>5. Real robot bridge (System B)</h2><div class="hint">This starts a task wrapper from <code>examples/openarm_b1</code>, which publishes joint commands. Each wrapper carries the joint limits of one checkpoint: pick the one that matches the checkpoint System A is serving. Verify your robot, topic wiring, action horizon, limits, and emergency stop first. These bridges are the 3-camera (world, wrist_right, wrist_left) bridge; they are not a drop-in bridge for a four-camera dataset.</div><div class="row"><div><label>Task wrapper (must match the served checkpoint)</label><select id="bridgeScript"></select></div><div><label>System A host</label><input id="policyHost" value="127.0.0.1"></div><div><label>System A port</label><input id="policyPort" value="5555"></div><div><label>Action horizon (must match checkpoint)</label><input id="bridgeChunk" value="8"></div><div><label>Confirmation</label><input id="confirm" placeholder="Type START ROBOT"></div></div><button onclick="bridge()">Start System B bridge</button><button class="stop" onclick="stop('bridge')">Stop bridge</button><div id="bridge" class="status">No bridge process.</div></section>
</div></main><script>
let state={};const TOKEN=new URLSearchParams(location.search).get('token')||'';const $=id=>document.getElementById(id);const value=id=>$(id).value;async function api(path,body){let r=await fetch(path,{method:body?'POST':'GET',headers:{'Content-Type':'application/json','X-Auth-Token':TOKEN},body:body?JSON.stringify(body):undefined});let d=await r.json();if(!r.ok)throw Error(d.error||'Request failed');return d}function options(select,items){let sig=JSON.stringify(items);if(select.dataset.sig===sig)return;select.dataset.sig=sig;let keep=select.value;select.innerHTML='';if(!items.length){select.innerHTML='<option value="">No items found</option>';return}items.forEach(x=>{let o=document.createElement('option');o.value=x.path;o.textContent=x.name||x.path;select.append(o)});if(items.some(x=>x.path===keep))select.value=keep}let firstLoad=true;function current(){return (state.datasets||[]).find(d=>d.path===value('dataset'))}function pickDataset(){let d=current();if(d&&d.ready)$('chunk').value=d.stats_horizon||d.config_horizon;showDataset()}function label(d){return d.path.split('/').slice(-2).join('/')}function setText(el,t){if(el.textContent!==t)el.textContent=t}function plan(d){if(!d.ready||d.stats_horizon===0)return d.reason;let chunk=d.stats_horizon||d.config_horizon;return `Config ${d.config.split('/').pop()} · action chunk ${chunk} `+(d.stats_horizon?'(matches meta/relative_stats.json)':'(meta/relative_stats.json will be generated)')}function showDataset(){let d=current(),el=$('datasetInfo');if(!d){el.className='info';setText(el,'No dataset selected.');return}el.className='info '+(d.ready?'ok':'bad');setText(el,`${d.ready?'● Ready to train':'! Not trainable'}: ${label(d)}\n${d.path}\n${d.episodes} episodes · ${d.frames} frames · ${d.fps} fps · ${d.action_dim} action values\n${plan(d)}`)}function showList(){let ds=state.datasets||[],w=Math.max(0,...ds.map(d=>label(d).length));setText($('allSummary'),`All datasets: ${ds.filter(d=>d.ready).length} ready of ${ds.length}`);setText($('datasetList'),ds.map(d=>`${d.ready?'●':'!'} ${label(d).padEnd(w)}  ${String(d.episodes).padStart(4)} ep  ${d.ready&&d.stats_horizon!==0?d.config.split('/').pop()+', chunk '+(d.stats_horizon||d.config_horizon):d.reason}`).join('\n'))}function jobLabel(j){let rc=j.returncode;if(j.running)return '● Running';if(rc===0)return '● Finished';if(rc===-2)return '■ Stopped with the Stop button';if(rc<0)return `✖ Killed by signal ${-rc}`;return `✖ Failed with exit code ${rc}`}function showJob(id,j){let el=$(id),atEnd=el.scrollHeight-el.scrollTop-el.clientHeight<40;setText(el,!j?'No process.':`${jobLabel(j)}\n$ ${j.command.join(' ')}\n\n${j.logs.join('\n')}${j.running?'':'\n\n'+jobLabel(j)}`);if(atEnd)el.scrollTop=el.scrollHeight}
async function loadState(){try{state=await api('/api/state');$('roots').textContent=state.defaults.dataset_roots.join('  ·  ');options($('dataset'),state.datasets.map(d=>({path:d.path,name:`${d.ready?'●':'!'} ${label(d)}`})));options($('model'),state.checkpoints);options($('bridgeScript'),state.bridges.map(s=>({path:s,name:s})));if(firstLoad){firstLoad=false;pickDataset()}showDataset();showList();for(let id of ['training','inference','evaluation','bridge'])showJob(id,state.jobs[id]);}catch(e){alert(e.message)}}async function train(){try{await api('/api/train',{dataset:value('dataset'),base_model:value('base'),output_dir:value('output'),learning_rate:value('lr'),chunk:value('chunk'),max_steps:value('steps'),batch_size:value('batch'),save_steps:value('save'),keep_checkpoints:value('keep'),cuda_devices:value('cuda'),workers:value('workers'),tune_diffusion:$('diffusion').checked,tune_visual:$('visual').checked});loadState()}catch(e){alert(e.message)}}async function server(){try{await api('/api/server',{model:value('model'),host:value('host'),port:value('serverPort')});loadState()}catch(e){alert(e.message)}}async function evaluate(){try{await api('/api/evaluate',{dataset:value('dataset'),model:value('model'),port:value('evalPort'),chunk:value('evalChunk')});window.open(`${location.protocol}//${location.hostname}:${value('evalPort')}/${TOKEN?'?token='+encodeURIComponent(TOKEN):''}`,'_blank');loadState()}catch(e){alert(e.message)}}async function bridge(){try{await api('/api/bridge',{script:value('bridgeScript'),policy_host:value('policyHost'),policy_port:value('policyPort'),chunk:value('bridgeChunk'),confirm:value('confirm')});loadState()}catch(e){alert(e.message)}}async function stop(name){if(name==='training'&&!confirm('Stop training now?\n\nSteps since the last saved checkpoint are lost. Start / resume training continues from the newest checkpoint in the same output folder.'))return;try{await api('/api/stop',{name});loadState()}catch(e){alert(e.message)}}loadState();setInterval(loadState,2500);
</script></body></html>'''


def handler(studio: Studio):
    class H(BaseHTTPRequestHandler):
        def reply(self, code, payload, kind="application/json"):
            raw = json.dumps(payload).encode() if kind == "application/json" else payload
            self.send_response(code); self.send_header("Content-Type", kind+"; charset=utf-8"); self.send_header("Content-Length", str(len(raw))); self.end_headers(); self.wfile.write(raw)
        def authorized(self) -> bool:
            if not studio.args.token:
                return True
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            given = (q.get("token") or [""])[0] or self.headers.get("X-Auth-Token", "")
            if hmac.compare_digest(given.encode(), studio.args.token.encode()):
                return True
            if urllib.parse.urlparse(self.path).path == "/":
                self.reply(401, b"Bad or missing token: open this page as /?token=<secret>", "text/plain")
            else:
                self.reply(401, {"error": "bad or missing token: open the page with ?token=<secret>"})
            return False
        def do_GET(self):
            if not self.authorized(): return
            if urllib.parse.urlparse(self.path).path == "/": self.reply(200, HTML.encode(), "text/html")
            elif urllib.parse.urlparse(self.path).path == "/api/state": self.reply(200, studio.state())
            else: self.reply(404,{"error":"not found"})
        def do_POST(self):
            if not self.authorized(): return
            try:
                n=int(self.headers.get("Content-Length","0")); body=json.loads(self.rfile.read(n) or b"{}")
                route=urllib.parse.urlparse(self.path).path
                if route=="/api/train": result=studio.start_training(body).public()
                elif route=="/api/server": result=studio.start_server(body).public()
                elif route=="/api/evaluate": result=studio.start_eval(body).public()
                elif route=="/api/bridge": result=studio.start_bridge(body).public()
                elif route=="/api/stop": result={"stopped":studio.jobs.get(body.get("name")).stop() if studio.jobs.get(body.get("name")) else False}
                else: raise ValueError("not found")
                self.reply(200,result)
            except (ValueError, PermissionError, RuntimeError, KeyError) as e: self.reply(400,{"error":str(e)})
            except Exception as e: self.reply(500,{"error":f"{type(e).__name__}: {e}"})
        def log_message(self,*_): pass
    return H


def main():
    p=argparse.ArgumentParser(description="Daksha GR00T Training Studio")
    p.add_argument("--host",default=os.environ.get("HOST","127.0.0.1"),help="Address to listen on, e.g. 192.168.200.114 for the LAN, 127.0.0.1 for this machine only.")
    p.add_argument("--token",default=os.environ.get("TOKEN",""),help="Require ?token=<secret> on every request. Strongly advised on a LAN address.");p.add_argument("--port",type=int,default=int(os.environ.get("PORT","8130")))
    p.add_argument("--dataset-root",action="append",default=None);p.add_argument("--output-root",default=str(REPO_ROOT/"outputs"));p.add_argument("--allow-root",action="append",default=None)
    a=p.parse_args();a.dataset_roots=[Path(x).expanduser().resolve() for x in (a.dataset_root or [str(r) for r in DEFAULT_DATASET_ROOTS])];a.output_root=Path(a.output_root).expanduser().resolve();a.allow_roots=[Path(x).expanduser().resolve() for x in (a.allow_root or [str(Path.home()),str(REPO_ROOT)])]
    try:
        httpd=ThreadingHTTPServer((a.host,a.port),handler(Studio(a)))
    except OSError as e:
        raise SystemExit(f"Cannot listen on {a.host}:{a.port} ({e}). Is {a.host} an address of this machine (ip -4 addr), and is the port free?")
    suffix=f"/?token={urllib.parse.quote(a.token)}" if a.token else "/"
    print(f"Daksha Training Studio: http://{a.host}:{a.port}{suffix}",flush=True)
    if a.host not in ("127.0.0.1","localhost","::1") and not a.token:
        print("  ! Anyone who can reach this address can start training and the robot bridge. Set TOKEN=<secret> on a shared network.",flush=True)
    httpd.serve_forever()
if __name__=="__main__": main()
