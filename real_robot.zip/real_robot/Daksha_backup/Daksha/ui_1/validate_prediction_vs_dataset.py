#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""
Offline (no-robot) validation UI for the Daksha GR00T N1.6 policy.

Runs the trained model open-loop over your RECORDED dataset and overlays, for
every joint, three curves:

  * state  : the recorded joint position (proprioception) at each frame
  * gt      : the recorded ACTION the human demonstrated (ground truth)
  * pred    : what the MODEL predicts given the recorded observation

If the model learned the task well, `pred` tracks `gt` closely. Where `pred` is
flat / offset / noisy for a joint, that joint was not learned well (very common
for grippers). Each subplot is labelled with the ACTUAL joint name taken from the
dataset meta (info.json + modality.json), so you can answer "which is the 1st
joint?" and spot ordering problems directly.

IMPORTANT — what this validates and what it does NOT:
  * VALIDATES the MODEL: given a correct observation, does it predict the
    recorded actions? This is independent of the ROS2 bridge.
  * Does NOT validate the ROS2 deployment mapping (topic order, left/right
    routing, clamp limits). Those live in eval_daksha_ros2.py. A model that
    looks perfect here can still move wrongly on the robot if the bridge maps
    joints incorrectly — validate both.

The observation is built with GR00T's own dataset loader + policy API (the exact
path training used), so this tool cannot reintroduce a left/right swap.

Outputs (into --out-dir):
  * episode_<id>.png            per-joint overlay figure
  * validation_report.html      self-contained dashboard (open in a browser)

Example:
  cd ~/Desktop/I/groot && source .venv/bin/activate
  python gr00t/eval/real_robot/Daksha_backup/Daksha/ui_1/validate_prediction_vs_dataset.py \
    --model-path /home/physicalai/Desktop/I/groot/outputs/pick_box_2_8chunk/checkpoint-50000 \
    --dataset-path /home/physicalai/Desktop/I/barani/pick_box_2 \
    --embodiment-tag openarm_b1 \
    --episodes 0 1 2 \
    --steps 200 --action-horizon 8

  # Or reuse an already-running policy server instead of loading the model:
  #   (drop --model-path and pass --host/--port)
"""

from __future__ import annotations

import argparse
import base64
import json
import logging
from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # headless: render straight to PNG, no display needed
import matplotlib.pyplot as plt
import numpy as np

# Reuse GR00T's own (correct) observation/action parsing so the state groups and
# normalisation match training exactly.
from gr00t.eval.open_loop_eval import parse_action_gr00t, parse_observation_gr00t
from gr00t.data.dataset.lerobot_episode_loader import LeRobotEpisodeLoader
from gr00t.data.dataset.sharded_single_step_dataset import extract_step_data
from gr00t.data.embodiment_tags import EmbodimentTag

# No modality config is imported here: the loader below is built from
# policy.get_modality_config(), i.e. the config baked into the checkpoint, so it
# always matches what the model was trained on (examples/openarm_b1/*_config.py).

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
log = logging.getLogger("validate")


def build_joint_labels(dataset_path: Path, action_keys: list[str]) -> list[str]:
    """Map each concatenated action dimension to its real recorded joint name.

    The prediction/gt vectors are concatenated in `action_keys` order, and each
    group's dims come from the modality.json slice into the flat action vector,
    whose per-index names live in info.json. Returns one label per output dim.
    """
    info = json.loads((dataset_path / "meta" / "info.json").read_text())
    modality = json.loads((dataset_path / "meta" / "modality.json").read_text())
    flat_names = info["features"]["action"]["names"]
    labels: list[str] = []
    for key in action_keys:
        sl = modality["action"][key]
        names = flat_names[sl["start"] : sl["end"]]
        # Prefix with the group so the physical side is unambiguous.
        labels.extend(f"{key}:{n}" for n in names)
    return labels


def run_episode(policy, loader, traj_id, embodiment_tag, steps, action_horizon):
    """Open-loop rollout over one recorded episode.

    Returns (state[T,D], gt[T,D], pred[T,D]) all aligned in the model's action
    key order.
    """
    from copy import deepcopy

    traj = loader[traj_id]
    actual_steps = min(steps, len(traj))
    log.info(f"episode {traj_id}: length={len(traj)} using {actual_steps} steps")

    state_keys = loader.modality_configs["state"].modality_keys
    action_keys = loader.modality_configs["action"].modality_keys

    obs_modality_configs = deepcopy(loader.modality_configs)
    obs_modality_configs.pop("action")

    pred_across_time: list[np.ndarray] = []
    for step in range(0, actual_steps, action_horizon):
        data_point = extract_step_data(traj, step, obs_modality_configs, embodiment_tag)
        obs = {}
        for k, v in data_point.states.items():
            obs[f"state.{k}"] = v
        for k, v in data_point.images.items():
            obs[f"video.{k}"] = np.array(v)
        for language_key in loader.modality_configs["language"].modality_keys:
            obs[language_key] = data_point.text
        parsed_obs = parse_observation_gr00t(obs, loader.modality_configs)
        raw_action, _ = policy.get_action(parsed_obs)
        action_chunk = parse_action_gr00t(raw_action)
        for j in range(action_horizon):
            vec = np.concatenate(
                [np.atleast_1d(np.atleast_1d(action_chunk[f"action.{key}"])[j]) for key in action_keys],
                axis=0,
            )
            pred_across_time.append(vec)

    def stack(columns):
        return np.concatenate([np.vstack([a for a in traj[c]]) for c in columns], axis=-1)

    state = stack([f"state.{k}" for k in state_keys])[:actual_steps]
    gt = stack([f"action.{k}" for k in action_keys])[:actual_steps]
    pred = np.array(pred_across_time)[:actual_steps]
    return state, gt, pred


def plot_episode(state, gt, pred, labels, traj_id, action_horizon, png_path: Path):
    n = gt.shape[1]
    ncols = 4
    nrows = int(np.ceil(n / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(5 * ncols, 3 * nrows), squeeze=False)
    same_shape = state.shape == gt.shape
    # Minimum y-window (radians). Without this, joints that barely move get zoomed
    # in so far that tiny prediction jitter looks like a huge error. Forcing a floor
    # makes small motions look small (which they are) and keeps the comparison honest.
    MIN_SPAN = 0.12
    for i in range(nrows * ncols):
        ax = axes[i // ncols][i % ncols]
        if i >= n:
            ax.axis("off")
            continue
        if same_shape:
            ax.plot(state[:, i], color="#9aa0a6", lw=1, alpha=0.7, label="robot state (recorded)")
        ax.plot(gt[:, i], color="#1a73e8", lw=2.2, label="DATASET action (recorded)")
        ax.plot(pred[:, i], color="#ea4335", lw=1.6, ls="--", label="MODEL prediction")
        for j in range(0, len(gt), action_horizon):
            ax.axvline(j, color="#eeeeee", lw=0.6, zorder=0)
        # y-limits: include all data, but never zoom tighter than MIN_SPAN.
        lo = float(min(gt[:, i].min(), pred[:, i].min()))
        hi = float(max(gt[:, i].max(), pred[:, i].max()))
        if hi - lo < MIN_SPAN:
            mid = 0.5 * (lo + hi)
            lo, hi = mid - MIN_SPAN / 2, mid + MIN_SPAN / 2
        pad = 0.08 * (hi - lo)
        ax.set_ylim(lo - pad, hi + pad)
        mae = float(np.mean(np.abs(gt[:, i] - pred[:, i])))
        rng = float(gt[:, i].max() - gt[:, i].min())
        if rng < 0.02:
            verdict = "~static (barely moves)"
        elif mae < 0.05:
            verdict = "MATCH"
        else:
            verdict = "check timing"
        ax.set_title(f"[{i}] {labels[i]}\nMAE={mae:.4f} rad  -  {verdict}", fontsize=9)
        ax.tick_params(labelsize=7)
        if i == 0:
            ax.legend(fontsize=8, loc="best")
    fig.suptitle(
        f"Episode {traj_id} — recorded action (blue) vs model prediction (red dashed)",
        fontsize=13,
    )
    fig.tight_layout(rect=(0, 0, 1, 0.98))
    png_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(png_path, dpi=110)
    plt.close(fig)


def per_joint_metrics(gt, pred, labels):
    rows = []
    for i, name in enumerate(labels):
        e = gt[:, i] - pred[:, i]
        rng = float(gt[:, i].max() - gt[:, i].min())
        rows.append(
            {
                "idx": i,
                "joint": name,
                "mae": float(np.mean(np.abs(e))),
                "rmse": float(np.sqrt(np.mean(e**2))),
                "gt_range": rng,
                # normalised error: MAE relative to how much the joint actually moves
                "nmae": float(np.mean(np.abs(e)) / rng) if rng > 1e-6 else float("nan"),
            }
        )
    return rows


def build_html(out_dir: Path, meta: dict, episodes: list[dict]):
    def color_for(nmae):
        if nmae != nmae:  # nan (joint barely moves)
            return "#5f6368"
        if nmae < 0.10:
            return "#188038"  # good
        if nmae < 0.25:
            return "#e37400"  # marginal
        return "#c5221f"  # poor

    css = """
    :root{color-scheme:light dark}
    body{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;margin:0;background:#fff;color:#202124}
    @media (prefers-color-scheme:dark){body{background:#111;color:#e8eaed}
      .card{background:#1c1c1e!important;border-color:#333!important}
      th{background:#26262a!important}}
    .wrap{max-width:1200px;margin:0 auto;padding:24px}
    h1{font-size:20px;margin:0 0 4px} h2{font-size:16px;margin:28px 0 10px}
    .sub{color:#5f6368;font-size:13px;margin-bottom:16px}
    .card{border:1px solid #e0e0e0;border-radius:10px;padding:16px;margin:12px 0;background:#fafafa}
    table{border-collapse:collapse;width:100%;font-size:13px}
    th,td{padding:6px 10px;text-align:right;border-bottom:1px solid #eee}
    th:nth-child(2),td:nth-child(2){text-align:left}
    th{position:sticky;top:0;background:#f1f3f4}
    .kpi{display:inline-block;margin-right:24px;font-size:13px}
    .kpi b{font-size:20px;display:block}
    img{max-width:100%;height:auto;border-radius:8px;border:1px solid #e0e0e0}
    .note{font-size:12.5px;line-height:1.5;background:#fff8e1;border-left:4px solid #f9ab00;padding:10px 14px;border-radius:4px}
    @media (prefers-color-scheme:dark){.note{background:#2a2410;color:#e8eaed}
      th,td{border-color:#333} .sub{color:#9aa0a6}}
    code{background:rgba(128,128,128,.2);padding:1px 5px;border-radius:4px}
    """

    parts = [f"<style>{css}</style>", "<div class='wrap'>"]
    parts.append("<h1>Daksha — Model Prediction vs Recorded Dataset</h1>")
    parts.append(
        f"<div class='sub'>Checkpoint: <code>{meta['model']}</code> &nbsp;•&nbsp; "
        f"Dataset: <code>{meta['dataset']}</code> &nbsp;•&nbsp; "
        f"Embodiment: <code>{meta['embodiment']}</code> &nbsp;•&nbsp; "
        f"horizon={meta['action_horizon']}</div>"
    )
    parts.append(
        "<div class='note'><b>How to read this:</b> blue = the action the human "
        "recorded (ground truth), red dashed = what the model predicts from the same "
        "recorded camera+state observation. Close curves = the model learned that joint. "
        "A flat / offset red line (often the gripper) means the model did not learn that "
        "joint's motion. <b>This checks the MODEL only</b> — the robot can still move "
        "wrongly if the ROS2 bridge maps joints incorrectly; validate that separately.</div>"
    )

    for ep in episodes:
        parts.append(f"<h2>Episode {ep['traj_id']}</h2>")
        parts.append("<div class='card'>")
        parts.append(
            f"<span class='kpi'>Overall MAE<b>{ep['overall_mae']:.4f}</b></span>"
            f"<span class='kpi'>Overall RMSE<b>{ep['overall_rmse']:.4f}</b></span>"
            f"<span class='kpi'>Steps<b>{ep['steps']}</b></span>"
            f"<span class='kpi'>Worst joint<b>{ep['worst']}</b></span>"
        )
        parts.append("</div>")

        b64 = base64.b64encode(ep["png"].read_bytes()).decode()
        parts.append(f"<img src='data:image/png;base64,{b64}' alt='episode {ep['traj_id']}'/>")

        parts.append("<div class='card'><table>")
        parts.append(
            "<tr><th>dim</th><th>joint</th><th>MAE</th><th>RMSE</th>"
            "<th>gt range</th><th>MAE/range</th></tr>"
        )
        for r in sorted(ep["rows"], key=lambda x: (x["nmae"] if x["nmae"] == x["nmae"] else -1), reverse=True):
            c = color_for(r["nmae"])
            nm = "—" if r["nmae"] != r["nmae"] else f"{r['nmae']*100:.0f}%"
            parts.append(
                f"<tr><td>{r['idx']}</td><td>{r['joint']}</td>"
                f"<td>{r['mae']:.4f}</td><td>{r['rmse']:.4f}</td>"
                f"<td>{r['gt_range']:.4f}</td>"
                f"<td style='color:{c};font-weight:600'>{nm}</td></tr>"
            )
        parts.append("</table></div>")

    parts.append("</div>")
    html = "\n".join(parts)
    out = out_dir / "validation_report.html"
    out.write_text(html)
    return out


def parse_args():
    p = argparse.ArgumentParser(description="Offline model-vs-dataset validation for Daksha")
    p.add_argument("--model-path", default=None, help="Checkpoint dir. If omitted, connect to a running server via --host/--port.")
    p.add_argument("--dataset-path", required=True, help="LeRobot dataset root (contains data/ meta/ videos/).")
    p.add_argument("--embodiment-tag", default="openarm_b1",
                   help="OPENARM_B1: the tag the local Daksha checkpoints were trained with.")
    p.add_argument("--episodes", type=int, nargs="+", default=[0], help="Episode ids to validate.")
    p.add_argument("--steps", type=int, default=200, help="Max frames per episode.")
    p.add_argument("--action-horizon", type=int, default=8, help="Must match the checkpoint's action delta_indices count.")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=5555)
    p.add_argument("--out-dir", default=None, help="Output dir (default: <dataset>/../validation_<name>).")
    return p.parse_args()


def main():
    args = parse_args()
    dataset_path = Path(args.dataset_path).expanduser().resolve()
    embodiment_tag = EmbodimentTag.resolve(args.embodiment_tag)
    out_dir = Path(args.out_dir).expanduser().resolve() if args.out_dir else (
        dataset_path.parent / f"validation_{dataset_path.name}"
    )
    out_dir.mkdir(parents=True, exist_ok=True)

    if args.model_path:
        import torch
        from gr00t.policy.gr00t_policy import Gr00tPolicy

        log.info(f"Loading model from {args.model_path} ...")
        policy = Gr00tPolicy(
            embodiment_tag=embodiment_tag,
            model_path=args.model_path,
            device="cuda" if torch.cuda.is_available() else "cpu",
        )
    else:
        from gr00t.policy.server_client import PolicyClient

        log.info(f"Connecting to policy server tcp://{args.host}:{args.port} ...")
        policy = PolicyClient(host=args.host, port=args.port)

    modality = policy.get_modality_config()
    loader = LeRobotEpisodeLoader(
        dataset_path=str(dataset_path),
        modality_configs=modality,
        video_backend="torchcodec",
        video_backend_kwargs=None,
    )
    log.info(f"Dataset episodes available: {len(loader)}")

    action_keys = modality["action"].modality_keys
    labels = build_joint_labels(dataset_path, action_keys)
    log.info(f"Action dim order (dim0 first): {labels}")

    episodes = []
    for traj_id in args.episodes:
        if traj_id >= len(loader):
            log.warning(f"episode {traj_id} out of range (have {len(loader)}); skipping")
            continue
        state, gt, pred = run_episode(policy, loader, traj_id, embodiment_tag, args.steps, args.action_horizon)
        png = out_dir / f"episode_{traj_id}.png"
        plot_episode(state, gt, pred, labels, traj_id, args.action_horizon, png)
        rows = per_joint_metrics(gt, pred, labels)
        # Raw curves for the interactive web UI (serve_validation_ui.py). Rounded to
        # 5 decimals: ~1e-5 rad is far below encoder resolution, and it keeps the
        # payload small enough to inline into the page.
        dump = {
            "traj_id": traj_id,
            "labels": labels,
            "action_horizon": args.action_horizon,
            "state": np.round(state, 5).tolist() if state.shape == gt.shape else None,
            "gt": np.round(gt, 5).tolist(),
            "pred": np.round(pred, 5).tolist(),
            # nmae is NaN for joints that do not move; NaN is not valid JSON and
            # JSON.parse() rejects it, so hand the UI a null instead.
            "rows": [{k: (None if isinstance(v, float) and v != v else v) for k, v in r.items()} for r in rows],
        }
        (out_dir / f"episode_{traj_id}.json").write_text(json.dumps(dump))
        worst = max(rows, key=lambda r: (r["nmae"] if r["nmae"] == r["nmae"] else -1))
        overall_mae = float(np.mean(np.abs(gt - pred)))
        overall_rmse = float(np.sqrt(np.mean((gt - pred) ** 2)))
        log.info(f"episode {traj_id}: overall MAE={overall_mae:.4f} RMSE={overall_rmse:.4f} worst={worst['joint']}")
        # concise console table
        print(f"\n=== Episode {traj_id} per-joint error (worst first) ===")
        print(f"{'dim':>3} {'joint':<32} {'MAE':>9} {'RMSE':>9} {'MAE/range':>10}")
        for r in sorted(rows, key=lambda x: (x["nmae"] if x["nmae"] == x["nmae"] else -1), reverse=True):
            nm = "  n/a" if r["nmae"] != r["nmae"] else f"{r['nmae']*100:6.1f}%"
            print(f"{r['idx']:>3} {r['joint']:<32} {r['mae']:>9.4f} {r['rmse']:>9.4f} {nm:>10}")
        episodes.append(
            {
                "traj_id": traj_id,
                "png": png,
                "rows": rows,
                "worst": worst["joint"],
                "overall_mae": overall_mae,
                "overall_rmse": overall_rmse,
                "steps": len(gt),
            }
        )

    if not episodes:
        log.error("No episodes evaluated.")
        return

    meta = {
        "model": args.model_path or f"server {args.host}:{args.port}",
        "dataset": str(dataset_path),
        "embodiment": str(args.embodiment_tag),
        "action_horizon": args.action_horizon,
        "episode_ids": [e["traj_id"] for e in episodes],
    }
    (out_dir / "meta.json").write_text(json.dumps(meta, indent=1))
    html = build_html(out_dir, meta, episodes)
    log.info(f"\nDone. Open the dashboard:\n  {html}\nPNG(s) in: {out_dir}")


if __name__ == "__main__":
    main()
