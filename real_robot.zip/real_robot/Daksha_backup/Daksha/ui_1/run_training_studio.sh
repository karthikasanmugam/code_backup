#!/usr/bin/env bash
# Local browser UI for Daksha (OpenArm B1) GR00T training and checkpoint deployment.
#
#   bash gr00t/eval/real_robot/Daksha_backup/Daksha/ui_1/run_training_studio.sh
#   DATASET_ROOTS=/home/physicalai/Desktop/I/barani bash .../run_training_studio.sh
#   TOKEN=mysecret bash .../run_training_studio.sh   # then open http://192.168.200.114:8130/?token=mysecret
#   HOST=127.0.0.1 bash .../run_training_studio.sh   # this machine only
#
# It listens on 192.168.200.114 (enp194s0), so other machines on 192.168.200.0/24
# can open http://192.168.200.114:8130. Anyone who reaches that address can start
# training and the robot bridge, so set TOKEN on a shared network.
#
# Training uses the configs in examples/openarm_b1 and the OPENARM_B1 tag.
set -euo pipefail

# Resolved before the cd below, so the studio is found wherever this folder lives.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

REPO_ROOT="${REPO_ROOT:-/home/physicalai/Desktop/I/groot}"
cd "$REPO_ROOT"
source .venv/bin/activate

HOST="${HOST:-192.168.200.114}"
TOKEN="${TOKEN:-}"
PORT="${PORT:-8130}"
# Colon-separated folders that hold the 16-DoF OpenArm B1 LeRobot datasets.
# The studio polls them every few seconds, so list dataset folders rather than
# /home/physicalai/Desktop/I itself, which also holds large model caches.
D=/home/physicalai/Desktop/I
DATASET_ROOTS="${DATASET_ROOTS:-$D/barani:$D/dinesh:$D/open_arm_datasetv3:$D/Muliti_dataset_storage:$D/Dataset}"
OUTPUT_ROOT="${OUTPUT_ROOT:-$REPO_ROOT/outputs}"
ALLOW_ROOT="${ALLOW_ROOT:-/home/physicalai}"

ROOT_ARGS=()
IFS=':' read -r -a _roots <<< "$DATASET_ROOTS"
for r in "${_roots[@]}"; do
  [ -n "$r" ] && ROOT_ARGS+=(--dataset-root "$r")
done

exec python "$SCRIPT_DIR/training_studio.py" \
  --host "$HOST" --port "$PORT" ${TOKEN:+--token "$TOKEN"} "${ROOT_ARGS[@]}" \
  --output-root "$OUTPUT_ROOT" --allow-root "$ALLOW_ROOT" --allow-root "$REPO_ROOT"
