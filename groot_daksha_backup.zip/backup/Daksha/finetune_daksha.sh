#!/usr/bin/env bash
set -euo pipefail

cd ~/.ihub/vla/groot/Isaac-GR00T-n1.6.1
source .venv/bin/activate

CUDA_VISIBLE_DEVICES=0 python -m gr00t.experiment.launch_finetune \
  --base-model-path nvidia/GR00T-N1.6-3B \
  --dataset-path /home/physicalai/Desktop/I/open_arm_datasetv3/new_daksha_b1_pick_place \
  --modality-config-path examples/Daksha/daksha_config.py \
  --embodiment-tag DAKSHA \
  --num-gpus 1 \
  --output-dir ./outputs/daksha_new_daksha_b1_pick_place_ft \
  --save-total-limit 2 \
  --save-steps 1000 \
  --max-steps 50000 \
  --global-batch-size 8 \
  --dataloader-num-workers 4 \
  --no-tune-diffusion-model
