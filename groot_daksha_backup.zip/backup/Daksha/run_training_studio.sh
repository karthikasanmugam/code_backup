#!/usr/bin/env bash
# Local browser UI for Daksha GR00T training and deployment.
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$REPO_ROOT"
source .venv/bin/activate

HOST="${HOST:-127.0.0.1}"
PORT="${PORT:-8105}"
URL="http://127.0.0.1:${PORT}"

echo "Daksha Training Studio will be available at: ${URL}"
# A local desktop session gets a browser tab automatically. This is deliberately
# skipped for a LAN binding: open http://<server-IP>:${PORT} from the other machine.
if [[ "$HOST" == "127.0.0.1" || "$HOST" == "localhost" ]]; then
  ( sleep 2; xdg-open "$URL" >/dev/null 2>&1 ) &
fi

exec python examples/Daksha/training_studio.py \
  --host "$HOST" --port "$PORT" \
  --dataset-root "${DATASET_ROOT:-/home/s1/Desktop/datasets}" \
  --output-root "${OUTPUT_ROOT:-$REPO_ROOT/outputs}" \
  --dataset-path "${DATASET_PATH:-}"
