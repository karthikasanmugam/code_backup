#!/usr/bin/env python3
"""Browser UI for Daksha GR00T fine-tuning, serving, robot bridging, and evaluation.

Run with ``bash examples/Daksha/run_training_studio.sh``.  The server deliberately
uses only the Python standard library, so it works in the same GR00T venv as training.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import re
import signal
import socket
import subprocess
import sys
import threading
import time
import traceback
import urllib.parse
from dataclasses import dataclass, field
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any


HERE = Path(__file__).resolve().parent
REPO_ROOT = HERE.parents[1]
HTML = HERE / "training_studio.html"


def is_dataset(path: Path) -> bool:
    return (path / "meta" / "info.json").is_file()


def checkpoint_dirs(root: Path) -> list[Path]:
    if not root.is_dir():
        return []
    return sorted(
        (p for p in root.rglob("checkpoint-*") if p.is_dir()),
        key=lambda p: (p.stat().st_mtime, str(p)), reverse=True,
    )


def read_info(path: Path) -> dict[str, Any]:
    try:
        data = json.loads((path / "meta" / "info.json").read_text())
        return {"path": str(path), "name": path.name, "episodes": data.get("total_episodes", 0),
                "frames": data.get("total_frames", 0), "fps": data.get("fps", "?"),
                "robot": data.get("robot_type", "")}
    except Exception:
        return {"path": str(path), "name": path.name, "episodes": "?", "frames": "?", "fps": "?", "robot": ""}


def find_datasets(root: Path, depth: int) -> list[dict[str, Any]]:
    found = []
    if not root.is_dir():
        return found
    for p in root.rglob("meta/info.json"):
        dataset = p.parent.parent
        if len(dataset.relative_to(root).parts) <= depth and is_dataset(dataset):
            found.append(read_info(dataset))
    return sorted(found, key=lambda x: x["path"])


@dataclass
class ManagedProcess:
    name: str
    command: list[str]
    cwd: Path
    proc: subprocess.Popen | None = None
    started: float = field(default_factory=time.time)
    lines: list[str] = field(default_factory=list)
    error: str = ""

    def public(self) -> dict[str, Any]:
        running = self.proc is not None and self.proc.poll() is None
        return {"name": self.name, "running": running, "returncode": None if running else (self.proc.poll() if self.proc else None),
                "started": self.started, "log": self.lines[-300:], "error": self.error,
                "command": " ".join(self.command)}


class Studio:
    def __init__(self, args: argparse.Namespace):
        self.args = args
        self.processes: dict[str, ManagedProcess] = {}
        self.lock = threading.Lock()

    def start(self, name: str, command: list[str], env: dict[str, str] | None = None) -> ManagedProcess:
        with self.lock:
            old = self.processes.get(name)
            if old and old.proc and old.proc.poll() is None:
                raise RuntimeError(f"{name} is already running; stop it first")
            item = ManagedProcess(name, command, REPO_ROOT)
            run_env = os.environ.copy()
            if env:
                run_env.update(env)
            item.proc = subprocess.Popen(command, cwd=REPO_ROOT, env=run_env, stdout=subprocess.PIPE,
                                         stderr=subprocess.STDOUT, text=True, bufsize=1,
                                         start_new_session=True)
            self.processes[name] = item
            threading.Thread(target=self._read, args=(item,), daemon=True).start()
            return item

    @staticmethod
    def _read(item: ManagedProcess) -> None:
        try:
            assert item.proc and item.proc.stdout
            for line in item.proc.stdout:
                item.lines.append(line.rstrip())
                if len(item.lines) > 1200:
                    del item.lines[:400]
        except Exception as exc:
            item.error = str(exc)

    def stop(self, name: str) -> bool:
        with self.lock:
            item = self.processes.get(name)
            if not item or not item.proc or item.proc.poll() is not None:
                return False
            os.killpg(item.proc.pid, signal.SIGTERM)
            item.lines.append("[studio] stop requested")
            return True

    def public(self) -> dict[str, Any]:
        return {name: item.public() for name, item in self.processes.items()}


class App:
    def __init__(self, args: argparse.Namespace):
        self.args = args
        self.dataset_root = Path(args.dataset_root).expanduser().resolve()
        self.output_root = Path(args.output_root).expanduser().resolve()
        self.allow_roots = [self.dataset_root, self.output_root, REPO_ROOT.resolve()]
        self.studio = Studio(args)

    def safe(self, raw: str, roots: list[Path] | None = None) -> Path:
        p = Path(raw).expanduser().resolve()
        if not any(p == root or root in p.parents for root in (roots or self.allow_roots)):
            raise PermissionError(f"{p} is outside the permitted Daksha Studio paths")
        return p

    def state(self) -> dict[str, Any]:
        checkpoints = checkpoint_dirs(self.output_root)
        return {"dataset_root": str(self.dataset_root), "output_root": str(self.output_root),
                "datasets": find_datasets(self.dataset_root, self.args.scan_depth),
                "checkpoints": [{"path": str(p), "name": f"{p.parent.name}/{p.name}", "mtime": p.stat().st_mtime}
                                for p in checkpoints], "processes": self.studio.public(),
                "defaults": {"dataset": self.args.dataset_path, "base_model": self.args.base_model,
                             "modality": str(HERE / "daksha_config.py"), "output": str(self.output_root)}}

    def train(self, body: dict[str, Any]) -> dict[str, Any]:
        dataset = self.safe(str(body["dataset"]), [self.dataset_root])
        if not is_dataset(dataset):
            raise ValueError("Dataset must be a LeRobot root containing meta/info.json")
        run_name = re.sub(r"[^A-Za-z0-9_.-]+", "-", str(body.get("run_name") or dataset.name)).strip(".-")
        if not run_name:
            raise ValueError("Enter a run name")
        output = (self.output_root / run_name).resolve()
        if self.output_root not in output.parents:
            raise PermissionError("Invalid run name")
        checkpoint = str(body.get("resume_checkpoint") or "").strip()
        base_model = checkpoint or str(body.get("base_model") or self.args.base_model)
        if checkpoint:
            cp = self.safe(checkpoint, [self.output_root])
            if not (cp / "config.json").is_file():
                raise ValueError("Resume checkpoint does not contain config.json")
            base_model = str(cp)
        def number(key: str, cast, low: float, default: Any):
            value = cast(body.get(key, default))
            if value < low:
                raise ValueError(f"{key} must be at least {low}")
            return value
        steps = number("max_steps", int, 1, 50000)
        chunk = number("chunk_size", int, 1, 8)
        lr = number("learning_rate", float, 1e-10, 1e-4)
        batch = number("batch_size", int, 1, 8)
        save_steps = number("save_steps", int, 1, 1000)
        keep = number("keep_checkpoints", int, 1, 2)
        gpus = number("num_gpus", int, 1, 1)
        workers = number("workers", int, 0, 4)
        command = [sys.executable, "-m", "gr00t.experiment.launch_finetune",
                   "--base-model-path", base_model, "--dataset-path", str(dataset),
                   "--modality-config-path", str(HERE / "daksha_config.py"),
                   "--embodiment-tag", "DAKSHA", "--action-chunk-size", str(chunk),
                   "--num-gpus", str(gpus), "--output-dir", str(output), "--max-steps", str(steps),
                   "--learning-rate", str(lr), "--global-batch-size", str(batch),
                   "--dataloader-num-workers", str(workers), "--save-steps", str(save_steps),
                   "--save-total-limit", str(keep), "--no-tune-diffusion-model"]
        env = {"CUDA_VISIBLE_DEVICES": str(body.get("cuda_devices") or "0")}
        return self.studio.start("training", command, env).public()

    def server(self, body: dict[str, Any]) -> dict[str, Any]:
        model = self.safe(str(body["model"]), [self.output_root])
        if not (model / "config.json").is_file():
            raise ValueError("Select a completed checkpoint")
        host, port = str(body.get("host") or "0.0.0.0"), int(body.get("port") or 5555)
        command = [sys.executable, "gr00t/eval/run_gr00t_server.py", "--model_path", str(model),
                   "--embodiment-tag", "DAKSHA", "--host", host, "--port", str(port)]
        return self.studio.start("inference-server", command).public()

    def bridge(self, body: dict[str, Any]) -> dict[str, Any]:
        # The bridge can actuate a real robot. Require an explicit browser acknowledgement.
        if body.get("armed") is not True:
            raise PermissionError("Confirm the real-robot safety checkbox before starting the bridge")
        command = ["bash", str(HERE / "run_system_b_daksha_ros2.sh")]
        env = {"POLICY_HOST": str(body.get("policy_host") or "127.0.0.1"),
               "POLICY_PORT": str(body.get("policy_port") or 5555),
               "ACTION_HORIZON": str(body.get("action_horizon") or 8),
               "LANG_INSTRUCTION": str(body.get("instruction") or "")}
        return self.studio.start("robot-bridge", command, env).public()

    def evaluation(self, body: dict[str, Any]) -> dict[str, Any]:
        dataset = self.safe(str(body["dataset"]), [self.dataset_root])
        model = self.safe(str(body["model"]), [self.output_root])
        if not is_dataset(dataset):
            raise ValueError("Select a LeRobot dataset")
        if not (model / "config.json").is_file():
            raise ValueError("Select a completed checkpoint")
        command = [sys.executable, "gr00t/eval/real_robot/Daksha/ui/validation_app.py", "--host", self.args.host,
                   "--port", str(self.args.evaluation_port), "--dataset-root", str(self.dataset_root),
                   "--model-root", str(self.output_root), "--allow-root", str(self.dataset_root),
                   "--allow-root", str(self.output_root), "--dataset-path", str(dataset),
                   "--model-path", str(model), "--embodiment-tag", "DAKSHA"]
        return self.studio.start("evaluation-studio", command).public()


def handler(app: App):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, fmt, *args):
            if "/api/state" not in self.path:
                print(fmt % args, flush=True)

        def send_json(self, code: int, data: Any):
            payload = json.dumps(data).encode()
            self.send_response(code); self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload))); self.end_headers(); self.wfile.write(payload)

        def route(self, method: str):
            path = urllib.parse.urlparse(self.path).path
            if path == "/" and method == "GET":
                payload = HTML.read_bytes(); self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(payload))); self.end_headers(); self.wfile.write(payload); return
            if not path.startswith("/api/"):
                self.send_json(404, {"error": "not found"}); return
            body = {}
            if method == "POST":
                try: body = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
                except json.JSONDecodeError: self.send_json(400, {"error": "Invalid JSON"}); return
            try:
                if path == "/api/state" and method == "GET": result = app.state()
                elif path == "/api/train" and method == "POST": result = app.train(body)
                elif path == "/api/server" and method == "POST": result = app.server(body)
                elif path == "/api/bridge" and method == "POST": result = app.bridge(body)
                elif path == "/api/evaluation" and method == "POST": result = app.evaluation(body)
                elif path.startswith("/api/stop/") and method == "POST": result = {"stopped": app.studio.stop(path.rsplit("/", 1)[1])}
                else: self.send_json(404, {"error": "unknown API route"}); return
                self.send_json(200, result)
            except (ValueError, PermissionError, RuntimeError) as exc: self.send_json(400, {"error": str(exc)})
            except Exception as exc: traceback.print_exc(); self.send_json(500, {"error": f"{type(exc).__name__}: {exc}"})

        def do_GET(self): self.route("GET")
        def do_POST(self): self.route("POST")
    return Handler


def main():
    p = argparse.ArgumentParser(description="Daksha GR00T Training Studio")
    p.add_argument("--host", default="127.0.0.1"); p.add_argument("--port", type=int, default=8105)
    p.add_argument("--dataset-root", default="/home/s1/Desktop/datasets")
    p.add_argument("--output-root", default=str(REPO_ROOT / "outputs")); p.add_argument("--dataset-path", default="")
    p.add_argument("--base-model", default="nvidia/GR00T-N1.6-3B"); p.add_argument("--scan-depth", type=int, default=5)
    p.add_argument("--evaluation-port", type=int, default=8123); args = p.parse_args()
    args.output_root = str(Path(args.output_root).expanduser().resolve()); Path(args.output_root).mkdir(parents=True, exist_ok=True)
    server = ThreadingHTTPServer((args.host, args.port), handler(App(args))); server.daemon_threads = True
    print(f"Daksha GR00T Training Studio: http://localhost:{args.port}", flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: print("\nstopped")


if __name__ == "__main__": main()
