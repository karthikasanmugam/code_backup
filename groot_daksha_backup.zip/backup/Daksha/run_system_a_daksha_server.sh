#!/usr/bin/env bash
# System A (GPU box): serve the daksha / pick_box_2_8chunk checkpoint.
#
# This MUST be the run System B is configured for: pick_box_2_8chunk emits 8-step
# action chunks, and run_system_b_daksha_ros2.sh sets ACTION_HORIZON=8 and
# REPLAN_AT=7 to match. Serving the older 16-chunk outputs/pick_box_2 from here
# would have the bridge execute only the first half of every chunk.
#
#   bash examples/Daksha/run_system_a_daksha_server.sh
#   MODEL_PATH=.../checkpoint-50000 bash examples/Daksha/run_system_a_daksha_server.sh
#   PORT=5556 bash examples/Daksha/run_system_a_daksha_server.sh
#
# Start this BEFORE System B (run_system_b_daksha_ros2.sh).
#
# The embodiment tag must be the one the checkpoint was trained with: `DAKSHA`.
# The checkpoint's own embodiment_id.json is loaded by the processor.
#
# No --modality-config-path is needed: Gr00tPolicy reads the modality config out of
# the checkpoint's processor_config.json, keyed by the embodiment tag. For this run
# that is video=[world, wrist_right, wrist_left], state/action=[left_arm,
# left_gripper, right_arm, right_gripper].
set -euo pipefail

REPO_ROOT="${REPO_ROOT:-/home/physicalai/Desktop/I/groot}"
cd "$REPO_ROOT"
source .venv/bin/activate

# The run keeps only the 2 newest checkpoints (save_total_limit=2) and wrote a new one
# every 1000 steps, so a hardcoded checkpoint number goes stale. Default to the
# highest-numbered one that currently exists; set MODEL_PATH to pin a specific one.
RUN_DIR="${RUN_DIR:-/home/physicalai/Desktop/I/groot/outputs/pick_box_2_8chunk}"
latest_checkpoint() {
  ls -d "$RUN_DIR"/checkpoint-* 2>/dev/null | sed 's/.*checkpoint-//' | sort -n | tail -1
}
if [ -z "${MODEL_PATH:-}" ]; then
  _step="$(latest_checkpoint)"
  [ -n "$_step" ] || { echo "no checkpoint-* under $RUN_DIR — set MODEL_PATH" >&2; exit 1; }
  MODEL_PATH="$RUN_DIR/checkpoint-$_step"
  echo "[daksha] using newest checkpoint: $MODEL_PATH"
fi

# A checkpoint whose save was interrupted leaves 0-byte trainer_state.json /
# model.safetensors.index.json behind, and the server dies mid-load with a confusing
# error. Catch it here and point at the previous checkpoint instead.
if [ ! -s "$MODEL_PATH/model.safetensors.index.json" ]; then
  echo "ERROR: $MODEL_PATH looks truncated (empty model.safetensors.index.json)." >&2
  echo "       Delete it and re-run, or set MODEL_PATH to an older checkpoint." >&2
  exit 1
fi

EMBODIMENT_TAG="${EMBODIMENT_TAG:-DAKSHA}"
HOST="${HOST:-0.0.0.0}"
PORT="${PORT:-5555}"

python gr00t/eval/run_gr00t_server.py \
  --model_path "$MODEL_PATH" \
  --embodiment-tag "$EMBODIMENT_TAG" \
  --host "$HOST" \
  --port "$PORT"
