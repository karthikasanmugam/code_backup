#!/usr/bin/env python3
"""Unpack an official LeRobot v3.0 dataset into the episode-based layout the Daksha
conversion pipeline expects.

v3.0 packs many episodes into one data/chunk-*/file-*.parquet and one packed
videos/<key>/chunk-*/file-*.mp4. examples/Daksha/conversion_code.py (and the studio)
expect one data/chunk-*/episode_*.parquet and one videos/<key>/chunk-*/episode_*.mp4
per episode. This splits the packed files back out, losslessly for the data and
frame-accurately for the videos (verified: each clip is exactly `length` frames,
starting on the right frame).

    python examples/Daksha/unpack_v3_to_episodes.py --src <v3.0 dataset> --dst <output>
    python examples/Daksha/unpack_v3_to_episodes.py --src <...> --dst <...> --max-episodes 3   # quick test

Afterwards point the conversion UI / studio at <output> and Convert it as usual.
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

import pandas as pd


def log(msg: str) -> None:
    print(msg, flush=True)


def read_concat(paths: list[Path]) -> pd.DataFrame:
    if not paths:
        raise FileNotFoundError("no parquet files found")
    return pd.concat([pd.read_parquet(p) for p in paths], ignore_index=True)


def extract_clip(src_mp4: Path, start: float, frames: int, out_mp4: Path) -> None:
    """One episode's video: fast-seek to `start` and re-encode exactly `frames` frames.
    Input -ss + -frames:v is frame-accurate here (the clip starts on round(start*fps))."""
    out_mp4.parent.mkdir(parents=True, exist_ok=True)
    cmd = ["ffmpeg", "-nostdin", "-loglevel", "error", "-ss", f"{start:.6f}", "-i", str(src_mp4),
           "-frames:v", str(frames), "-c:v", "libx264", "-pix_fmt", "yuv420p", "-an", str(out_mp4), "-y"]
    subprocess.run(cmd, check=True)


def main() -> int:
    p = argparse.ArgumentParser(description="Unpack a LeRobot v3.0 dataset into episode-based layout.")
    p.add_argument("--src", required=True, help="Source v3.0 dataset root (has data/chunk-*/file-*.parquet).")
    p.add_argument("--dst", help="Output dataset root. Default: <src>_episodes next to the source.")
    p.add_argument("--chunks-size", type=int, default=1024, help="Episodes per chunk folder in the output.")
    p.add_argument("--max-episodes", type=int, default=0, help="Only convert the first N episodes (0 = all; for testing).")
    a = p.parse_args()

    src = Path(a.src).expanduser().resolve()
    dst = Path(a.dst).expanduser().resolve() if a.dst else src.parent / f"{src.name}_episodes"
    chunks = a.chunks_size

    info = json.loads((src / "meta/info.json").read_text())
    if "file-" not in info.get("data_path", ""):
        raise SystemExit(f"{src} does not look like a file-packed v3.0 dataset (data_path={info.get('data_path')!r}).")
    fps = int(info["fps"])
    video_keys = info.get("video_keys") or [k for k in info["features"] if k.startswith("observation.images")]

    ep_meta = read_concat(sorted(src.glob("meta/episodes/chunk-*/file-*.parquet"))).sort_values("episode_index")
    data = read_concat(sorted(src.glob("data/chunk-*/file-*.parquet")))
    if "episode_index" not in data.columns:
        raise SystemExit("data parquet has no episode_index column; cannot split by episode.")

    episode_ids = sorted(int(e) for e in ep_meta["episode_index"].unique())
    if a.max_episodes:
        episode_ids = episode_ids[: a.max_episodes]

    if dst.exists():
        raise SystemExit(f"Output {dst} already exists; remove it or choose another --dst.")
    (dst / "meta").mkdir(parents=True)

    log(f"Unpacking {len(episode_ids)} episode(s) from {src.name} -> {dst}")
    total_frames = 0
    for e in episode_ids:
        sub = data[data["episode_index"] == e].sort_values("frame_index")
        if sub.empty:
            raise SystemExit(f"Episode {e} has no rows in the packed data parquet.")
        chunk = e // chunks
        out_parquet = dst / f"data/chunk-{chunk:03d}/episode_{e:06d}.parquet"
        out_parquet.parent.mkdir(parents=True, exist_ok=True)
        sub.to_parquet(out_parquet, index=False)
        total_frames += len(sub)

        em = ep_meta[ep_meta["episode_index"] == e].iloc[0]
        length = int(em["length"])
        for vk in video_keys:
            ci, fi = int(em[f"videos/{vk}/chunk_index"]), int(em[f"videos/{vk}/file_index"])
            start = float(em[f"videos/{vk}/from_timestamp"])
            src_mp4 = src / f"videos/{vk}/chunk-{ci:03d}/file-{fi:03d}.mp4"
            out_mp4 = dst / f"videos/{vk}/chunk-{chunk:03d}/episode_{e:06d}.mp4"
            extract_clip(src_mp4, start, length, out_mp4)
        log(f"  episode {e:04d}: {len(sub)} frames, {len(video_keys)} video(s)")

    # tasks: the v3.0 tasks.parquet often lacks the 'task' text, so build it from the data.
    task_rows = (data[["task_index", "task"]].drop_duplicates().sort_values("task_index")
                 if "task" in data.columns else None)
    if task_rows is None:
        raise SystemExit("data parquet has no 'task' column; cannot build task.json.")
    tasks = [{"task_index": int(r.task_index), "task": str(r.task), "prompt": str(r.task)}
             for r in task_rows.itertuples()]
    (dst / "meta/task.json").write_text(json.dumps(tasks, indent=2))

    src_stats = src / "meta/stats.json"
    if src_stats.is_file():
        shutil.copy2(src_stats, dst / "meta/stats.json")

    out_info = {
        "codebase_version": "custom_v3_local",
        "repo_id": f"local/{dst.name}",
        "robot_type": info.get("robot_type", "daksha"),
        "fps": fps,
        "total_episodes": len(episode_ids),
        "total_frames": total_frames,
        "total_tasks": len(tasks),
        "use_videos": True,
        "camera_keys": list(video_keys),
        "video_keys": list(video_keys),
        "data_path": "data/chunk-{episode_chunk:03d}/episode_{episode_index:06d}.parquet",
        "video_path": "videos/{video_key}/chunk-{episode_chunk:03d}/episode_{episode_index:06d}.mp4",
        "splits": {"train": f"0:{len(episode_ids)}"},
        "chunks_size": chunks,
        "features": info["features"],
    }
    (dst / "meta/info.json").write_text(json.dumps(out_info, indent=2))

    log(f"Done: {len(episode_ids)} episodes, {total_frames} frames -> {dst}")
    log("Next: point the conversion UI / studio at this folder and Convert it.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
