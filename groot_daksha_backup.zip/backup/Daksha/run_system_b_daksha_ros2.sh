#!/usr/bin/env bash
# System B (robot machine): ROS2 bridge for the daksha / pick_box_2_8chunk checkpoint.
#
# Start System A (the GPU box) first:
#   bash examples/Daksha/run_system_a_daksha_server.sh
#
# Then here:
#   bash examples/Daksha/run_system_b_daksha_ros2.sh
#   POLICY_HOST=192.168.x.x bash examples/Daksha/run_system_b_daksha_ros2.sh
#
# Every default below is the bridge's own default, derived from
# outputs/pick_box_2_8chunk/checkpoint-50000's baked configs and the pick_box_2
# dataset meta (220 episodes / 121 000 frames, 30 fps, 320x240).
# They are spelled out here so each one is overridable from the environment without
# editing Python.
set -euo pipefail

REPO_ROOT="${REPO_ROOT:-/home/physicalai/Desktop/I/groot}"
cd "$REPO_ROOT"
source .venv/bin/activate

# The robot's arm/camera nodes live on ROS_DOMAIN_ID=55. Pin it here instead of
# inheriting it: a VS Code / non-interactive shell can export a different domain, and
# the bridge then lands on an empty DDS graph and sits forever in "Waiting for inputs"
# even though `ros2 topic echo` works in your own terminal.
export ROS_DOMAIN_ID="${ROS_DOMAIN_ID:-55}"
export RMW_IMPLEMENTATION="${RMW_IMPLEMENTATION:-rmw_cyclonedds_cpp}"
if [ -z "${AMENT_PREFIX_PATH:-}" ]; then
  set +u  # ROS setup.bash trips over unbound vars
  # shellcheck disable=SC1091
  source /opt/ros/humble/setup.bash
  set -u
fi

POLICY_HOST="${POLICY_HOST:-127.0.0.1}"
POLICY_PORT="${POLICY_PORT:-5555}"
# 30 Hz = pick_box_2 meta/info.json fps (verified: "fps": 30 -- the 60 that used to be
# here played every chunk back at double the recorded speed).
# 8 = the checkpoint's action delta_indices (processor_config.json -> modality_configs
# -> daksha -> action), i.e. len(range(0, 8)) from pick_box_config.py.
# ACTION_HORIZON must match the checkpoint you are actually SERVING: run a 16-step
# checkpoint with 8 here and the bridge executes only the first half of every chunk --
# and because the arms are RELATIVE the displacement accumulates toward the chunk's
# END, so the arm barely moves.
# NOTE the ":-" in every default below. "${ACTION_HORIZON:8}" is bash SUBSTRING syntax,
# not a default: with the variable unset it expands to the empty string and the bridge
# dies on --action-horizon "".
CONTROL_HZ="${CONTROL_HZ:-30}"
ACTION_HORIZON="${ACTION_HORIZON:-8}"
WATCHDOG_TIMEOUT_S="${WATCHDOG_TIMEOUT_S:-2.0}"
INPUT_TIMEOUT_S="${INPUT_TIMEOUT_S:-1.0}"
VALIDATION_MODE="${VALIDATION_MODE:-full}"
RUN_VALIDATION_SUITE="${RUN_VALIDATION_SUITE:-false}"
PHASE_SECONDS="${PHASE_SECONDS:-12.0}"

# Must match meta/tasks.jsonl verbatim -- pick_box_2 has exactly one task. Feeding a
# different sentence is an unnecessary distribution shift on the language input.
LANG_INSTRUCTION="${LANG_INSTRUCTION:-pick the brown box on the right hand side, place it in to the center of the box}"

# ros2_topics.json -> follower_state_topic
LEFT_JOINT_STATE_TOPIC="${LEFT_JOINT_STATE_TOPIC:-/LeftArmSystem_ordered_joint_states}"
RIGHT_JOINT_STATE_TOPIC="${RIGHT_JOINT_STATE_TOPIC:-/RightArmSystem_ordered_joint_states}"
JOINT_STATE_TOPIC="${JOINT_STATE_TOPIC:-/joint_states}"
# /joint_cmd is the command entry point; joint_command_limiter fans it out to the
# *_mit_controller/joint_trajectory topics listed as follower_cmd_topic.
CMD_TOPIC="${CMD_TOPIC:-/joint_cmd}"
PUBLISH_JOINT_ORDER="${PUBLISH_JOINT_ORDER:-left_first}"

# ros2_topics.json -> camera_topics, minus the "/compressed" suffix the bridge
# re-appends itself when IMAGE_TRANSPORT=compressed (which is how they were recorded).
WORLD_TOPIC="${WORLD_TOPIC:-/world/camera/color/image_raw/compressed}"
RIGHT_WRIST_TOPIC="${RIGHT_WRIST_TOPIC:-/right/camera/color/image_raw/compressed}"
LEFT_WRIST_TOPIC="${LEFT_WRIST_TOPIC:-/left/camera/color/image_raw/compressed}"
IMAGE_TRANSPORT="${IMAGE_TRANSPORT:-compressed}"
# The LIVE cameras publish 640x480 (world) and 848x480 (wrists), but every camera in
# pick_box_2 is 320x240: custom_v3format_dataset/recorder.py squashed each frame with
# cv2.resize(frame, (320, 240), INTER_AREA) -- no aspect preservation, no crop. Doing
# the same here is what makes inference see the geometry it trained on, and it is also
# the biggest latency win available: the server resizes the SHORTEST edge to 256, so a
# raw 848x480 wrist frame becomes 256x452 against training's 256x341, ~33% more vision
# tokens on two of the three cameras, plus 5x the bytes over the wire.
IMAGE_SIZE="${IMAGE_SIZE:-320x240}"
# Legacy aspect-preserving long-edge cap. Leave at 0; IMAGE_SIZE supersedes it.
IMAGE_MAX_EDGE="${IMAGE_MAX_EDGE:-0}"

# processor_config.json -> modality_configs -> daksha -> video -> modality_keys
WORLD_CAMERA_KEY="${WORLD_CAMERA_KEY:-world}"
RIGHT_WRIST_CAMERA_KEY="${RIGHT_WRIST_CAMERA_KEY:-wrist_right}"
LEFT_WRIST_CAMERA_KEY="${LEFT_WRIST_CAMERA_KEY:-wrist_left}"

# LEFT-first, matching the checkpoint's modality_keys and meta/modality.json.
# Reordering these without also reordering the CSVs below silently swaps the arms.
JOINT_KEYS="left_joint_1,left_joint_2,left_joint_3,left_joint_4,left_joint_5,left_joint_6,left_joint_7,left_gripper_left_joint,right_joint_1,right_joint_2,right_joint_3,right_joint_4,right_joint_5,right_joint_6,right_joint_7,right_gripper_right_joint"
STATE_OBS_KEYS_CSV="${STATE_OBS_KEYS_CSV:-$JOINT_KEYS}"
ACTION_KEYS_CSV="${ACTION_KEYS_CSV:-$JOINT_KEYS}"

# outputs/pick_box_2_8chunk/checkpoint-50000/experiment_cfg/dataset_statistics.json ->
# daksha: union of the action and state ranges widened by max(10% of range, 0.05)
# for arms / 0.01 for grippers (right-gripper min floored at 0.0 -- a negative command
# over-closes the jaw against its stop).
#
# RE-DERIVED FOR THE 8-CHUNK CHECKPOINT. The values that used to be here came from
# outputs/pick_box_2 (the 16-chunk run, trained when pick_box_2 held 101 episodes);
# pick_box_2 now has 220, and the poses moved enough that the old limits amputated the
# trained range of the LEFT arm in particular:
#   left_joint_2  was capped at -0.12948, the checkpoint reaches +0.08071
#   left_joint_6  was floored at +0.11041, the checkpoint reaches -0.28899
#   left_joint_1  was capped at  0.05767, the checkpoint reaches +0.19858
# Every one of those clamps pins the joint at a bound for the whole episode.
#
# RETRAINED AGAIN? Re-derive from the checkpoint you are actually serving -- limits
# from another run can be disjoint from this one's poses. The recipe is in the
# --joint-min-csv comment in eval_daksha_ros2.py.
JOINT_MIN_CSV="${JOINT_MIN_CSV:--0.06736,-0.27297,-0.12670,-0.06278,-0.16198,-0.28899,-0.12670,-0.05418,-1.27588,-0.36374,-0.70903,0.28232,0.71468,-0.94800,-1.70379,0.0}"
JOINT_MAX_CSV="${JOINT_MAX_CSV:-0.19858,0.08071,0.05515,0.06074,0.34927,0.22027,0.17989,0.01021,1.15534,0.24057,1.24613,1.93225,1.96825,1.44501,1.45682,0.05503}"
# 1.5x the per-joint p99.9 frame-to-frame action delta over ALL 220 of pick_box_2's
# episodes (120 780 transitions), floored at 0.02; grippers pinned to 0.06 so a grasp
# is never throttled. Scale by (30 / CONTROL_HZ) if you change the rate.
#
# RE-DERIVED over the full 220 episodes. The previous values came from the 101-episode
# cut and throttled five of the seven right-arm joints -- the arm physically could not
# track the trajectory the policy predicted, which reads as sluggish, laggy motion:
#   right_joint_1  needs 0.106, was capped at 0.080
#   right_joint_4  needs 0.094, was capped at 0.087
#   right_joint_5  needs 0.067, was capped at 0.053
#   right_joint_6  needs 0.175, was capped at 0.150
#   right_joint_7  needs 0.196, was capped at 0.165
#
# To re-derive:
#   import glob, numpy as np, pandas as pd
#   D = np.concatenate([np.abs(np.diff(np.stack(
#           pd.read_parquet(f, columns=["action"])["action"].values), axis=0))
#       for f in sorted(glob.glob("<dataset>/data/chunk-*/episode_*.parquet"))])
#   print(np.maximum(np.round(1.5 * np.percentile(D, 99.9, axis=0), 3), 0.02))
MAX_STEP_DELTA_CSV="${MAX_STEP_DELTA_CSV:-0.02,0.02,0.02,0.02,0.02,0.02,0.02,0.06,0.106,0.039,0.097,0.094,0.067,0.175,0.196,0.06}"

# Start the next chunk once only this many of the 8 planned steps remain, so the round
# trip overlaps with executing the chunk instead of stalling the arm at hold:
#
#   REPLAN_AT = ceil(measured_inference_s * CONTROL_HZ)
#
# Measured on this machine off the "inference N ms" log line: 199-227 ms in steady
# state (286 ms on the first, cold call), so ceil(0.227 * 30) = ceil(6.8) = 7. The
# bridge requires 0 <= REPLAN_AT < ACTION_HORIZON, so at this horizon 7 is both the
# computed value and the hard ceiling.
#
# Timeline: the chunk lands, one step is published, the next chunk is submitted with 7
# still queued, those 7 execute in 233 ms, and the new chunk arrives as the queue
# empties -- continuous motion, and nothing is discarded (the queue is empty when it is
# replaced, so the usual "an oversized REPLAN_AT throws away the chunk's motion" caveat
# does not bite at this horizon).
#
# There is almost no slack here: an 8-step chunk is only 267 ms of motion against a
# ~210-230 ms round trip. If inference drifts past ~267 ms the queue runs dry and the
# arm hold-stutters between chunks. The fix is a longer chunk (retrain with more action
# delta_indices) or faster inference -- NOT a larger REPLAN_AT, which is already maxed.
# Re-derive whenever CONTROL_HZ, ACTION_HORIZON or the serving hardware changes.
REPLAN_AT="${REPLAN_AT:-5}"

extra_flags=()
if [ "$RUN_VALIDATION_SUITE" = "true" ]; then
  extra_flags+=(--run-validation-suite)
fi

# The three CSV limit flags use --flag=value, not --flag value: JOINT_MIN_CSV starts
# with a minus sign and argparse would otherwise read it as an option name.
python gr00t/eval/real_robot/Daksha/eval_daksha_ros2.py \
  --joint-min-csv="$JOINT_MIN_CSV" \
  --joint-max-csv="$JOINT_MAX_CSV" \
  --max-step-delta-csv="$MAX_STEP_DELTA_CSV" \
  --policy-host "$POLICY_HOST" \
  --policy-port "$POLICY_PORT" \
  --control-hz "$CONTROL_HZ" \
  --action-horizon "$ACTION_HORIZON" \
  --replan-at "$REPLAN_AT" \
  --watchdog-timeout-s "$WATCHDOG_TIMEOUT_S" \
  --input-timeout-s "$INPUT_TIMEOUT_S" \
  --validation-mode "$VALIDATION_MODE" \
  --phase-seconds "$PHASE_SECONDS" \
  --lang-instruction "$LANG_INSTRUCTION" \
  --joint-state-topic "$JOINT_STATE_TOPIC" \
  --left-joint-state-topic "$LEFT_JOINT_STATE_TOPIC" \
  --right-joint-state-topic "$RIGHT_JOINT_STATE_TOPIC" \
  --cmd-topic "$CMD_TOPIC" \
  --publish-joint-order "$PUBLISH_JOINT_ORDER" \
  --world-topic "$WORLD_TOPIC" \
  --right-wrist-topic "$RIGHT_WRIST_TOPIC" \
  --left-wrist-topic "$LEFT_WRIST_TOPIC" \
  --image-transport "$IMAGE_TRANSPORT" \
  --image-max-edge "$IMAGE_MAX_EDGE" \
  --image-size "$IMAGE_SIZE" \
  --world-camera-key "$WORLD_CAMERA_KEY" \
  --right-wrist-camera-key "$RIGHT_WRIST_CAMERA_KEY" \
  --left-wrist-camera-key "$LEFT_WRIST_CAMERA_KEY" \
  --state-obs-keys-csv "$STATE_OBS_KEYS_CSV" \
  --action-keys-csv "$ACTION_KEYS_CSV" \
  "${extra_flags[@]}"
