# Daksha (16 DoF, 4 Cameras)

This folder is a standalone embodiment setup, modeled after existing `PIPER` and `SO100` examples.

Embodiment tag to use:
- `DAKSHA` (the only Daksha training and inference embodiment ID)

## Files

- `modality.json`: Dataset key mapping for state/action/video/language.
- `daksha_config.py`: ModalityConfig registration for training.
- `finetune_daksha.sh`: Example training command.
- `scripts.txt`: Full command list (meta patch, train, resume, server, ROS2 eval).

## Expected dataset schema

- `action`: shape `[16]`
- `observation.state`: shape `[16]`
- cameras:
  - `observation.images.zed_right`
  - `observation.images.zed_left`
  - `observation.images.right_wrist`
  - `observation.images.left_wrist`
- language mapping should use `task_index` in dataset `meta/modality.json`



