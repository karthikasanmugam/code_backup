#!/usr/bin/env bash
# Local browser UI for Daksha GR00T training and checkpoint deployment.
#
#   bash gr00t/eval/real_robot/Daksha/ui_1/run_training_studio.sh
#   DATASET_ROOTS=/home/s1/Desktop/datasets bash .../run_training_studio.sh
#   TOKEN=mysecret bash .../run_training_studio.sh   # then open http://<lan-ip>:8130/?token=mysecret
#   HOST=127.0.0.1 bash .../run_training_studio.sh   # this machine only
#
# It listens on 0.0.0.0:8130 (all interfaces), so this machine opens
# http://localhost:8130 and others on the LAN open http://<this-ip>:8130. Anyone
# who reaches that address can start training and the robot bridge, so set TOKEN
# on a shared network.
#
# Training uses the configs in examples/Daksha and the DAKSHA tag.
set -euo pipefail

# Resolved before the cd below, so the studio is found wherever this folder lives.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

REPO_ROOT="${REPO_ROOT:-$(cd "$SCRIPT_DIR/../../../../.." && pwd)}"
cd "$REPO_ROOT"
source .venv/bin/activate

# torch's CUDA libs ship under the venv's nvidia/*/lib (libcudss.so.0 etc.); put them on
# LD_LIBRARY_PATH so "import torch" works in training/eval/stats children.
NVLIB="$(echo "$REPO_ROOT"/.venv/lib/python*/site-packages/nvidia/*/lib | tr ' ' ':')"
export LD_LIBRARY_PATH="${NVLIB}${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"

HOST="${HOST:-0.0.0.0}"
TOKEN="${TOKEN:-}"
PORT="${PORT:-8130}"
# Colon-separated folders that hold the 16-DoF Daksha LeRobot datasets.
DATASET_ROOTS="${DATASET_ROOTS:-/home/s1/Desktop/datasets}"
OUTPUT_ROOT="${OUTPUT_ROOT:-$REPO_ROOT/outputs}"
ALLOW_ROOT="${ALLOW_ROOT:-/home/s1}"

ROOT_ARGS=()
IFS=':' read -r -a _roots <<< "$DATASET_ROOTS"
for r in "${_roots[@]}"; do
  [ -n "$r" ] && ROOT_ARGS+=(--dataset-root "$r")
done

exec python "$SCRIPT_DIR/training_studio.py" \
  --host "$HOST" --port "$PORT" ${TOKEN:+--token "$TOKEN"} "${ROOT_ARGS[@]}" \
  --output-root "$OUTPUT_ROOT" --allow-root "$ALLOW_ROOT" --allow-root "$REPO_ROOT"
