"""Jerk scores (what GROOVE minimises) and metrics (what you report).

Scores work in command units per step. Metrics are converted to physical units using
the control period dt, so rad/s^3 (joints) or m/s^3 / rad/s^3 (EEF).
"""

from __future__ import annotations

import numpy as np


def jerk_cost(seq: np.ndarray, past: np.ndarray) -> float:
    """Sum of squared third differences of positions, including the boundary.

    seq: (H, D) positions to be executed; past: (3, D) positions already delivered.
    This is the paper's command-space score P (second difference of increments).
    """
    full = np.concatenate([past, seq], axis=0)
    d3 = np.diff(full, n=3, axis=0)
    return float(np.sum(d3 * d3))


def jerk_metrics(seq: np.ndarray, dt: float, boundaries: np.ndarray | None = None) -> dict:
    """Jerk statistics of an executed position trace.

    seq: (T, D). boundaries: optional step indices where a new chunk started; the jerk
    samples touching a boundary are reported separately, since that is where replacing
    a chunk shows up.
    """
    seq = np.asarray(seq, dtype=np.float64)
    if seq.shape[0] < 4:
        return {"rms": float("nan"), "p95": float("nan"), "max": float("nan"), "n": 0}
    j = np.diff(seq, n=3, axis=0) / dt**3  # sample i spans steps i..i+3
    mag = np.linalg.norm(j, axis=1)
    out = {
        "rms": float(np.sqrt(np.mean(mag**2))),
        "p95": float(np.percentile(mag, 95)),
        "max": float(mag.max()),
        "n": int(mag.size),
        "rms_per_dim": np.sqrt(np.mean(j**2, axis=0)).tolist(),
    }
    if boundaries is not None and len(boundaries):
        touch = np.zeros(mag.size, dtype=bool)
        for b in np.asarray(boundaries, dtype=int):
            touch[max(0, b - 3) : min(mag.size, b + 1)] = True
        if touch.any():
            out["rms_boundary"] = float(np.sqrt(np.mean(mag[touch] ** 2)))
        if (~touch).any():
            out["rms_interior"] = float(np.sqrt(np.mean(mag[~touch] ** 2)))
    return out
