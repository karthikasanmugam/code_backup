"""Gripper guard: keep the arm on the policy's path around a grasp or release.

Paper: within w_g steps of a gripper transition every candidate box shrinks to
eps_g (0.001), so smoothing never moves the hand while the jaw is closing or opening.
w_g = 5 steps at 20 Hz = 0.25 s; the default window here is that time converted to the
bridge's control rate.

Transition detection has to survive the diffusion head's gripper noise. The bridge's
own measurements (eval_openarm_b1_ros2.py, _apply_safety) put that noise at
0.003-0.010 rad per fresh chunk, against a 0.044 rad jaw travel, and show that a real
demo step is at most ~0.012 rad per 30 Hz frame (p99 0.005). So:

  * inside the chunk and inside the delivered history, a step > step_thresh (0.005)
    counts as a transition -- samples within one chunk are smooth, so noise does not
    reach it;
  * across the chunk boundary (last delivered command -> first new target) the
    threshold is jump_thresh (0.012), above the per-chunk resampling noise.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class GuardConfig:
    enabled: bool = True
    window: int = 8  # steps on each side of a transition (0.25 s at 30 Hz)
    step_thresh: float = 0.005
    jump_thresh: float = 0.012

    @classmethod
    def from_seconds(cls, window_s: float, control_hz: float, **kw) -> "GuardConfig":
        return cls(window=int(round(window_s * control_hz)), **kw)


def guard_mask(grip_chunk: np.ndarray, grip_hist: np.ndarray, cfg: GuardConfig) -> np.ndarray:
    """Bool (H,): steps of this chunk that lie within cfg.window of a gripper transition.

    grip_chunk: (H,) raw gripper targets of the new chunk.
    grip_hist:  (K,) gripper commands already delivered, oldest first (K >= 1).
    """
    H = grip_chunk.shape[0]
    if not cfg.enabled or H == 0:
        return np.zeros(H, dtype=bool)
    grip_hist = np.asarray(grip_hist, dtype=np.float64).reshape(-1)
    K = grip_hist.shape[0]
    seq = np.concatenate([grip_hist, grip_chunk])
    step = np.abs(np.diff(seq))  # step[i] = change arriving at seq index i + 1
    thresh = np.full(step.shape, cfg.step_thresh)
    if K >= 1:
        thresh[K - 1] = cfg.jump_thresh  # the boundary step: delivered -> new chunk
    events = np.flatnonzero(step > thresh) + 1 - K  # in chunk-step coordinates
    if events.size == 0:
        return np.zeros(H, dtype=bool)
    t = np.arange(H)
    return np.any(np.abs(t[:, None] - events[None, :]) <= cfg.window, axis=1)
