"""GROOVE on top of the existing OpenArm B1 ROS2 bridge -- without editing it.

The bridge (gr00t/eval/real_robot/OPENARM_B1/eval_openarm_b1_ros2.py) is imported
by file path and SUBCLASSED. Nothing of its behaviour changes except one step:

    policy chunk lands  ->  [anchor compensation]  ->  GROOVE  ->  base _build_plan
                                                                  (limits, rate limit,
                                                                   gripper deadband,
                                                                   grasp guard)

  * Delivered history. GROOVE's boundary conditions are the commands the robot was
    actually SENT, so `cmd_pub` is wrapped and every published JointState is recorded
    (chunk steps, holds, frozen pauses alike).
  * Anchor compensation. The base applies it inside _build_plan, which is after the
    point GROOVE has to run. The subclass applies the identical offset itself (arms
    only, only with --replan-at > 0) and switches the base's copy off, so it is applied
    exactly once and GROOVE sees the chunk the base would have executed.
  * Safety is untouched: the smoothed chunk goes through the base's _build_plan /
    _apply_safety unchanged, so joint limits, max_step_delta, the gripper deadband
    and the grasp guard all still have the last word.
  * Any exception in GROOVE falls back to the raw chunk for that plan.

--no-groove runs the very same bridge with the regulator off, which is the baseline
for an A/B comparison with the same logging (--groove-log-dir).
"""

from __future__ import annotations

import argparse
from collections import deque
import importlib.util
import json
import os
from pathlib import Path
import sys
import time
from typing import Any

import numpy as np

HERE = Path(__file__).resolve().parent
DEFAULT_REPO_ROOT = HERE.parents[2]  # external/groove/groove_common -> repo root
BRIDGE_REL = Path("gr00t/eval/real_robot/OPENARM_B1/eval_openarm_b1_ros2.py")


def load_base_bridge_module(repo_root: str | Path | None = None):
    """Import eval_openarm_b1_ros2.py by path (gr00t/eval has no __init__.py)."""
    root = Path(repo_root or os.environ.get("GROOT_REPO_ROOT") or DEFAULT_REPO_ROOT)
    path = root / BRIDGE_REL
    if not path.is_file():
        raise FileNotFoundError(f"base bridge not found at {path}; set GROOT_REPO_ROOT")
    spec = importlib.util.spec_from_file_location("eval_openarm_b1_ros2", path)
    mod = importlib.util.module_from_spec(spec)
    # Refer, don't touch: no __pycache__ writes next to the bridge (or anything it imports).
    prev, sys.dont_write_bytecode = sys.dont_write_bytecode, True
    try:
        spec.loader.exec_module(mod)
    finally:
        sys.dont_write_bytecode = prev
    return mod


def env_default(name: str, default: Any, cast=str):
    v = os.environ.get(name)
    if v is None or v == "":
        return default
    if cast is bool:
        return v.strip().lower() in ("1", "true", "yes", "on")
    return cast(v)


def add_common_groove_args(p: argparse.ArgumentParser) -> None:
    """Flags shared by both variants. Every default can also come from the environment,
    so launcher scripts can set them without touching the task script's argv."""
    g = p.add_argument_group("GROOVE (common)")
    g.add_argument(
        "--groove", action=argparse.BooleanOptionalAction,
        default=env_default("GROOVE_ENABLE", True, bool),
        help="Regulate chunks (default). --no-groove = same bridge, raw chunks (A/B baseline).",
    )
    g.add_argument(
        "--groove-arms", default=env_default("GROOVE_ARMS", "left,right"),
        help="Comma list of arms to regulate (left,right). Others pass through raw.",
    )
    g.add_argument("--groove-lambda", type=float, default=env_default("GROOVE_LAMBDA", 1e-9, float))
    g.add_argument(
        "--groove-guard", action=argparse.BooleanOptionalAction,
        default=env_default("GROOVE_GUARD", True, bool),
        help="Pin the arm to the policy near gripper transitions (paper's eps_g window).",
    )
    g.add_argument(
        "--groove-guard-window-s", type=float, default=env_default("GROOVE_GUARD_WINDOW_S", 0.25, float),
        help="Guard half-window in seconds (paper: 5 steps at 20 Hz = 0.25 s).",
    )
    g.add_argument("--groove-guard-step-thresh", type=float,
                   default=env_default("GROOVE_GUARD_STEP_THRESH", 0.005, float))
    g.add_argument("--groove-guard-jump-thresh", type=float,
                   default=env_default("GROOVE_GUARD_JUMP_THRESH", 0.012, float))
    g.add_argument(
        "--groove-hist-len", type=int, default=env_default("GROOVE_HIST_LEN", 16, int),
        help="Delivered commands kept for boundary conditions and the gripper guard.",
    )
    g.add_argument(
        "--groove-log-dir", default=env_default("GROOVE_LOG_DIR", ""),
        help="Write raw/smoothed chunks and every delivered command to <dir>/*.npz.",
    )


class ChunkLog:
    """In-memory log flushed to one .npz per session (overwritten every flush)."""

    def __init__(self, log_dir: str, method: str, args: argparse.Namespace, flush_every: int = 20):
        self.dir = Path(log_dir).expanduser()
        self.dir.mkdir(parents=True, exist_ok=True)
        stamp = time.strftime("%Y%m%d_%H%M%S")
        self.path = self.dir / f"groove_{method}_{stamp}.npz"
        self.meta = {
            "method": method,
            "control_hz": args.control_hz,
            "action_horizon": args.action_horizon,
            "replan_at": args.replan_at,
            "argv": {k: v for k, v in vars(args).items() if k.startswith("groove") or k in (
                "control_hz", "action_horizon", "replan_at", "lang_instruction")},
        }
        self.flush_every = flush_every
        self.chunks: list[dict] = []
        self.t_pub: list[float] = []
        self.cmd: list[np.ndarray] = []
        self.meas: list[np.ndarray] = []

    def delivered(self, t: float, cmd16: np.ndarray, meas16: np.ndarray | None) -> None:
        self.t_pub.append(t)
        self.cmd.append(cmd16)
        self.meas.append(meas16 if meas16 is not None else np.full(16, np.nan))

    def chunk(self, **rec) -> None:
        self.chunks.append(rec)
        if len(self.chunks) % self.flush_every == 0:
            self.save()

    def save(self) -> None:
        if not self.chunks and not self.cmd:
            return
        H = max((c["raw"].shape[0] for c in self.chunks), default=0)

        def pad(key):
            out = np.full((len(self.chunks), H, 16), np.nan)
            for i, c in enumerate(self.chunks):
                out[i, : c[key].shape[0]] = c[key]
            return out

        np.savez_compressed(
            self.path,
            meta=json.dumps(self.meta),
            chunk_t=np.array([c["t"] for c in self.chunks]),
            chunk_raw=pad("raw"),
            chunk_out=pad("out"),
            chunk_hist3=np.array([c["hist3"] for c in self.chunks]) if self.chunks else np.zeros((0, 3, 16)),
            chunk_solve_ms=np.array([c["solve_ms"] for c in self.chunks]),
            chunk_info=np.array([json.dumps(c["info"]) for c in self.chunks]),
            pub_t=np.array(self.t_pub),
            pub_cmd=np.array(self.cmd) if self.cmd else np.zeros((0, 16)),
            pub_meas=np.array(self.meas) if self.meas else np.zeros((0, 16)),
        )


class _RecordingPublisher:
    """Wraps rclpy's Publisher: publishes first, then records what went out."""

    def __init__(self, pub, on_publish):
        self._pub = pub
        self._on_publish = on_publish

    def publish(self, msg) -> None:
        self._pub.publish(msg)
        try:
            self._on_publish(msg)
        except Exception:  # recording must never break command publishing
            pass

    def __getattr__(self, name):
        return getattr(self._pub, name)


def _fmt_info(info: dict) -> str:
    parts = []
    for arm, a in info.get("arms", {}).items():
        if not a.get("accepted", True):
            parts.append(f"{arm}: RAW ({a.get('fallback') or 'rejected'})")
            continue
        s = f"{arm}: jerk -{a.get('reduction_pct', 0.0):.0f}% dev {a.get('max_dev', 0.0):.4f}"
        if a.get("via_joint_fallback"):
            s += f" [joint fallback: {a.get('fallback')}]"
        elif "box" in a:
            s += f" box {a['box']}"
        if a.get("guard_steps"):
            s += f" guard {a['guard_steps']}"
        parts.append(s)
    return " | ".join(parts)


def make_groove_bridge_class(base_module):
    Base = base_module.Gr00TOpenArmB1RosBridge

    class GrooveOpenArmB1Bridge(Base):
        def __init__(self, args: argparse.Namespace, regulator, method: str):
            super().__init__(args)
            # Timers exist but have not fired yet: nothing spins until rclpy.spin().
            self.groove = regulator
            self.groove_method = method if regulator is not None else "raw"
            # Take the anchor compensation over (see module docstring).
            self._groove_anchor_comp = bool(args.replan_anchor_compensation)
            self.args.replan_anchor_compensation = False
            self._groove_hist: deque[tuple[float, np.ndarray]] = deque(maxlen=max(3, args.groove_hist_len))
            self._groove_dt = 1.0 / args.control_hz
            self.cmd_pub = _RecordingPublisher(self.cmd_pub, self._groove_on_publish)
            self._groove_log = (
                ChunkLog(args.groove_log_dir, self.groove_method, args) if args.groove_log_dir else None
            )
            self._groove_slow_warned = False
            self.get_logger().info(
                f"GROOVE: method={self.groove_method}, arms={args.groove_arms}, "
                f"guard={'on' if args.groove_guard else 'off'} ({args.groove_guard_window_s:.2f} s), "
                f"log={self._groove_log.path if self._groove_log else 'off'}"
            )

        # ---- delivered-command history ------------------------------------------
        def _groove_on_publish(self, msg) -> None:
            vec = np.empty(16)
            vec[self.publish_indices] = np.asarray(msg.position, dtype=np.float64)
            now = time.monotonic()
            self._groove_hist.append((now, vec))
            if self._groove_log is not None:
                try:
                    meas = self._hold_vec16().astype(np.float64)
                except Exception:
                    meas = None
                self._groove_log.delivered(now, vec, meas)

        def _groove_history(self, current16: np.ndarray) -> np.ndarray:
            """(K, 16) commands at the last K ticks, oldest first.

            Before anything was published the arm is at rest at the measured pose. A gap
            since the last publish (waiting for inputs, first chunk) means the controller
            kept holding the last command, so it is repeated for the missed ticks.
            """
            K = self._groove_hist.maxlen
            if not self._groove_hist:
                return np.tile(current16.astype(np.float64), (K, 1))
            vecs = [v for _, v in self._groove_hist]
            gap_ticks = int((time.monotonic() - self._groove_hist[-1][0]) / self._groove_dt + 0.5) - 1
            if gap_ticks > 0:
                vecs += [vecs[-1]] * min(gap_ticks, K)
            vecs = vecs[-K:]
            if len(vecs) < K:
                vecs = [vecs[0]] * (K - len(vecs)) + vecs
            return np.stack(vecs)

        # ---- the one hook --------------------------------------------------------
        def _build_plan(self, anchor16, action_vecs, mode):
            if mode == "hold" or not action_vecs:
                return super()._build_plan(anchor16, action_vecs, mode)
            current16 = self._hold_vec16()
            raw = np.stack(action_vecs).astype(np.float64)
            if self._groove_anchor_comp and self.args.replan_at > 0:
                offset = (current16 - anchor16).astype(np.float64)
                offset[self.policy_gripper_indices] = 0.0
                raw = raw + offset
            out, info, solve_ms = raw, {}, 0.0
            hist = self._groove_history(current16)
            if self.groove is not None:
                t0 = time.perf_counter()
                try:
                    out, info = self.groove.regulate(raw, hist)
                    if out.shape != raw.shape or not np.all(np.isfinite(out)):
                        raise ValueError(f"regulator returned {out.shape} / non-finite values")
                except Exception as exc:
                    self.get_logger().error(f"GROOVE failed, sending the raw chunk: {exc}")
                    out, info = raw, {"error": str(exc)}
                solve_ms = 1000.0 * (time.perf_counter() - t0)
                self.get_logger().info(f"GROOVE[{self.groove_method}] {solve_ms:.1f} ms | {_fmt_info(info)}")
                if solve_ms > 0.5 * 1000.0 * self._groove_dt and not self._groove_slow_warned:
                    self._groove_slow_warned = True
                    self.get_logger().warn(
                        f"GROOVE took {solve_ms:.0f} ms, over half a control tick; the command "
                        "at each chunk landing goes out that much late. Consider "
                        "--groove-boxes reference or regulating one arm (--groove-arms)."
                    )
            if self._groove_log is not None:
                self._groove_log.chunk(
                    t=time.monotonic(), raw=raw, out=out, hist3=hist[-3:], solve_ms=solve_ms, info=info
                )
            return super()._build_plan(anchor16, [v.astype(np.float32) for v in out], mode)

        def destroy_node(self) -> bool:
            if self._groove_log is not None:
                try:
                    self._groove_log.save()
                    self.get_logger().info(f"GROOVE log written to {self._groove_log.path}")
                except Exception as exc:
                    self.get_logger().error(f"could not write GROOVE log: {exc}")
            return super().destroy_node()

    return GrooveOpenArmB1Bridge


def run(base_module, args: argparse.Namespace, regulator, method: str) -> None:
    """Same lifecycle as the base bridge's main()."""
    import rclpy

    rclpy.init()
    node = make_groove_bridge_class(base_module)(args, regulator, method)
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
