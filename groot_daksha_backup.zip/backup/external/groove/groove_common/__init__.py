"""Shared pieces of the two GROOVE variants (a_joint_groove, b_cartesian_groove).

    box_qp         batched, exact jerk QP with a per-step deviation box
    jerk           jerk scores and metrics
    gripper_guard  "don't smooth near a grasp" mask
    layout         the OpenArm B1 16-DoF left-first layout the bridge uses

Nothing in here imports ROS or GR00T, so it can be tested and used offline.
"""

from .box_qp import solve_jerk_qp  # noqa: F401
from .gripper_guard import GuardConfig, guard_mask  # noqa: F401
from .jerk import jerk_cost, jerk_metrics  # noqa: F401
from .layout import OPENARM_B1_ARMS, ArmSlots  # noqa: F401
