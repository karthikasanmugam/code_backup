"""The GROOVE quadratic program, solved exactly and in batch.

Paper (eq. 1), per command dimension, increments v_t with fixed delivered history
v_{-2}, v_{-1}:

    min_v   sum_t ||v_t - 2 v_{t-1} + v_{t-2}||^2 + lam ||v_t||^2
    s.t.    | sum_{i<=t} (v_i - r_i) | <= eps_t          t = 0..H-1

Substituting the running sum p_t = p_{-1} + sum_{i<=t} v_i turns this into a problem
over POSITIONS with a plain per-step box, which is what both variants actually have:

    min_p   sum_t (p_t - 3 p_{t-1} + 3 p_{t-2} - p_{t-3})^2 + lam (p_t - p_{t-1})^2
    s.t.    target_t - eps_t <= p_t <= target_t + eps_t

  * joint GROOVE:     p = joint position, target = the policy's joint chunk,
                      past = the last three joint commands actually delivered.
  * Cartesian GROOVE: p = running sum of EEF increments along one box axis,
                      target = running sum of the raw increments, past rebuilt from
                      the two delivered increments.

The third difference of positions equals the second difference of increments, so this
is exactly the paper's objective. The raw chunk (p = target) is always feasible, and
the fixed history makes the objective strictly convex, so the minimiser is unique.

WHY A CUSTOM SOLVER. The OpenArm bridge builds each plan on its 30 Hz timer thread
(`_build_plan`), so anything slow there delays a command and adds the very jerk we
are removing. Every column shares the same H x H Hessian, so a lock-step primal
active-set method over all columns at once (batched 8x8 solves) is exact and takes a
few ms for the 90 columns of Cartesian GROOVE on both arms, where calling a
general-purpose solver per column takes tens of ms. Columns that fail to converge (not
expected; guarded anyway) are re-solved with scipy's BVLS.
"""

from __future__ import annotations

from functools import lru_cache

import numpy as np

# p_t - 3 p_{t-1} + 3 p_{t-2} - p_{t-3}
_JERK_STENCIL = np.array([1.0, -3.0, 3.0, -1.0])


@lru_cache(maxsize=32)
def _operators(H: int, lam: float) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """(M, P, A): residual matrix, Hessian M'M, and the pure jerk block A of M."""
    A = sum(c * np.eye(H, k=-k) for k, c in enumerate(_JERK_STENCIL))
    D = np.eye(H) - np.eye(H, k=-1)
    M = np.vstack([A, np.sqrt(lam) * D]) if lam > 0 else A
    P = M.T @ M
    return M, P, A


def _residual_offsets(past: np.ndarray, H: int, lam: float) -> np.ndarray:
    """Constant part b of the residual M p + b contributed by the fixed past.

    past: (N, 3) = [p_{-3}, p_{-2}, p_{-1}] per column.
    """
    N = past.shape[0]
    rows = 2 * H if lam > 0 else H
    b = np.zeros((N, rows))
    for t in range(min(3, H)):
        for k in range(t + 1, 4):  # terms that reach before t = 0
            b[:, t] += _JERK_STENCIL[k] * past[:, 3 + t - k]
    if lam > 0:
        b[:, H] = -np.sqrt(lam) * past[:, 2]
    return b


def jerk_objective(p: np.ndarray, past: np.ndarray, lam: float = 0.0) -> np.ndarray:
    """Objective value per column. p: (N, H), past: (N, 3)."""
    H = p.shape[1]
    M, _, _ = _operators(H, float(lam))
    r = p @ M.T + _residual_offsets(past, H, float(lam))
    return np.sum(r * r, axis=1)


def _active_set(P, q, lo, hi, x0, max_iter):
    """Batched primal active-set for  min 1/2 x'Px + q'x  s.t. lo <= x <= hi.

    x0 must be feasible. Returns (x, converged[N]).
    """
    N, H = q.shape
    x = x0.copy()
    W = np.zeros((N, H), dtype=np.int8)  # 0 free, -1 at lo, +1 at hi
    done = np.zeros(N, dtype=bool)
    scale = 1.0 + np.abs(q).max(axis=1)
    eye = np.eye(H)
    for _ in range(max_iter):
        act = np.flatnonzero(~done)
        if act.size == 0:
            break
        Wa, xa, qa = W[act], x[act], q[act]
        free = Wa == 0
        fixed_val = np.where(Wa < 0, lo[act], np.where(Wa > 0, hi[act], 0.0))
        # Equality-constrained subproblem: fixed vars at their bound, free vars solve
        # the reduced normal equations. Built as one full-size system per column.
        ff = free[:, :, None] & free[:, None, :]
        K = np.where(ff, P, 0.0) + np.where(~free, 1.0, 0.0)[:, :, None] * eye
        rhs = np.where(free, -qa - fixed_val @ P.T, fixed_val)
        xhat = np.linalg.solve(K, rhs[..., None])[..., 0]
        d = xhat - xa

        moving = np.abs(d).max(axis=1) > 1e-11 * (1.0 + np.abs(xa).max(axis=1))
        # --- columns that still move: step to xhat or to the first blocking bound
        if moving.any():
            m = np.flatnonzero(moving)
            dm, xm = d[m], xa[m]
            lom, him = lo[act[m]], hi[act[m]]
            with np.errstate(divide="ignore", invalid="ignore"):
                ratio = np.where(
                    free[m] & (dm < 0), (lom - xm) / dm,
                    np.where(free[m] & (dm > 0), (him - xm) / dm, np.inf),
                )
            ratio = np.maximum(ratio, 0.0)
            j = np.argmin(ratio, axis=1)
            alpha = np.minimum(1.0, ratio[np.arange(m.size), j])
            xm = xm + alpha[:, None] * dm
            block = alpha < 1.0
            if block.any():
                b_rows = np.flatnonzero(block)
                b_cols = j[b_rows]
                to_lo = dm[b_rows, b_cols] < 0
                xm[b_rows, b_cols] = np.where(to_lo, lom[b_rows, b_cols], him[b_rows, b_cols])
                Wm = W[act[m]]
                Wm[b_rows, b_cols] = np.where(to_lo, -1, 1)
                W[act[m]] = Wm
            x[act[m]] = xm
        # --- columns at a stationary point: check multipliers, release one if needed
        still = np.flatnonzero(~moving)
        if still.size:
            s = act[still]
            xs = x[s]
            g = xs @ P.T + q[s]
            Ws = W[s]
            # At a lower bound the gradient must be >= 0, at an upper bound <= 0.
            viol = np.where(Ws < 0, -g, np.where(Ws > 0, g, 0.0))
            worst = np.argmax(viol, axis=1)
            vmax = viol[np.arange(s.size), worst]
            ok = vmax <= 1e-10 * scale[s]
            done[s[ok]] = True
            rel = np.flatnonzero(~ok)
            if rel.size:
                Ws[rel, worst[rel]] = 0
                W[s] = Ws
    return x, done


def solve_jerk_qp(
    target: np.ndarray,
    past: np.ndarray,
    eps: np.ndarray | float,
    lam: float = 0.0,
    max_iter: int | None = None,
) -> np.ndarray:
    """Minimum-jerk sequence inside a per-step box around `target`, many columns at once.

    target: (N, H)  raw sequence per column (positions, or running sums of increments)
    past:   (N, 3)  [p_{-3}, p_{-2}, p_{-1}] fixed history per column
    eps:    scalar, (H,), (N, 1) or (N, H) half-width of the box; must be > 0
    lam:    weight of the paper's lam * ||increment||^2 term

    Returns p: (N, H) with |p - target| <= eps elementwise.
    """
    target = np.asarray(target, dtype=np.float64)
    past = np.asarray(past, dtype=np.float64)
    if target.ndim != 2 or past.shape != (target.shape[0], 3):
        raise ValueError(f"target must be (N,H) and past (N,3), got {target.shape}, {past.shape}")
    # The objective only sees differences, so re-centre every column on its last
    # delivered value; joint positions of ~1.7 rad otherwise cost precision for nothing.
    origin = past[:, 2:3].copy()
    target, past = target - origin, past - origin
    N, H = target.shape
    eps = np.broadcast_to(np.asarray(eps, dtype=np.float64), (N, H))
    if np.any(eps <= 0):
        raise ValueError("eps must be strictly positive (use a tiny value to pin a step)")
    lo, hi = target - eps, target + eps

    M, P, _ = _operators(H, float(lam))
    b = _residual_offsets(past, H, float(lam))
    q = b @ M  # gradient of 1/2 ||M p + b||^2 at p = 0 is M'b
    # Cold start at the raw sequence (always feasible). Warm-starting from the clipped
    # unconstrained minimiser was measured slower on policy-like data: releasing the
    # wrongly clipped entries costs more lock-step iterations than it saves.
    x, ok = _active_set(P, q, lo, hi, target.copy(), max_iter or 20 * H)
    if not ok.all():
        from scipy.optimize import lsq_linear

        for n in np.flatnonzero(~ok):
            res = lsq_linear(M, -b[n], bounds=(lo[n], hi[n]), method="bvls")
            x[n] = res.x if res.success else target[n]
    return np.clip(x, lo, hi) + origin
