"""16-DoF action layout of the OpenArm B1 bridge.

Mirrors (does not import) Gr00TOpenArmB1RosBridge.__init__ in
gr00t/eval/real_robot/OPENARM_B1/eval_openarm_b1_ros2.py, which validates the key CSVs
to be LEFT-first:  left_arm 0..6, left_gripper 7, right_arm 8..14, right_gripper 15.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class ArmSlots:
    name: str
    arm: np.ndarray  # indices of the arm joints in the 16-vector
    gripper: int  # index of that arm's gripper


OPENARM_B1_ARMS: tuple[ArmSlots, ...] = (
    ArmSlots("left", np.arange(0, 7), 7),
    ArmSlots("right", np.arange(8, 15), 15),
)
GRIPPER_INDICES = np.array([7, 15])
DOF = 16


def select_arms(names: list[str] | None) -> tuple[ArmSlots, ...]:
    """Subset of OPENARM_B1_ARMS by name; None or [] = both."""
    if not names:
        return OPENARM_B1_ARMS
    by_name = {a.name: a for a in OPENARM_B1_ARMS}
    unknown = [n for n in names if n not in by_name]
    if unknown:
        raise ValueError(f"unknown arm(s) {unknown}; expected a subset of {list(by_name)}")
    return tuple(by_name[n] for n in names)
