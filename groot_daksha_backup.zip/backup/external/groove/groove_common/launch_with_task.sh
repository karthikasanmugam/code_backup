#!/usr/bin/env bash
# Run an EXISTING System-B task script unchanged, but with its bridge swapped for a
# GROOVE bridge. Called by a_joint_groove/run_system_b_joint_groove.sh and
# b_cartesian_groove/run_system_b_cartesian_groove.sh; not usually run directly.
#
#   GROOVE_ENTRY=<.../run_bridge.py> TASK_SCRIPT=<task script> \
#     bash launch_with_task.sh [extra bridge or --groove-* flags ...]
#
# How: the task script runs as a child bash with two exported shell functions,
# `python` and `exec`. When it reaches `python .../eval_openarm_b1_ros2.py ARGS` or
# `exec python .../eval_openarm_b1_ros2.py ARGS`, the call becomes
# `python <GROOVE_ENTRY> ARGS <extra flags>`. Everything else -- env setup, ROS
# sourcing, the venv, every limit/topic/language flag -- is the task script's own,
# so a GROOVE run and a baseline run of the same task use identical settings.
# Every other `python`/`exec` call passes straight through.
#
# Extra flags come last, so they override the task script's values (argparse keeps
# the last occurrence).
#
# examples/openarm_b1/run_system_b_pick_box_2_ros2.sh and _two_box_pick_ros2.sh end in
# `exec bash examples/openarm_b1/run_system_b_openarm_b1_ros2.sh`, which is not in the
# repo. Set GROOVE_BASE_SCRIPT to the script that should run in its place, e.g.
#   GROOVE_BASE_SCRIPT=gr00t/eval/real_robot/OPENARM_B1/run_ros2_openarm_b1_eval.sh
# That one reads the wrapper's JOINT_MIN_CSV / JOINT_MAX_CSV / MAX_STEP_DELTA_CSV /
# LANG_INSTRUCTION exports, but NOT its START_POSE_* ones (the start-pose check then
# uses the bridge's built-in pick_box_2 values; it only warns, it clamps nothing).
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export REPO_ROOT="${REPO_ROOT:-$(cd "$HERE/../../.." && pwd)}"
: "${GROOVE_ENTRY:?set GROOVE_ENTRY to a GROOVE run_bridge.py}"
[ -f "$GROOVE_ENTRY" ] || { echo "[groove] GROOVE_ENTRY not found: $GROOVE_ENTRY" >&2; exit 1; }

TASK_SCRIPT="${TASK_SCRIPT:-gr00t/eval/real_robot/OPENARM_B1/run_ros2_openarm_b1_eval.sh}"
case "$TASK_SCRIPT" in /*) ;; *) TASK_SCRIPT="$REPO_ROOT/$TASK_SCRIPT" ;; esac
[ -f "$TASK_SCRIPT" ] || { echo "[groove] TASK_SCRIPT not found: $TASK_SCRIPT" >&2; exit 1; }

GROOVE_EXTRA_ARGS_FILE="$(mktemp -t groove_args.XXXXXX)"
trap 'rm -f "$GROOVE_EXTRA_ARGS_FILE"' EXIT
if [ "$#" -gt 0 ]; then printf '%s\0' "$@" > "$GROOVE_EXTRA_ARGS_FILE"; fi
export GROOVE_ENTRY GROOVE_EXTRA_ARGS_FILE

_groove_extra() {
  _GROOVE_EXTRA=()
  if [ -s "${GROOVE_EXTRA_ARGS_FILE:-}" ]; then
    mapfile -d '' -t _GROOVE_EXTRA < "$GROOVE_EXTRA_ARGS_FILE"
  fi
}
_groove_is_bridge() {
  case "${1:-}" in *eval_openarm_b1_ros2.py) return 0 ;; esac
  return 1
}
python() {
  if _groove_is_bridge "${1:-}"; then
    shift
    _groove_extra
    echo "[groove] bridge -> $GROOVE_ENTRY ${_GROOVE_EXTRA[*]}" >&2
    command python "$GROOVE_ENTRY" "$@" "${_GROOVE_EXTRA[@]}"
    return $?
  fi
  command python "$@"
}
exec() {
  if [ "${1:-}" = python ] || [ "${1:-}" = python3 ]; then
    local py="$1"
    shift
    if _groove_is_bridge "${1:-}"; then
      shift
      _groove_extra
      echo "[groove] bridge -> $GROOVE_ENTRY ${_GROOVE_EXTRA[*]}" >&2
      builtin exec "$py" "$GROOVE_ENTRY" "$@" "${_GROOVE_EXTRA[@]}"
    fi
    builtin exec "$py" "$@"
  fi
  if [ "${1:-}" = bash ] && [ -n "${2:-}" ] && [ ! -e "$2" ]; then
    if [ -n "${GROOVE_BASE_SCRIPT:-}" ]; then
      local b="$GROOVE_BASE_SCRIPT"
      case "$b" in /*) ;; *) b="$REPO_ROOT/$b" ;; esac
      echo "[groove] $2 does not exist; running GROOVE_BASE_SCRIPT=$b instead" >&2
      shift 2
      builtin exec bash "$b" "$@"
    fi
    echo "[groove] ERROR: the task script execs $2, which does not exist." >&2
    echo "[groove] Set GROOVE_BASE_SCRIPT to the script to run instead, e.g." >&2
    echo "[groove]   GROOVE_BASE_SCRIPT=gr00t/eval/real_robot/OPENARM_B1/run_ros2_openarm_b1_eval.sh" >&2
    return 127
  fi
  builtin exec "$@"
}
export -f python exec _groove_extra _groove_is_bridge

echo "[groove] task script: $TASK_SCRIPT" >&2
bash "$TASK_SCRIPT"
