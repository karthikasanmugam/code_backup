#!/usr/bin/env bash
# System B (robot machine) with CARTESIAN GROOVE (option B, as in the paper).
#
# Needs external/groove/b_cartesian_groove/arm_config.json (URDF path + base/tip links
# per arm). Create it from arm_config.example.json; for a first draft run
#   python external/groove/b_cartesian_groove/inspect_urdf.py --urdf <file> --suggest-config
#
# Runs one of the existing task scripts unchanged with the bridge swapped for
# b_cartesian_groove/run_bridge.py:
#
#   TASK_SCRIPT=examples/openarm_b1/run_system_b_blackbox_pick_and_place_ros2.sh \
#     bash external/groove/b_cartesian_groove/run_system_b_cartesian_groove.sh
#
# Tuning (flags after the script name override the task script and the defaults):
#   --groove-eps0 0.005          reference cube half-width, m (paper-equivalent 0.0075)
#   --groove-eps-rot 0.01        rotation half-width, rad (paper-equivalent 0.075)
#   --groove-max-joint-dev 0.05  chunks whose IK moves a joint further go to joint GROOVE
#   --groove-fallback raw        paper behaviour: rejected chunks go out raw
#   --groove-boxes reference     cube only instead of all 14 boxes (faster)
#   --groove-arm-config FILE     a different arm config
#   --groove-log-dir DIR / --no-groove   as in option A
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export GROOVE_ENTRY="$HERE/run_bridge.py"
exec bash "$HERE/../groove_common/launch_with_task.sh" "$@"
