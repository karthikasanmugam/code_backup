# Option B: Cartesian GROOVE (the paper's formulation)

Per arm, per chunk:

1. **FK.** The joint chunk and the last 3 published commands become TCP poses.
2. **Increments.** Translation `p_t − p_{t−1}` and local rotation
   `log(R_{t−1}ᵀ R_t)`: the paper's delta-EEF commands.
3. **Stages A/B.** 14 equal-volume correction regions: the reference cube, plus boxes
   that are tight along one of 3 axes, 6 face diagonals or 4 body diagonals and wide
   across it. Each region gives a jerk QP with the delivered increments as boundary
   conditions. That is 14 × 3 + 3 = 45 scalar QPs per arm, solved in one batch
   together with the other arm.
4. **Stage C.** Keep the lowest-jerk region among the reference and those that beat it
   without deviating more than `rho_B` × the reference's total deviation.
5. **Back to joints.** Singularity-robust damped IK. Joint GROOVE's smoothed chunk is
   the IK seed and null-space reference, so the elbow's self-motion (the 7th DoF) is
   smoothed as well.
6. **Acceptance.** The arm falls back to joint GROOVE, or raw with
   `--groove-fallback raw`, if any of these holds:
   - the IK residual is too large;
   - a joint moves more than `max_joint_dev` from the policy;
   - joint jerk grows more than 2×;
   - the achieved TCP path is not smoother than raw.

`urdf_kinematics.py` is numpy-only (FK, Jacobian, batched IK), so nothing new has to
be installed.

## Daksha: already configured

`arm_config.json` points at
`research/astra/inspect-robots/daksha/daksha_description_full_body/urdf/robot.urdf`. It
smooths `left_tcp` / `right_tcp` in `world`, the same frames `daksha_placo_ik_sim.py`
drives. The URDF's joint names equal the dataset/policy names. What the checks found:

- **Left-arm joint signs.** Recorded left-arm values do not match this URDF's
  conventions. As-is, the left arm "grasps" 27 cm above the right arm with its gripper
  pointing the wrong way, and `left_joint_5` sits outside its URDF limits in 100% of
  `two_box_pick` frames. `joint_signs: [1,1,1,1,-1,-1,1]` fixes that.
  - The `left_joint_5` flip appears in every top-ranked fit and puts 100% of recorded
    values back inside the limits.
  - The `left_joint_6` flip is the best fit, but less certain.
  - **Confirm on the robot:** jog `left_joint_5` and then `left_joint_6` in the positive
    direction and compare with the URDF in RViz or placo. Reproduce the ranking with
    `inspect_urdf.py --config arm_config.json --dataset .../two_box_pick --fit-signs`.
- **URDF joint limits are tighter than the hardware.** `joint_1` on both arms is
  exceeded by up to 0.9 rad, and `joint_6` by up to 0.5 rad. The IK therefore clamps to
  the URDF range widened to the policy's own targets. Safety still comes from the
  bridge's `--joint-min/max-csv`.
- **The left arm hangs straight on one-arm tasks** (`pick_box_2`, `blackbox`):
  σ_min ≈ 0.003 in 100% of frames, so B always falls back to joint GROOVE there. For
  those tasks use A, or B with `--groove-arms right`.
- **Corrections are expensive in joint space** at the right arm's working poses
  (σ_min 0.08–0.13). On `two_box_pick` with the real policy, 40–50% of B's arm-chunks
  needed more than 0.05 rad of joint change or hit an IK residual, and went to the
  joint-GROOVE fallback.

## When you have the URDF

```bash
cd ~/Desktop/I/groot
# 1. look at it
python external/groove/b_cartesian_groove/inspect_urdf.py --urdf /path/to/openarm.urdf
# 2. draft the config (7-revolute chains, left/right guessed from names), then REVIEW it
python external/groove/b_cartesian_groove/inspect_urdf.py --urdf /path/to/openarm.urdf \
    --suggest-config > external/groove/b_cartesian_groove/arm_config.json
# 3. check the mapping and conditioning at the dataset's start pose
python external/groove/b_cartesian_groove/inspect_urdf.py \
    --config external/groove/b_cartesian_groove/arm_config.json --check-pose
```

Check these three things in `arm_config.json`:

- **`joint_names`**: the URDF joint names in the **policy's order**
  (`left_joint_1..7`, `right_joint_1..7`). `--check-pose` prints the mapping. A wrong
  order is a wrong kinematics model.
- **`tip_link` / `tcp_xyz`**: the point to smooth. Use the grasp point, not the wrist
  flange, if the URDF has one.
- **`sigma_min`** from `--check-pose`: below ~0.05 means that arm is near a singularity
  at its start pose. B will mostly fall back to joint GROOVE there.

`.urdf.xacro` files are expanded automatically when ROS is sourced, because the
`xacro` module is then importable. Otherwise convert once with
`xacro in.urdf.xacro > out.urdf`.

Then evaluate offline (`tools/offline_eval.py --methods raw,joint,cartesian
--arm-config ...`) and run:

```bash
TASK_SCRIPT=examples/openarm_b1/run_system_b_blackbox_pick_and_place_ros2.sh \
  bash external/groove/b_cartesian_groove/run_system_b_cartesian_groove.sh --groove-log-dir ~/groove_logs
```

## Flags

| flag | default | meaning |
|---|---|---|
| `--groove-arm-config` | `b_cartesian_groove/arm_config.json` | URDF + links |
| `--groove-eps0` | `0.005` m | reference cube half-width (paper-equivalent 0.0075) |
| `--groove-eps-tight` | `eps0/3` | tight axis of the directional boxes (paper ratio) |
| `--groove-eps-rot` | `0.01` rad | rotation half-width (paper-equivalent 0.075, see below) |
| `--groove-eps-guard` / `-rot` | `0.0005` m / `0.002` rad | guard box (paper-literal 5e-5 / 5e-4) |
| `--groove-boxes` | `all` | `reference` = cube only, ~2× faster |
| `--no-groove-smooth-rot` | | smooth position only, keep the policy's orientation |
| `--groove-max-joint-dev` | `0.05` rad | beyond this, use the joint-GROOVE fallback |
| `--groove-fallback` | `joint` | `raw` = the paper's behaviour |

Plus all of option A's common flags (`--groove-arms`, `--groove-log-dir`, `--no-groove`, guard).

## Why the defaults differ from the paper

The paper's values are in LIBERO's normalised action units. With robosuite's OSC
scaling they convert to 7.5 mm, 0.075 rad and a 0.05 mm guard. This robot differs
from the paper's setup in three ways:

- The policy emits 8-step, not 16-step, chunks.
- Its actions are joint positions, so every orientation correction has to be paid for
  in joint motion.
- Those joint actions are RELATIVE, so a posture offset carries into every later chunk.

The synthetic tests showed 0.1–0.5 rad of posture drift with a 0.03 rad rotation box.
They also showed that a 0.05 mm guard is smaller than the IK's own residual. The
defaults above were chosen from those tests. Re-tune on your recordings.
