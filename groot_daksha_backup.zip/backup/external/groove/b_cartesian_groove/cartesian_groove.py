"""Option B -- GROOVE on the end-effector path, as in the paper.

Per arm, per new chunk:

  1. FK: joint chunk + the last 3 delivered joint commands -> TCP poses.
  2. Command space = per-step increments: translation p_t - p_{t-1} (base frame) and
     rotation log(R_{t-1}^T R_t) (local axis-angle), exactly the paper's delta-EEF.
  3. Stage A/B: 14 candidate correction regions of equal volume -- the reference cube
     and 13 boxes that are tight along one direction (3 axes, 6 face diagonals,
     4 body diagonals) and wide across it -- each solved as the jerk QP, with the two
     delivered increments as boundary conditions. In each box's own orthonormal frame
     the translation QP splits into 3 scalar QPs; rotation uses one shared cube, so
     14 x 3 + 3 = 45 scalar QPs per arm, solved in one batch.
  4. Stage C: keep the lowest-jerk candidate among the reference and the boxes that
     beat it (P_k < P_0) without deviating much more in total (B_k <= rho_B * B_0).
  5. Integrate the chosen increments back to poses and run IK to joint targets, seeded
     with the policy's joints and pulled toward them in the null space, so the 7-DoF
     arm keeps the posture the policy chose. If IK does not converge, or the joint
     solution moves further than max_joint_dev from the policy, that arm's chunk is
     sent raw.

UNITS. The paper's values (eps0 0.15, eps_tight 0.05, eps_g 0.001) are in LIBERO's
normalised delta-EEF action units. PAPER_* below converts them assuming robosuite's
default OSC_POSE scaling, which LIBERO uses: 1.0 = 0.05 m translation and 0.5 rad
rotation per step -> 7.5 mm / 2.5 mm / 0.075 rad.

The DEFAULT_* box is smaller (5 mm, 0.01 rad):
  * these checkpoints emit 8-step chunks (0.27 s), not the paper's 16, so a 7.5 mm box
    already lets a smooth reach collapse to a pure constant-acceleration arc; 5 mm is
    what joint GROOVE's 0.01 rad default amounts to at a ~0.5 m lever;
  * rotation is the expensive direction for a joint-space robot: a 0.03 rad
    orientation correction along a weakly manipulable axis took 0.1-0.5 rad of joint
    motion in the offline tests, and because the arms are RELATIVE actions that
    posture offset carries into every later chunk. 0.01 rad plus max_joint_dev 0.05
    kept B ahead of A on TCP jerk while bounding that drift (tools/offline_eval.py).
The tight/reference ratio (1/3) and the equal-volume rule are the paper's. Treat all of
these as starting points to re-tune on your own recordings, not measured OpenArm values.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
import json
from pathlib import Path
import sys

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from groove_common.box_qp import solve_jerk_qp  # noqa: E402
from groove_common.gripper_guard import GuardConfig, guard_mask  # noqa: E402
from groove_common.jerk import jerk_cost  # noqa: E402
from groove_common.layout import ArmSlots, OPENARM_B1_ARMS  # noqa: E402

from . import so3  # noqa: E402
from .urdf_kinematics import KinematicChain, UrdfModel  # noqa: E402

TRANS_UNIT_M = 0.05  # robosuite OSC_POSE output_max, translation
ROT_UNIT_RAD = 0.5  # robosuite OSC_POSE output_max, rotation

PAPER_EPS0 = 0.15 * TRANS_UNIT_M  # 7.5 mm
PAPER_EPS_TIGHT = 0.05 * TRANS_UNIT_M  # 2.5 mm
PAPER_EPS_ROT = 0.15 * ROT_UNIT_RAD  # 0.075 rad

DEFAULT_EPS0 = 0.005  # m, reference cube half-width
DEFAULT_EPS_TIGHT = DEFAULT_EPS0 / 3.0  # m, tight axis of a directional box (paper ratio)
DEFAULT_EPS_ROT = 0.01  # rad
PAPER_EPS_GUARD = 0.001 * TRANS_UNIT_M  # 0.05 mm, paper's eps_g
PAPER_EPS_GUARD_ROT = 0.001 * ROT_UNIT_RAD  # 0.5 mrad
# Guard box used by default: 0.5 mm / 2 mrad, i.e. what joint GROOVE's 0.001 rad guard
# amounts to at the TCP, so A and B protect a grasp equally. At the paper-literal 0.05 mm
# the IK's own residual (~0.06 mm) is as large as the whole allowed correction, and
# the guard windows around every grasp and release went through effectively raw.
DEFAULT_EPS_GUARD = 0.0005
DEFAULT_EPS_GUARD_ROT = 0.002


def _complete_basis(d: np.ndarray) -> np.ndarray:
    d = d / np.linalg.norm(d)
    helper = np.array([1.0, 0, 0]) if abs(d[0]) < 0.9 else np.array([0, 1.0, 0])
    u = np.cross(d, helper)
    u /= np.linalg.norm(u)
    return np.stack([d, u, np.cross(d, u)], axis=1)  # columns = box axes


def box_frames(eps0: float, eps_tight: float, which: str = "all") -> list[tuple[str, np.ndarray, np.ndarray]]:
    """[(name, Q (3x3, columns = box axes), half-widths (3,))], reference first.

    Directional boxes keep the reference volume: eps_tight * eps_wide^2 = eps0^3.
    """
    frames = [("cube", np.eye(3), np.full(3, eps0))]
    if which == "reference":
        return frames
    if which != "all":
        raise ValueError(f"boxes must be 'all' or 'reference', got {which!r}")
    if not 0 < eps_tight < eps0:
        raise ValueError(f"need 0 < eps_tight < eps0, got {eps_tight}, {eps0}")
    eps_wide = np.sqrt(eps0**3 / eps_tight)
    eta = np.array([eps_tight, eps_wide, eps_wide])
    dirs = {
        "x": (1, 0, 0), "y": (0, 1, 0), "z": (0, 0, 1),
        "xy": (1, 1, 0), "x-y": (1, -1, 0), "xz": (1, 0, 1),
        "x-z": (1, 0, -1), "yz": (0, 1, 1), "y-z": (0, 1, -1),
        "xyz": (1, 1, 1), "xy-z": (1, 1, -1), "x-yz": (1, -1, 1), "-xyz": (-1, 1, 1),
    }
    for name, d in dirs.items():
        frames.append((f"tight_{name}", _complete_basis(np.asarray(d, dtype=np.float64)), eta))
    return frames


def _past_from_increments(h: np.ndarray) -> np.ndarray:
    """Delivered increments [h_{-2}, h_{-1}] (2, D) -> running-sum past (D, 3) with p_{-1} = 0."""
    return np.stack([-(h[0] + h[1]), -h[1], np.zeros(h.shape[1])], axis=1)


@dataclass
class CartesianGrooveCore:
    """Stages A-C on increments. Pure math; no kinematics."""

    eps0: float = DEFAULT_EPS0
    eps_tight: float = DEFAULT_EPS_TIGHT
    eps_rot: float = DEFAULT_EPS_ROT
    eps_guard: float = DEFAULT_EPS_GUARD
    eps_guard_rot: float = DEFAULT_EPS_GUARD_ROT
    rho_b: float = 1.5
    lam: float = 1e-9
    boxes: str = "all"
    # False = regulate TCP position only and keep the policy's orientation increments.
    # Orientation corrections are the ones that turn into large wrist motion near a
    # wrist singularity.
    smooth_rot: bool = True

    def __post_init__(self):
        self.frames = box_frames(self.eps0, self.eps_tight, self.boxes)

    def regulate(self, r: np.ndarray, h: np.ndarray, guard: np.ndarray) -> tuple[np.ndarray, dict]:
        """r: (H, 6) raw increments, h: (2, 6) delivered [h_{-2}, h_{-1}], guard: (H,) bool."""
        target, past, eps = self.build(r, h, guard)
        return self.select(solve_jerk_qp(target, past, eps, self.lam), r, h)

    def build(self, r: np.ndarray, h: np.ndarray, guard: np.ndarray):
        """Stages A+B setup: one scalar QP column per (box, axis), plus rotation.

        Returns (target, past, eps), each stacked over columns, ready for solve_jerk_qp.
        Split from select() so both arms can share one batched solve.
        """
        H = r.shape[0]
        targets, pasts, epss = [], [], []
        for _, Q, eta in self.frames:
            rk, hk = r[:, :3] @ Q, h[:, :3] @ Q
            targets.append(np.cumsum(rk, axis=0).T)
            pasts.append(_past_from_increments(hk))
            e = np.tile(eta[:, None], (1, H))
            e[:, guard] = np.minimum(e[:, guard], self.eps_guard)
            epss.append(e)
        if self.smooth_rot:
            targets.append(np.cumsum(r[:, 3:], axis=0).T)
            pasts.append(_past_from_increments(h[:, 3:]))
            e = np.full((3, H), self.eps_rot)
            e[:, guard] = min(self.eps_rot, self.eps_guard_rot)
            epss.append(e)
        return np.concatenate(targets), np.concatenate(pasts), np.concatenate(epss)

    def select(self, p: np.ndarray, r: np.ndarray, h: np.ndarray) -> tuple[np.ndarray, dict]:
        """Stage C on the solved columns p from build(): pick the admitted lowest-jerk box."""
        K = len(self.frames)
        u = np.diff(p, axis=1, prepend=0.0)  # running sums -> increments (p_{-1} = 0)
        u_rot = u[3 * K :].T if self.smooth_rot else r[:, 3:].copy()

        past_tr = _past_from_increments(h[:, :3]).T  # (3, 3): rows = time
        raw_cum = np.cumsum(r[:, :3], axis=0)
        P, Bdev, cands = [], [], []
        for k, (_, Q, _) in enumerate(self.frames):
            u_tr = u[3 * k : 3 * k + 3].T @ Q.T
            cum = np.cumsum(u_tr, axis=0)
            cands.append(u_tr)
            P.append(jerk_cost(cum, past_tr))
            Bdev.append(float(np.abs(cum - raw_cum).sum()))
        P, Bdev = np.array(P), np.array(Bdev)
        admitted = np.isfinite(P) & (Bdev <= self.rho_b * max(Bdev[0], 1e-12)) & (P < P[0])
        admitted[0] = True
        k_best = int(np.flatnonzero(admitted)[np.argmin(P[admitted])])

        u_out = np.concatenate([cands[k_best], u_rot], axis=1)
        past_rot = _past_from_increments(h[:, 3:]).T
        info = {
            "box": self.frames[k_best][0],
            "admitted": int(admitted.sum() - 1),
            "jerk_tr_raw": jerk_cost(raw_cum, past_tr),
            "jerk_tr_groove": float(P[k_best]),
            "jerk_rot_raw": jerk_cost(np.cumsum(r[:, 3:], axis=0), past_rot),
            "jerk_rot_groove": jerk_cost(np.cumsum(u_rot, axis=0), past_rot),
            "dev_tr_max": float(np.abs(np.cumsum(u_out[:, :3] - r[:, :3], axis=0)).max()),
            "dev_rot_max": float(np.abs(np.cumsum(u_rot - r[:, 3:], axis=0)).max()),
        }
        return u_out, info


class ArmKinematics:
    """A chain plus the map from the policy's joint values to the URDF's.

    q_urdf[chain slot c] = sign * q_policy[perm[c]] + offset, where sign / offset are
    given per POLICY joint (same order as joint_names). They absorb a robot driver whose
    joint direction or zero differs from the URDF's -- see inspect_urdf.py --fit-signs.
    """

    def __init__(self, chain: KinematicChain, policy_joint_names: list[str] | None, n_policy: int = 7,
                 signs: list[float] | None = None, offsets: list[float] | None = None):
        self.chain = chain
        if policy_joint_names is None:
            if chain.n != n_policy:
                raise ValueError(
                    f"chain has {chain.n} actuated joints {chain.joint_names}, policy arm has "
                    f"{n_policy}; list the URDF joint names in policy order via 'joint_names'"
                )
            self.perm = np.arange(chain.n)
        else:
            if len(policy_joint_names) != n_policy:
                raise ValueError(f"'joint_names' must list {n_policy} names, got {len(policy_joint_names)}")
            missing = [n for n in chain.joint_names if n not in policy_joint_names]
            extra = [n for n in policy_joint_names if n not in chain.joint_names]
            if missing or extra:
                raise ValueError(
                    f"joint name mismatch: in chain but not in joint_names {missing}; "
                    f"in joint_names but not in chain {extra}. Chain order: {chain.joint_names}"
                )
            self.perm = np.array([policy_joint_names.index(n) for n in chain.joint_names])
        for label, v in (("joint_signs", signs), ("joint_offsets", offsets)):
            if v is not None and len(v) != n_policy:
                raise ValueError(f"'{label}' must have {n_policy} values (policy order), got {len(v)}")
        if signs is not None and not all(s in (1, -1) for s in signs):
            raise ValueError(f"'joint_signs' must be +1 / -1, got {signs}")
        # Stored in CHAIN order.
        self.sign = np.ones(n_policy) if signs is None else np.asarray(signs, dtype=np.float64)[self.perm]
        self.offset = np.zeros(n_policy) if offsets is None else np.asarray(offsets, dtype=np.float64)[self.perm]

    def to_chain(self, q_policy: np.ndarray) -> np.ndarray:
        return np.asarray(q_policy, dtype=np.float64)[..., self.perm] * self.sign + self.offset

    def to_policy(self, q_chain: np.ndarray, like: np.ndarray) -> np.ndarray:
        out = np.array(like, dtype=np.float64, copy=True)
        out[..., self.perm] = (np.asarray(q_chain, dtype=np.float64) - self.offset) * self.sign
        return out

    def poses(self, q_policy: np.ndarray) -> np.ndarray:
        return self.chain.fk(self.to_chain(q_policy))

    def eef_trace(self, q_policy: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """(positions (T,3), running sum of local rotation increments (T,3)) for metrics."""
        T = self.poses(q_policy)
        R = T[:, :3, :3]
        drot = so3.log(np.swapaxes(R[:-1], -1, -2) @ R[1:])
        return T[:, :3, 3], np.concatenate([np.zeros((1, 3)), np.cumsum(drot, axis=0)])


@dataclass
class CartesianArmGroove:
    kin: ArmKinematics
    core: CartesianGrooveCore = field(default_factory=CartesianGrooveCore)
    # rad. Chunks whose IK solution moves any joint further than this from the policy
    # go to the joint-GROOVE fallback. It bounds the posture drift that relative actions
    # would otherwise accumulate chunk after chunk; an IK branch flip is several tenths.
    max_joint_dev: float = 0.05
    max_joint_jerk_ratio: float = 2.0  # reject if joint-space jerk grows more than this
    # Largest IK residual accepted, as a fraction of eps0 / eps_rot. Near a singularity
    # the damped IK stops short of the target, i.e. BETWEEN raw and smoothed -- never
    # further from the policy -- so a residual only costs smoothing, which the TCP
    # jerk check below already measures. This bound only catches a diverged solve.
    ik_accept_frac: float = 1.0
    ik_kwargs: dict = field(default_factory=dict)

    def regulate(self, q_raw: np.ndarray, q_hist: np.ndarray, guard: np.ndarray) -> tuple[np.ndarray, dict]:
        """q_raw: (H, 7) policy order; q_hist: (K>=3, 7) delivered, oldest first."""
        cols, ctx = self.prepare(q_raw, q_hist, guard)
        return self.finish(solve_jerk_qp(*cols, self.core.lam), ctx)

    def prepare(self, q_raw: np.ndarray, q_hist: np.ndarray, guard: np.ndarray):
        """FK + increments + QP columns. Returns (columns for solve_jerk_qp, context)."""
        qc_raw = self.kin.to_chain(q_raw)
        qc_hist = self.kin.to_chain(q_hist[-3:])
        T = self.kin.chain.fk(np.vstack([qc_hist, qc_raw]))
        p, R = T[:, :3, 3], T[:, :3, :3]
        inc = np.concatenate(
            [np.diff(p, axis=0), so3.log(np.swapaxes(R[:-1], -1, -2) @ R[1:])], axis=1
        )  # (2 + H, 6)
        ctx = dict(q_raw=q_raw, qc_raw=qc_raw, qc_hist=qc_hist, p=p, R=R, inc=inc, guard=guard)
        return self.core.build(inc[2:], inc[:2], guard), ctx

    def finish(self, sol: np.ndarray, ctx: dict, q_posture: np.ndarray | None = None) -> tuple[np.ndarray, dict]:
        """Stage C, back to joints via IK, and the acceptance checks.

        q_posture (H, 7, policy order): seed and null-space reference for the IK. The
        TCP path fixes 6 of the arm's 7 DoF; the 7th (elbow self-motion) follows this
        reference. The raw chunk is the default, but it carries the policy's per-chunk
        offset, so the self-motion then jumps at every chunk boundary and joint jerk
        rises even while TCP jerk falls. CartesianGroove passes the joint-GROOVE
        solution instead, which is smooth by construction.
        """
        q_raw, qc_raw, qc_hist = ctx["q_raw"], ctx["qc_raw"], ctx["qc_hist"]
        p, R, inc, guard = ctx["p"], ctx["R"], ctx["inc"], ctx["guard"]
        u, info = self.core.select(sol, inc[2:], inc[:2])

        p_new = p[2] + np.cumsum(u[:, :3], axis=0)
        R_new = np.empty((len(u), 3, 3))
        Rc = R[2]
        dR = so3.exp(u[:, 3:])
        for t in range(len(u)):
            Rc = Rc @ dR[t]
            R_new[t] = Rc
        qc_ref = qc_raw if q_posture is None else self.kin.to_chain(q_posture)
        # URDF limits, widened to wherever the policy itself is asking to go: recorded
        # OpenArm/Daksha poses sit up to a few mrad past some URDF limits (e.g. the
        # elbow at +0.003 against a 0.0 bound), and IK must not "correct" what the
        # policy did not ask for. The bridge's --joint-min/max-csv remain the real clamp.
        lo = np.minimum(self.kin.chain.lower, np.minimum(qc_raw, qc_ref).min(axis=0))
        hi = np.maximum(self.kin.chain.upper, np.maximum(qc_raw, qc_ref).max(axis=0))
        q_sol, pe, re, _ = self.kin.chain.ik(
            so3.make_T(R_new, p_new), qc_ref, qc_ref, lower=lo, upper=hi, **self.ik_kwargs
        )

        # Judge what the arm will ACTUALLY do: the achieved TCP path, not the target.
        T_sol = self.kin.chain.fk(q_sol)
        past_p = p[:3]
        eef_raw = jerk_cost(p[3:], past_p)
        eef_new = jerk_cost(T_sol[:, :3, 3], past_p)
        jj_raw, jj_new = jerk_cost(qc_raw, qc_hist), jerk_cost(q_sol, qc_hist)
        dev = float(np.abs(q_sol - qc_raw).max())
        pos_ok = self.ik_accept_frac * self.core.eps0
        rot_ok = self.ik_accept_frac * self.core.eps_rot
        reason = None
        if pe.max() > max(pos_ok, 1e-4) or re.max() > max(rot_ok, 1e-3):
            reason = f"ik residual (pos {pe.max() * 1e3:.2f} mm, rot {re.max():.1e} rad)"
        elif dev > self.max_joint_dev:
            reason = f"joint_dev {dev:.3f} > {self.max_joint_dev}"
        elif jj_new > self.max_joint_jerk_ratio * jj_raw + 1e-12:
            reason = f"joint jerk x{jj_new / max(jj_raw, 1e-18):.1f}"
        elif eef_new >= eef_raw:
            reason = "no TCP jerk gain after IK"
        info.update(
            tcp_jerk_raw=eef_raw,
            tcp_jerk_groove=eef_new if reason is None else eef_raw,
            accepted=reason is None,
            fallback=reason,
            joint_jerk_raw=jj_raw,
            joint_jerk_groove=jj_new if reason is None else jj_raw,
            max_dev=dev if reason is None else 0.0,
            ik_pos_err=float(pe.max()),
            ik_rot_err=float(re.max()),
            guard_steps=int(np.asarray(guard).sum()),
        )
        info["reduction_pct"] = (
            100.0 * (1 - eef_new / eef_raw) if reason is None and eef_raw > 0 else 0.0
        )
        if reason is not None:
            return np.array(q_raw, dtype=np.float64, copy=True), info
        return self.kin.to_policy(q_sol, q_raw), info


@dataclass
class CartesianGroove:
    """16-DoF interface, same as JointGroove.regulate: grippers pass through.

    fallback: a JointGroove, used twice (None = paper-faithful: neither):
      * posture reference -- its smoothed joints seed the IK and set the null-space
        target, so the 7th DoF is smoothed too (see CartesianArmGroove.finish);
      * fallback -- an arm whose Cartesian result is rejected (IK residual, joint
        deviation, joint-jerk growth, no TCP gain) gets the joint-GROOVE chunk instead
        of the raw one. A raw chunk between smoothed ones ignores the delivered history
        and brings the boundary jerk straight back.
    """

    arms: list[tuple[ArmSlots, CartesianArmGroove]]
    guard: GuardConfig = field(default_factory=GuardConfig)
    fallback: object | None = None  # a_joint_groove.JointGroove

    name = "cartesian"

    def regulate(self, raw16: np.ndarray, hist16: np.ndarray) -> tuple[np.ndarray, dict]:
        raw16 = np.asarray(raw16, dtype=np.float64)
        hist16 = np.asarray(hist16, dtype=np.float64)
        if hist16.shape[0] < 3:
            raise ValueError("need at least 3 delivered commands of history")
        out = raw16.copy()
        info: dict = {"method": self.name, "arms": {}}
        preps = []
        for slots, reg in self.arms:
            mask = guard_mask(raw16[:, slots.gripper], hist16[:, slots.gripper], self.guard)
            cols, ctx = reg.prepare(raw16[:, slots.arm], hist16[:, slots.arm], mask)
            preps.append((slots, reg, cols, ctx))
        lams = {reg.core.lam for _, reg, _, _ in preps}
        if len(lams) == 1 and len(preps) > 1:
            # Every arm's columns in ONE batched solve: the per-call overhead dominates.
            sol_all = solve_jerk_qp(
                *(np.concatenate([c[i] for _, _, c, _ in preps]) for i in range(3)), lams.pop()
            )
            sizes = np.cumsum([0] + [c[0].shape[0] for _, _, c, _ in preps])
            sols = [sol_all[a:b] for a, b in zip(sizes[:-1], sizes[1:])]
        else:
            sols = [solve_jerk_qp(*c, reg.core.lam) for _, reg, c, _ in preps]
        q_joint = None
        if self.fallback is not None:
            q_joint, j_info = replace(self.fallback, arms=tuple(s for s, _ in self.arms)).regulate(raw16, hist16)
        rejected = []
        for (slots, reg, _, ctx), sol in zip(preps, sols):
            q, ainfo = reg.finish(sol, ctx, None if q_joint is None else q_joint[:, slots.arm])
            out[:, slots.arm] = q
            info["arms"][slots.name] = ainfo
            if not ainfo["accepted"]:
                rejected.append(slots)
        if rejected and q_joint is not None:
            for slots in rejected:
                out[:, slots.arm] = q_joint[:, slots.arm]
                a = info["arms"][slots.name]
                j = j_info["arms"][slots.name]
                a["fallback"] = f"{a['fallback']} -> joint GROOVE"
                a["accepted"] = j["accepted"]
                a["via_joint_fallback"] = True
                a["reduction_pct"] = j["reduction_pct"]
                a["max_dev"] = j["max_dev"]
        return out, info


def load_arm_kinematics(config_path: str | Path, arm_names: list[str]) -> dict[str, ArmKinematics]:
    """Build ArmKinematics per arm from the JSON described in arm_config.example.json."""
    cfg = json.loads(Path(config_path).expanduser().read_text())
    base_dir = Path(config_path).expanduser().resolve().parent
    models: dict[str, UrdfModel] = {}

    def model(path_str: str) -> UrdfModel:
        path = Path(path_str).expanduser()
        if not path.is_absolute():
            path = base_dir / path
        key = str(path)
        if key not in models:
            models[key] = UrdfModel.from_file(path)
        return models[key]

    out = {}
    for name in arm_names:
        a = cfg["arms"].get(name)
        if a is None:
            raise ValueError(f"{config_path}: no entry for arm {name!r} under 'arms'")
        urdf = a.get("urdf", cfg.get("urdf"))
        if not urdf:
            raise ValueError(f"{config_path}: arm {name!r} has no 'urdf' (set it per arm or top-level)")
        tcp = so3.make_T(
            so3.rpy_to_matrix(np.asarray(a.get("tcp_rpy", [0, 0, 0]), dtype=np.float64)),
            np.asarray(a.get("tcp_xyz", [0, 0, 0]), dtype=np.float64),
        )
        chain = model(urdf).chain(a["base_link"], a["tip_link"], tcp)
        out[name] = ArmKinematics(chain, a.get("joint_names"),
                                  signs=a.get("joint_signs"), offsets=a.get("joint_offsets"))
    return out


def build_from_args(args, arms: tuple[ArmSlots, ...] = OPENARM_B1_ARMS) -> CartesianGroove:
    kins = load_arm_kinematics(args.groove_arm_config, [a.name for a in arms])
    core_kw = dict(
        eps0=args.groove_eps0,
        eps_tight=args.groove_eps_tight if args.groove_eps_tight else args.groove_eps0 / 3.0,
        eps_rot=args.groove_eps_rot,
        eps_guard=args.groove_eps_guard,
        eps_guard_rot=args.groove_eps_guard_rot,
        rho_b=args.groove_rho_b,
        lam=args.groove_lambda,
        boxes=args.groove_boxes,
        smooth_rot=args.groove_smooth_rot,
    )
    regs = [
        (
            slots,
            CartesianArmGroove(
                kin=kins[slots.name],
                core=CartesianGrooveCore(**core_kw),
                max_joint_dev=args.groove_max_joint_dev,
                max_joint_jerk_ratio=args.groove_max_joint_jerk_ratio,
            ),
        )
        for slots in arms
    ]
    guard = GuardConfig.from_seconds(
        args.groove_guard_window_s,
        args.control_hz,
        enabled=args.groove_guard,
        step_thresh=args.groove_guard_step_thresh,
        jump_thresh=args.groove_guard_jump_thresh,
    )
    fallback = None
    if args.groove_fallback == "joint":
        from a_joint_groove.joint_groove import JointGroove, parse_eps

        fallback = JointGroove(eps=parse_eps(args.groove_fallback_eps), eps_guard=0.001,
                               lam=args.groove_lambda, guard=guard, arms=())
    return CartesianGroove(arms=regs, guard=guard, fallback=fallback)
