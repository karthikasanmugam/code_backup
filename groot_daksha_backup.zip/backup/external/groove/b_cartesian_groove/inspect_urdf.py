#!/usr/bin/env python3
"""Inspect a URDF and prepare arm_config.json for Cartesian GROOVE.

  # what is in it
  python external/groove/b_cartesian_groove/inspect_urdf.py --urdf openarm.urdf

  # draft config (7-revolute chains, left/right guessed from link names) -- REVIEW IT
  python external/groove/b_cartesian_groove/inspect_urdf.py --urdf openarm.urdf \
      --suggest-config > external/groove/b_cartesian_groove/arm_config.json

  # check a finished config: TCP pose and conditioning at a joint pose (default: the
  # pick_box_2 median start pose the bridge reports as START_POSE_HOME)
  python external/groove/b_cartesian_groove/inspect_urdf.py \
      --config external/groove/b_cartesian_groove/arm_config.json --check-pose

The conditioning check matters: Cartesian GROOVE needs IK, and near a singularity
(straight elbow, aligned wrist axes) a millimetre of TCP correction needs a large joint
motion. Such chunks are rejected and handed to the joint-GROOVE fallback, so a pose
that is singular most of the time means option B adds nothing over option A there.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
import glob
import json
from pathlib import Path
import re
import sys

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from b_cartesian_groove.cartesian_groove import ArmKinematics, load_arm_kinematics  # noqa: E402
from b_cartesian_groove.urdf_kinematics import ACTUATED, UrdfModel  # noqa: E402

# pick_box_2 median start pose, left-first 16-vector (run_system_b_pick_box_2_ros2.sh).
PICK_BOX_2_HOME = [
    -0.00019, -0.16785, -0.05436, 0.00286, 0.00324, -0.00153, 0.07572, -0.04393,
    -0.59911, -0.02213, 0.02041, 1.68326, 1.43053, -0.03586, 0.69848, 0.04376,
]
ARM_SLICES = {"left": slice(0, 7), "right": slice(8, 15)}


def describe(model: UrdfModel) -> None:
    print(f"robot '{model.name}': {len(model.links)} links, {len(model.joints)} joints")
    print(f"root link(s): {model.root_links()}")
    print(f"leaf links:   {model.leaf_links()}")
    print("actuated joints (parent -> child, limits):")
    for j in model.joints.values():
        if j.type in ACTUATED:
            print(f"  {j.name:32s} {j.type:10s} {j.parent} -> {j.child}  [{j.lower:+.3f}, {j.upper:+.3f}]")


def candidate_chains(model: UrdfModel) -> list[dict]:
    """Root -> (7th revolute joint's child, extended through fixed joints) for every leaf."""
    out, seen = [], set()
    for root in model.root_links():
        for leaf in model.leaf_links():
            try:
                path = model.path(root, leaf)
            except ValueError:
                continue
            rev = [j for j in path if j.type in ("revolute", "continuous")]
            if len(rev) < 7:
                continue
            arm = rev[:7]
            tip = arm[-1].child
            # Walk on through fixed joints (gripper mount, hand, tcp frames): follow a
            # frame named like a tool point when there is one, otherwise only a unique
            # child (a mount with two fingers AND a tcp frame must still reach the tcp).
            fixed_kids, all_kids = defaultdict(list), defaultdict(list)
            for j in model.joints.values():
                all_kids[j.parent].append(j.child)
                if j.type == "fixed":
                    fixed_kids[j.parent].append(j.child)
            while fixed_kids[tip]:
                pref = [c for c in fixed_kids[tip] if re.search(r"tcp|tool|grasp|end_?effector", c, re.I)]
                if pref:
                    tip = pref[0]
                elif len(all_kids[tip]) == 1:
                    tip = fixed_kids[tip][0]
                else:
                    break
            key = (root, tip)
            if key in seen:
                continue
            seen.add(key)
            names = " ".join([tip] + [j.name for j in arm]).lower()
            side = "left" if "left" in names else "right" if "right" in names else None
            out.append({"side": side, "base_link": root, "tip_link": tip, "joint_names": [j.name for j in arm]})
    return out


def check_pose(config: str, pose16: list[float]) -> None:
    kins = load_arm_kinematics(config, ["left", "right"])
    q16 = np.asarray(pose16, dtype=np.float64)
    for name, kin in kins.items():
        q = q16[ARM_SLICES[name]]
        T, J = kin.chain.fk_jacobian(kin.to_chain(q)[None])
        s = np.linalg.svd(J[0], compute_uv=False)
        p = T[0, :3, 3]
        verdict = "OK" if s[-1] >= 0.05 else "NEAR-SINGULAR: expect joint-GROOVE fallbacks here"
        print(f"{name:5s} TCP at [{p[0]:+.3f} {p[1]:+.3f} {p[2]:+.3f}] m | "
              f"singular values {np.round(s, 3).tolist()} | sigma_min {s[-1]:.3f} -> {verdict}")
        print(f"      chain joints (policy slot): "
              + ", ".join(f"{n}({int(i)})" for n, i in zip(kin.chain.joint_names, kin.perm)))


def check_dataset(config: str, dataset: str, stride: int) -> None:
    """Run the kinematics over every recorded state: conditioning, limits, workspace."""
    import pandas as pd

    ds = Path(dataset).expanduser()
    names = json.loads((ds / "meta" / "info.json").read_text())["features"]["observation.state"]["names"]
    files = sorted(glob.glob(str(ds / "data" / "chunk-*" / "episode_*.parquet")))
    S = np.concatenate([np.stack(pd.read_parquet(f, columns=["observation.state"])["observation.state"].values)[::stride]
                        for f in files])
    print(f"{ds.name}: {len(files)} episodes, {len(S)} states (every {stride}th frame)")
    kins = load_arm_kinematics(config, ["left", "right"])
    for name, kin in kins.items():
        sl = ARM_SLICES[name]
        want = [names[i] for i in range(sl.start, sl.stop)]
        mapped = [kin.chain.joint_names[list(kin.perm).index(i)] for i in range(7)]
        if want != mapped:
            print(f"  {name}: WARNING dataset slots {want} map to URDF joints {mapped} -- check joint_names")
        q = S[:, sl].astype(np.float64)
        qc = kin.to_chain(q)
        T, J = kin.chain.fk_jacobian(qc)
        smin = np.linalg.svd(J, compute_uv=False)[:, -1]
        p = T[:, :3, 3]
        over = np.maximum(qc - kin.chain.upper, 0) + np.maximum(kin.chain.lower - qc, 0)
        outside = [(kin.chain.joint_names[i], float((over[:, i] > 1e-6).mean()), float(over[:, i].max()))
                   for i in range(kin.chain.n) if over[:, i].max() > 1e-6]
        print(f"  {name}: sigma_min p5 {np.percentile(smin, 5):.3f}  p50 {np.median(smin):.3f}  "
              f"near-singular (<0.05) {100 * (smin < 0.05).mean():.1f}% of frames")
        print(f"  {name}: TCP x [{p[:, 0].min():+.3f}, {p[:, 0].max():+.3f}]  y [{p[:, 1].min():+.3f}, "
              f"{p[:, 1].max():+.3f}]  z [{p[:, 2].min():+.3f}, {p[:, 2].max():+.3f}] m  (travel "
              f"{np.linalg.norm(np.ptp(p, axis=0)):.3f} m)")
        for jn, frac, worst in outside:
            print(f"  {name}: {jn} outside URDF limits in {100 * frac:.1f}% of frames, by up to {worst:.4f} rad")


def fit_signs(config: str, dataset: str) -> None:
    """Which per-joint signs make the LEFT arm's grasps mirror the RIGHT arm's?

    Needs a dataset where BOTH grippers grasp (e.g. two_box_pick). Assumes the right arm's
    kinematics are right, and that both arms pick from the same table: at grasp the left
    TCP should sit at the right's mirrored position and point the mirrored way. Also
    scores how many recorded states fall inside the URDF limits. Evidence, not proof --
    confirm on the robot (move the joint, compare with RViz / placo).
    """
    import itertools

    import pandas as pd

    ds = Path(dataset).expanduser()
    eps = [np.stack(pd.read_parquet(f, columns=["observation.state"])["observation.state"].values)
           for f in sorted(glob.glob(str(ds / "data" / "chunk-*" / "episode_*.parquet")))]
    kins = load_arm_kinematics(config, ["left", "right"])

    def grasps(e, idx):
        c = np.abs(e[:, idx]) < 0.022  # both jaws: |q| < half of the 0.044 travel = closing
        return np.flatnonzero(c[1:] & ~c[:-1]) + 1

    R = np.array([e[f, 8:15] for e in eps for f in grasps(e, 15)])
    L = np.array([e[f, 0:7] for e in eps for f in grasps(e, 7)])
    if len(R) < 5 or len(L) < 5:
        raise SystemExit(f"{ds.name}: {len(R)} right / {len(L)} left grasps -- need a bimanual dataset")
    S = np.concatenate(eps)[::5, 0:7]
    Tr = kins["right"].poses(R)
    M = np.diag([1.0, -1.0, 1.0])
    pr, zr = M @ np.median(Tr[:, :3, 3], 0), M @ np.median(Tr[:, :3, 2], 0)
    left = kins["left"]
    base = left.sign[np.argsort(left.perm)]  # configured signs, policy order
    rows = []
    for fl in itertools.product([1, -1], repeat=7):
        f = np.asarray(fl) * base
        trial = ArmKinematics(left.chain, [left.chain.joint_names[list(left.perm).index(i)] for i in range(7)],
                              signs=f.tolist(), offsets=None)
        Tl = trial.poses(L)
        pl, zl = np.median(Tl[:, :3, 3], 0), np.median(Tl[:, :3, 2], 0)
        cos = float(zl @ zr / np.linalg.norm(zl) / np.linalg.norm(zr))
        qc = trial.to_chain(S)
        inside = float(np.mean(np.all((qc >= left.chain.lower - 1e-3) & (qc <= left.chain.upper + 1e-3), axis=1)))
        score = np.linalg.norm(pl - pr) + Tl[:, 2, 3].std() + 0.2 * (1 - cos) + 0.2 * (1 - inside)
        rows.append((score, f.astype(int).tolist(), np.linalg.norm(pl - pr), Tl[:, 2, 3].std(), cos, inside))
    rows.sort(key=lambda r: r[0])
    print(f"{ds.name}: {len(R)} right / {len(L)} left grasps. Right grasp TCP {np.median(Tr[:, :3, 3], 0).round(3)}")
    print("left joint_signs (policy order)       score  mirror err  z spread  cos(approach)  inside limits")
    for sc, f, pe, sd, cos, ins in rows[:6]:
        print(f"  {str(f):34s}  {sc:.3f}  {pe:.3f} m    {sd:.3f}     {cos:+.2f}          {100 * ins:.0f}%")
    cur = next(r for r in rows if r[1] == base.astype(int).tolist())
    print(f"  current config {str(cur[1]):19s}  {cur[0]:.3f}  {cur[2]:.3f} m    {cur[3]:.3f}     {cur[4]:+.2f}"
          f"          {100 * cur[5]:.0f}%   (rank {rows.index(cur) + 1}/128)")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--urdf", help=".urdf or .urdf.xacro")
    ap.add_argument("--suggest-config", action="store_true", help="print a draft arm_config.json")
    ap.add_argument("--config", help="arm_config.json to check")
    ap.add_argument("--check-pose", nargs="?", const="home", default=None,
                    help="16 comma-separated joint values (left-first), or 'home' (pick_box_2 start)")
    ap.add_argument("--dataset", help="LeRobot dataset root: check every recorded state (needs --config)")
    ap.add_argument("--dataset-stride", type=int, default=5)
    ap.add_argument("--fit-signs", action="store_true",
                    help="with --config and a BIMANUAL --dataset: rank left-arm joint sign conventions")
    args = ap.parse_args()

    if args.urdf:
        model = UrdfModel.from_file(args.urdf)
        cands = candidate_chains(model)
        if args.suggest_config:
            arms = {}
            for c in cands:
                if c["side"] and c["side"] not in arms:
                    arms[c["side"]] = {k: c[k] for k in ("base_link", "tip_link", "joint_names")}
                    arms[c["side"]].update(tcp_xyz=[0.0, 0.0, 0.0], tcp_rpy=[0.0, 0.0, 0.0])
            cfg = {
                "_comment": (
                    "DRAFT from inspect_urdf.py. Check: (1) joint_names are the URDF names in the "
                    "POLICY's order (left_joint_1..7 / right_joint_1..7); (2) tip_link is the frame "
                    "you want smoothed -- set tcp_xyz to move it to the fingertip / grasp point."
                ),
                "urdf": str(Path(args.urdf).expanduser().resolve()),
                "arms": arms,
            }
            print(json.dumps(cfg, indent=2))
            if len(arms) < 2:
                print(f"WARNING: found {len(arms)} arm(s) with a left/right name; fill the rest by hand. "
                      f"Candidates: {cands}", file=sys.stderr)
            return
        describe(model)
        print("\n7-revolute chains found:")
        for c in cands:
            print(f"  side={c['side']}  base={c['base_link']}  tip={c['tip_link']}\n    joints={c['joint_names']}")
        if not cands:
            print("  none -- pass base/tip links by hand in arm_config.json")
    if args.config and args.check_pose:
        pose = PICK_BOX_2_HOME if args.check_pose == "home" else [float(x) for x in args.check_pose.split(",")]
        if len(pose) != 16:
            raise SystemExit("--check-pose needs 16 values (left_arm 7, left_gripper, right_arm 7, right_gripper)")
        check_pose(args.config, pose)
    if args.config and args.dataset and args.fit_signs:
        fit_signs(args.config, args.dataset)
    elif args.config and args.dataset:
        check_dataset(args.config, args.dataset, args.dataset_stride)
    if not args.urdf and not (args.config and (args.check_pose or args.dataset)):
        ap.print_help()


if __name__ == "__main__":
    main()
