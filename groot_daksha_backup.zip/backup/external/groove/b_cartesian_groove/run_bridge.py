#!/usr/bin/env python3
"""OpenArm B1 ROS2 bridge + Cartesian GROOVE (option B, needs the URDF).

Takes every flag of gr00t/eval/real_robot/OPENARM_B1/eval_openarm_b1_ros2.py unchanged,
plus the --groove-* flags below. Normally launched through
run_system_b_cartesian_groove.sh.

  python external/groove/b_cartesian_groove/run_bridge.py <bridge flags> \
      --groove-arm-config external/groove/b_cartesian_groove/arm_config.json
"""

from __future__ import annotations

import argparse
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from b_cartesian_groove.cartesian_groove import (  # noqa: E402
    DEFAULT_EPS0,
    DEFAULT_EPS_GUARD,
    DEFAULT_EPS_GUARD_ROT,
    DEFAULT_EPS_ROT,
    build_from_args,
)
from groove_common.layout import select_arms  # noqa: E402
from groove_common.ros2_groove_bridge import (  # noqa: E402
    add_common_groove_args,
    env_default,
    load_base_bridge_module,
    run,
)

HERE = Path(__file__).resolve().parent


def add_cartesian_args(p) -> None:
    g = p.add_argument_group("GROOVE (Cartesian)")
    g.add_argument(
        "--groove-arm-config", default=env_default("GROOVE_ARM_CONFIG", str(HERE / "arm_config.json")),
        help="JSON with the URDF path and base/tip links per arm (see arm_config.example.json).",
    )
    g.add_argument("--groove-eps0", type=float, default=env_default("GROOVE_EPS0", DEFAULT_EPS0, float),
                   help="Reference cube half-width, m (paper-equivalent: 0.0075).")
    g.add_argument("--groove-eps-tight", type=float, default=env_default("GROOVE_EPS_TIGHT", 0.0, float),
                   help="Tight axis of a directional box, m. 0 = eps0/3 (paper ratio).")
    g.add_argument("--groove-eps-rot", type=float, default=env_default("GROOVE_EPS_ROT", DEFAULT_EPS_ROT, float),
                   help="Rotation half-width, rad (paper-equivalent: 0.075; see cartesian_groove.py UNITS).")
    g.add_argument("--groove-eps-guard", type=float,
                   default=env_default("GROOVE_EPS_GUARD", DEFAULT_EPS_GUARD, float),
                   help="Translation half-width inside the gripper-guard window, m.")
    g.add_argument("--groove-eps-guard-rot", type=float,
                   default=env_default("GROOVE_EPS_GUARD_ROT", DEFAULT_EPS_GUARD_ROT, float))
    g.add_argument("--groove-rho-b", type=float, default=env_default("GROOVE_RHO_B", 1.5, float),
                   help="A directional box may deviate at most rho_B x the reference's total.")
    g.add_argument("--groove-boxes", choices=["all", "reference"], default=env_default("GROOVE_BOXES", "all"),
                   help="all = 14 geometry-guided boxes (paper); reference = cube only (faster).")
    g.add_argument("--groove-max-joint-dev", type=float,
                   default=env_default("GROOVE_MAX_JOINT_DEV", 0.05, float),
                   help="Send the raw chunk if IK moves any joint further than this from the policy, rad.")
    g.add_argument("--groove-smooth-rot", action=argparse.BooleanOptionalAction,
                   default=env_default("GROOVE_SMOOTH_ROT", True, bool),
                   help="--no-groove-smooth-rot = regulate TCP position only, keep policy orientation.")
    g.add_argument("--groove-fallback", choices=["joint", "raw"], default=env_default("GROOVE_FALLBACK", "joint"),
                   help="What a rejected arm gets: joint-space GROOVE (default) or the raw chunk (paper).")
    g.add_argument("--groove-fallback-eps", default=env_default("GROOVE_FALLBACK_EPS", "0.01"),
                   help="eps (rad) for the joint GROOVE fallback, as a_joint_groove --groove-eps.")
    g.add_argument("--groove-max-joint-jerk-ratio", type=float,
                   default=env_default("GROOVE_MAX_JOINT_JERK_RATIO", 2.0, float),
                   help="Send the raw chunk if joint-space jerk grows by more than this factor.")


def main() -> None:
    base = load_base_bridge_module()
    p = base.build_arg_parser()
    add_common_groove_args(p)
    add_cartesian_args(p)
    args = p.parse_args()
    arms = select_arms([a.strip() for a in args.groove_arms.split(",") if a.strip()])
    regulator = None
    if args.groove:
        if not Path(args.groove_arm_config).expanduser().is_file():
            raise SystemExit(
                f"--groove-arm-config {args.groove_arm_config} not found. Copy "
                f"{HERE / 'arm_config.example.json'} to arm_config.json and fill in the URDF path "
                "and links (python external/groove/b_cartesian_groove/inspect_urdf.py --urdf X "
                "--suggest-config prints a draft)."
            )
        regulator = build_from_args(args, arms)
    run(base, args, regulator, "cartesian")


if __name__ == "__main__":
    main()
