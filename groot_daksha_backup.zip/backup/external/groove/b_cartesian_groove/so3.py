"""Batched SO(3) helpers (numpy only). All functions accept leading batch dims."""

from __future__ import annotations

import numpy as np


def hat(w: np.ndarray) -> np.ndarray:
    w = np.asarray(w, dtype=np.float64)
    z = np.zeros(w.shape[:-1])
    return np.stack(
        [
            np.stack([z, -w[..., 2], w[..., 1]], -1),
            np.stack([w[..., 2], z, -w[..., 0]], -1),
            np.stack([-w[..., 1], w[..., 0], z], -1),
        ],
        -2,
    )


def exp(w: np.ndarray) -> np.ndarray:
    """Rotation vector (..., 3) -> rotation matrix (..., 3, 3), Rodrigues."""
    w = np.asarray(w, dtype=np.float64)
    th = np.linalg.norm(w, axis=-1)[..., None, None]
    K = hat(w)
    small = th < 1e-8
    th_safe = np.where(small, 1.0, th)
    a = np.where(small, 1.0 - th**2 / 6.0, np.sin(th_safe) / th_safe)
    b = np.where(small, 0.5 - th**2 / 24.0, (1.0 - np.cos(th_safe)) / th_safe**2)
    return np.eye(3) + a * K + b * (K @ K)


def log(R: np.ndarray) -> np.ndarray:
    """Rotation matrix (..., 3, 3) -> rotation vector (..., 3), robust near 0 and pi."""
    R = np.asarray(R, dtype=np.float64)
    tr = np.trace(R, axis1=-2, axis2=-1)
    cos = np.clip((tr - 1.0) / 2.0, -1.0, 1.0)
    th = np.arccos(cos)
    vee = np.stack(
        [R[..., 2, 1] - R[..., 1, 2], R[..., 0, 2] - R[..., 2, 0], R[..., 1, 0] - R[..., 0, 1]], -1
    )
    sin = np.sin(th)
    small = th < 1e-6
    near_pi = th > np.pi - 1e-4
    scale = np.where(small, 0.5 + th**2 / 12.0, th / (2.0 * np.where(small, 1.0, sin)))
    w = scale[..., None] * vee
    if np.any(near_pi):
        # R ~ 2nn' - I: take the best-conditioned column of (R + I) / 2 as the axis.
        B = (R[near_pi] + np.eye(3)) / 2.0
        diag = np.diagonal(B, axis1=-2, axis2=-1)
        k = np.argmax(diag, axis=-1)
        n = B[np.arange(B.shape[0]), :, k] / np.sqrt(np.maximum(diag[np.arange(B.shape[0]), k], 1e-12))[:, None]
        # Fix the sign from the (small) antisymmetric part when available.
        s = np.sign(np.sum(n * vee[near_pi], axis=-1))
        s = np.where(s == 0, 1.0, s)
        w[near_pi] = (s * th[near_pi])[:, None] * n
    return w


def rpy_to_matrix(rpy: np.ndarray) -> np.ndarray:
    """URDF convention: R = Rz(yaw) @ Ry(pitch) @ Rx(roll)."""
    r, p, y = np.asarray(rpy, dtype=np.float64)
    cr, sr, cp, sp, cy, sy = np.cos(r), np.sin(r), np.cos(p), np.sin(p), np.cos(y), np.sin(y)
    return np.array(
        [
            [cy * cp, cy * sp * sr - sy * cr, cy * sp * cr + sy * sr],
            [sy * cp, sy * sp * sr + cy * cr, sy * sp * cr - cy * sr],
            [-sp, cp * sr, cp * cr],
        ]
    )


def make_T(R: np.ndarray, p: np.ndarray) -> np.ndarray:
    T = np.zeros(np.broadcast_shapes(R.shape[:-2], p.shape[:-1]) + (4, 4))
    T[..., :3, :3] = R
    T[..., :3, 3] = p
    T[..., 3, 3] = 1.0
    return T
