"""Minimal URDF kinematics: parse, forward kinematics, Jacobian, batched IK.

Numpy only, so it runs in the existing .venv with nothing new installed. Meshes,
inertias and collision geometry are ignored -- only <joint> origins, axes, types and
limits matter here. `.urdf.xacro` files are expanded with the ROS `xacro` module when
it is importable (source /opt/ros/humble/setup.bash first); otherwise convert once:

    xacro openarm.urdf.xacro > openarm.urdf
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import xml.etree.ElementTree as ET

import numpy as np

from . import so3

ACTUATED = ("revolute", "continuous", "prismatic")


def _cross(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """np.cross for (..., 3) without its moveaxis overhead (hot path in the IK)."""
    return np.stack(
        [a[..., 1] * b[..., 2] - a[..., 2] * b[..., 1],
         a[..., 2] * b[..., 0] - a[..., 0] * b[..., 2],
         a[..., 0] * b[..., 1] - a[..., 1] * b[..., 0]],
        axis=-1,
    )


@dataclass
class UrdfJoint:
    name: str
    type: str
    parent: str
    child: str
    origin: np.ndarray  # (4, 4) parent -> joint frame
    axis: np.ndarray  # (3,) in the joint frame
    lower: float
    upper: float


def load_urdf_text(path: str | Path) -> str:
    path = Path(path).expanduser()
    if path.suffix == ".xacro" or path.name.endswith(".urdf.xacro"):
        try:
            import xacro  # type: ignore
        except ImportError as exc:
            raise RuntimeError(
                f"{path} is a xacro file and the xacro module is not importable. Either "
                "`source /opt/ros/humble/setup.bash` first, or convert it once with "
                f"`xacro {path} > {path.with_suffix('')}` and pass the .urdf."
            ) from exc
        return xacro.process_file(str(path)).toxml()
    return path.read_text()


class UrdfModel:
    def __init__(self, xml_text: str):
        root = ET.fromstring(xml_text)
        if root.tag != "robot":
            raise ValueError("not a URDF: root element is not <robot>")
        self.name = root.get("name", "")
        self.links = [l.get("name") for l in root.findall("link")]
        self.joints: dict[str, UrdfJoint] = {}
        self.joint_by_child: dict[str, UrdfJoint] = {}
        for j in root.findall("joint"):
            jt = j.get("type")
            o = j.find("origin")
            xyz = np.fromstring(o.get("xyz", "0 0 0"), sep=" ") if o is not None else np.zeros(3)
            rpy = np.fromstring(o.get("rpy", "0 0 0"), sep=" ") if o is not None else np.zeros(3)
            a = j.find("axis")
            axis = np.fromstring(a.get("xyz", "1 0 0"), sep=" ") if a is not None else np.array([1.0, 0, 0])
            n = np.linalg.norm(axis)
            axis = axis / n if n > 0 else np.array([1.0, 0, 0])
            lim = j.find("limit")
            if jt == "continuous" or lim is None:
                lower, upper = -np.inf, np.inf
            else:
                lower = float(lim.get("lower", "-inf"))
                upper = float(lim.get("upper", "inf"))
            joint = UrdfJoint(
                name=j.get("name"),
                type=jt,
                parent=j.find("parent").get("link"),
                child=j.find("child").get("link"),
                origin=so3.make_T(so3.rpy_to_matrix(rpy), xyz),
                axis=axis,
                lower=lower,
                upper=upper,
            )
            self.joints[joint.name] = joint
            self.joint_by_child[joint.child] = joint

    @classmethod
    def from_file(cls, path: str | Path) -> "UrdfModel":
        return cls(load_urdf_text(path))

    def root_links(self) -> list[str]:
        return [l for l in self.links if l not in self.joint_by_child]

    def leaf_links(self) -> list[str]:
        parents = {j.parent for j in self.joints.values()}
        return [l for l in self.links if l not in parents]

    def path(self, base: str, tip: str) -> list[UrdfJoint]:
        """Joints from base to tip, in order. Raises if tip is not below base."""
        for name in (base, tip):
            if name not in self.links:
                raise ValueError(f"link {name!r} not in URDF (have {len(self.links)} links)")
        chain = []
        link = tip
        while link != base:
            j = self.joint_by_child.get(link)
            if j is None:
                raise ValueError(f"{tip!r} is not a descendant of {base!r}")
            chain.append(j)
            link = j.parent
        return chain[::-1]

    def chain(self, base: str, tip: str, tcp: np.ndarray | None = None) -> "KinematicChain":
        return KinematicChain(self.path(base, tip), tcp)


class KinematicChain:
    """Serial chain base -> tip (+ optional fixed TCP offset). q is in chain order."""

    def __init__(self, joints: list[UrdfJoint], tcp: np.ndarray | None = None):
        self.elements = joints
        self.tcp = np.eye(4) if tcp is None else np.asarray(tcp, dtype=np.float64)
        act = [j for j in joints if j.type in ACTUATED]
        self.joint_names = [j.name for j in act]
        self.n = len(act)
        self.lower = np.array([j.lower for j in act])
        self.upper = np.array([j.upper for j in act])
        for j in joints:
            if j.type not in ACTUATED + ("fixed",):
                raise ValueError(f"joint {j.name!r}: unsupported type {j.type!r} in a serial chain")
        self._compile()

    def _compile(self) -> None:
        """Fold fixed transforms together and precompute each axis' skew matrices.

        FK runs a few dozen times per chunk inside the 30 Hz control tick, so it works
        on (R, p) directly instead of composing generic 4x4 matrices.
        """
        steps = []  # (R_const, p_const, kind, axis, K, K2) per actuated joint
        Rc, pc = np.eye(3), np.zeros(3)
        for j in self.elements:
            Ro, po = j.origin[:3, :3], j.origin[:3, 3]
            pc, Rc = pc + Rc @ po, Rc @ Ro
            if j.type == "fixed":
                continue
            K = so3.hat(j.axis)
            steps.append((Rc, pc, j.type, j.axis.copy(), K, K @ K))
            Rc, pc = np.eye(3), np.zeros(3)
        Rt, pt = self.tcp[:3, :3], self.tcp[:3, 3]
        self._steps = steps
        self._tail = (Rc @ Rt, pc + Rc @ pt)

    def fk(self, q: np.ndarray) -> np.ndarray:
        return self._fk(q, need_jac=False)[0]

    def fk_jacobian(self, q: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """(T (B,4,4), J (B,6,n)); J = [linear; angular] of the TCP in the base frame."""
        return self._fk(q, need_jac=True)

    def _fk(self, q, need_jac):
        q = np.atleast_2d(np.asarray(q, dtype=np.float64))
        B = q.shape[0]
        if q.shape[1] != self.n:
            raise ValueError(f"expected {self.n} joint values, got {q.shape[1]}")
        R = np.broadcast_to(np.eye(3), (B, 3, 3))
        p = np.zeros((B, 3))
        zs, os_ = [], []
        for i, (Rc, pc, kind, axis, K, K2) in enumerate(self._steps):
            p = p + R @ pc
            R = R @ Rc
            z = R @ axis
            if need_jac:
                zs.append(z)
                os_.append(p)
            qi = q[:, i]
            if kind == "prismatic":
                p = p + z * qi[:, None]
            else:
                s, c = np.sin(qi)[:, None, None], np.cos(qi)[:, None, None]
                R = R @ (np.eye(3) + s * K + (1.0 - c) * K2)
        Rt, pt = self._tail
        p = p + R @ pt
        R = R @ Rt
        T = so3.make_T(R, p)
        if not need_jac:
            return T, None
        J = np.zeros((B, 6, self.n))
        for k, (z, o, step) in enumerate(zip(zs, os_, self._steps)):
            if step[2] == "prismatic":
                J[:, :3, k] = z
            else:
                J[:, :3, k] = _cross(z, p - o)
                J[:, 3:, k] = z
        return T, J

    def ik(
        self,
        T_target: np.ndarray,
        q_seed: np.ndarray,
        q_nominal: np.ndarray | None = None,
        max_iter: int = 15,
        pos_tol: float = 1e-4,
        rot_tol: float = 1e-3,
        damping: float = 1e-3,
        sing_threshold: float = 0.05,
        sing_damping: float = 0.05,
        nullspace_gain: float = 0.2,
        max_step: float = 0.2,
        lower: np.ndarray | None = None,
        upper: np.ndarray | None = None,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """Batched, singularity-robust damped-least-squares IK.

        Damping grows smoothly from `damping` to `sing_damping` as the smallest singular
        value of J drops below `sing_threshold` (Nakamura / Chiaverini). Near a
        singularity -- e.g. an arm stretched straight at its zero pose -- an exact small
        Cartesian correction would need a large joint motion; the damped step instead
        gives up a little of the correction along the singular direction. The caller
        checks the remaining error and the joint deviation and falls back to the raw
        chunk if either is too large.

        The secondary task pulls the redundant (7-DoF) self-motion toward q_nominal --
        here the policy's own joint chunk, so the arm keeps the elbow posture the
        policy chose instead of drifting to whatever IK happens to find.

        lower / upper override the URDF joint limits (scalar per joint or per batch row).

        Returns (q, pos_err [m], rot_err [rad], converged to pos_tol/rot_tol).
        """
        T_target = np.asarray(T_target, dtype=np.float64).reshape(-1, 4, 4)
        q = np.atleast_2d(np.asarray(q_seed, dtype=np.float64)).copy()
        q_nom = q.copy() if q_nominal is None else np.atleast_2d(np.asarray(q_nominal, dtype=np.float64))
        B, n = q.shape
        eye6, eyen = np.eye(6), np.eye(n)
        lo = np.broadcast_to(self.lower if lower is None else lower, (B, n))
        hi = np.broadcast_to(self.upper if upper is None else upper, (B, n))

        def errors(qq):
            T, J = self.fk_jacobian(qq)
            ep = T_target[:, :3, 3] - T[:, :3, 3]
            er = so3.log(T_target[:, :3, :3] @ np.swapaxes(T[:, :3, :3], -1, -2))
            return ep, er, J

        ep, er, J = errors(q)
        # Newton converges quadratically where J is well conditioned. Where it is not,
        # the damped step deliberately makes little progress; stop those entries as soon
        # as an iteration buys less than 20%, instead of spinning to max_iter.
        stalled = np.zeros(B, dtype=bool)
        err = np.linalg.norm(ep, axis=1) + 0.1 * np.linalg.norm(er, axis=1)
        for _ in range(max_iter):
            pe, re = np.linalg.norm(ep, axis=1), np.linalg.norm(er, axis=1)
            active = ((pe > pos_tol) | (re > rot_tol)) & ~stalled
            if not active.any():
                break
            Ja = J[active]
            e = np.concatenate([ep[active], er[active]], axis=1)
            smin = np.linalg.svd(Ja, compute_uv=False)[:, -1]
            ratio = np.clip(smin / sing_threshold, 0.0, 1.0)
            lam2 = damping**2 + (sing_damping**2) * (1.0 - ratio**2)
            JJt = Ja @ np.swapaxes(Ja, -1, -2) + lam2[:, None, None] * eye6
            Jpinv = np.swapaxes(Ja, -1, -2) @ np.linalg.inv(JJt)
            dq = (Jpinv @ e[..., None])[..., 0]
            null = eyen - Jpinv @ Ja
            dq += (null @ (nullspace_gain * (q_nom[active] - q[active]))[..., None])[..., 0]
            dq = np.clip(dq, -max_step, max_step)
            q[active] = np.clip(q[active] + dq, lo[active], hi[active])
            ep, er, J = errors(q)
            new_err = np.linalg.norm(ep, axis=1) + 0.1 * np.linalg.norm(er, axis=1)
            stalled |= active & (new_err > 0.8 * err)
            err = new_err
        pe, re = np.linalg.norm(ep, axis=1), np.linalg.norm(er, axis=1)
        return q, pe, re, (pe <= pos_tol) & (re <= rot_tol)
