#!/usr/bin/env python3
"""Integration test: the GROOVE subclass on the REAL bridge module, fake policy and robot.

SAFETY: it forces an isolated ROS 2 domain (ROS_DOMAIN_ID=199, ROS_LOCALHOST_ONLY=1)
and publishes on a private topic (/groove_selftest/joint_cmd), so it cannot command a
robot even when run on the robot machine. It never spins; control ticks are called
by hand.

    source /opt/ros/humble/setup.bash
    .venv/bin/python external/groove/tests/test_bridge_integration.py

Skips (exit 0) when rclpy is not importable.
"""

from __future__ import annotations

import os

os.environ["ROS_DOMAIN_ID"] = "199"
os.environ["ROS_LOCALHOST_ONLY"] = "1"

from pathlib import Path  # noqa: E402
import sys  # noqa: E402
import tempfile  # noqa: E402

import numpy as np  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

try:
    import rclpy  # noqa: F401
    from sensor_msgs.msg import JointState
except ImportError:
    print("SKIP: rclpy not importable (source /opt/ros/humble/setup.bash first)")
    sys.exit(0)

from a_joint_groove.joint_groove import JointGroove, parse_eps  # noqa: E402
from b_cartesian_groove.cartesian_groove import (  # noqa: E402
    CartesianArmGroove,
    CartesianGroove,
    load_arm_kinematics,
)
from groove_common.gripper_guard import GuardConfig  # noqa: E402
from groove_common.layout import OPENARM_B1_ARMS  # noqa: E402
from groove_common.ros2_groove_bridge import (  # noqa: E402
    add_common_groove_args,
    load_base_bridge_module,
    make_groove_bridge_class,
)

H = 8
HOME = np.array(
    [-0.00019, -0.16785, -0.05436, 0.00286, 0.00324, -0.00153, 0.07572, -0.04393,
     -0.59911, -0.02213, 0.02041, 1.68326, 1.43053, -0.03586, 0.69848, 0.04376]
)


class FakePolicy:
    """Smooth reach + per-chunk offset + per-step noise: what a diffusion head looks like."""

    def __init__(self, seed: int = 0):
        self.rng = np.random.default_rng(seed)
        self.calls = 0

    def ping(self):
        return True

    def get_action(self, obs):
        self.calls += 1
        st = {k: np.asarray(v).reshape(-1) for k, v in obs["state"].items()}
        vel = 0.01 * np.sin(0.3 * self.calls + np.arange(7))  # rad/step
        out = {}
        for side in ("left", "right"):
            steps = np.arange(1, H + 1)[:, None]
            arm = (st[f"{side}_arm"] + vel * steps
                   + self.rng.normal(0, 0.004, (1, 7)) + self.rng.normal(0, 0.002, (H, 7)))
            grip = np.full((H, 1), st[f"{side}_gripper"][0])
            out[f"{side}_arm"] = arm[None]
            out[f"{side}_gripper"] = grip[None]
        return out, {}


def make_args(base, extra):
    p = base.build_arg_parser()
    add_common_groove_args(p)
    p.add_argument("--groove-eps", default="0.01")
    p.add_argument("--groove-eps-guard", type=float, default=0.001)
    wide_lo = ",".join(["-3.0"] * 16)
    wide_hi = ",".join(["3.0"] * 16)
    return p.parse_args(
        ["--no-verify-server", "--cmd-topic", "/groove_selftest/joint_cmd",
         "--input-timeout-s", "0", "--watchdog-timeout-s", "1000",
         f"--joint-min-csv={wide_lo}", f"--joint-max-csv={wide_hi}",
         "--max-step-delta-csv=" + ",".join(["0.5"] * 16),
         "--start-pose-min-csv=", "--start-pose-max-csv="] + extra
    )


def simulate(base, args, regulator, method, ticks=120):
    base.PolicyClient = lambda **kw: FakePolicy(seed=0)  # patch the module-level import
    Cls = make_groove_bridge_class(base)
    node = Cls(args, regulator, method)
    published = []
    orig = node.cmd_pub._on_publish

    def spy(msg):
        orig(msg)
        published.append(np.array(msg.position, dtype=np.float64))

    node.cmd_pub._on_publish = spy
    q = HOME.copy()
    img = np.zeros((240, 320, 3), dtype=np.uint8)
    for _ in range(ticks):
        js = JointState()
        js.name = list(node.state_obs_keys)
        js.position = [float(v) for v in q]
        node._joint_cb(js)
        now = __import__("time").monotonic()
        for k in node.camera_keys:
            node.latest_images[k] = img
            node.image_stamps[k] = now
        node._control_step()
        if node.pending_plan_future is not None:
            node.pending_plan_future.result()  # deterministic: let inference land next tick
        if published:
            q = published[-1].copy()  # perfect tracking
    log_path = node._groove_log.path if node._groove_log else None
    node.destroy_node()
    return np.array(published), log_path


def arm_jerk(cmds):
    arms = np.r_[0:7, 8:15]
    return float(np.sqrt(np.mean(np.diff(cmds[:, arms], n=3, axis=0) ** 2)))


def tcp_jerk(cmds, kins):
    """RMS TCP jerk over both arms (synthetic fixture kinematics), m/step^3."""
    js = []
    for a in OPENARM_B1_ARMS:
        p = kins[a.name].poses(cmds[:, a.arm])[:, :3, 3]
        js.append(np.sum(np.diff(p, n=3, axis=0) ** 2, axis=1))
    return float(np.sqrt(np.mean(np.concatenate(js))))


def main():
    base = load_base_bridge_module()
    rclpy.init()
    try:
        results = {}
        with tempfile.TemporaryDirectory() as tmp:
            for replan_at in ("0", "4"):
                args = make_args(base, ["--replan-at", replan_at, "--groove-log-dir", tmp])
                raw_cmds, _ = simulate(base, args, None, "raw")
                args = make_args(base, ["--replan-at", replan_at, "--groove-log-dir", tmp])
                jg = JointGroove(eps=parse_eps("0.01"), guard=GuardConfig())
                jcmds, jlog = simulate(base, args, jg, "joint")
                kins = load_arm_kinematics(ROOT / "tests/fixtures/synthetic_arm_config.json", ["left", "right"])
                cg = CartesianGroove(
                    arms=[(a, CartesianArmGroove(kin=kins[a.name])) for a in OPENARM_B1_ARMS],
                    fallback=JointGroove(eps=parse_eps("0.01"), arms=()),
                )
                args = make_args(base, ["--replan-at", replan_at, "--groove-log-dir", tmp])
                ccmds, clog = simulate(base, args, cg, "cartesian")
                results[replan_at] = [(arm_jerk(c), tcp_jerk(c, kins)) for c in (raw_cmds, jcmds, ccmds)]
                for path in (jlog, clog):
                    d = np.load(path)
                    assert d["chunk_raw"].shape[1:] == (H, 16), d["chunk_raw"].shape
                    assert d["pub_cmd"].shape[1] == 16 and len(d["pub_cmd"]) > 50
                    dev = np.nanmax(np.abs(d["chunk_out"] - d["chunk_raw"])[..., np.r_[0:7, 8:15]])
                    assert np.all(d["chunk_out"][..., [7, 15]] == d["chunk_raw"][..., [7, 15]]), "grippers changed"
                    if "joint" in path.name:
                        assert dev <= 0.01 + 1e-9, dev
    finally:
        rclpy.shutdown()
    for ra, ((rj, rt), (jj, jt), (cj, ct)) in results.items():
        print(f"replan_at={ra}: delivered JOINT jerk raw {rj:.2e} | A joint {jj:.2e} ({100*(jj/rj-1):+.0f}%)"
              f" | B cartesian {cj:.2e} ({100*(cj/rj-1):+.0f}%)")
        print(f"             delivered TCP jerk   raw {rt:.2e} | A joint {jt:.2e} ({100*(jt/rt-1):+.0f}%)"
              f" | B cartesian {ct:.2e} ({100*(ct/rt-1):+.0f}%)")
        assert jj < rj, "joint GROOVE must lower delivered joint jerk"
        assert ct < rt, "Cartesian GROOVE must lower delivered TCP jerk"
    print("OK")


if __name__ == "__main__":
    main()
