#!/usr/bin/env bash
# All GROOVE tests. Safe on the robot machine: the bridge test forces ROS_DOMAIN_ID=199,
# ROS_LOCALHOST_ONLY=1 and a private command topic.
#   bash external/groove/tests/run_all.sh
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$HERE/../../.." && pwd)"
PY="$REPO_ROOT/.venv/bin/python"
status=0

echo "== unit tests"
"$PY" "$HERE/test_core.py" || status=1

echo; echo "== launcher"
bash "$HERE/test_launcher.sh" || status=1

echo; echo "== bridge integration (real bridge module, fake policy + robot)"
if [ -z "${AMENT_PREFIX_PATH:-}" ] && [ -f /opt/ros/humble/setup.bash ]; then
  set +u; source /opt/ros/humble/setup.bash; set -u
fi
# FastDDS prints a harmless transport warning per node under ROS_LOCALHOST_ONLY=1.
"$PY" "$HERE/test_bridge_integration.py" 2>&1 \
  | grep -vE "TRANSPORT|whitelist|^\[INFO\]|^\[WARN\]" ; [ "${PIPESTATUS[0]}" -eq 0 ] || status=1

echo; [ $status -eq 0 ] && echo "ALL PASSED" || echo "SOME TESTS FAILED"
exit $status
