#!/usr/bin/env python3
"""Unit tests for groove_common, a_joint_groove and b_cartesian_groove. No ROS, no GPU.

    .venv/bin/python external/groove/tests/test_core.py        # plain runner
    .venv/bin/python -m pytest external/groove/tests/          # if pytest is installed
"""

from __future__ import annotations

from pathlib import Path
import sys
import traceback

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from a_joint_groove.joint_groove import JointGroove, parse_eps  # noqa: E402
from b_cartesian_groove import so3  # noqa: E402
from b_cartesian_groove.cartesian_groove import (  # noqa: E402
    ArmKinematics,
    CartesianArmGroove,
    CartesianGroove,
    CartesianGrooveCore,
    box_frames,
    load_arm_kinematics,
)
from b_cartesian_groove.urdf_kinematics import UrdfModel  # noqa: E402
from groove_common.box_qp import _operators, _residual_offsets, jerk_objective, solve_jerk_qp  # noqa: E402
from groove_common.gripper_guard import GuardConfig, guard_mask  # noqa: E402
from groove_common.jerk import jerk_cost  # noqa: E402
from groove_common.layout import OPENARM_B1_ARMS, select_arms  # noqa: E402

FIX = ROOT / "tests" / "fixtures"
RNG = np.random.default_rng(0)


def _policy_like(N, H, scale=0.02):
    t = np.arange(H + 3)[None, :] / 30.0
    sig = 0.3 * np.sin(2 * np.pi * 0.3 * t + RNG.uniform(0, 6, (N, 1))) + 1.2
    target = sig[:, 3:] + RNG.normal(0, scale / 5, (N, 1)) + RNG.normal(0, scale / 10, (N, H))
    return target, sig[:, :3]


def _kkt(x, target, past, eps, lam):
    H = x.shape[1]
    M, P, _ = _operators(H, lam)
    o = past[:, 2:3]
    q = _residual_offsets(past - o, H, lam) @ M
    xc, lo, hi = x - o, target - o - eps, target - o + eps
    g = xc @ P.T + q
    atlo, athi = np.isclose(xc, lo, atol=1e-12), np.isclose(xc, hi, atol=1e-12)
    free = ~(atlo | athi)
    v = np.abs(np.where(free, g, 0)) + np.where(atlo, np.maximum(-g, 0), 0) + np.where(athi, np.maximum(g, 0), 0)
    return float(v.max() / (1 + np.abs(q).max()))


# ------------------------------------------------------------------ box QP
def test_qp_optimal_and_feasible():
    for H in (8, 16):
        for lam in (0.0, 1e-9, 1e-4):
            target, past = _policy_like(40, H)
            eps = RNG.uniform(1e-4, 0.02, target.shape)
            x = solve_jerk_qp(target, past, eps, lam)
            assert np.all(np.abs(x - target) <= eps + 1e-12)
            assert _kkt(x, target, past, eps, lam) < 1e-9
            assert np.all(jerk_objective(x, past, lam) <= jerk_objective(target, past, lam) + 1e-15)


def test_qp_shift_invariant():
    target, past = _policy_like(10, 8)
    a = solve_jerk_qp(target, past, 0.005)
    b = solve_jerk_qp(target + 2.0, past + 2.0, 0.005)
    assert np.allclose(a + 2.0, b, atol=1e-10)


def test_qp_rejects_nonpositive_eps():
    target, past = _policy_like(2, 8)
    try:
        solve_jerk_qp(target, past, 0.0)
    except ValueError:
        return
    raise AssertionError("eps = 0 must raise")


def test_jerk_cost_matches_objective():
    target, past = _policy_like(5, 8)
    for n in range(5):
        assert np.isclose(jerk_cost(target[n][:, None], past[n][:, None]), jerk_objective(target[n : n + 1], past[n : n + 1])[0])


# ------------------------------------------------------------------ guard
def test_guard_mask():
    cfg = GuardConfig(window=2, step_thresh=0.005, jump_thresh=0.012)
    flat = np.full(8, 0.044)
    assert not guard_mask(flat, np.full(3, 0.044), cfg).any()
    closing = flat.copy()
    closing[5:] = 0.030  # 0.014 step inside the chunk at t = 5
    assert guard_mask(closing, np.full(3, 0.044), cfg).tolist() == [False, False, False, True, True, True, True, True]
    # A boundary jump below jump_thresh is resampling noise, not a transition.
    assert not guard_mask(flat + 0.008, np.full(3, 0.044), cfg).any()
    assert guard_mask(flat + 0.02, np.full(3, 0.044), cfg)[:3].all()
    assert not guard_mask(closing, np.full(3, 0.044), GuardConfig(enabled=False)).any()


# ------------------------------------------------------------------ joint GROOVE
def _chunk16(H=8):
    raw, hist = np.zeros((H, 16)), np.zeros((3, 16))
    for a in OPENARM_B1_ARMS:
        t, p = _policy_like(7, H)
        raw[:, a.arm], hist[:, a.arm] = t.T, p.T
        raw[:, a.gripper] = hist[:, a.gripper] = 0.044
    return raw, hist


def test_parse_eps():
    assert np.all(parse_eps("0.01") == 0.01)
    e = parse_eps(",".join(["0.1"] * 7 + ["0.2"] * 7))
    assert e[0] == 0.1 and e[8] == 0.2 and e.shape == (16,)
    assert parse_eps(",".join(["0.3"] * 16)).shape == (16,)


def test_joint_groove_basic():
    raw, hist = _chunk16()
    out, info = JointGroove(eps=parse_eps("0.01")).regulate(raw, hist)
    assert np.all(out[:, [7, 15]] == raw[:, [7, 15]]), "grippers must pass through"
    assert np.abs(out - raw).max() <= 0.01 + 1e-12
    for a in OPENARM_B1_ARMS:
        assert jerk_cost(out[:, a.arm], hist[:, a.arm]) < jerk_cost(raw[:, a.arm], hist[:, a.arm])
        assert info["arms"][a.name]["accepted"]


def test_joint_groove_single_arm_and_guard():
    raw, hist = _chunk16()
    out, _ = JointGroove(arms=select_arms(["right"])).regulate(raw, hist)
    assert np.all(out[:, 0:8] == raw[:, 0:8]), "left arm must stay raw"
    raw[4:, 15] = 0.02  # right gripper closes mid-chunk -> guard pins the right arm
    out, info = JointGroove(guard=GuardConfig(window=8)).regulate(raw, hist)
    assert info["arms"]["right"]["guard_steps"] == 8
    assert np.abs(out[:, 8:15] - raw[:, 8:15]).max() <= 0.001 + 1e-12


# ------------------------------------------------------------------ kinematics
def _kins():
    return load_arm_kinematics(FIX / "synthetic_arm_config.json", ["left", "right"])


def test_so3_roundtrip():
    w = RNG.normal(0, 1, (50, 3))
    w *= np.minimum(1.0, 3.0 / np.linalg.norm(w, axis=1))[:, None]
    assert np.allclose(so3.log(so3.exp(w)), w, atol=1e-9)
    near_pi = np.array([[np.pi - 1e-6, 0, 0], [0, 0, np.pi - 1e-7]])
    assert np.allclose(so3.exp(so3.log(so3.exp(near_pi))), so3.exp(near_pi), atol=1e-6)


def test_jacobian_matches_finite_differences():
    ch = _kins()["right"].chain
    q = RNG.uniform(-1, 1, (4, 7))
    T, J = ch.fk_jacobian(q)
    h = 1e-6
    for i in range(7):
        dq = np.zeros(7)
        dq[i] = h
        T2 = ch.fk(q + dq)
        assert np.allclose((T2[:, :3, 3] - T[:, :3, 3]) / h, J[:, :3, i], atol=1e-5)
        dw = so3.log(T2[:, :3, :3] @ np.swapaxes(T[:, :3, :3], -1, -2)) / h
        assert np.allclose(dw, J[:, 3:, i], atol=1e-5)


def test_ik_roundtrip():
    ch = _kins()["left"].chain
    q = RNG.uniform(-1, 1, (8, 7)) + np.array([0, 0.6, 0, 1.3, 0, 0.9, 0])
    qs, pe, re, ok = ch.ik(ch.fk(q), q + RNG.normal(0, 0.02, q.shape), q, max_iter=30)
    assert ok.all() and pe.max() < 1e-4 and re.max() < 1e-3


def test_joint_name_permutation():
    model = UrdfModel.from_file(FIX / "synthetic_bimanual_7dof.urdf")
    chain = model.chain("world", "right_hand")
    shuffled = [chain.joint_names[i] for i in (3, 0, 6, 1, 5, 2, 4)]
    kin = ArmKinematics(chain, shuffled)
    q_policy = RNG.uniform(-1, 1, (2, 7))
    q_chain = kin.to_chain(q_policy)
    for c, name in enumerate(chain.joint_names):
        assert np.allclose(q_chain[:, c], q_policy[:, shuffled.index(name)])
    assert np.allclose(kin.to_policy(q_chain, q_policy), q_policy)
    try:
        ArmKinematics(chain, shuffled[:6] + ["nope"])
    except ValueError:
        return
    raise AssertionError("unknown joint name must raise")


# ------------------------------------------------------------------ Cartesian GROOVE
def test_box_frames():
    frames = box_frames(0.005, 0.005 / 3)
    assert len(frames) == 14 and frames[0][0] == "cube"
    for _, Q, eta in frames:
        assert np.allclose(Q.T @ Q, np.eye(3), atol=1e-12)
        assert np.isclose(np.prod(eta), 0.005**3)
    assert len(box_frames(0.005, 0.001, "reference")) == 1


def test_core_respects_boxes_and_beats_reference():
    H = 8
    r = np.concatenate([RNG.normal(0.004, 0.0015, (H, 3)), RNG.normal(0, 0.004, (H, 3))], axis=1)
    h = np.concatenate([np.full((2, 3), 0.004), np.zeros((2, 3))], axis=1)
    core = CartesianGrooveCore()
    u, info = core.regulate(r, h, np.zeros(H, bool))
    name = info["box"]
    Q, eta = next((Q, e) for n, Q, e in core.frames if n == name)
    e = np.cumsum(u[:, :3] - r[:, :3], axis=0) @ Q
    assert np.all(np.abs(e) <= eta + 1e-12)
    assert np.all(np.abs(np.cumsum(u[:, 3:] - r[:, 3:], axis=0)) <= core.eps_rot + 1e-12)
    ref, _ = CartesianGrooveCore(boxes="reference").regulate(r, h, np.zeros(H, bool))
    past = np.stack([-(h[0, :3] + h[1, :3]), -h[1, :3], np.zeros(3)])
    assert jerk_cost(np.cumsum(u[:, :3], 0), past) <= jerk_cost(np.cumsum(ref[:, :3], 0), past) + 1e-15
    keep_rot, _ = CartesianGrooveCore(smooth_rot=False).regulate(r, h, np.zeros(H, bool))
    assert np.allclose(keep_rot[:, 3:], r[:, 3:])


def _bent_chunk(H=8):
    raw, hist = np.zeros((H, 16)), np.zeros((3, 16))
    pose = {"left": [0.2, 0.6, 0.1, 1.3, 0.2, 0.9, 0.1], "right": [-0.3, 0.5, -0.2, 1.4, -0.1, 1.0, 0.3]}
    for a in OPENARM_B1_ARMS:
        steps = np.arange(-2, H + 1)[:, None] * 0.01
        traj = np.array(pose[a.name]) + steps * np.linspace(0.5, 1.0, 7)
        hist[:, a.arm] = traj[:3]
        raw[:, a.arm] = traj[3:] + RNG.normal(0, 0.004, (1, 7)) + RNG.normal(0, 0.002, (H, 7))
        raw[:, a.gripper] = hist[:, a.gripper] = 0.044
    return raw, hist


def test_cartesian_groove_end_to_end():
    kins = _kins()
    raw, hist = _bent_chunk()
    reg = CartesianGroove(arms=[(a, CartesianArmGroove(kin=kins[a.name])) for a in OPENARM_B1_ARMS],
                          fallback=JointGroove(arms=()))
    out, info = reg.regulate(raw, hist)
    assert np.all(out[:, [7, 15]] == raw[:, [7, 15]])
    for a in OPENARM_B1_ARMS:
        ai = info["arms"][a.name]
        assert ai["accepted"], ai
        if not ai.get("via_joint_fallback"):
            p_raw = kins[a.name].poses(np.vstack([hist[:, a.arm], raw[:, a.arm]]))[:, :3, 3]
            p_out = kins[a.name].poses(np.vstack([hist[:, a.arm], out[:, a.arm]]))[:, :3, 3]
            assert jerk_cost(p_out[3:], p_out[:3]) < jerk_cost(p_raw[3:], p_raw[:3])


def test_cartesian_rejection_uses_fallback():
    kins = _kins()
    raw, hist = _bent_chunk()
    strict = [(a, CartesianArmGroove(kin=kins[a.name], max_joint_dev=1e-9)) for a in OPENARM_B1_ARMS]
    out, info = CartesianGroove(arms=strict, fallback=JointGroove(arms=())).regulate(raw, hist)
    joint_only, _ = JointGroove().regulate(raw, hist)
    assert all(a["via_joint_fallback"] for a in info["arms"].values())
    assert np.allclose(out, joint_only)
    out_raw, info_raw = CartesianGroove(arms=strict, fallback=None).regulate(raw, hist)
    assert np.allclose(out_raw, raw) and not any(a["accepted"] for a in info_raw["arms"].values())


# ------------------------------------------------------------------ runner
def main() -> int:
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    failed = 0
    for name, fn in tests:
        try:
            fn()
            print(f"PASS  {name}")
        except Exception:
            failed += 1
            print(f"FAIL  {name}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
