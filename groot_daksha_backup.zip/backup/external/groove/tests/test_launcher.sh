#!/usr/bin/env bash
# The launcher must hand the task script's own bridge flags, plus the extra GROOVE
# flags, to GROOVE_ENTRY -- for `exec python ...` and plain `python ...` task scripts,
# with spaces and --flag=-negative values intact -- and follow GROOVE_BASE_SCRIPT
# when a wrapper execs a script that does not exist. Uses throw-away dummy scripts.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
L="$HERE/../groove_common/launch_with_task.sh"
REPO_ROOT="$(cd "$HERE/../../.." && pwd)"
export PATH="$REPO_ROOT/.venv/bin:$PATH"
T="$(mktemp -d)"
trap 'rm -rf "$T"' EXIT

cat > "$T/entry.py" <<'EOF'
import sys; print("ARGV=" + "|".join(sys.argv[1:]))
EOF
cat > "$T/task_exec.sh" <<'EOF'
set -euo pipefail
X="a b"
exec python gr00t/eval/real_robot/OPENARM_B1/eval_openarm_b1_ros2.py --lang-instruction "$X" --joint-min-csv=-0.1,0.2
EOF
cat > "$T/task_plain.sh" <<'EOF'
set -euo pipefail
python -c "print('PASSTHROUGH')"
python gr00t/eval/real_robot/OPENARM_B1/eval_openarm_b1_ros2.py --replan-at 0
EOF
cat > "$T/task_missing.sh" <<'EOF'
set -euo pipefail
exec bash "/nonexistent/run_system_b_openarm_b1_ros2.sh"
EOF

fail=0
check() {  # name, expected substring, command...
  local name="$1" want="$2"; shift 2
  local got
  got="$("$@" 2>/dev/null || true)"
  if [[ "$got" == *"$want"* ]]; then echo "PASS  $name"; else echo "FAIL  $name: got [$got]"; fail=1; fi
}
check "exec form + extra flags" "ARGV=--lang-instruction|a b|--joint-min-csv=-0.1,0.2|--groove-eps|0.008|--groove-log-dir|/tmp/x y" \
  env GROOVE_ENTRY="$T/entry.py" TASK_SCRIPT="$T/task_exec.sh" bash "$L" --groove-eps 0.008 --groove-log-dir "/tmp/x y"
check "plain form" "ARGV=--replan-at|0" env GROOVE_ENTRY="$T/entry.py" TASK_SCRIPT="$T/task_plain.sh" bash "$L"
check "other python calls pass through" "PASSTHROUGH" env GROOVE_ENTRY="$T/entry.py" TASK_SCRIPT="$T/task_plain.sh" bash "$L"
check "missing base -> GROOVE_BASE_SCRIPT" "ARGV=--lang-instruction|a b|--joint-min-csv=-0.1,0.2|--no-groove" \
  env GROOVE_ENTRY="$T/entry.py" TASK_SCRIPT="$T/task_missing.sh" GROOVE_BASE_SCRIPT="$T/task_exec.sh" bash "$L" --no-groove
if env GROOVE_ENTRY="$T/entry.py" TASK_SCRIPT="$T/task_missing.sh" bash "$L" >/dev/null 2>&1; then
  echo "FAIL  missing base without GROOVE_BASE_SCRIPT must fail"; fail=1
else
  echo "PASS  missing base without GROOVE_BASE_SCRIPT fails loudly"
fi
exit $fail
