#!/usr/bin/env bash
# System B (robot machine) with JOINT-SPACE GROOVE (option A). No URDF needed.
#
# Runs one of the existing task scripts unchanged -- same ROS domain, topics, limits,
# language, grasp guard -- with the bridge swapped for a_joint_groove/run_bridge.py.
# Start System A (the policy server) exactly as you do today.
#
#   # blackbox pick & place
#   TASK_SCRIPT=examples/openarm_b1/run_system_b_blackbox_pick_and_place_ros2.sh \
#     bash external/groove/a_joint_groove/run_system_b_joint_groove.sh
#
#   # pick_box_2 (its wrapper execs a script that is missing from the repo; name the
#   # one to use instead -- see groove_common/launch_with_task.sh)
#   TASK_SCRIPT=examples/openarm_b1/run_system_b_pick_box_2_ros2.sh \
#   GROOVE_BASE_SCRIPT=gr00t/eval/real_robot/OPENARM_B1/run_ros2_openarm_b1_eval.sh \
#     bash external/groove/a_joint_groove/run_system_b_joint_groove.sh
#
# Tuning (flags after the script name override the task script and the defaults):
#   --groove-eps 0.01            max |smoothed - policy| per joint, rad (1, 14 or 16 values)
#   --groove-arms right          regulate only the right arm
#   --groove-log-dir DIR         log every chunk + delivered command for tools/analyze_log.py
#   --no-groove                  same bridge, regulator off: the A/B baseline
# Or set GROOVE_EPS / GROOVE_ARMS / GROOVE_LOG_DIR / GROOVE_ENABLE=0 in the environment.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export GROOVE_ENTRY="$HERE/run_bridge.py"
exec bash "$HERE/../groove_common/launch_with_task.sh" "$@"
