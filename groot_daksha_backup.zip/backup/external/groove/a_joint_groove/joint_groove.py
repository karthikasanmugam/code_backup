"""Option A -- GROOVE in joint space (no URDF needed).

The paper regulates Cartesian end-effector increments. The OpenArm B1 checkpoints emit
joint positions (arms RELATIVE, converted to absolute by the server; grippers
ABSOLUTE), so this variant applies the same regulator per arm joint:

    min_q  sum_t ||q_t - 3 q_{t-1} + 3 q_{t-2} - q_{t-3}||^2 + lam ||q_t - q_{t-1}||^2
    s.t.   |q_t - raw_t| <= eps_j          (eps_g within the gripper-guard window)
           q_{-3..-1} = the last three commands actually DELIVERED

This is the paper's reference box (k = 0) with joints as the axes. The 13 directional
boxes are left out on purpose: they encode 3D workspace directions (along a motion
axis, across it) and have no counterpart among 7 joint angles. For those, use
b_cartesian_groove.

Grippers are passed through untouched (as in the paper); the bridge's gripper
deadband still runs on them afterwards.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from groove_common.box_qp import solve_jerk_qp  # noqa: E402
from groove_common.gripper_guard import GuardConfig, guard_mask  # noqa: E402
from groove_common.jerk import jerk_cost  # noqa: E402
from groove_common.layout import DOF, OPENARM_B1_ARMS, ArmSlots  # noqa: E402


def parse_eps(value: str | float | np.ndarray, dof: int = DOF) -> np.ndarray:
    """eps as one scalar, 14 arm values (left 7 then right 7), or 16 values (grippers ignored)."""
    if isinstance(value, str):
        vals = [float(x) for x in value.split(",") if x.strip()]
    else:
        vals = np.atleast_1d(np.asarray(value, dtype=np.float64)).tolist()
    if len(vals) == 1:
        return np.full(dof, vals[0])
    if len(vals) == 14:
        out = np.zeros(dof)
        out[0:7], out[8:15] = vals[:7], vals[7:]
        return out
    if len(vals) == dof:
        return np.asarray(vals, dtype=np.float64)
    raise ValueError(f"eps needs 1, 14 or {dof} values, got {len(vals)}")


@dataclass
class JointGroove:
    eps: np.ndarray = field(default_factory=lambda: np.full(DOF, 0.01))  # rad, per 16-slot
    eps_guard: float = 0.001  # rad, paper's eps_g
    lam: float = 1e-9
    guard: GuardConfig = field(default_factory=GuardConfig)
    arms: tuple[ArmSlots, ...] = OPENARM_B1_ARMS

    name = "joint"

    def regulate(self, raw16: np.ndarray, hist16: np.ndarray) -> tuple[np.ndarray, dict]:
        """raw16: (H, 16) absolute targets; hist16: (K>=3, 16) delivered commands, oldest first."""
        raw16 = np.asarray(raw16, dtype=np.float64)
        hist16 = np.asarray(hist16, dtype=np.float64)
        H = raw16.shape[0]
        if hist16.shape[0] < 3:
            raise ValueError("need at least 3 delivered commands of history")
        out = raw16.copy()
        info: dict = {"method": self.name, "arms": {}}
        if H == 0:
            return out, info

        # One batched solve for every joint of every regulated arm.
        targets, pasts, epss, spans, masks = [], [], [], [], []
        for arm in self.arms:
            mask = guard_mask(raw16[:, arm.gripper], hist16[:, arm.gripper], self.guard)
            eps = np.tile(self.eps[arm.arm][:, None], (1, H))
            eps[:, mask] = np.minimum(eps[:, mask], self.eps_guard)
            start = sum(len(t) for t in targets)
            targets.append(raw16[:, arm.arm].T)
            pasts.append(hist16[-3:, arm.arm].T)
            epss.append(eps)
            spans.append((start, start + len(arm.arm)))
            masks.append(mask)
        sol = solve_jerk_qp(
            np.concatenate(targets), np.concatenate(pasts), np.concatenate(epss), self.lam
        )

        for arm, (s, e), mask in zip(self.arms, spans, masks):
            raw_a = raw16[:, arm.arm]
            past_a = hist16[-3:, arm.arm]
            new_a = sol[s:e].T
            p_raw, p_new = jerk_cost(raw_a, past_a), jerk_cost(new_a, past_a)
            # The raw chunk is feasible, so the optimum can only be lower; anything else
            # means a numerical failure, and raw is the safe answer.
            accepted = bool(np.all(np.isfinite(new_a)) and p_new <= p_raw * (1 + 1e-9))
            if accepted:
                out[:, arm.arm] = new_a
            info["arms"][arm.name] = {
                "accepted": accepted,
                "jerk_raw": p_raw,
                "jerk_groove": p_new if accepted else p_raw,
                "reduction_pct": 100.0 * (1 - p_new / p_raw) if accepted and p_raw > 0 else 0.0,
                "max_dev": float(np.abs(out[:, arm.arm] - raw_a).max()),
                "guard_steps": int(mask.sum()),
            }
        return out, info

    @classmethod
    def from_args(cls, args, arms: tuple[ArmSlots, ...]) -> "JointGroove":
        return cls(
            eps=parse_eps(args.groove_eps),
            eps_guard=args.groove_eps_guard,
            lam=args.groove_lambda,
            guard=GuardConfig.from_seconds(
                args.groove_guard_window_s,
                args.control_hz,
                enabled=args.groove_guard,
                step_thresh=args.groove_guard_step_thresh,
                jump_thresh=args.groove_guard_jump_thresh,
            ),
            arms=arms,
        )
