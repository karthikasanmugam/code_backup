# Option A: joint-space GROOVE

The paper's regulator applied to each arm joint. No URDF needed.

For every new chunk and every arm joint `j`:

```
min_q  Σ_t (q_t − 3q_{t−1} + 3q_{t−2} − q_{t−3})² + λ (q_t − q_{t−1})²      (jerk)
s.t.   |q_t − raw_t| ≤ eps_j      (eps_guard within ±0.25 s of a gripper transition)
       q_{−3..−1} = the last three commands actually published
```

The third difference of positions is the paper's second difference of increments, so
this is exactly GROOVE's objective with the reference cube, and joints as the axes.
The 13 directional boxes are omitted because they describe 3D workspace directions,
which have no counterpart among 7 joint angles. For those, use option B.

## Run

```bash
TASK_SCRIPT=examples/openarm_b1/run_system_b_blackbox_pick_and_place_ros2.sh \
  bash external/groove/a_joint_groove/run_system_b_joint_groove.sh [flags]
```

| flag (env var) | default | meaning |
|---|---|---|
| `--groove-eps` (`GROOVE_EPS`) | `0.01` | max change per joint, rad. Accepts one value, 14 values (left 7 then right 7) or 16 values |
| `--groove-eps-guard` | `0.001` | box half-width near gripper transitions |
| `--groove-arms` (`GROOVE_ARMS`) | `left,right` | e.g. `right` for one-arm tasks |
| `--groove-guard-window-s` | `0.25` | guard half-window (paper: 5 steps at 20 Hz) |
| `--no-groove-guard` | | disable the guard |
| `--groove-log-dir` (`GROOVE_LOG_DIR`) | off | log for `tools/analyze_log.py` |
| `--no-groove` (`GROOVE_ENABLE=0`) | | same bridge with the regulator off (baseline) |

Every flag of the base bridge still works and can be appended, e.g. `--replan-at 4`.

## Choosing eps

- `eps` bounds how far a command may move from what the policy asked for. The policy's
  own error is already 0.003–0.009 rad per joint (see the bridge's comments), so
  0.005–0.01 keeps smoothing inside the policy's own noise.
- Per-joint values help when the arms differ. On one-box tasks the left arm barely
  moves, e.g.
  `--groove-eps 0.004,0.004,0.004,0.004,0.004,0.004,0.004,0.01,0.01,0.01,0.01,0.01,0.01,0.01`.
- Check with `tools/offline_eval.py` before and after: jerk down, `max_dev_from_policy`
  equal to eps.
