#!/usr/bin/env python3
"""OpenArm B1 ROS2 bridge + joint-space GROOVE (option A).

Takes every flag of gr00t/eval/real_robot/OPENARM_B1/eval_openarm_b1_ros2.py unchanged,
plus the --groove-* flags below. Normally launched through
run_system_b_joint_groove.sh, which reuses an existing task script's settings.

  python external/groove/a_joint_groove/run_bridge.py <bridge flags> \
      --groove-eps 0.01 --groove-log-dir /tmp/groove_logs
"""

from __future__ import annotations

from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from a_joint_groove.joint_groove import JointGroove  # noqa: E402
from groove_common.layout import select_arms  # noqa: E402
from groove_common.ros2_groove_bridge import (  # noqa: E402
    add_common_groove_args,
    env_default,
    load_base_bridge_module,
    run,
)


def add_joint_args(p) -> None:
    g = p.add_argument_group("GROOVE (joint space)")
    g.add_argument(
        "--groove-eps", default=env_default("GROOVE_EPS", "0.01"),
        help="Max |smoothed - policy| per joint, rad: one value, 14 (left 7, right 7) or 16.",
    )
    g.add_argument(
        "--groove-eps-guard", type=float, default=env_default("GROOVE_EPS_GUARD", 0.001, float),
        help="Box half-width inside the gripper-guard window (paper eps_g).",
    )


def main() -> None:
    base = load_base_bridge_module()
    p = base.build_arg_parser()
    add_common_groove_args(p)
    add_joint_args(p)
    args = p.parse_args()
    arms = select_arms([a.strip() for a in args.groove_arms.split(",") if a.strip()])
    regulator = JointGroove.from_args(args, arms) if args.groove else None
    run(base, args, regulator, "joint")


if __name__ == "__main__":
    main()
