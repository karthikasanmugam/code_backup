# GROOVE offline eval -- episodes [0, 1, 2], H=8, 30 Hz, hold_ticks=0, safety=off, reanchor=on

## left arm

| metric | raw policy | A: joint GROOVE | B: Cartesian GROOVE |
|---|---|---|---|
| joint_jerk_rms (rad/s^3) | 1675 | 906 (-46%) | 969.5 (-42%) |
| joint_jerk_rms_boundary (rad/s^3) | 2029 | 1256 (-38%) | 1334 (-34%) |
| joint_jerk_rms_interior (rad/s^3) | 1225 | 245.4 (-80%) | 306.2 (-75%) |
| mae_vs_gt (rad) | 0.007309 | 0.03601 | 0.07887 |
| max_dev_from_policy (rad) | 0 | 0.01 | 0.04927 |
| tcp_jerk_rms (m/s^3) | 470.5 | 267.9 (-43%) | 256.9 (-45%) |
| rot_jerk_rms (rad/s^3) | 1646 | 920.3 (-44%) | 935.7 (-43%) |

## right arm

| metric | raw policy | A: joint GROOVE | B: Cartesian GROOVE |
|---|---|---|---|
| joint_jerk_rms (rad/s^3) | 1976 | 1111 (-44%) | 1410 (-29%) |
| joint_jerk_rms_boundary (rad/s^3) | 2362 | 1530 (-35%) | 1915 (-19%) |
| joint_jerk_rms_interior (rad/s^3) | 1495 | 365.2 (-76%) | 566.2 (-62%) |
| mae_vs_gt (rad) | 0.008192 | 0.0394 | 0.07333 |
| max_dev_from_policy (rad) | 0 | 0.01 | 0.04953 |
| tcp_jerk_rms (m/s^3) | 590.8 | 349.9 (-41%) | 302.3 (-49%) |
| rot_jerk_rms (rad/s^3) | 1992 | 1143 (-43%) | 1196 (-40%) |
