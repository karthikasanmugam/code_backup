# GROOVE offline eval -- episodes [0, 1, 2], H=8, 30 Hz, hold_ticks=0, safety=off, reanchor=on

## left arm

| metric | raw policy | A: joint GROOVE | B: Cartesian GROOVE |
|---|---|---|---|
| joint_jerk_rms (rad/s^3) | 194.8 | 0 (-100%) | 26.27 (-87%) |
| joint_jerk_rms_boundary (rad/s^3) | 199.7 | 0 (-100%) | 32.74 (-84%) |
| joint_jerk_rms_interior (rad/s^3) | 189.4 | 0 (-100%) | 16.29 (-91%) |
| mae_vs_gt (rad) | 0.0005855 | 0.003121 | 0.05417 |
| max_dev_from_policy (rad) | 0 | 0.009331 | 0.04166 |
| tcp_jerk_rms (m/s^3) | 68.81 | 0 (-100%) | 5.236 (-92%) |
| rot_jerk_rms (rad/s^3) | 197.9 | 0 (-100%) | 19.11 (-90%) |

## right arm

| metric | raw policy | A: joint GROOVE | B: Cartesian GROOVE |
|---|---|---|---|
| joint_jerk_rms (rad/s^3) | 2002 | 1301 (-35%) | 1449 (-28%) |
| joint_jerk_rms_boundary (rad/s^3) | 2547 | 1820 (-29%) | 2020 (-21%) |
| joint_jerk_rms_interior (rad/s^3) | 1235 | 266.3 (-78%) | 336.7 (-73%) |
| mae_vs_gt (rad) | 0.009452 | 0.02878 | 0.05961 |
| max_dev_from_policy (rad) | 0 | 0.01 | 0.0485 |
| tcp_jerk_rms (m/s^3) | 547.2 | 353.8 (-35%) | 320.8 (-41%) |
| rot_jerk_rms (rad/s^3) | 1867 | 1214 (-35%) | 1220 (-35%) |
