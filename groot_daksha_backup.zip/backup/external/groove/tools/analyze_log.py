#!/usr/bin/env python3
"""Compare robot runs logged by the GROOVE bridge (--groove-log-dir), e.g. an A/B:

  # baseline: same bridge, regulator off           # GROOVE on
  ... run_system_b_joint_groove.sh --no-groove \\   ... run_system_b_joint_groove.sh \\
      --groove-log-dir ~/groove_logs                     --groove-log-dir ~/groove_logs

  python external/groove/tools/analyze_log.py ~/groove_logs/groove_raw_*.npz \\
      ~/groove_logs/groove_joint_*.npz [--arm-config .../arm_config.json] [--plot ab.png]

The first log is the reference for the % columns. Reported per arm:
  * cmd jerk      -- RMS jerk of what was PUBLISHED (rad/s^3), overall and at chunk
                     boundaries (the replace-on-replan seam)
  * meas jerk     -- the same from /joint_states sampled at each publish; what the arm
                     actually did, including tracking and encoder noise
  * TCP jerk      -- with --arm-config, from FK of the published commands (m/s^3)
  * publish period p99 / max -- a slow regulator shows up here as late commands
  * GROOVE solve time, per-chunk reduction, fallbacks
Compare runs of the same task and duration; jerk depends on what the arm was doing.
"""

from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path
import re
import sys

import numpy as np

GROOVE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(GROOVE))

from groove_common.jerk import jerk_metrics  # noqa: E402
from groove_common.layout import OPENARM_B1_ARMS  # noqa: E402

SURFACE, INK, INK2, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#e4e3df"
SLOTS = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#4a3aa7", "#e34948"]


def analyze(path: Path, kins) -> dict:
    z = np.load(path, allow_pickle=False)
    meta = json.loads(str(z["meta"]))
    dt = 1.0 / float(meta["control_hz"])
    t_pub, cmd, meas = z["pub_t"], z["pub_cmd"], z["pub_meas"]
    starts = np.searchsorted(t_pub, z["chunk_t"], side="left")  # first publish after each landing
    res = {"file": path.name, "method": meta["method"], "n_pub": int(len(t_pub)),
           "n_chunks": int(len(z["chunk_t"])), "arms": {}}
    if len(t_pub) > 1:
        period = np.diff(t_pub) * 1000.0
        res["period_ms"] = {"p50": float(np.median(period)), "p99": float(np.percentile(period, 99)),
                            "max": float(period.max())}
    for arm in OPENARM_B1_ARMS:
        a = {}
        m = jerk_metrics(cmd[:, arm.arm], dt, starts)
        a["cmd_jerk_rms"], a["cmd_jerk_boundary"] = m["rms"], m.get("rms_boundary", float("nan"))
        ok = np.all(np.isfinite(meas[:, arm.arm]), axis=1)
        a["meas_jerk_rms"] = jerk_metrics(meas[ok][:, arm.arm], dt)["rms"] if ok.sum() > 4 else float("nan")
        if kins and arm.name in kins:
            p, _ = kins[arm.name].eef_trace(cmd[:, arm.arm])
            a["tcp_jerk_rms"] = jerk_metrics(p, dt, starts)["rms"]
        res["arms"][arm.name] = a
    infos = [json.loads(s) for s in z["chunk_info"]]
    if meta["method"] != "raw" and infos:
        res["solve_ms"] = {"p50": float(np.median(z["chunk_solve_ms"])),
                           "p95": float(np.percentile(z["chunk_solve_ms"], 95)),
                           "max": float(np.max(z["chunk_solve_ms"]))}
        for arm in OPENARM_B1_ARMS:
            per = [i["arms"][arm.name] for i in infos if arm.name in i.get("arms", {})]
            if not per:
                continue
            reasons = Counter(re.sub(r"[0-9.]+(e[-+]?\d+)?", "#", p.get("fallback") or "") for p in per if p.get("fallback"))
            res["arms"][arm.name]["groove"] = {
                "chunk_reduction_p50": float(np.median([p.get("reduction_pct", 0.0) for p in per])),
                "max_dev": float(max(p.get("max_dev", 0.0) for p in per)),
                "fallbacks": dict(reasons),
                "errors": sum(1 for i in infos if "error" in i),
            }
    return res


def fmt_table(results: list[dict]) -> str:
    ref = results[0]
    head = "| metric | " + " | ".join(f"{r['method']} ({r['file']})" for r in results) + " |"
    lines = [head, "|---|" + "---|" * len(results)]

    def row(label, get, unit, pct=True):
        cells = []
        for r in results:
            v = get(r)
            if v is None or not np.isfinite(v):
                cells.append("-")
                continue
            s = f"{v:.4g}"
            r0 = get(ref)
            if pct and r is not ref and r0 and np.isfinite(r0) and r0 > 0:
                s += f" ({100 * (v / r0 - 1):+.0f}%)"
            cells.append(s)
        lines.append(f"| {label} ({unit}) | " + " | ".join(cells) + " |")

    for arm in [a.name for a in OPENARM_B1_ARMS]:
        row(f"{arm} cmd jerk", lambda r: r["arms"][arm]["cmd_jerk_rms"], "rad/s^3")
        row(f"{arm} cmd jerk @ boundaries", lambda r: r["arms"][arm]["cmd_jerk_boundary"], "rad/s^3")
        row(f"{arm} measured jerk", lambda r: r["arms"][arm]["meas_jerk_rms"], "rad/s^3")
        if "tcp_jerk_rms" in ref["arms"][arm]:
            row(f"{arm} TCP jerk", lambda r: r["arms"][arm].get("tcp_jerk_rms"), "m/s^3")
    row("publish period p99", lambda r: r.get("period_ms", {}).get("p99"), "ms", pct=False)
    row("publish period max", lambda r: r.get("period_ms", {}).get("max"), "ms", pct=False)
    row("GROOVE solve p95", lambda r: r.get("solve_ms", {}).get("p95"), "ms", pct=False)
    lines.append("")
    for r in results:
        for arm, a in r["arms"].items():
            g = a.get("groove")
            if g:
                lines.append(f"- {r['file']} {arm}: median per-chunk jerk reduction {g['chunk_reduction_p50']:.0f}%, "
                             f"max change {g['max_dev']:.4f}, fallbacks {g['fallbacks'] or 'none'}, errors {g['errors']}")
    return "\n".join(lines)


def plot(path: str, results: list[dict]) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    arms = [a.name for a in OPENARM_B1_ARMS]
    metrics = [("cmd_jerk_rms", "published command"), ("meas_jerk_rms", "measured joint state")]
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.4), facecolor=SURFACE)
    w = 0.8 / len(results)
    for ax, (key, title) in zip(axes, metrics):
        ax.set_facecolor(SURFACE)
        for s in ("top", "right"):
            ax.spines[s].set_visible(False)
        for s in ("left", "bottom"):
            ax.spines[s].set_color(GRID)
        ax.tick_params(colors=INK2, labelsize=8)
        ax.grid(True, axis="y", color=GRID, lw=0.6)
        ax.set_axisbelow(True)
        for i, r in enumerate(results):
            xs = np.arange(len(arms)) + (i - (len(results) - 1) / 2) * w
            vals = [r["arms"][a][key] for a in arms]
            ax.bar(xs, vals, width=w * 0.92, color=SLOTS[i % len(SLOTS)], edgecolor=SURFACE, linewidth=2,
                   label=f"{r['method']} ({r['file']})")
        ax.set_xticks(np.arange(len(arms)), [f"{a} arm" for a in arms], color=INK)
        ax.set_ylabel("RMS jerk (rad/s^3)", fontsize=8, color=INK2)
        ax.set_title(title, fontsize=10, color=INK, loc="left")
    axes[0].legend(fontsize=7, frameon=False, labelcolor=INK)
    fig.tight_layout()
    fig.savefig(path, dpi=110, facecolor=SURFACE)
    plt.close(fig)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("logs", nargs="+", help="groove_*.npz files; the first is the reference")
    ap.add_argument("--arm-config", help="arm_config.json, to add TCP jerk")
    ap.add_argument("--plot", help="write a bar chart PNG here")
    ap.add_argument("--json", help="write the full results here")
    args = ap.parse_args()
    kins = None
    if args.arm_config:
        from b_cartesian_groove.cartesian_groove import load_arm_kinematics

        kins = load_arm_kinematics(args.arm_config, [a.name for a in OPENARM_B1_ARMS])
    results = [analyze(Path(p).expanduser(), kins) for p in args.logs]
    print(fmt_table(results))
    if args.plot:
        plot(args.plot, results)
        print(f"\nplot written to {args.plot}")
    if args.json:
        Path(args.json).write_text(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
