#!/usr/bin/env python3
"""Offline A/B of raw vs joint GROOVE (A) vs Cartesian GROOVE (B) on RECORDED episodes.

No robot. The policy is run open-loop over the dataset exactly the way
gr00t/eval/real_robot/OPENARM_B1/ui/validate_prediction_vs_dataset.py does it (its
run_episode() is imported, not copied): one chunk per --action-horizon frames,
predicted from the recorded observation. Each method then "executes" those chunks
back to back, regulating every chunk against the commands it already executed --
the same boundary conditions the GROOVE bridge uses on the robot.

  cd ~/Desktop/I/groot && source .venv/bin/activate
  python external/groove/tools/offline_eval.py \
      --dataset-path /home/physicalai/Desktop/I/barani/pick_box_2 \
      --model-path outputs/pick_box_2_8chunk/checkpoint-50000 \
      --episodes 0 1 2 --steps 300 --save-preds /tmp/pick_box_2_preds.npz

  # re-tune without the GPU, from the saved predictions:
  python external/groove/tools/offline_eval.py --preds-npz /tmp/pick_box_2_preds.npz \
      --joint-eps 0.006 --methods raw,joint

  # add B once the URDF is in:
  python external/groove/tools/offline_eval.py --preds-npz /tmp/pick_box_2_preds.npz \
      --methods raw,joint,cartesian --arm-config external/groove/b_cartesian_groove/arm_config.json

What it does NOT model: tracking dynamics (commands are scored, not the arm), the
bridge's gripper deadband / grasp guard, and closed-loop feedback (the next chunk is
always predicted from the RECORDED observation). --hold-ticks inserts the hold the
bridge publishes while inference runs with --replan-at 0; --joint-min/max-csv and
--max-step-delta-csv apply the bridge's clamp and rate limit.

Outputs in --out-dir: summary.json, summary.md, traces_ep<N>.png, jerk_summary.png.
"""

from __future__ import annotations

import argparse
from collections import deque
import importlib.util
import json
from pathlib import Path
import sys
import types

import numpy as np

GROOVE = Path(__file__).resolve().parents[1]
REPO = GROOVE.parents[1]
sys.path.insert(0, str(GROOVE))

from a_joint_groove.joint_groove import JointGroove, parse_eps  # noqa: E402
from groove_common.gripper_guard import GuardConfig  # noqa: E402
from groove_common.jerk import jerk_metrics  # noqa: E402
from groove_common.layout import OPENARM_B1_ARMS, select_arms  # noqa: E402
from groove_common.ros2_groove_bridge import add_common_groove_args  # noqa: E402

VALIDATOR = REPO / "gr00t/eval/real_robot/OPENARM_B1/ui/validate_prediction_vs_dataset.py"
EXPECTED_KEYS = ["left_arm", "left_gripper", "right_arm", "right_gripper"]

# Reference palette (dataviz skill, references/palette.md), light mode.
SURFACE, INK, INK2, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#e4e3df"
REF = "#8a8984"  # neutral reference line (ground truth), not a categorical slot
SERIES = {"raw": "#2a78d6", "joint": "#eb6834", "cartesian": "#1baf7a"}  # slots 1-3, fixed
LABEL = {"raw": "raw policy", "joint": "A: joint GROOVE", "cartesian": "B: Cartesian GROOVE"}


# ---------------------------------------------------------------- predictions
def load_validator():
    spec = importlib.util.spec_from_file_location("validate_prediction_vs_dataset", VALIDATOR)
    mod = importlib.util.module_from_spec(spec)
    sys.path.insert(0, str(REPO))  # it imports examples.openarm_b1.pick_box_config
    prev, sys.dont_write_bytecode = sys.dont_write_bytecode, True  # no __pycache__ in the repo
    try:
        spec.loader.exec_module(mod)
    finally:
        sys.dont_write_bytecode = prev
    return mod


def predict(args) -> dict:
    val = load_validator()
    from gr00t.data.dataset.lerobot_episode_loader import LeRobotEpisodeLoader
    from gr00t.data.embodiment_tags import EmbodimentTag

    tag = EmbodimentTag.resolve(args.embodiment_tag)
    if args.model_path:
        import torch
        from gr00t.policy.gr00t_policy import Gr00tPolicy

        policy = Gr00tPolicy(embodiment_tag=tag, model_path=args.model_path,
                             device="cuda" if torch.cuda.is_available() else "cpu")
    else:
        from gr00t.policy.server_client import PolicyClient

        policy = PolicyClient(host=args.host, port=args.port)
    modality = policy.get_modality_config()
    keys = list(modality["action"].modality_keys)
    if keys != EXPECTED_KEYS:
        raise SystemExit(f"action keys {keys} are not the left-first layout {EXPECTED_KEYS} GROOVE assumes")
    loader = LeRobotEpisodeLoader(dataset_path=str(Path(args.dataset_path).expanduser()),
                                  modality_configs=modality, video_backend="torchcodec",
                                  video_backend_kwargs=None)
    eps = {}
    for ep in args.episodes:
        state, gt, pred = val.run_episode(policy, loader, ep, tag, args.steps, args.action_horizon)
        eps[ep] = {"state": state, "gt": gt, "pred": pred}
    return eps


def save_preds(path: str, eps: dict, H: int, hz: float) -> None:
    flat = {"action_horizon": H, "control_hz": hz, "episodes": np.array(sorted(eps))}
    for ep, d in eps.items():
        for k, v in d.items():
            flat[f"{k}_{ep}"] = v
    np.savez_compressed(path, **flat)


def load_preds(path: str) -> tuple[dict, int, float]:
    z = np.load(path)
    eps = {int(ep): {k: z[f"{k}_{ep}"] for k in ("state", "gt", "pred")} for ep in z["episodes"]}
    return eps, int(z["action_horizon"]), float(z["control_hz"])


# ---------------------------------------------------------------- execution
class Safety:
    """The bridge's arm clamp + rate limit (eval_openarm_b1_ros2.py, _apply_safety)."""

    def __init__(self, jmin, jmax, msd):
        self.jmin, self.jmax, self.msd = jmin, jmax, msd

    def __call__(self, target, prev):
        t = np.clip(target, self.jmin, self.jmax)
        c = np.clip(prev + np.clip(t - prev, -self.msd, self.msd), self.jmin, self.jmax)
        return np.clip(c, prev - self.msd, prev + self.msd)


ARM_IDX = np.r_[0:7, 8:15]


def execute(pred, H, regulator, init16, hold_ticks, safety, hist_len=16, state=None):
    """Returns (commands (T',16), chunk start indices, is-chunk-step mask, frame index, infos).

    state: pass the recorded states (T,16) to turn re-anchoring on. The arms are RELATIVE
    actions (the server adds the state it was sent), so on the robot a regulator's
    deviation at the end of one chunk is still there when the next chunk is planned.
    Without re-anchoring, open-loop replay drags every method back to the recorded
    trajectory at each boundary, which penalises any method that deviates. What is
    carried forward is ONLY the regulator's own deviation -- the executed command minus
    what the raw policy commanded at that step -- so the raw run is exactly the
    validation tool's open-loop replay. (Anchoring to the recorded STATE instead would
    also carry the command-to-state tracking offset, which piles up chunk after chunk.)
    """
    hist = deque([init16.copy()] * hist_len, maxlen=hist_len)
    cmds, starts, is_step, frame, infos, targets = [], [], [], [], [], []
    prev = init16.copy()

    def emit(v, f, target=None):
        nonlocal prev
        c = safety(v, prev) if safety is not None else v
        cmds.append(c); hist.append(c); prev = c
        is_step.append(f >= 0); frame.append(f)
        targets.append(c if target is None else target)

    for c0 in range(0, len(pred), H):
        if c0 > 0:
            for _ in range(hold_ticks):  # bridge holds the last command during inference
                emit(prev.copy(), -1)
        chunk = pred[c0 : c0 + H].astype(np.float64)
        if state is not None and c0 > 0:
            chunk[:, ARM_IDX] += prev[ARM_IDX] - pred[c0 - 1, ARM_IDX]
        policy_chunk = chunk.copy()  # what the regulator was given
        if regulator is not None and len(chunk) >= 1:
            chunk, info = regulator.regulate(chunk, np.array(hist))
            infos.append(info)
        starts.append(len(cmds))
        for j, v in enumerate(chunk):
            emit(v, c0 + j, policy_chunk[j])
    return (np.array(cmds), np.array(starts), np.array(is_step), np.array(frame), infos,
            np.array(targets))


# ---------------------------------------------------------------- metrics
def score(cmds, starts, is_step, frame, gt, targets, dt, kins):
    out = {}
    for arm in OPENARM_B1_ARMS:
        q = cmds[:, arm.arm]
        m = jerk_metrics(q, dt, starts)
        f = frame[is_step]
        a = {
            "joint_jerk_rms": m["rms"],
            "joint_jerk_rms_boundary": m.get("rms_boundary", float("nan")),
            "joint_jerk_rms_interior": m.get("rms_interior", float("nan")),
            # With --reanchor this includes open-loop drift (no visual feedback to pull the
            # arm back), so it is pessimistic for every method; compare, don't read absolutely.
            "mae_vs_gt": float(np.mean(np.abs(q[is_step] - gt[f][:, arm.arm]))),
            # Largest change the regulator made to the chunk it was handed.
            "max_dev_from_policy": float(np.max(np.abs(q[is_step] - targets[is_step][:, arm.arm]))),
        }
        if kins and arm.name in kins:
            p, rc = kins[arm.name].eef_trace(q)
            a["tcp_jerk_rms"] = jerk_metrics(p, dt, starts)["rms"]
            a["rot_jerk_rms"] = jerk_metrics(rc, dt, starts)["rms"]
        out[arm.name] = a
    return out


def build_regulators(args, kins):
    arms = select_arms([a.strip() for a in args.groove_arms.split(",") if a.strip()])
    guard = GuardConfig.from_seconds(
        args.groove_guard_window_s, args.control_hz, enabled=args.groove_guard,
        step_thresh=args.groove_guard_step_thresh, jump_thresh=args.groove_guard_jump_thresh,
    )
    joint = JointGroove(eps=parse_eps(args.joint_eps), eps_guard=args.joint_eps_guard,
                        lam=args.groove_lambda, guard=guard, arms=arms)
    regs = {"raw": None, "joint": joint}
    if "cartesian" in args.methods:
        from b_cartesian_groove.cartesian_groove import build_from_args

        ns = types.SimpleNamespace(
            groove_arm_config=args.arm_config, groove_eps0=args.cart_eps0,
            groove_eps_tight=args.cart_eps_tight, groove_eps_rot=args.cart_eps_rot,
            groove_eps_guard=args.cart_eps_guard, groove_eps_guard_rot=args.cart_eps_guard_rot,
            groove_rho_b=args.cart_rho_b, groove_lambda=args.groove_lambda,
            groove_boxes=args.cart_boxes, groove_smooth_rot=args.cart_smooth_rot,
            groove_max_joint_dev=args.cart_max_joint_dev,
            groove_max_joint_jerk_ratio=args.cart_max_joint_jerk_ratio,
            groove_fallback=args.cart_fallback, groove_fallback_eps=args.joint_eps,
            groove_guard_window_s=args.groove_guard_window_s, control_hz=args.control_hz,
            groove_guard=args.groove_guard, groove_guard_step_thresh=args.groove_guard_step_thresh,
            groove_guard_jump_thresh=args.groove_guard_jump_thresh,
        )
        regs["cartesian"] = build_from_args(ns, arms)
    return {m: regs[m] for m in args.methods}


# ---------------------------------------------------------------- plots
def _style(ax):
    ax.set_facecolor(SURFACE)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_color(GRID)
    ax.tick_params(colors=INK2, labelsize=8)
    ax.grid(True, color=GRID, lw=0.6)
    ax.set_axisbelow(True)


def plot_traces(path, ep, runs, gt, H, dt, n_joints=4):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    arms = np.r_[0:7, 8:15]
    moving = arms[np.argsort(-np.ptp(gt[:, arms], axis=0))[:n_joints]]
    fig, axes = plt.subplots(n_joints, 1, figsize=(11, 2.3 * n_joints), sharex=True, facecolor=SURFACE)
    for ax, j in zip(np.atleast_1d(axes), moving):
        _style(ax)
        t = np.arange(len(gt)) * dt
        ax.plot(t, gt[:, j], color=REF, lw=1.2, ls=(0, (4, 2)), label="recorded action (GT)")
        for m, r in runs.items():
            steps = r["is_step"]
            ax.plot(r["frame"][steps] * dt, r["cmds"][steps, j], color=SERIES[m], lw=1.6, label=LABEL[m])
        for c0 in range(0, len(gt), H):
            ax.axvline(c0 * dt, color=GRID, lw=0.6, zorder=0)
        side = "left" if j < 8 else "right"
        ax.set_title(f"{side}_joint_{(j % 8) + 1}  (policy slot {j})", fontsize=9, color=INK, loc="left")
        ax.set_ylabel("rad", fontsize=8, color=INK2)
    np.atleast_1d(axes)[0].legend(fontsize=8, frameon=False, ncol=len(runs) + 1, loc="lower left",
                                  bbox_to_anchor=(0, 1.18), labelcolor=INK)
    np.atleast_1d(axes)[-1].set_xlabel("time (s) -- faint lines = chunk boundaries", fontsize=8, color=INK2)
    fig.suptitle(f"Episode {ep}: most-moving arm joints", fontsize=11, color=INK, x=0.01, ha="left")
    fig.tight_layout()
    fig.savefig(path, dpi=110, facecolor=SURFACE)
    plt.close(fig)


def plot_summary(path, agg, methods, metric, unit):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    arms = [a.name for a in OPENARM_B1_ARMS]
    fig, ax = plt.subplots(figsize=(6.5, 3.4), facecolor=SURFACE)
    _style(ax)
    ax.grid(True, axis="y", color=GRID, lw=0.6)
    ax.grid(False, axis="x")
    w = 0.8 / len(methods)
    for i, m in enumerate(methods):
        vals = [agg[m][a][metric] for a in arms]
        xs = np.arange(len(arms)) + (i - (len(methods) - 1) / 2) * w
        ax.bar(xs, vals, width=w * 0.92, color=SERIES[m], label=LABEL[m], edgecolor=SURFACE, linewidth=2)
        for x, v, a in zip(xs, vals, arms):
            if m != "raw" and agg["raw"][a][metric] > 0:
                ch = 100 * (v / agg["raw"][a][metric] - 1)
                ax.text(x, v, f"{ch:+.0f}%", ha="center", va="bottom", fontsize=8, color=INK2)
    ax.set_xticks(np.arange(len(arms)), [f"{a} arm" for a in arms], color=INK)
    ax.set_ylabel(unit, fontsize=8, color=INK2)
    ax.set_title(f"{metric.replace('_', ' ')} (mean over episodes)", fontsize=10, color=INK, loc="left")
    ax.legend(fontsize=8, frameon=False, labelcolor=INK)
    fig.tight_layout()
    fig.savefig(path, dpi=110, facecolor=SURFACE)
    plt.close(fig)


# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    src = ap.add_argument_group("prediction source")
    src.add_argument("--preds-npz", help="reuse predictions saved with --save-preds (no GPU)")
    src.add_argument("--dataset-path")
    src.add_argument("--model-path", help="checkpoint dir; omit to use a running server (--host/--port)")
    src.add_argument("--host", default="127.0.0.1")
    src.add_argument("--port", type=int, default=5555)
    src.add_argument("--embodiment-tag", default="openarm_b1")
    src.add_argument("--episodes", type=int, nargs="+", default=[0])
    src.add_argument("--steps", type=int, default=300)
    src.add_argument("--action-horizon", type=int, default=8)
    src.add_argument("--save-preds", help="write the predictions here for later --preds-npz runs")
    ex = ap.add_argument_group("execution model")
    ex.add_argument("--control-hz", type=float, default=30.0)
    ex.add_argument("--hold-ticks", type=int, default=0,
                    help="hold commands between chunks (bridge with --replan-at 0: ~inference_s * hz)")
    ex.add_argument("--joint-min-csv", default="")
    ex.add_argument("--joint-max-csv", default="")
    ex.add_argument("--max-step-delta-csv", default="")
    ex.add_argument("--reanchor", action=argparse.BooleanOptionalAction, default=True,
                    help="re-anchor each chunk's (RELATIVE) arm targets to the executed state (default)")
    ev = ap.add_argument_group("methods")
    ev.add_argument("--methods", default="raw,joint", help="comma list of raw, joint, cartesian")
    ev.add_argument("--joint-eps", default="0.01")
    ev.add_argument("--joint-eps-guard", type=float, default=0.001)
    ev.add_argument("--arm-config", default=str(GROOVE / "b_cartesian_groove/arm_config.json"))
    ev.add_argument("--cart-eps0", type=float, default=0.005)
    ev.add_argument("--cart-eps-tight", type=float, default=0.0, help="0 = eps0/3")
    ev.add_argument("--cart-eps-rot", type=float, default=0.01)
    ev.add_argument("--cart-eps-guard", type=float, default=5e-4, help="paper-literal: 5e-5")
    ev.add_argument("--cart-eps-guard-rot", type=float, default=2e-3, help="paper-literal: 5e-4")
    ev.add_argument("--cart-rho-b", type=float, default=1.5)
    ev.add_argument("--cart-boxes", choices=["all", "reference"], default="all")
    ev.add_argument("--cart-smooth-rot", action=argparse.BooleanOptionalAction, default=True)
    ev.add_argument("--cart-fallback", choices=["joint", "raw"], default="joint")
    ev.add_argument("--cart-max-joint-dev", type=float, default=0.05)
    ev.add_argument("--cart-max-joint-jerk-ratio", type=float, default=2.0)
    add_common_groove_args(ap)
    ap.add_argument("--out-dir", default=str(GROOVE / "results/offline_eval"))
    args = ap.parse_args()
    args.methods = [m.strip() for m in args.methods.split(",") if m.strip()]
    for m in args.methods:
        if m not in SERIES:
            raise SystemExit(f"unknown method {m!r}")
    if "raw" not in args.methods:
        args.methods.insert(0, "raw")

    if args.preds_npz:
        eps, H, hz = load_preds(args.preds_npz)
        args.control_hz = hz
    else:
        if not args.dataset_path:
            raise SystemExit("need --preds-npz, or --dataset-path with --model-path / a running server")
        eps, H = predict(args), args.action_horizon
        if args.save_preds:
            save_preds(args.save_preds, eps, H, args.control_hz)
            print(f"predictions saved to {args.save_preds}")
    dt = 1.0 / args.control_hz

    safety = None
    if args.joint_min_csv and args.joint_max_csv and args.max_step_delta_csv:
        f = lambda s: np.array([float(x) for x in s.split(",")])  # noqa: E731
        safety = Safety(f(args.joint_min_csv), f(args.joint_max_csv), f(args.max_step_delta_csv))

    kins = None
    if Path(args.arm_config).expanduser().is_file():
        from b_cartesian_groove.cartesian_groove import load_arm_kinematics

        kins = load_arm_kinematics(args.arm_config, [a.name for a in OPENARM_B1_ARMS])
    elif "cartesian" in args.methods:
        raise SystemExit(f"--arm-config {args.arm_config} not found (needed for 'cartesian')")
    regs = build_regulators(args, kins)

    out_dir = Path(args.out_dir).expanduser()
    out_dir.mkdir(parents=True, exist_ok=True)
    per_ep = {}
    for ep, d in sorted(eps.items()):
        gt, pred = d["gt"].astype(np.float64), d["pred"].astype(np.float64)
        init = d["state"][0].astype(np.float64) if d["state"].shape[1] == 16 else gt[0]
        runs = {}
        for m, reg in regs.items():
            cmds, starts, is_step, frame, infos, targets = execute(
                pred, H, reg, init, args.hold_ticks, safety,
                state=d["state"].astype(np.float64) if args.reanchor and d["state"].shape[1] == 16 else None,
            )
            runs[m] = dict(cmds=cmds, is_step=is_step, frame=frame)
            per_ep.setdefault(m, {})[ep] = score(cmds, starts, is_step, frame, gt, targets, dt, kins)
            if m == "cartesian":
                fb = sum(1 for i in infos for a in i["arms"].values() if a.get("via_joint_fallback"))
                per_ep[m][ep]["joint_fallback_arm_chunks"] = fb
        plot_traces(out_dir / f"traces_ep{ep}.png", ep, runs, gt, H, dt)

    metrics = [k for k in per_ep["raw"][next(iter(per_ep["raw"]))]["left"]]
    agg = {m: {a.name: {k: float(np.nanmean([per_ep[m][e][a.name][k] for e in per_ep[m]])) for k in metrics}
               for a in OPENARM_B1_ARMS} for m in regs}
    (out_dir / "summary.json").write_text(json.dumps({"per_episode": per_ep, "mean": agg,
                                                      "args": {k: v for k, v in vars(args).items()}},
                                                     indent=2, default=str))
    lines = [f"# GROOVE offline eval -- episodes {sorted(eps)}, H={H}, {args.control_hz:g} Hz, "
             f"hold_ticks={args.hold_ticks}, safety={'on' if safety else 'off'}, "
             f"reanchor={'on' if args.reanchor else 'off'}", ""]
    units = {"joint_jerk_rms": "rad/s^3", "joint_jerk_rms_boundary": "rad/s^3",
             "joint_jerk_rms_interior": "rad/s^3", "mae_vs_gt": "rad", "max_dev_from_policy": "rad",
             "tcp_jerk_rms": "m/s^3", "rot_jerk_rms": "rad/s^3"}
    for a in OPENARM_B1_ARMS:
        lines += [f"## {a.name} arm", "", "| metric | " + " | ".join(LABEL[m] for m in regs) + " |",
                  "|---|" + "---|" * len(regs)]
        for k in metrics:
            row = [f"{k} ({units.get(k, '')})"]
            for m in regs:
                v, r = agg[m][a.name][k], agg["raw"][a.name][k]
                ch = f" ({100 * (v / r - 1):+.0f}%)" if m != "raw" and r > 0 and "jerk" in k else ""
                row.append(f"{v:.4g}{ch}")
            lines.append("| " + " | ".join(row) + " |")
        lines.append("")
    (out_dir / "summary.md").write_text("\n".join(lines))
    plot_summary(out_dir / "jerk_summary.png", agg, list(regs), "joint_jerk_rms", "rad/s^3")
    if kins:
        plot_summary(out_dir / "tcp_jerk_summary.png", agg, list(regs), "tcp_jerk_rms", "m/s^3")
    print("\n".join(lines))
    print(f"\nwritten to {out_dir}")


if __name__ == "__main__":
    main()
