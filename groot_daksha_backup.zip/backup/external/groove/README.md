# GROOVE for the OpenArm B1 GR00T policy

GROOVE (*Geometry-Guided Reduction of Operational-Space Jerk in VLA Execution*,
https://devsangho.github.io/GROOVE-public/, arXiv 2609.13695) is an **inference-time**
regulator for chunked VLA policies. It needs no retraining and no extra model calls.
Every time a new action chunk arrives it solves a small quadratic program. The QP
finds the lowest-jerk version of the chunk that:

- starts from the commands that were **already delivered**, which smooths the seam
  where a new chunk replaces the old one;
- stays inside a box of size `eps` around the policy's own chunk;
- stays essentially on the policy's path near gripper open/close events (the
  "gripper guard").

Nothing outside this folder was modified. The existing bridge
(`gr00t/eval/real_robot/OPENARM_B1/eval_openarm_b1_ros2.py`), the task scripts
(`examples/openarm_b1/run_system_b_*.sh`) and the validation tool are imported or run
as they are.

## Two variants

| | **A: `a_joint_groove/`** | **B: `b_cartesian_groove/`** |
|---|---|---|
| Smooths | each arm joint (7 per arm) | TCP path: position + orientation, the paper's space |
| Box | `eps` per joint (rad) | 14 geometry-guided boxes (cube + 13 directional), as in the paper |
| Needs | nothing | the OpenArm URDF (`arm_config.json`) |
| Back to joints | not needed | damped IK, seeded and null-space-referenced by A's solution |
| If B's solution is unsafe | n/a | that arm falls back to A (or raw with `--groove-fallback raw`) |
| Cost per 8-step chunk (both arms) | ~3 ms | ~13 ms |

Grippers always pass through untouched. The bridge's gripper deadband and grasp guard
still apply to them.

## How it plugs into the robot

```
policy chunk ─► anchor compensation ─► GROOVE ─► your bridge's _build_plan
                (same as the bridge)             (joint limits, max_step_delta,
                                                  gripper deadband, grasp guard)
```

`groove_common/ros2_groove_bridge.py` **subclasses** `Gr00TOpenArmB1RosBridge`. Only
the step between the policy and the bridge's own safety layer is new:

- It records every published command, because those are the boundary conditions.
- It applies the anchor offset itself, before GROOVE. The base bridge's copy is
  switched off, so the offset is applied exactly once.
- Everything else is the base bridge's code, unchanged.

Any error in GROOVE sends that chunk raw.

`groove_common/launch_with_task.sh` runs one of your **existing task scripts
unchanged** and swaps only the Python entry point. ROS domain, topics, limits,
language and grasp guard therefore come from the task script, and a GROOVE run and a
baseline run use identical settings.

## Quick start (robot machine, System B)

Start System A (the policy server) as usual. Then:

```bash
cd ~/Desktop/I/groot

# A: joint GROOVE, blackbox pick & place
TASK_SCRIPT=examples/openarm_b1/run_system_b_blackbox_pick_and_place_ros2.sh \
  bash external/groove/a_joint_groove/run_system_b_joint_groove.sh --groove-log-dir ~/groove_logs

# Same thing, regulator OFF (the baseline for an A/B comparison, same logging)
TASK_SCRIPT=examples/openarm_b1/run_system_b_blackbox_pick_and_place_ros2.sh \
  bash external/groove/a_joint_groove/run_system_b_joint_groove.sh --no-groove --groove-log-dir ~/groove_logs

# pick_box_2 / two_box_pick: their wrappers exec examples/openarm_b1/run_system_b_openarm_b1_ros2.sh,
# which is not in the repo. Name the script to run in its place:
TASK_SCRIPT=examples/openarm_b1/run_system_b_pick_box_2_ros2.sh \
GROOVE_BASE_SCRIPT=gr00t/eval/real_robot/OPENARM_B1/run_ros2_openarm_b1_eval.sh \
  bash external/groove/a_joint_groove/run_system_b_joint_groove.sh

# Compare the two runs
python external/groove/tools/analyze_log.py ~/groove_logs/groove_raw_*.npz ~/groove_logs/groove_joint_*.npz --plot ~/groove_ab.png
```

Each chunk logs one line, e.g.
`GROOVE[joint] 3.1 ms | left: jerk -62% dev 0.0040 | right: jerk -71% dev 0.0100 guard 8`.

B works the same way once the URDF is in (see `b_cartesian_groove/README.md`):
`bash external/groove/b_cartesian_groove/run_system_b_cartesian_groove.sh`.

## Tune offline first (no robot)

`tools/offline_eval.py` runs the policy over recorded episodes, using the validation
tool's own `run_episode()`. It then executes raw, A and B back to back with the same
boundary conditions the bridge uses, and reports jerk, deviation from the policy,
and TCP jerk if an arm config is given:

```bash
python external/groove/tools/offline_eval.py --dataset-path /home/physicalai/Desktop/I/barani/pick_box_2 \
    --model-path outputs/pick_box_2_8chunk/checkpoint-50000 --episodes 0 1 2 --steps 300 \
    --hold-ticks 3 --save-preds ~/pick_box_2_preds.npz          # GPU once
python external/groove/tools/offline_eval.py --preds-npz ~/pick_box_2_preds.npz --joint-eps 0.006   # re-tune, no GPU
```

It writes `summary.md`, `summary.json`, `traces_ep<N>.png` and `jerk_summary.png`
to `external/groove/results/offline_eval/` (change with `--out-dir`).
Set `--hold-ticks` to about `inference_s x 30`. With `--replan-at 0` the bridge holds
the arm while the policy thinks, and those stop-go seams are part of what GROOVE
smooths.

## Results on your checkpoints (offline, 3 recorded episodes each)

`tools/offline_eval.py` defaults: A `eps` 0.01; B 5 mm / 0.01 rad; Daksha URDF with the
left-arm sign fix; no hold ticks. Reports are in `results/pick_box_2/` and
`results/two_box_pick/`; the predictions are saved, so you can re-tune without a GPU.

| checkpoint | arm | raw → A: joint jerk / TCP jerk | raw → B: joint jerk / TCP jerk | mean deviation from demo, raw / A / B |
|---|---|---|---|---|
| pick_box_2_8chunk | left (near-static) | −100% / −100% | −87% / −92% | 0.001 / 0.003 / 0.054 rad |
| pick_box_2_8chunk | right | −35% / −35% | −28% / −41% | 0.009 / 0.029 / 0.060 rad |
| two_box_pick_8chunk | left | −46% / −43% | −42% / −45% | 0.007 / 0.036 / 0.079 rad |
| two_box_pick_8chunk | right | −44% / −41% | −29% / −49% | 0.008 / 0.039 / 0.073 rad |

- **Where the jerk is.** Most of it is at chunk boundaries. Consecutive chunks jump by
  up to 0.3 rad per joint, far more than a 0.01 rad box can absorb. Inside a chunk,
  both variants cut jerk by 70–79%. A larger `eps` trades more smoothing for more
  deviation: on two_box_pick, 0.02 gives about −55% at 0.05 rad deviation.
- **The pick_box_2 left arm** only jitters from diffusion noise. A removes that
  completely while staying within 0.003 rad. B moves the near-singular arm 0.04 rad to
  do the same, so use A (or `--groove-arms right` for B) on one-arm tasks.
- **A is the better default for these checkpoints.** B adds a few points of TCP
  smoothing on the right arm, but it smooths joints less, drifts about twice as far,
  and 15–50% of its chunks fall back to A anyway.
- **Deviation is pessimistic.** The deviation column is open-loop: the replay has no
  camera feedback, so each chunk's deviation carries into the next. On the robot the
  policy sees where the arm actually is.

## What the tests showed (synthetic data only)

These results come from a **synthetic** 7-DoF arm (`tests/fixtures/`, *not* OpenArm
geometry), a fake diffusion-like policy, and the real bridge code on an isolated ROS
domain. They show the machinery works. They are **not** OpenArm results; re-measure
on your recordings and robot.

- **A** cut delivered joint jerk by 47% with `--replan-at 0` and by 97% with
  `--replan-at 4`. TCP jerk fell by about the same amount. A never needs IK, so it
  cannot fail near a singularity.
- **B** beats A on TCP jerk when the policy's noise is Cartesian-like: −81% vs −68% on
  one arm, −50% vs −46% on the other. When the noise is joint-like, B roughly ties A.
  Your policy predicts **joints**, so expect A to be the stronger default, and treat B
  as something to confirm with `offline_eval.py` once the URDF is in.
- Near singular poses B falls back to A. On the synthetic arm that includes the
  dataset's home pose, where `left_joint_4 ≈ 0` means a straight elbow.
  `inspect_urdf.py --check-pose` shows whether the real OpenArm has the same problem.
- Relative (RELATIVE) arm actions carry any joint offset forward into the next chunk.
  With a large rotation box, B's IK let the posture drift 0.1–0.5 rad from the
  demonstrations. The defaults (0.01 rad rotation box, `max_joint_dev` 0.05) bound that.

## Layout

```
groove_common/     solver (exact batched active-set QP), jerk metrics, gripper guard,
                   ROS2 bridge subclass, launcher
a_joint_groove/    option A: joint_groove.py, run_bridge.py, run_system_b_joint_groove.sh
b_cartesian_groove/ option B: cartesian_groove.py (14 boxes, IK), urdf_kinematics.py (numpy FK/IK),
                   inspect_urdf.py, arm_config.example.json, run_bridge.py, run_system_b_cartesian_groove.sh
tools/             offline_eval.py (dataset A/B), analyze_log.py (robot-log A/B)
tests/             test_core.py (unit), test_bridge_integration.py (real bridge, fake robot), run_all.sh
```

## Tests

```bash
bash external/groove/tests/run_all.sh
```

The script runs the unit tests, the launcher test and the bridge integration test.
The integration test forces `ROS_DOMAIN_ID=199` with `ROS_LOCALHOST_ONLY=1` and uses
a private command topic, so it cannot move a robot.

## Limits and things to know

- The QP runs on the bridge's 30 Hz timer thread, as `_build_plan` does. The command
  published at each chunk landing is delayed by the solve time: ~3 ms for A, ~13 ms
  (p90 ~17 ms) for B. The bridge warns once if a solve exceeds half a tick. To shrink
  B, use `--groove-boxes reference`, or regulate one arm with `--groove-arms right`.
- `eps` is the only knob that trades smoothness against tracking the policy. The
  defaults are starting points, not tuned OpenArm values: A uses 0.01 rad; B uses
  5 mm and 0.01 rad. The bridge's rate limit and joint limits still bound every
  command.
- Offline evaluation is open-loop. It re-anchors each chunk to the executed state, as
  the relative actions do on the robot, but it has no visual feedback, so its
  `mae_vs_gt` includes drift for every method.
