#!/usr/bin/env bash
# Browser UI for examples/Daksha/conversion_code.py: pick datasets, check, convert.
#
#   bash external/run_conversion_ui.sh
#   HOST=127.0.0.1 bash external/run_conversion_ui.sh    # this machine only
#   TOKEN=mysecret bash external/run_conversion_ui.sh    # then open http://<lan-ip>:8140/?token=mysecret
#   DATASET_ROOTS=/home/s1/Desktop/datasets bash external/run_conversion_ui.sh
#
# It listens on 0.0.0.0:8140 (all interfaces); others on the LAN open http://<this-ip>:8140.
# Anyone who reaches that address can rewrite dataset metadata, so set TOKEN on a shared network.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="${REPO_ROOT:-$(cd "$SCRIPT_DIR/.." && pwd)}"
cd "$REPO_ROOT"
source .venv/bin/activate

# torch's CUDA libs ship under the venv's nvidia/*/lib (libcudss.so.0 etc.); put them on
# LD_LIBRARY_PATH so "import torch" works during stats generation.
NVLIB="$(echo "$REPO_ROOT"/.venv/lib/python*/site-packages/nvidia/*/lib | tr ' ' ':')"
export LD_LIBRARY_PATH="${NVLIB}${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"

HOST="${HOST:-0.0.0.0}"
PORT="${PORT:-8140}"
TOKEN="${TOKEN:-}"
# Colon-separated folders that hold the Daksha LeRobot datasets.
DATASET_ROOTS="${DATASET_ROOTS:-/home/s1/Desktop/datasets}"

ROOT_ARGS=()
IFS=':' read -r -a _roots <<< "$DATASET_ROOTS"
for r in "${_roots[@]}"; do
  [ -n "$r" ] && ROOT_ARGS+=(--dataset-root "$r")
done

exec python "$SCRIPT_DIR/conversion_ui.py" \
  --host "$HOST" --port "$PORT" ${TOKEN:+--token "$TOKEN"} "${ROOT_ARGS[@]}"
