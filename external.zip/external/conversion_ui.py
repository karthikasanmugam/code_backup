#!/usr/bin/env python3
"""OpenArm B1 Conversion UI: pick LeRobot datasets and run conversion_code.py on them.

A local browser page in front of examples/openarm_b1/conversion_code.py. Like the
training studio it has no third-party web dependency, and it never edits a dataset
itself:

  - Check   runs the script's own validation (tasks, episodes, cameras, joint layout)
            in a child process and writes nothing.
  - Convert runs conversion_code.py unchanged, one dataset at a time, with a live log.

    bash external/run_conversion_ui.sh
    TOKEN=<secret> bash external/run_conversion_ui.sh   # then open /?token=<secret>

`python external/conversion_ui.py check --dataset-root ...` is the Check step the page
runs; it takes the same --modality-template/--modality-config/--world-camera flags as
conversion_code.py.
"""
from __future__ import annotations

import argparse
import ast
import codecs
import hmac
import importlib.util
import json
import os
import re
import shlex
import signal
import subprocess
import sys
import threading
import time
import urllib.parse
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

UI_FILE = Path(__file__).resolve()


def find_repo_root(start: Path) -> Path:
    """Walk up to the repo that owns examples/openarm_b1/conversion_code.py. An exported REPO_ROOT wins."""
    if os.environ.get("REPO_ROOT"):
        return Path(os.environ["REPO_ROOT"]).expanduser().resolve()
    for p in start.parents:
        if (p / "examples/openarm_b1/conversion_code.py").is_file():
            return p
    raise SystemExit(f"Cannot find examples/openarm_b1/conversion_code.py above {start}; set REPO_ROOT")


REPO_ROOT = find_repo_root(UI_FILE)
CONVERSION_SCRIPT = REPO_ROOT / "examples/openarm_b1/conversion_code.py"
EXAMPLE_DIR = CONVERSION_SCRIPT.parent
DEFAULT_DATASET_ROOTS = [Path("/home/physicalai/Desktop/I/barani")]
# The conversion needs pandas and gr00t, so children use the repo's venv even when this
# page was started with another interpreter.
VENV_PYTHON = REPO_ROOT / ".venv/bin/python"
PYTHON = str(VENV_PYTHON) if VENV_PYTHON.is_file() else sys.executable
# Folders inside a dataset, never datasets themselves; skipping them keeps the scan fast.
SKIP_DIRS = {"data", "videos", "meta", "wandb", "__pycache__"}
# Joint vectors conversion_code.py names in info.json (left_joint_1, ... like barani/pick_box_2).
JOINT_FEATURES = ("action", "observation.state", "observation.leader_state")
OWN_TEMPLATE = "own"
OWN_LABEL = "meta/modality.json (this dataset)"


# --------------------------------------------------------------------------- reading


def read_json(path: Path) -> Any:
    return json.loads(path.read_text())


def rel(path: str | Path) -> str:
    p = Path(path)
    try:
        return str(p.relative_to(REPO_ROOT))
    except ValueError:
        return str(p)


def script_constants() -> dict[str, Any]:
    """Defaults read from conversion_code.py itself, so the page follows edits to it."""
    found: dict[str, Any] = {
        "DEFAULT_MODALITY_TEMPLATE": "modality_pick_box.json",
        "DEFAULT_MODALITY_CONFIG": "pick_box_config.py",
        "WORLD_CAMERA_CANDIDATES": ("world", "zed_left"),
        "DEFAULT_CHUNKS_SIZE": 1024,
    }
    try:
        tree = ast.parse(CONVERSION_SCRIPT.read_text())
    except (OSError, SyntaxError):
        return found
    for node in tree.body:
        if not (isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)):
            continue
        name = node.targets[0].id
        if name not in found:
            continue
        value = node.value.right if isinstance(node.value, ast.BinOp) else node.value  # EXAMPLE_DIR / "x.json"
        try:
            found[name] = ast.literal_eval(value)
        except ValueError:
            pass
    return found


def template_info(path: Path, name: str) -> dict[str, Any]:
    modality = read_json(path)
    return {
        "name": name,
        "path": str(path),
        # Same fallback as LeRobotEpisodeLoader when original_key is left out.
        "video": {k: v.get("original_key", f"observation.images.{k}") for k, v in modality.get("video", {}).items()},
        "state": {k: [v["start"], v["end"]] for k, v in modality.get("state", {}).items()},
        "action": {k: [v["start"], v["end"]] for k, v in modality.get("action", {}).items()},
    }


def _horizon(node: ast.AST | None) -> int | None:
    """Length of delta_indices written as [..] or list(range(a, b))."""
    if isinstance(node, (ast.List, ast.Tuple)):
        return len(node.elts)
    if (isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "list" and node.args
            and isinstance(node.args[0], ast.Call) and isinstance(node.args[0].func, ast.Name)
            and node.args[0].func.id == "range"):
        try:
            return len(range(*[ast.literal_eval(a) for a in node.args[0].args]))
        except (ValueError, TypeError):
            return None
    return None


def config_info(path: Path) -> dict[str, Any] | None:
    """Keys and action chunk of a *_config.py, parsed without importing gr00t."""
    try:
        tree = ast.parse(path.read_text())
    except (OSError, SyntaxError):
        return None
    for node in ast.walk(tree):
        if not isinstance(node, ast.Dict):
            continue
        groups: dict[str, dict[str, Any]] = {}
        for key, value in zip(node.keys, node.values):
            if isinstance(key, ast.Constant) and isinstance(value, ast.Call):
                kw = {k.arg: k.value for k in value.keywords}
                try:
                    keys = list(ast.literal_eval(kw["modality_keys"])) if "modality_keys" in kw else []
                except ValueError:
                    keys = []
                groups[key.value] = {"keys": keys, "horizon": _horizon(kw.get("delta_indices"))}
        if {"video", "state", "action"} <= groups.keys():
            return {
                "name": path.name,
                "path": str(path),
                "video": groups["video"]["keys"],
                "state": groups["state"]["keys"],
                "action": groups["action"]["keys"],
                "horizon": groups["action"]["horizon"],
            }
    return None


def example_templates(consts: dict[str, Any]) -> list[dict[str, Any]]:
    default = consts["DEFAULT_MODALITY_TEMPLATE"]
    templates = []
    for p in sorted(EXAMPLE_DIR.glob("modality*.json"), key=lambda p: (p.name != default, p.name)):
        try:
            templates.append(template_info(p, p.name))
        except (OSError, ValueError, KeyError, TypeError):
            pass
    return templates


def example_configs(consts: dict[str, Any]) -> list[dict[str, Any]]:
    default = consts["DEFAULT_MODALITY_CONFIG"]
    paths = sorted(EXAMPLE_DIR.glob("*_config.py"), key=lambda p: (p.name != default, p.name))
    return [c for c in (config_info(p) for p in paths) if c]


# ------------------------------------------------------------------ dataset checks


def name_side(name: object) -> str | None:
    return next((side for side in ("left", "right") if str(name).startswith(side)), None)


def world_source(template: dict[str, Any], features: dict, candidates) -> str | None:
    """The camera conversion_code.build_modality maps to "world" when --world-camera is not given."""
    if "world" not in template["video"]:
        return None
    for name in candidates:
        if f"observation.images.{name}" in features:
            return name
    return template["video"]["world"].removeprefix("observation.images.")


def pair_problem(template: dict, config: dict, features: dict, current: dict | None, candidates) -> str | None:
    """Why conversion_code.py would refuse this template + config for the dataset, or None.

    Mirrors the script's checks so the page can suggest a pair; Check runs the real ones.
    """
    for key, original in template["video"].items():
        if key == "world":
            original = f"observation.images.{world_source(template, features, candidates)}"
        if original not in features:
            return f"{template['name']}: dataset has no {original.removeprefix('observation.images.')} camera"
    for group in ("video", "state", "action"):
        missing = [k for k in config[group] if k not in template[group]]
        if missing:
            return f"{config['name']} needs {group} keys {', '.join(missing)} that {template['name']} lacks"
    for key, group in (("action", "action"), ("observation.state", "state")):
        sides = {i: g.split("_")[0] for g, (start, end) in template[group].items() for i in range(start, end)}
        for i, name in enumerate(features.get(key, {}).get("names") or []):
            side = name_side(name)
            if side and sides.get(i) in ("left", "right") and side != sides[i]:
                return (f"info.json names {key}[{i}] {name}, but {template['name']} puts the "
                        f"{sides[i]} arm there (different arm order)")
    if current:
        for group in ("state", "action"):
            for key, new in template[group].items():
                old = current[group].get(key)
                if old is not None and old != new:
                    return (f"{template['name']} puts {group}.{key} at {new[0]}:{new[1]}, but "
                            f"meta/modality.json has {old[0]}:{old[1]} (different arm order)")
    return None


def find_datasets(root: Path, depth: int = 3) -> list[Path]:
    found: list[Path] = []
    if not root.is_dir():
        return found
    for current, dirs, _ in os.walk(root):
        p = Path(current)
        if (p / "meta/info.json").is_file():
            found.append(p)
            dirs[:] = []
        elif len(p.relative_to(root).parts) >= depth:
            dirs[:] = []
        else:
            dirs[:] = [d for d in dirs if not d.startswith(".") and d not in SKIP_DIRS]
    return sorted(found)


def blank_summary(path: Path, root: Path) -> dict[str, Any]:
    return {
        "path": str(path), "name": str(path.relative_to(root)) if path != root else path.name,
        "episodes": 0, "frames": None, "fps": None, "cameras": [], "layout": "unknown", "world_view": None,
        "issues": [], "blockers": [], "pairs": [], "suggested": None, "status": "blocked",
    }


def dataset_summary(path: Path, root: Path, templates: list[dict], configs: list[dict], consts: dict) -> dict[str, Any]:
    """What the table shows for one dataset. Cheap: reads meta/ and lists data/, never parquet contents."""
    meta = path / "meta"
    summary = blank_summary(path, root)
    issues, blockers = summary["issues"], summary["blockers"]
    info = read_json(meta / "info.json")
    features = info.get("features", {})
    parquet = sorted(path.glob("data/chunk-*/episode_*.parquet"))
    summary.update(
        episodes=len(parquet), frames=info.get("total_frames"), fps=info.get("fps"),
        cameras=[k.removeprefix("observation.images.") for k, v in features.items() if v.get("dtype") == "video"],
    )

    current = None
    if (meta / "modality.json").is_file():
        try:
            current = template_info(meta / "modality.json", OWN_LABEL)
        except (ValueError, KeyError, TypeError):
            issues.append("meta/modality.json cannot be read")
    else:
        issues.append("meta/modality.json missing")
    if current:
        if "left_arm" in current["state"] and "right_arm" in current["state"]:
            left_first = current["state"]["left_arm"][0] < current["state"]["right_arm"][0]
            summary["layout"] = "left arm first" if left_first else "right arm first"
        if "world" in current["video"]:
            summary["world_view"] = current["video"]["world"].removeprefix("observation.images.")

    candidates = consts["WORLD_CAMERA_CANDIDATES"]
    for template, template_id in [(t, t["name"]) for t in templates] + ([(current, OWN_TEMPLATE)] if current else []):
        for config in configs:
            summary["pairs"].append({
                "template": template_id, "template_label": template["name"], "config": config["name"],
                "has_world": "world" in template["video"],
                "world_from": world_source(template, features, candidates),
                "problem": pair_problem(template, config, features, current, candidates),
            })
    suggested = next((p for p in summary["pairs"] if not p["problem"]), None)
    summary["suggested"] = suggested
    config = next((c for c in configs if suggested and c["name"] == suggested["config"]), None)

    if not parquet:
        blockers.append("no data/chunk-*/episode_*.parquet files")
    if not (meta / "tasks.parquet").is_file() and not (meta / "task.json").is_file():
        blockers.append("no meta/tasks.parquet or meta/task.json to build tasks.jsonl from")
    if not suggested:
        reasons = list(dict.fromkeys(p["problem"] for p in summary["pairs"]))[:2]
        blockers.append("no template + config in examples/openarm_b1 fits: " + "; ".join(reasons))

    # Removing an episode file changes its chunk folder's mtime, so this also catches deletions.
    data_mtime = max((p.stat().st_mtime for p in [*parquet, *path.glob("data/chunk-*")]), default=0.0)
    episodes_path = meta / "episodes.jsonl"
    if not episodes_path.is_file():
        issues.append("episodes.jsonl missing")
    else:
        with open(episodes_path) as f:
            listed = sum(1 for line in f if line.strip())
        if listed != len(parquet):
            issues.append(f"episodes.jsonl lists {listed} episodes, data/ has {len(parquet)}")
    if not (meta / "tasks.jsonl").is_file():
        issues.append("tasks.jsonl missing")
    if info.get("total_episodes") != len(parquet):
        issues.append(f"info.json says {info.get('total_episodes')} episodes, data/ has {len(parquet)}")
    generic = [k for k in JOINT_FEATURES
               if k in features and not all(name_side(n) for n in features[k].get("names") or [None])]
    if generic:
        issues.append(f"info.json joint names are not left_/right_ names in {', '.join(generic)}")

    stats_path = meta / "stats.json"
    if not stats_path.is_file():
        issues.append("stats.json missing")
    elif stats_path.stat().st_mtime < data_mtime:
        issues.append("stats.json is older than data/ (episodes changed since)")
    rel_path = meta / "relative_stats.json"
    if not rel_path.is_file():
        issues.append("relative_stats.json missing")
    else:
        try:
            steps = sorted({len(v["mean"]) for v in read_json(rel_path).values()})
        except (ValueError, KeyError, TypeError, AttributeError):
            steps = None
            issues.append("relative_stats.json cannot be read")
        horizon = config["horizon"] if config else None
        if steps is not None and horizon and steps != [horizon]:
            issues.append(f"relative_stats.json is {'/'.join(map(str, steps))}-step, {config['name']} uses {horizon}")
        elif steps is not None and rel_path.stat().st_mtime < data_mtime:
            issues.append("relative_stats.json is older than data/ (episodes changed since)")

    if current:
        gone = [o.removeprefix("observation.images.") for o in current["video"].values() if o not in features]
        if gone:
            issues.append(f"meta/modality.json points at missing camera(s): {', '.join(gone)}")
        if config:
            missing = [k for k in config["video"] if k not in current["video"]]
            if missing:
                issues.append(f"meta/modality.json lacks camera key(s) {', '.join(missing)} that {config['name']} needs")

    summary["status"] = "blocked" if blockers else "needs" if issues else "ok"
    return summary


# ---------------------------------------------------------------------- planning


def parse_settings(body: dict, templates: list[str], configs: list[str]) -> dict[str, Any]:
    template = str(body.get("template") or "auto")
    if template not in ("auto", OWN_TEMPLATE, *templates):
        raise ValueError(f"Unknown template {template}")
    config = str(body.get("config") or "auto")
    if config not in ("auto", *configs):
        raise ValueError(f"Unknown config {config}")
    world = str(body.get("world_camera") or "").strip()
    if world and not re.fullmatch(r"[A-Za-z0-9_.-]+", world):
        raise ValueError("Camera names may only contain letters, digits, _ . and -")
    raw_chunks = body.get("chunks_size")
    chunks = int(raw_chunks) if raw_chunks not in (None, "") else None
    if chunks is not None and not 1 <= chunks <= 1_000_000:
        raise ValueError("chunks_size must be between 1 and 1000000")
    return {"template": template, "config": config, "world_camera": world,
            "chunks_size": chunks, "skip_stats": bool(body.get("skip_stats"))}


def resolve_plan(ds: dict[str, Any], settings: dict[str, Any]) -> dict[str, Any]:
    """Which template + config one dataset gets. Auto takes the first pair the script accepts."""
    plan: dict[str, Any] = {"path": ds["path"], "name": ds["name"], "error": None, "warning": None}
    template_id = settings["template"]
    if template_id == "auto":
        if not ds["suggested"]:
            plan["error"] = "; ".join(ds["blockers"]) or "no template fits this dataset"
            return plan
        template_id = ds["suggested"]["template"]
    options = [p for p in ds["pairs"] if p["template"] == template_id]
    if not options:
        plan["error"] = "this dataset has no meta/modality.json" if template_id == OWN_TEMPLATE else f"unknown template {template_id}"
        return plan
    if settings["config"] == "auto":
        pick = next((p for p in options if not p["problem"]), None)
        if pick is None:
            plan["error"] = f"no config fits {options[0]['template_label']}: {options[0]['problem']}"
            return plan
    else:
        pick = next((p for p in options if p["config"] == settings["config"]), None)
        if pick is None:
            plan["error"] = f"unknown config {settings['config']}"
            return plan

    warnings = [pick["problem"]] if pick["problem"] else []
    world_from = pick["world_from"]
    if settings["world_camera"]:
        if not pick["has_world"]:
            warnings.append(f"{pick['template_label']} has no world camera, so --world-camera is refused")
        elif settings["world_camera"] not in ds["cameras"]:
            warnings.append(f"dataset has no {settings['world_camera']} camera")
        world_from = settings["world_camera"] if pick["has_world"] else None
    plan.update(
        template=pick["template_label"], config=pick["config"], world_from=world_from,
        world_camera=settings["world_camera"],
        template_path=str(Path(ds["path"]) / "meta/modality.json") if template_id == OWN_TEMPLATE else str(EXAMPLE_DIR / template_id),
        config_path=str(EXAMPLE_DIR / pick["config"]),
        warning="; ".join(warnings) or None,
    )
    return plan


def commands_for(plan: dict[str, Any], settings: dict[str, Any], kind: str) -> tuple[list[str], list[str]]:
    """(command to run, the same command as typed from the repo root with the venv active)."""
    tail = ["--dataset-root", plan["path"], "--modality-template", plan["template_path"],
            "--modality-config", plan["config_path"]]
    shown = ["--dataset-root", plan["path"], "--modality-template", rel(plan["template_path"]),
             "--modality-config", rel(plan["config_path"])]
    extra = ["--world-camera", plan["world_camera"]] if plan["world_camera"] else []
    if kind == "check":
        return [PYTHON, str(UI_FILE), "check", *tail, *extra], ["python", rel(UI_FILE), "check", *shown, *extra]
    if settings["chunks_size"]:
        extra += ["--chunks-size", str(settings["chunks_size"])]
    if settings["skip_stats"]:
        extra.append("--skip-stats")
    return [PYTHON, str(CONVERSION_SCRIPT), *tail, *extra], ["python", rel(CONVERSION_SCRIPT), *shown, *extra]


# -------------------------------------------------------------------------- runs


class Job:
    """Runs one command per dataset, in order, keeping each one's log."""

    def __init__(self, kind: str, items: list[dict[str, Any]]):
        self.kind, self.items = kind, items
        self.lock = threading.Lock()
        self.proc: subprocess.Popen | None = None
        self.stop_requested = False
        self.started, self.finished = time.time(), None
        threading.Thread(target=self._run, daemon=True).start()

    def running(self) -> bool:
        return self.finished is None

    def _log(self, item: dict[str, Any], line: str) -> None:
        with self.lock:
            item["logs"].append(line)

    def _run(self) -> None:
        for item in self.items:
            if self.stop_requested:
                item["status"] = "skipped"
                self._log(item, "– Skipped: the run was stopped.")
                continue
            if item["error"]:
                item["status"] = "skipped"
                self._log(item, f"✖ Can't convert: {item['error']}")
                continue
            item["status"] = "running"
            self._log(item, "$ " + item["display"])
            try:
                self.proc = subprocess.Popen(
                    item["command"], cwd=REPO_ROOT, env={**os.environ, "PYTHONUNBUFFERED": "1"},
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True,
                )
            except OSError as e:
                item["status"] = "failed"
                self._log(item, f"✖ Could not start: {e}")
                continue
            self._pump(item, self.proc)
            rc = self.proc.wait()
            item["returncode"] = rc
            item["status"] = "ok" if rc == 0 else "stopped" if self.stop_requested else "failed"
            self._log(item, "" if rc == 0 else f"✖ Exit code {rc}")
        self.finished = time.time()

    def _pump(self, item: dict[str, Any], proc: subprocess.Popen) -> None:
        # tqdm redraws its bar with \r; keep only the latest redraw instead of one line each.
        decoder = codecs.getincrementaldecoder("utf-8")(errors="replace")
        fd = proc.stdout.fileno()
        line, carriage_return = "", False
        while chunk := os.read(fd, 4096):
            for piece in re.split(r"(\r\n|\r|\n)", decoder.decode(chunk)):
                if piece in ("\n", "\r\n"):
                    self._log(item, line)
                    line, carriage_return = "", False
                elif piece == "\r":
                    carriage_return = True
                elif piece:
                    if carriage_return:
                        line, carriage_return = "", False
                    line += piece
            item["partial"] = line
        if line:
            self._log(item, line)
        item["partial"] = ""

    def stop(self) -> bool:
        if not self.running():
            return False
        again = self.stop_requested
        self.stop_requested = True
        proc = self.proc
        if proc and proc.poll() is None:
            # First press: SIGINT, like Ctrl+C. Second press: SIGTERM.
            os.killpg(proc.pid, signal.SIGTERM if again else signal.SIGINT)
        return True

    def public(self, index: int | None) -> dict[str, Any]:
        with self.lock:
            if index is None or not 0 <= index < len(self.items):
                # The running dataset, else the last one that actually ran.
                index = next((i for i, it in enumerate(self.items) if it["status"] == "running"), None)
                if index is None:
                    index = max((i for i, it in enumerate(self.items) if it["status"] in ("ok", "failed", "stopped")),
                                default=0)
            shown = self.items[index]
            return {
                "kind": self.kind, "running": self.running(), "stopping": self.stop_requested,
                "started": self.started, "finished": self.finished, "shown": index,
                "items": [{k: it[k] for k in ("name", "path", "status", "returncode", "warning")} for it in self.items],
                "logs": list(shown["logs"]), "partial": shown["partial"],
            }


class App:
    def __init__(self, args: argparse.Namespace):
        self.args = args
        self.lock = threading.Lock()
        self.job: Job | None = None
        self.catalog: dict[str, Any] = {}

    def scan(self) -> dict[str, Any]:
        consts = script_constants()
        templates, configs = example_templates(consts), example_configs(consts)
        datasets = []
        for root in self.args.dataset_roots:
            for path in find_datasets(root):
                try:
                    datasets.append(dataset_summary(path, root, templates, configs, consts))
                except Exception as e:  # one broken dataset must not hide the others
                    broken = blank_summary(path, root)
                    broken["blockers"].append(f"cannot read meta/: {type(e).__name__}: {e}")
                    datasets.append(broken)
        self.catalog = {
            "roots": [str(r) for r in self.args.dataset_roots],
            "script": rel(CONVERSION_SCRIPT),
            "datasets": datasets,
            "templates": [t["name"] for t in templates],
            "configs": [{"name": c["name"], "video": c["video"], "horizon": c["horizon"]} for c in configs],
            "defaults": {
                "template": consts["DEFAULT_MODALITY_TEMPLATE"], "config": consts["DEFAULT_MODALITY_CONFIG"],
                "world_candidates": list(consts["WORLD_CAMERA_CANDIDATES"]), "chunks_size": consts["DEFAULT_CHUNKS_SIZE"],
            },
        }
        return self.catalog

    def plans(self, body: dict) -> tuple[dict[str, Any], list[dict[str, Any]]]:
        catalog = self.catalog or self.scan()
        settings = parse_settings(body, catalog["templates"], [c["name"] for c in catalog["configs"]])
        by_path = {d["path"]: d for d in catalog["datasets"]}
        plans = []
        for path in body.get("datasets") or []:
            ds = by_path.get(path)
            if ds is None:
                raise ValueError(f"{path} is not a dataset under {', '.join(catalog['roots'])}; press Rescan")
            plan = resolve_plan(ds, settings)
            if not plan["error"]:
                plan["command"] = shlex.join(commands_for(plan, settings, "convert")[1])
            plans.append(plan)
        return settings, plans

    def run(self, body: dict) -> Job:
        kind = body.get("kind")
        if kind not in ("check", "convert"):
            raise ValueError("kind must be check or convert")
        with self.lock:
            if self.job and self.job.running():
                raise RuntimeError("A run is already in progress. Wait for it or press Stop.")
            self.scan()  # plan against what is on disk now, not the page's last scan
            settings, plans = self.plans(body)
            if not plans:
                raise ValueError("Select at least one dataset")
            items = []
            for plan in plans:
                command, shown = commands_for(plan, settings, kind) if not plan["error"] else (None, [])
                items.append({
                    "name": plan["name"], "path": plan["path"], "error": plan["error"], "warning": plan["warning"],
                    "command": command, "display": shlex.join(shown), "status": "queued", "returncode": None,
                    "logs": deque(maxlen=3000), "partial": "",
                })
            self.job = Job(kind, items)
            return self.job


# ------------------------------------------------------------------- check mode


def run_check(argv: list[str]) -> int:
    """Validate one dataset with conversion_code.py's own functions, writing nothing."""
    p = argparse.ArgumentParser(prog="conversion_ui.py check",
                                description="Validate a dataset the way conversion_code.py does, without writing anything.")
    p.add_argument("--dataset-root", required=True)
    p.add_argument("--modality-template", required=True)
    p.add_argument("--modality-config", required=True)
    p.add_argument("--world-camera")
    a = p.parse_args(argv)
    try:
        spec = importlib.util.spec_from_file_location("conversion_code", CONVERSION_SCRIPT)
        cc = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(cc)

        root = cc.resolve_dataset_root(a.dataset_root)
        meta = root / "meta"
        template = Path(a.modality_template).expanduser().resolve()
        config_path = Path(a.modality_config).expanduser().resolve()
        print(f"Dataset: {root}")
        modality_config = cc.load_modality_config(config_path)
        print(f"✔ Config {config_path.name}: cameras {', '.join(modality_config['video'].modality_keys)}, "
              f"action chunk {len(modality_config['action'].delta_indices)} steps")
        tasks = cc.read_tasks(meta)
        print(f"✔ {len(tasks)} task(s): " + " | ".join(str(t["task"]) for t in tasks))
        episodes = cc.build_episodes(root)
        print(f"✔ {len(episodes)} episodes, {sum(int(e['length']) for e in episodes)} frames")
        features = read_json(meta / "info.json")["features"]
        modality = cc.build_modality(template, features, a.world_camera)
        cc.check_modality(modality, template, meta, features, modality_config)
        cameras = ", ".join(f"{k} ← {v['original_key'].removeprefix('observation.images.')}"
                            for k, v in modality["video"].items())
        current = meta / "modality.json"
        layout = ("joint layout matches meta/modality.json" if current.is_file()
                  else "no meta/modality.json yet, so the template's joint layout is used as is")
        print(f"✔ Template {template.name}: {cameras}; {layout}")
        if current.is_file() and read_json(current) == modality:
            print("  Convert keeps meta/modality.json as it is.")
        else:
            print("  Convert rewrites meta/modality.json from the template.")
        for key, (names, how) in cc.plan_joint_names(root, modality, features).items():
            if names is None:
                print(f"  info.json {key}: {how}")
            elif features[key].get("names") == names:
                print(f"  info.json {key} names: already {names[0]}, ... {names[-1]}")
            else:
                print(f"  info.json {key} names → {names[0]}, {names[1]}, ... {names[-1]} ({how})")
        print("  Convert regenerates stats.json and relative_stats.json (old files kept as *.bak.json)"
              " unless 'Skip stats' is ticked.")
    except Exception as e:
        print(f"✖ {type(e).__name__}: {e}")
        return 1
    print("Ready to convert.")
    return 0


# -------------------------------------------------------------------------- page


HTML = r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>OpenArm B1 · Dataset Conversion</title><style>
:root{color-scheme:dark;--bg:#09111d;--panel:#101c2e;--line:#263b58;--txt:#eef4ff;--muted:#93a8c7;--blue:#66a9ff;--good:#66e3ad;--warn:#ffca6b;--red:#ff8491;--code:#0b1727}
*{box-sizing:border-box}
html{background:var(--bg)}
body{margin:0;min-height:100vh;background:radial-gradient(circle at 85% -10%,#1c416c,transparent 38%) no-repeat,var(--bg);color:var(--txt);font:14px/1.45 system-ui,sans-serif}
.wrap{max-width:1360px;margin:auto;padding:28px 16px 80px}
h1{font-size:26px;margin:0}h2{font-size:16px;margin:0}
.sub{color:var(--muted);margin:8px 0 22px;max-width:960px}
code{font:12px ui-monospace,SFMono-Regular,Menlo,monospace;color:#cfe0ff}
.card{background:rgba(16,28,46,.92);border:1px solid var(--line);border-radius:14px;padding:18px;margin-bottom:16px}
.head{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:10px}.grow{flex:1}
.hint,.muted{color:var(--muted);font-size:12px}.hint{margin:0 0 12px}
.notice{background:#2a1520;border:1px solid #73404b;color:var(--red);border-radius:8px;padding:10px 12px;margin-bottom:16px}
.table-wrap,.log{scrollbar-color:#304968 #0b1727}
.table-wrap{overflow-x:auto;border:1px solid var(--line);border-radius:10px}
table{width:100%;border-collapse:collapse;min-width:860px}
th,td{padding:9px 10px;text-align:left;vertical-align:top;border-bottom:1px solid #1b2c44}
th{font-size:12px;color:var(--muted);font-weight:600;background:#0c1829}
tbody tr[data-path]{cursor:pointer}tbody tr[data-path]:hover{background:#13243b}tbody tr.sel{background:#16304f}
td.num{text-align:right;font-variant-numeric:tabular-nums}
.badge{display:inline-block;padding:2px 8px;border-radius:99px;font-size:11px;font-weight:700;border:1px solid;white-space:nowrap}
.badge.ok{color:var(--good);border-color:#2d6b55}.badge.warn{color:var(--warn);border-color:#6b5a2d}.badge.bad{color:var(--red);border-color:#73404b}
ul.notes{margin:6px 0 0;padding-left:16px;color:var(--muted);font-size:12px}
.row{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}
label{display:block;font-size:12px;color:var(--muted);margin:0 0 5px}
input,select{width:100%;background:#091525;border:1px solid #304968;color:var(--txt);border-radius:7px;padding:9px;font:inherit}
input:focus,select:focus{outline:2px solid var(--blue);border-color:transparent}
input[type=checkbox]{width:auto;accent-color:var(--blue);margin:0}
label.check{display:flex;gap:8px;align-items:center;margin:12px 0 0;font-size:13px}
button{background:var(--blue);color:#071323;border:0;border-radius:7px;padding:10px 14px;font:inherit;font-weight:700;cursor:pointer}
button.secondary{background:#20334d;color:var(--txt)}button.stop{background:var(--red)}
button:disabled{opacity:.45;cursor:not-allowed}
.actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:14px}
h3{font-size:13px;margin:16px 0 6px;color:var(--muted);font-weight:600}
.plan{display:grid;gap:8px}
.plan-item{background:var(--code);border-left:3px solid var(--good);border-radius:7px;padding:9px 12px;font-size:12px;overflow-wrap:anywhere}
.plan-item.warn{border-left-color:var(--warn)}.plan-item.bad{border-left-color:var(--red)}
.plan-item code{display:block;margin-top:6px;white-space:pre-wrap;color:var(--muted)}
.warn-text{color:var(--warn);margin-top:4px}
.items{display:flex;flex-wrap:wrap;gap:6px;margin:10px 0}
.item{background:#20334d;color:var(--txt);padding:6px 11px;border-radius:99px;font-size:12px;font-weight:600}
.item.shown{outline:2px solid var(--blue)}
.st-ok{color:var(--good)}.st-failed{color:var(--red)}.st-running{color:var(--blue)}.st-stopped,.st-skipped{color:var(--warn)}
.log{margin:0;background:var(--code);border-radius:8px;padding:12px;min-height:160px;max-height:460px;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere;font:12px/1.55 ui-monospace,SFMono-Regular,Menlo,monospace;color:#c9d7ee}
@media(max-width:900px){.row{grid-template-columns:1fr 1fr}}
@media(max-width:560px){.row{grid-template-columns:1fr}}
</style></head><body><main class="wrap">
<h1>OpenArm B1 · Dataset Conversion</h1>
<p class="sub">Select LeRobot datasets in <code id="roots">…</code> and run <code id="script">examples/openarm_b1/conversion_code.py</code> on them. <b>Check</b> validates and writes nothing. <b>Convert</b> rewrites <code>meta/info.json</code> (totals, and joint names like <code>pick_box_2</code>: <code>left_joint_1</code> … <code>right_gripper_right_joint</code>), <code>modality.json</code>, <code>tasks.jsonl</code> and <code>episodes.jsonl</code>, and regenerates <code>stats.json</code> and <code>relative_stats.json</code> (the old ones are kept as <code>*.bak.json</code>).</p>
<div id="notice" class="notice" hidden></div>

<section class="card">
  <div class="head"><h2>1. Datasets</h2><span class="grow"></span><span id="summary" class="muted"></span>
    <button class="secondary" id="pickNeeds">Select all that need conversion</button><button class="secondary" id="rescan">Rescan</button></div>
  <p class="hint">Click rows to select. <b>Up to date</b>: metadata and stats match <code>data/</code>. <b>Needs conversion</b>: something in <code>meta/</code> is missing, out of date, or older than <code>data/</code>. <b>Can't convert</b>: no template + config pair in <code>examples/openarm_b1</code> fits, or files are missing.</p>
  <div class="table-wrap"><table><thead><tr><th><input type="checkbox" id="all" aria-label="Select all"></th><th>Dataset</th><th style="text-align:right">Episodes</th><th style="text-align:right">FPS</th><th>Cameras</th><th>Arm layout</th><th>Status</th></tr></thead><tbody id="rows"><tr><td colspan="7" class="muted">Scanning…</td></tr></tbody></table></div>
</section>

<section class="card">
  <h2>2. Settings</h2>
  <p class="hint" style="margin-top:8px">Auto picks, per dataset, the first template + config pair the script accepts, trying the 3-camera (world, wrist_right, wrist_left) pair first. Datasets without a world camera use the ZED left image as the world view unless you choose another camera.</p>
  <div class="row">
    <div><label for="template">Modality template</label><select id="template"></select></div>
    <div><label for="config">Modality config</label><select id="config"></select></div>
    <div><label for="world">World camera</label><select id="world"></select></div>
    <div><label for="chunks">chunks_size (used only if info.json lacks it)</label><input id="chunks" type="number" min="1"></div>
  </div>
  <label class="check"><input type="checkbox" id="skipStats"> Skip stats generation (training needs stats; leave this off unless you only want the metadata files)</label>
  <h3>Plan</h3>
  <div id="plan" class="plan"><div class="muted">Select one or more datasets in the table.</div></div>
  <div class="actions"><button class="secondary" id="checkBtn" disabled>Check selected (no changes)</button><button id="convertBtn" disabled>Convert selected</button><button class="stop" id="stopBtn" disabled>Stop</button></div>
</section>

<section class="card">
  <h2>3. Run</h2>
  <div id="jobHead" class="muted" style="margin-top:8px">Nothing has run yet.</div>
  <div id="items" class="items"></div>
  <pre id="log" class="log"></pre>
</section>
</main><script>
const TOKEN = new URLSearchParams(location.search).get('token') || '';
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
const BADGE = {ok: ['ok', 'Up to date'], needs: ['warn', 'Needs conversion'], blocked: ['bad', "Can't convert"]};
const ICON = {queued: '○', running: '●', ok: '✔', failed: '✖', stopped: '■', skipped: '–'};
let catalog = {datasets: [], templates: [], configs: [], roots: [], defaults: {}};
const selected = new Set();
let plans = [], job = null, shownItem = null, pollTimer = null, planTimer = null;

async function api(path, body) {
  const r = await fetch(path, {method: body ? 'POST' : 'GET', headers: {'Content-Type': 'application/json', 'X-Auth-Token': TOKEN},
                               body: body ? JSON.stringify(body) : undefined});
  const d = await r.json().catch(() => ({error: `HTTP ${r.status}`}));
  if (!r.ok) throw new Error(d.error || `HTTP ${r.status}`);
  return d;
}
function notice(msg) { $('notice').hidden = !msg; $('notice').textContent = msg || ''; }
function fillSelect(el, options) {
  const keep = el.value;
  el.innerHTML = options.map(([v, t]) => `<option value="${esc(v)}">${esc(t)}</option>`).join('');
  if (options.some(([v]) => v === keep)) el.value = keep;
}
const chosen = () => catalog.datasets.filter(d => selected.has(d.path)).map(d => d.path);
const settings = () => ({template: $('template').value, config: $('config').value, world_camera: $('world').value,
                         chunks_size: $('chunks').value, skip_stats: $('skipStats').checked});

async function scan() {
  try { catalog = await api('/api/datasets'); } catch (e) { return notice(e.message); }
  notice('');
  $('roots').textContent = catalog.roots.join(' · ');
  $('script').textContent = catalog.script;
  fillSelect($('template'), [['auto', `Auto: best fit per dataset (tries ${catalog.defaults.template} first)`],
                             ...catalog.templates.map(t => [t, t]), ['own', "This dataset's own meta/modality.json"]]);
  fillSelect($('config'), [['auto', 'Auto: first config that fits the template'],
                           ...catalog.configs.map(c => [c.name, `${c.name} · ${c.video.join(', ')} · chunk ${c.horizon ?? '?'}`])]);
  $('chunks').placeholder = `${catalog.defaults.chunks_size} (script default)`;
  for (const p of [...selected]) if (!catalog.datasets.some(d => d.path === p)) selected.delete(p);
  renderTable();
  schedulePlan();
}

function renderTable() {
  const ds = catalog.datasets, count = s => ds.filter(d => d.status === s).length;
  $('summary').textContent = `${ds.length} datasets · ${count('ok')} up to date · ${count('needs')} need conversion` +
                             (count('blocked') ? ` · ${count('blocked')} can't convert` : '');
  $('rows').innerHTML = ds.length ? ds.map(d => {
    const [cls, text] = BADGE[d.status], notes = [...d.blockers, ...d.issues], on = selected.has(d.path);
    return `<tr data-path="${esc(d.path)}" class="${on ? 'sel' : ''}">
      <td><input type="checkbox" ${on ? 'checked' : ''} aria-label="Select ${esc(d.name)}"></td>
      <td><b>${esc(d.name)}</b><div class="muted">${esc(d.path)}</div></td>
      <td class="num">${d.episodes}<div class="muted">${d.frames ?? '?'} frames</div></td>
      <td class="num">${d.fps ?? '?'}</td>
      <td>${esc(d.cameras.join(', '))}${d.world_view ? `<div class="muted">modality.json: world ← ${esc(d.world_view)}</div>` : ''}</td>
      <td>${esc(d.layout)}</td>
      <td><span class="badge ${cls}">${text}</span>${notes.length ? `<ul class="notes">${notes.map(n => `<li>${esc(n)}</li>`).join('')}</ul>` : ''}</td>
    </tr>`;
  }).join('') : `<tr><td colspan="7" class="muted">No datasets found: no folder under ${esc(catalog.roots.join(', '))} has meta/info.json.</td></tr>`;
  $('all').checked = ds.length > 0 && ds.every(d => selected.has(d.path));
  const pool = selected.size ? ds.filter(d => selected.has(d.path)) : ds;
  const cams = [...new Set(pool.flatMap(d => d.cameras))].sort();
  fillSelect($('world'), [['', `Auto: ${(catalog.defaults.world_candidates || []).join(', else ')}`], ...cams.map(c => [c, c])]);
}

function schedulePlan() { clearTimeout(planTimer); planTimer = setTimeout(loadPlan, 150); }
async function loadPlan() {
  if (!selected.size) {
    plans = [];
    $('plan').innerHTML = '<div class="muted">Select one or more datasets in the table.</div>';
    return updateButtons();
  }
  try { plans = (await api('/api/plan', {datasets: chosen(), ...settings()})).plans; }
  catch (e) { plans = []; $('plan').innerHTML = `<div class="plan-item bad">${esc(e.message)}</div>`; return updateButtons(); }
  $('plan').innerHTML = plans.map(p => p.error
    ? `<div class="plan-item bad"><b>${esc(p.name)}</b> · can't convert: ${esc(p.error)}</div>`
    : `<div class="plan-item ${p.warning ? 'warn' : ''}"><b>${esc(p.name)}</b> · ${esc(p.template)} + ${esc(p.config)}` +
      (p.world_from ? ` · world ← ${esc(p.world_from)}` : '') +
      (p.warning ? `<div class="warn-text">⚠ ${esc(p.warning)}. The script will refuse this; Check shows its message.</div>` : '') +
      `<code>${esc(p.command)}</code></div>`).join('');
  updateButtons();
}

function updateButtons() {
  const running = !!(job && job.running), runnable = plans.some(p => !p.error);
  $('checkBtn').disabled = running || !runnable;
  $('convertBtn').disabled = running || !runnable;
  $('stopBtn').disabled = !running;
}

async function run(kind) {
  const ok = plans.filter(p => !p.error), skipped = plans.length - ok.length;
  if (kind === 'convert' && !confirm(`Convert ${ok.length} dataset(s)?\n\n${ok.map(p => '• ' + p.name).join('\n')}\n\n` +
      'This rewrites meta/info.json, modality.json, tasks.jsonl and episodes.jsonl' +
      ($('skipStats').checked ? '.' : ', and regenerates stats.json and relative_stats.json (the old ones are kept as *.bak.json).') +
      (skipped ? `\n\n${skipped} selected dataset(s) can't be converted and will be skipped.` : ''))) return;
  try {
    job = (await api('/api/run', {kind, datasets: chosen(), ...settings()})).job;
    shownItem = null;
    renderJob();
    startPolling();
  } catch (e) { alert(e.message); }
}

async function stopJob() {
  if (!confirm('Stop the run?\n\nThe dataset being processed is interrupted; stopping it during stats generation leaves it without ' +
               'stats.json until you convert it again. Datasets not started yet are skipped. Press Stop twice to force it.')) return;
  try { await api('/api/stop', {}); pollJob(); } catch (e) { alert(e.message); }
}

function startPolling() { if (!pollTimer) pollTimer = setInterval(pollJob, 1500); }
async function pollJob() {
  const wasRunning = !!(job && job.running);
  try { job = (await api('/api/job' + (shownItem !== null ? `?item=${shownItem}` : ''))).job; }
  catch (e) { return notice(e.message); }
  renderJob();
  if (job && job.running) startPolling();
  else { clearInterval(pollTimer); pollTimer = null; if (wasRunning) scan(); }
}

function renderJob() {
  updateButtons();
  if (!job) return;
  const done = job.items.filter(i => i.status === 'ok').length, n = job.items.length;
  const verb = job.kind === 'check' ? 'Check' : 'Conversion';
  $('jobHead').textContent = job.running
    ? `${verb} running… ${done} of ${n} finished` + (job.stopping ? ' (stopping)' : '')
    : `${verb} finished: ${done} of ${n} ${job.kind === 'check' ? 'ready to convert' : 'converted'}. Click a dataset to see its log.`;
  $('items').innerHTML = job.items.map((it, i) =>
    `<button class="item st-${it.status} ${i === job.shown ? 'shown' : ''}" data-i="${i}">${ICON[it.status] || ''} ${esc(it.name)}</button>`).join('');
  const log = $('log'), atEnd = log.scrollHeight - log.scrollTop - log.clientHeight < 40;
  const text = [...job.logs, ...(job.partial ? [job.partial] : [])].join('\n');
  if (log.textContent !== text) { log.textContent = text; if (atEnd) log.scrollTop = log.scrollHeight; }
}

$('rows').addEventListener('click', e => {
  const tr = e.target.closest('tr[data-path]');
  if (!tr) return;
  selected.has(tr.dataset.path) ? selected.delete(tr.dataset.path) : selected.add(tr.dataset.path);
  renderTable();
  schedulePlan();
});
$('all').addEventListener('change', e => {
  catalog.datasets.forEach(d => e.target.checked ? selected.add(d.path) : selected.delete(d.path));
  renderTable();
  schedulePlan();
});
$('pickNeeds').addEventListener('click', () => {
  selected.clear();
  catalog.datasets.filter(d => d.status === 'needs').forEach(d => selected.add(d.path));
  renderTable();
  schedulePlan();
});
$('items').addEventListener('click', e => {
  const b = e.target.closest('[data-i]');
  if (b) { shownItem = +b.dataset.i; pollJob(); }
});
$('rescan').addEventListener('click', scan);
$('checkBtn').addEventListener('click', () => run('check'));
$('convertBtn').addEventListener('click', () => run('convert'));
$('stopBtn').addEventListener('click', stopJob);
for (const id of ['template', 'config', 'world', 'chunks', 'skipStats']) $(id).addEventListener('change', schedulePlan);
scan();
pollJob();
</script></body></html>'''


# ------------------------------------------------------------------------ server


def make_handler(app: App):
    class Handler(BaseHTTPRequestHandler):
        def reply(self, code: int, payload: Any, kind: str = "application/json") -> None:
            raw = json.dumps(payload).encode() if kind == "application/json" else payload
            self.send_response(code)
            self.send_header("Content-Type", kind + "; charset=utf-8")
            self.send_header("Content-Length", str(len(raw)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(raw)

        def authorized(self) -> bool:
            if not app.args.token:
                return True
            url = urllib.parse.urlparse(self.path)
            given = (urllib.parse.parse_qs(url.query).get("token") or [""])[0] or self.headers.get("X-Auth-Token", "")
            if hmac.compare_digest(given.encode(), app.args.token.encode()):
                return True
            if url.path == "/":
                self.reply(401, b"Bad or missing token: open this page as /?token=<secret>", "text/plain")
            else:
                self.reply(401, {"error": "bad or missing token: open the page with ?token=<secret>"})
            return False

        def do_GET(self) -> None:
            if not self.authorized():
                return
            url = urllib.parse.urlparse(self.path)
            try:
                if url.path == "/":
                    self.reply(200, HTML.encode(), "text/html")
                elif url.path == "/api/datasets":
                    self.reply(200, app.scan())
                elif url.path == "/api/job":
                    item = (urllib.parse.parse_qs(url.query).get("item") or [""])[0]
                    self.reply(200, {"job": app.job.public(int(item) if item.isdigit() else None) if app.job else None})
                else:
                    self.reply(404, {"error": "not found"})
            except Exception as e:
                self.reply(500, {"error": f"{type(e).__name__}: {e}"})

        def do_POST(self) -> None:
            if not self.authorized():
                return
            try:
                body = json.loads(self.rfile.read(int(self.headers.get("Content-Length", "0"))) or b"{}")
                route = urllib.parse.urlparse(self.path).path
                if route == "/api/plan":
                    result = {"plans": app.plans(body)[1]}
                elif route == "/api/run":
                    result = {"job": app.run(body).public(0)}
                elif route == "/api/stop":
                    result = {"stopped": app.job.stop() if app.job else False}
                else:
                    raise KeyError("not found")
                self.reply(200, result)
            except (ValueError, RuntimeError, KeyError) as e:
                self.reply(400, {"error": str(e).strip("'")})
            except Exception as e:
                self.reply(500, {"error": f"{type(e).__name__}: {e}"})

        def log_message(self, *_) -> None:
            pass

    return Handler


def main() -> None:
    if len(sys.argv) > 1 and sys.argv[1] == "check":
        raise SystemExit(run_check(sys.argv[2:]))
    p = argparse.ArgumentParser(description="OpenArm B1 dataset conversion UI")
    p.add_argument("--host", default=os.environ.get("HOST", "127.0.0.1"),
                   help="Address to listen on, e.g. 192.168.200.114 for the LAN, 127.0.0.1 for this machine only.")
    p.add_argument("--port", type=int, default=int(os.environ.get("PORT", "8140")))
    p.add_argument("--token", default=os.environ.get("TOKEN", ""),
                   help="Require ?token=<secret> on every request. Advised on a LAN address.")
    p.add_argument("--dataset-root", action="append", default=None,
                   help=f"Folder that holds LeRobot datasets (repeatable). Default: {DEFAULT_DATASET_ROOTS[0]}")
    a = p.parse_args()
    a.dataset_roots = [Path(x).expanduser().resolve() for x in (a.dataset_root or DEFAULT_DATASET_ROOTS)]
    try:
        httpd = ThreadingHTTPServer((a.host, a.port), make_handler(App(a)))
    except OSError as e:
        raise SystemExit(f"Cannot listen on {a.host}:{a.port} ({e}). Is {a.host} an address of this machine "
                         "(ip -4 addr), and is the port free?")
    suffix = f"/?token={urllib.parse.quote(a.token)}" if a.token else "/"
    print(f"OpenArm B1 conversion UI: http://{a.host}:{a.port}{suffix}", flush=True)
    print(f"  datasets: {', '.join(map(str, a.dataset_roots))}", flush=True)
    if a.host not in ("127.0.0.1", "localhost", "::1") and not a.token:
        print("  ! Anyone who can reach this address can rewrite dataset metadata. Set TOKEN=<secret> on a shared network.",
              flush=True)
    httpd.serve_forever()


if __name__ == "__main__":
    main()
