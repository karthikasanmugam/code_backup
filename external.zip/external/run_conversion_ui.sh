#!/usr/bin/env bash
# Browser UI for examples/openarm_b1/conversion_code.py: pick datasets, check, convert.
#
#   bash external/run_conversion_ui.sh
#   HOST=127.0.0.1 bash external/run_conversion_ui.sh    # this machine only
#   TOKEN=mysecret bash external/run_conversion_ui.sh    # then open http://192.168.200.114:8140/?token=mysecret
#   DATASET_ROOTS=/home/physicalai/Desktop/I/barani:/home/physicalai/Desktop/I/dinesh bash external/run_conversion_ui.sh
#
# It listens on 192.168.200.114 (enp194s0), so other machines on 192.168.200.0/24 can
# open http://192.168.200.114:8140. Anyone who reaches that address can rewrite dataset
# metadata, so set TOKEN on a shared network.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="${REPO_ROOT:-$(cd "$SCRIPT_DIR/.." && pwd)}"
cd "$REPO_ROOT"
source .venv/bin/activate

HOST="${HOST:-192.168.200.114}"
PORT="${PORT:-8140}"
TOKEN="${TOKEN:-}"
# Colon-separated folders that hold the OpenArm B1 LeRobot datasets.
DATASET_ROOTS="${DATASET_ROOTS:-/home/physicalai/Desktop/I/barani}"

ROOT_ARGS=()
IFS=':' read -r -a _roots <<< "$DATASET_ROOTS"
for r in "${_roots[@]}"; do
  [ -n "$r" ] && ROOT_ARGS+=(--dataset-root "$r")
done

exec python "$SCRIPT_DIR/conversion_ui.py" \
  --host "$HOST" --port "$PORT" ${TOKEN:+--token "$TOKEN"} "${ROOT_ARGS[@]}"
